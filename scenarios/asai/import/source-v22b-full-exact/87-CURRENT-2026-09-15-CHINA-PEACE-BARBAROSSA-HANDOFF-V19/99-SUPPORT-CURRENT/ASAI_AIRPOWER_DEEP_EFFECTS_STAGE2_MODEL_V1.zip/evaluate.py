#!/usr/bin/env python3
"""Scenario audit, not a historical reconstruction or attack-planning model.

Uses declared aggregate allocation and economic-capacity assumptions.  There is
no empirical mapping from aircraft sorties to economic losses: the two layers
are deliberately separate. All outputs are conditional and carry status tags.
Run: python evaluate.py [--output DIRECTORY]
"""
from __future__ import annotations
import argparse
import calendar
import hashlib
import json
from pathlib import Path

SCENARIOS = {
    "lower": {"net_incoming_twin": 10, "net_incoming_single": 4,
              "vehicle_unavailable": .01, "cycle_extension": .04, "load_factor_loss": .01,
              "air_availability_pp_loss": .03, "air_cycle_extension": .07, "air_execution_ratio": .95},
    "central": {"net_incoming_twin": 14, "net_incoming_single": 8,
                "vehicle_unavailable": .02, "cycle_extension": .08, "load_factor_loss": .025,
                "air_availability_pp_loss": .05, "air_cycle_extension": .10, "air_execution_ratio": .95},
    "upper": {"net_incoming_twin": 18, "net_incoming_single": 12,
              "vehicle_unavailable": .035, "cycle_extension": .14, "load_factor_loss": .04,
              "air_availability_pp_loss": .08, "air_cycle_extension": .16, "air_execution_ratio": .96},
}
SOURCE_FACTS = {
    "clock": "1940-09-30 24:00; NOT ADVANCED",
    "july_end_central_china_assigned_anchor": {"twin":18, "single":12},
    "twin_accepted_plan_aug_sep":28,
    "twin_accepted_plan_through_sep":99,
    "single_accepted_plan_through_sep_band":[56,76],
    "single_accepted_plan_through_sep_midpoint":66,
    "twin_national_planning_extant_jul_sep":[68,94],
    "north_detachment_twin":6,
    "indochina_detachment_twin":2,
    "note":"Source plans and conversation adjudications; not newly found actual production records."
}

def capacity(n:float, a:float, days:float, per_ready_day:float)->float:
    if min(n, a, days, per_ready_day)<0 or a>1:
        raise ValueError('Invalid capacity assumption')
    return n*a*days*per_ready_day

def flow_capacity(h:float, p:dict)->float:
    return (1-p['vehicle_unavailable']*h)*(1-p['load_factor_loss']*h)/(1+p['cycle_extension']*h)

def exposure_curve()->list[float]:
    # New, illustrative extra pressure versus the matched baseline, not weather observations.
    points = [(31,0.,.35),(31,.35,.70),(30,.70,1.)]
    return [start+(end-start)*(i+1)/days for days,start,end in points for i in range(days)]

def simulate_economy(p:dict, q4:bool=False, buffer_days:float=2., demand_util:float=.95,
                     input_dependency:float=.60, transit_lag:int=7, q4_path:str='hold')->dict:
    if not(0<demand_util<=1 and 0<=input_dependency<=1) or buffer_days<0 or transit_lag<0:
        raise ValueError('Invalid economic assumption')
    h = exposure_curve()
    # Forward stress case holds the September exposure constant; no new bombing events assumed.
    if q4:
        if q4_path=='hold':
            h += [1.]*92
        elif q4_path=='recover_30days':
            h += [max(0.,1-(i+1)/30) for i in range(92)]
        else:
            raise ValueError('Unknown future pressure path')
    backlog=0.; stock=buffer_days
    daily=[]; delivered=[]
    for day,x in enumerate(h):
        c=flow_capacity(x,p)
        shipment=min(c, demand_util+backlog)
        backlog += demand_util-shipment
        assert backlog>=-1e-9
        rel=shipment/demand_util
        delivered.append(rel)
        arrival=delivered[day-transit_lag] if day>=transit_lag else 1.
        # Same input, normalized per day of baseline output; other supply is unchanged.
        supply=(1-input_dependency)+input_dependency*arrival
        output=min(1.,stock+supply)
        stock=stock+supply-output
        assert stock>=-1e-9 and 0<=output<=1+1e-9
        daily.append({'day':day+1,'exposure':x,'capacity_ratio':c,'shipment_ratio':rel,
                      'backlog_in_baseline_delivery_days':backlog/demand_util,
                      'selected_input_supply_ratio':supply,'stock_days':stock,'output_ratio':output})
    groups={'Jul':daily[:31],'Aug':daily[31:62],'Sep':daily[62:92]}
    if q4: groups['Q4_hold_pressure']=daily[92:]
    summaries={key:{'capacity_ratio_mean':sum(r['capacity_ratio'] for r in rows)/len(rows),
                    'shipment_ratio_mean':sum(r['shipment_ratio'] for r in rows)/len(rows),
                    'selected_output_ratio_mean':sum(r['output_ratio'] for r in rows)/len(rows),
                    'ending_stock_days':rows[-1]['stock_days'],
                    'ending_backlog_days':rows[-1]['backlog_in_baseline_delivery_days']}
               for key,rows in groups.items()}
    return {'assumptions':{'baseline_utilization':demand_util,'initial_buffer_days':buffer_days,
                          'input_dependency_share':input_dependency,'transit_lag_days':transit_lag,'Q4_pressure_path':q4_path},
            'monthly':summaries,'q3_average_shipment_ratio':sum(delivered[:92])/92,
            'q3_average_selected_output_ratio':sum(r['output_ratio'] for r in daily[:92])/92,
            'first_output_shortfall_day':next((r['day'] for r in daily if r['output_ratio']<1-1e-8),None),
            'daily':daily}

def main()->None:
    ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,default=Path(__file__).parent)
    args=ap.parse_args();args.output.mkdir(parents=True,exist_ok=True)
    results={'status':'CONDITIONAL_MODEL_V1; NOT OOB/LOSS/ECONOMIC ACTUALS',
             'layer_independence':'Aircraft-allocation scenarios and economic-shock scenarios are independently specified. Matching names do NOT represent an estimated dose-response or imply causation. No sortie-to-damage conversion is made.', 'sources':SOURCE_FACTS,
             'assumptions_common':{'twin_readiness':.81,'single_readiness':.80,'flyable_days_per_30':18,
                  'twin_sorties_per_ready_flyable_day':.65,'single_sorties_per_ready_flyable_day':.75,
                  'stockflow_note':'Net incoming includes replacement/return minus unrecorded writeoffs/other outward flows, excluding the explicitly tracked 8 detachments. No actual loss events are invented.',
                  'pressure_note':'Economic shock assumptions are independent conditional inputs, not inferred from sortie count.'},
             'scenarios':{}}
    for name,p in SCENARIOS.items():
        nT=18+p['net_incoming_twin']-8; nS=12+p['net_incoming_single']
        assert p['net_incoming_twin']<=26 # 28 accepted less 2 planning writeoffs nationally
        ST=capacity(nT,.81,18,.65); SS=capacity(nS,.80,18,.75)
        c=flow_capacity(1.,p)
        air=(.72-p['air_availability_pp_loss'])/.72/(1+p['air_cycle_extension'])*p['air_execution_ratio']
        econ=simulate_economy(p,q4=True)
        results['scenarios'][name]={'input_assumptions':p,
            'sept_end_assigned_scenario':{'twin':nT,'single':nS},
            'standardized_30day_sortie_budget':{'twin':ST,'single':SS,'total':ST+SS},
            'economic_end_state':{'affected_transport_capacity_ratio':c,
                'delivery_ratio_if_baseline_utilization_95pct':min(1.,c/.95),
                'relative_resource_requirement_for_same_capacity':1/c,
                'chinese_air_sortie_generation_ratio_at_equal_surviving_airframes':air,
                'survivor_increase_needed_to_offset_generation_loss':1/air-1,
                'same_item_replenishment_margin_ratio_if_routine_need_85pct':(min(1.,c/.95)-.85)/.15},
            'economy':econ}
    baseline=capacity(18,.81,18,.65)+capacity(12,.80,18,.75)
    omit=capacity(10,.81,18,.65)+capacity(12,.80,18,.75)
    # Illustrative central trajectory interpolates end-month stocks, without inventing dated arrivals.
    traj={'Jul':(18,12),'Aug':(18,14),'Sep':(21,18)}
    results['central_month_average_capacity']={m:{'mean_twin':t,'mean_single':s,
        'standardized_30day_twin':capacity(t,.81,18,.65),
        'standardized_30day_single':capacity(s,.80,18,.75),
        'standardized_30day_total':capacity(t,.81,18,.65)+capacity(s,.80,18,.75)} for m,(t,s) in traj.items()}
    results['comparisons']={'july_standardized_budget':baseline,'omitting_all_aug_sep_replacement_budget':omit,
        'central_endpoint_over_july':results['scenarios']['central']['standardized_30day_sortie_budget']['total']/baseline,
        'central_endpoint_over_omission':results['scenarios']['central']['standardized_30day_sortie_budget']['total']/omit}
    # All roles share the same finite Twin sortie budget; no new airframes or total sorties.
    total=results['scenarios']['central']['standardized_30day_sortie_budget']['twin']
    results['multirole_illustration']={'exclusive_primary_categories':{
        'information_only':total*.45,'information_with_secondary_task':total*.20,
        'limited_attack_primary':total*.15,'cover_escort':total*.10,'liaison_transport':total*.10},
        'sum_primary_sorties':total,
        'secondary_tasks_performed_if_half_of_dual_mission_sorties_find_conditions':total*.20*.50,
        'conventional_reallocation_equiv_with_30_to_50pct_overlap_and_60_to_80pct_realization':[
            total*.65*.30*.60,total*.65*.50*.80],
        'old_e5_ki42_activity':'retained baseline; not counted as zero and not added again without ledger'}
    results['sensitivities']={
      'allocation_and_activity_combined_outer_bounds':[
        capacity(20,.78,16,.55)+capacity(16,.75,16,.65),
        capacity(28,.84,20,.75)+capacity(24,.83,20,.85)],
      'central_transport_delivery_by_baseline_utilization':{
        str(u):min(1.,flow_capacity(1.,SCENARIOS['central'])/u) for u in [.80,.85,.90,.95,.99]},
      'central_selected_output_by_initial_buffer':{},
      'central_weighted_network_delivery_loss_by_affected_share':{
        str(s):s*(1-min(1.,flow_capacity(1.,SCENARIOS['central'])/.95)) for s in [.20,.30,.50]}}
    for b in [0.,.5,2.,5.,10.]:
        e=simulate_economy(SCENARIOS['central'],q4=True,buffer_days=b)
        results['sensitivities']['central_selected_output_by_initial_buffer'][str(b)]={
           'Q3_loss':1-e['q3_average_selected_output_ratio'],
           'Q4_loss':1-e['monthly']['Q4_hold_pressure']['selected_output_ratio_mean'],
           'first_shortfall_day':e['first_output_shortfall_day'],
           'stock_end_Sep':e['monthly']['Sep']['ending_stock_days']}
    recovery=simulate_economy(SCENARIOS['central'],q4=True,q4_path='recover_30days')
    results['sensitivities']['central_Q4_30day_recovery_case']={
       'Q4_output_loss':1-recovery['monthly']['Q4_hold_pressure']['selected_output_ratio_mean'],
       'ending_stock_days':recovery['daily'][-1]['stock_days'],
       'ending_backlog_days':recovery['daily'][-1]['backlog_in_baseline_delivery_days']}
    # Allowing 0--2 national planned writeoffs, a 14-plane net allocation fits 28 receipts.
    results['central_theater_stockflow_monthly']=[
       {'month':'1940-08','twin_open':18,'twin_net_incoming':6,'north_detachment':6,'indochina_detachment':0,'twin_close':18,'single_open':12,'single_net_incoming':4,'single_close':16},
       {'month':'1940-09','twin_open':18,'twin_net_incoming':8,'north_detachment':0,'indochina_detachment':2,'twin_close':24,'single_open':16,'single_net_incoming':4,'single_close':20}]
    for row in results['central_theater_stockflow_monthly']:
        assert row['twin_open']+row['twin_net_incoming']-row['north_detachment']-row['indochina_detachment']==row['twin_close']
        assert row['single_open']+row['single_net_incoming']==row['single_close']
    # Core monotonicity and conservation checks.
    assert all(abs(sum(row['exclusive_primary_categories'].values())-row['sum_primary_sorties'])<1e-8
               for row in [results['multirole_illustration']])
    caps=[results['scenarios'][k]['economic_end_state']['affected_transport_capacity_ratio'] for k in ['lower','central','upper']]
    assert caps[0]>caps[1]>caps[2]
    for name,p in SCENARIOS.items():
        e=results['scenarios'][name]['economy']
        last=e['daily'][-1]
        cumulative_delivery=sum(r['shipment_ratio'] for r in e['daily'])
        assert abs(cumulative_delivery+last['backlog_in_baseline_delivery_days']-len(e['daily']))<1e-7
    results['validation']={'stockflow_capacity_checks':'PASS','primary_sortie_conservation':'PASS',
       'transport_mass_balance':'PASS','monotonicity':'PASS',
       'not_validated':['causal mapping sorties->damage','actual Chinese capacities/inventories','actual month-by-month receipts/assignments']}
    (args.output/'model_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    summary={k:{kk:vv for kk,vv in v.items() if kk!='economy'} for k,v in results['scenarios'].items()}
    print(json.dumps({'scenarios':summary,'central_trajectory':results['central_month_average_capacity'],
       'comparisons':results['comparisons'],'economy_summary':{
          k:{'monthly':v['economy']['monthly'],'q3_avg_ship':v['economy']['q3_average_shipment_ratio'],
             'q3_avg_output':v['economy']['q3_average_selected_output_ratio'],
             'first_shortfall_day':v['economy']['first_output_shortfall_day']} for k,v in results['scenarios'].items()},
        'multirole':results['multirole_illustration'],'sensitivity':results['sensitivities']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
