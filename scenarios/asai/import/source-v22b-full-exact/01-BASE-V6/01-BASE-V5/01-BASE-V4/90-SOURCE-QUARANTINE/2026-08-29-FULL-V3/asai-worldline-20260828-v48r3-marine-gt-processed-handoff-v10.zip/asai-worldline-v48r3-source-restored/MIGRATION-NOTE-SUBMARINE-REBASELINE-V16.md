# Migration note — submarine rebaseline v16

基底：v15 product chronology。

変更：
- 潜水艦専用H→A帳簿を新設。
- 1927–33海大／巡潜を初回再基底化。
- 2サイクル潜水艦主機へ4サイクル商船ターボの+30–40%を直接適用する旧記述をSUPERSEDED。
- 海大六型の中央を25–26 ktから23 kt級の信頼性・成熟へ戻す。
- 論点P0を航空戦史/OOBから潜水艦技術1934–37へ移動。
