# Crosswalk decision pass 1 — 2026-08-27

Status: working derivation on top of v48r3 source-restored. This file does not rebaseline the canonical package by itself.

## Immediate closures from the verified calendar

1. **Momi / 樅 historical availability is closed.** She was removed from the Navy List on 1932-04-01 and then existed as Disposal Destroyer No.2 / 廃駆二号 for trials through 1936. This overlaps the exact internal window in which E4 becomes a saleable product (1932–33), marine GT joint trials begin (1934), and E5 matures (1934–36). The old-hull *availability* question is therefore no longer OPEN. Whether this worldline actually installs GT machinery in her remains an adoption/design choice.

2. **Kaga is too early for mature large-E5/E6 propulsion adoption during her historical 1934–35 reconstruction.** The window is valuable for observation, arrangement studies, instrumentation, and possibly auxiliary experiments, but not as the central first co-main GT carrier.

3. **Akagi is chronologically borderline, not a clean adoption window.** Her 1935-10-24 to 1938-08-31 reconstruction overlaps E5 completion and the beginning of the E6 front, but the machinery architecture would need to be committed before large-E5 marine qualification is convincingly closed. A full GT co-main conversion is therefore disfavored as central; limited experimental insertion remains plausible.

4. **Soryu is too early for E6 and Hiryu is only a provisional E5-influence window.** Both should retain steam as the central baseline unless an explicit alternate design branch is created rather than inherited automatically.

5. **1939 program ships are the first clean paper-design intersection with E6, not the first clean adoption.** Yugumo- and Agano-class design/order windows can host E6-large studies. Their historical lead ships should not silently receive radical GT machinery because large-E6 products, salt/life qualification, and high-power reduction-gear production are not yet closed.

6. **Taiyo (Kasuga Maru) is a real 1941 conversion window but not yet a closed four-E6-large conversion.** The existing four-engine carrier calculation remains a useful engineering worksheet. It is not a chronology-supported adoption until E6-large product/life/gear dates are formalized.

7. **Unryu is the first high-value new-build carrier decision point.** The 1941 urgent construction decision occurs after the E6 family is technically credible, but the historical program strongly rewards rapid, standardized construction. An E6-large alternative therefore needs an explicit proof that its marine productization and production infrastructure are ready *before* the order/design freeze; otherwise historical steam stays central.

## Consequence for next processing step

The crosswalk removes the need to treat `1940 torpedo-boat success` as the universal marine-GT gate. The correct sequence is now:

- use Momi/廃駆二号 1932–36 as the natural old-hull sea-trial slot if the worldline chooses an old-hull program;
- keep large land-rig endurance/gear/salt work in 1935–37 as the bridge to larger cores;
- treat 1939–41 destroyer/cruiser/carrier designs as separate requirement-driven adoption decisions;
- resolve the E6 50–55 t torpedo-boat branch on its own operational requirement, not as a prerequisite for large-ship adoption.

## Source discrepancies preserved

- Soryu: some secondary databases show a May 1937 `completed` field, while stronger commissioning records put commissioning at **1937-12-29**. The crosswalk uses 1937-12-29 for fleet-entry chronology.
- Kasuga Maru/Taiyo: sources differ by several days on conversion completion in September 1941. The crosswalk uses **1941-09-05** as a practical service-entry anchor and keeps the exact completion day non-critical.
- Unryu: NHHC identifies her as constructed under **1941 estimates**; program listings place the urgent program decision on **1941-07-28** and activation on **1941-09-21**. These are compatible as a decision/order window, but the exact design-freeze date remains to be derived if machinery adoption is pursued.
