# Marine GT processed handoff — START HERE — 2026-08-27

## State

Base semantic authority remains **v48 / machine v48r3**. This directory is a **marine-GT processing overlay** produced from the previous open handoff. It does not rename E-generations or analysis scale classes into canonical in-world engine models.

For marine GT chronology/adoption questions, use the files in this directory according to the precedence below rather than reviving older carrier/Taiyo/torpedo-boat claims from `main/` or the v46 aviation archive.

## Read order

1. `CURRENT-CANONICAL-STATE.md` at package root.
2. `28-OPEN-CLOSED-MATRIX-PASS3.tsv` — current marine processing status.
3. `10-HISTORICAL-TECH-CROSSWALK-V1.tsv` and `11-CROSSWALK-DECISION-PASS1.md` — verified 1931–41 chronology intersection.
4. `13-MARINE-LARGE-SCALE-AUDIT-V1.tsv` and `14-MARINE-LARGE-SCALE-AUDIT-NOTES-V1.md` — output-plane and large-class arithmetic.
5. `16-LARGE-CORE-AVAILABILITY-GATES-V1.tsv` — derived earliest gates, not canonical product dates.
6. `18-TEST-PLATFORM-DECISION-V1.md`, `24-MOMI-MARINE-TEST-PROGRAM-V1.tsv`, `25-LARGE-MARINE-LAND-RIG-GATES-V1.tsv` — marine qualification architecture.
7. `27-E6-TORPEDO-PROTOTYPE-CLOSURE-V2.md` — 1941 No.600 prototype/design closure; post-boundary trials frozen.
8. `15-TAIYO-WORKING-RECALC-V2.csv`, `19-CARRIER-BOOST-COMPARISON-V1.csv`, `20-CARRIER-DECISION-PASS1.md` — carrier calculations and adoption decisions.
9. `21-FUEL-IMPORT-EVIDENCE-V1.tsv`, `22-FUEL-DEMAND-SENSITIVITY-V1.csv`, `23-FUEL-POLICY-PASS1.md` — fuel product-slate processing.
10. `29-MARINE-GT-PRECEDENCE-OVERLAY-V1.tsv` — conflicts with older source files.

## Processed central decisions

- **Momi / 廃駆二号 is the central 1934–36 old-hull marine integration platform.** It is a test platform, not an E4/E5 destroyer-performance claim.
- **No dedicated new-build propulsion test ship is central before 1941.** Shore powertrain rigs plus old-hull/qualification craft carry the program; a later purpose-built laboratory hull remains conditional.
- E5/E6 large-A/B/C remain **analysis scale classes**, not named products. Earliest derived ship-design windows are approximately E5-A 1937 conditional, E5-B 1938, E6-A 1940, E6-B 1941; E6-C is not cleanly prewar-qualified.
- The old E6 large `scale gain` assumption is retired. Use accepted specific-work accounting plus an explicit marine reduction efficiency/output plane.
- E5 ~700 C large-engine long-life numbers are sensitivity ceilings unless a low-TIT bleed/life schedule is closed.
- **1940 torpedo-boat success is not a universal gate.** The heavy-MTB requirement window is 1941. The prewar central state authorizes a **No.600 E6-M hybrid prototype/design program**; follow-on series and achieved performance await prototype acceptance and are FROZEN beyond 1941-12-08.
- **Kaga:** no mature GT co-main adoption in 1934–35 refit.
- **Akagi:** no full co-main GT central adoption in 1935–38; experimental/auxiliary insertion only.
- **Soryu/Hiryu:** steam propulsion central; GT main/co-main not adopted.
- **Taiyo/Kasuga Maru:** revised E6 boost calculation retained as engineering comparison, but no co-main GT adoption under the historical May–September 1941 short conversion window.
- **Unryu 1941 urgent design:** historical-type steam plant central; E6 co-main/boost not adopted in the urgent central design.
- Direct imports of kerosene/gas-oil/diesel products are historically verified. A broad clean **marine turbine distillate pool** is the working policy; exact national quantities remain open. Large turbo-diesels are pushed toward heavier grades subject to qualification.

## Intentional OPEN / CONDITIONAL items

These are not data-processing omissions; current evidence does not justify turning them into hard canon:

- exact hardware identities/names and production dates for E5/E6 large analysis classes;
- low-TIT E5 large hot-section bleed/life rating and E6 780 C life guarantee;
- exact high-power reducer/shaft installed mass and production rate;
- exact E6-large-B/C sea-trial hull;
- exhaust-heat recovery hardware/back-pressure/boiler arrangement;
- 25.5 kt carrier WOD threshold (aviation branch remains reset under v48);
- grade-by-grade national refinery balance and reserve stocks;
- No.600 post-1941 construction/trials and follow-on series release.

## Boundary discipline

Do not use post-1941-12-08 trial/combat outcomes to backfill the prewar state. In particular, the No.600 design may be ordered before the boundary while its achieved speed/reliability remains unknown.

Do not propagate old GT-Taiyo carrier counts or attack-carrier conversions into force structure. v48 archived the old aviation adoption layer, and this marine pass independently rejects the short-window Taiyo co-main installation as central.


## Validation and integrity

The processed overlay passed structured-data parsing, deterministic large-core audit regeneration, and checksum verification. See `32-PROCESS-VALIDATION-REPORT.txt` and `SHA256SUMS-HANDOFF-PASS5.txt`. For package-level acceptance, use `tools/validate_v48r3.py`; `tools/validate_machine_layer.py` is a legacy v46r1 validator and is incompatible with the v48 aviation archive layout.
