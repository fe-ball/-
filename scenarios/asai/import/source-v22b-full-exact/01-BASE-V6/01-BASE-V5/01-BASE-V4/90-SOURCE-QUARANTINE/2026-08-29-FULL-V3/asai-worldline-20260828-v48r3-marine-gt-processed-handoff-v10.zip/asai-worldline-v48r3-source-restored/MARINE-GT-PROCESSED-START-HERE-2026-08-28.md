# Marine GT processed handoff V5 — START HERE — 2026-08-28

Base authority is still **semantic v48 / machine v48r3**. V5 is a processing overlay, not a semantic rebaseline.

Read first:

1. `2026-08-27-marine-gt-handoff/72-PROCESSED-START-HERE-V5.md`
2. `2026-08-27-marine-gt-handoff/63-QUALIFICATION-TERMINOLOGY-V5.md`
3. `2026-08-27-marine-gt-handoff/64-E5-QUALIFICATION-CRAFT-MASS-BUILDUP-V5.tsv`
4. `2026-08-27-marine-gt-handoff/65-E5-QUALIFICATION-CRAFT-GEOMETRY-SPEED-V5.tsv`
5. `2026-08-27-marine-gt-handoff/66-UNIT-POWER-DEMAND-MAP-V5.tsv`
6. `2026-08-27-marine-gt-handoff/67-LARGE-CORE-PROGRAM-GATES-V5.tsv`
7. `2026-08-27-marine-gt-handoff/74-LARGE-CORE-ENABLING-INHERITANCE-V5.tsv`
8. `2026-08-27-marine-gt-handoff/75-TAIYO-MODULE-ARCHITECTURE-TRADE-V5.tsv` and `75A-...`
9. `2026-08-27-marine-gt-handoff/68-MARINE-DEMONSTRATION-LADDER-V5.tsv`
10. `2026-08-27-marine-gt-handoff/69-MARINE-GT-REWORK-QUEUE-V5.tsv`
11. `2026-08-27-marine-gt-handoff/71-MARINE-GT-PRECEDENCE-OVERLAY-V5.tsv`
12. `2026-08-27-marine-gt-handoff/73-PROCESS-STATE-V5.json`
13. `2026-08-27-marine-gt-handoff/76-PROCESS-VALIDATION-REPORT-V5.txt`

Immediate V5 changes: scalar `maturity` wording is retired in favor of named proof/qualification states; the E5 qualification craft no longer inherits 25–27 t as a target; its intake and center-shaft geometry are derived from the actual E5 worldline product; and >13.2 kg/s hot-core work is tied to named platform demand rather than a diameter multiplier or a later engine analogue. The Taiyo pre-planned boost branch currently makes a six-module / three-per-shaft, ~20.4 kg/s per-core case the leading architecture trade at an explicit 0.93 path-retention sensitivity, while ten canonical E6-M modules remain the low-new-core-development fallback. Neither is selected yet.
