# 2026-08-16 更新内容：機体比較・真珠湾・Wake

この更新は `SESSION-20260816-AIRWAR-PREP` に以下を追加した。

- `09-AIR-COMBAT-CLOSURE-1941.md`
- `10-PEARL-HARBOR-CANON-1941-12-07.md`
- `11-WAKE-CANON-1941-12-08-23.md`
- `12-NEXT-SOUTHERN-OPERATIONS.md`

また `00-README-CURRENT.md` の再開地点を更新した。

## 現在の歴史中央線

- Enterpriseの位置は史実固定。
- 真珠湾では能力相応の限定追加索敵を行うが、最尤でEnterprise未発見。
- 第三次対基地施設攻撃は行わない。
- 真珠湾の戦艦損害骨格は史実同様。第二波通信改善によって巡洋艦損害がやや増える。
- Wake第一次攻略失敗、Hayate/Kisaragi喪失、飛龍/蒼龍投入、12月23日陥落を維持。
- Wake救援TF14/Saratogaへ長距離索敵線は届き得るが、最尤では未発見。
- 次はDavao/Jolo→Manado/Tarakan→Balikpapan/Kendari。
