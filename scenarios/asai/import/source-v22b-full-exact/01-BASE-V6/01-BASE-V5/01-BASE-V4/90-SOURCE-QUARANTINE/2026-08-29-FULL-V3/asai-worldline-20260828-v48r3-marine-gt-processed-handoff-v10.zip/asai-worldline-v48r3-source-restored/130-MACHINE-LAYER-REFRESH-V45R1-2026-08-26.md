# 130 — Machine-layer refresh v45r1 — 2026-08-26

v45r1 refreshes the machine layer after the first E6-S aircraft H→A propagation.

- chronology: **657 records** (`CANONICAL-CHRONOLOGY-V45R1.tsv` / `.jsonl`)
- main canonical files: **200**
- status partition: **current 492 / conditional 71 / superseded 52 / scope 33 / mixed 9**
- new v45 chronology delta: CHR-0648..0657
- broad v44 E6-S aircraft H→A gate CHR-0644 is superseded by the v45 split closure/gates.
- B6N Tenzan standard is now **455–485 km/h clean / 1,200–1,500 km practical loaded range** at E6-S-T 1,300 hp.
- Ki-40 E6-S-N-T standard is now **625–650 km/h @8 km / 645–870 hp @8 km / 3,000–3,600 km practical internal range**.
- Tenzan ~1,400 hp and Ki-40 ~1,600 hp high-flow short points remain conditional.
- remaining E6-S fighter/twin-engine H→A and residual-jet ESHP re-audit remain conditional.
- E6-M aircraft/marine installation and jet/JF installed-thrust gates remain inherited and conditional.

Current recall layer:
`CURRENT-CANONICAL-STATE.md` → `CANONICAL-MAIN-INDEX-V45R1.tsv` → `CANONICAL-CHRONOLOGY-V45R1.tsv` → `CROSS-DOMAIN-PREFLIGHT-V45R1.md` → `CAPABILITY-TRIGGER-MATRIX-V45R1.tsv`.
