# 110 — Machine-layer refresh v40r1 — 2026-08-26

v40r1 refreshes the machine layer after the E4/E5 cooled installed-cycle rebaseline.

- chronology: **594 records** (`CANONICAL-CHRONOLOGY-V40R1.tsv` / `.jsonl`)
- main canonical files: **195**
- manifest entries: **550**
- status partition: **current 456 / conditional 60 / superseded 41 / scope 28 / mixed 9**
- new v40 chronology delta: CHR-0579..0594
- old v39 cooling-debit open gate CHR-0578: superseded
- mixed legacy rows retain unrelated current facts while marking old gross-derived product-output fragments provisional.
- E4/E5 product-specific 500 kW / ~1,000 hp configurations remain conditional until mass-flow/size/output/weight/envelope requalification closes.

Current recall layer:
`CURRENT-CANONICAL-STATE.md` → `CANONICAL-MAIN-INDEX-V40R1.tsv` → `CANONICAL-CHRONOLOGY-V40R1.tsv` → `CROSS-DOMAIN-PREFLIGHT-V40R1.md` → `CAPABILITY-TRIGGER-MATRIX-V40R1.tsv`.
