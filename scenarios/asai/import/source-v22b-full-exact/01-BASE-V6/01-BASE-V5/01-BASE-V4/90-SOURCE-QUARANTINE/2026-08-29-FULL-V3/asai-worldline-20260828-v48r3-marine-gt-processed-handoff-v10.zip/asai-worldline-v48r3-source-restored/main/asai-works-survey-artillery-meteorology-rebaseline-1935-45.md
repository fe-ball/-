# 測量・砲兵気象再基線化 1935–45 — 観測からballistic-met messageまでの工程標準化

> **v34 current canonical parent.** Survey, plotting, sound/flash location and military meteorology already exist historically. Asai changes calibration, reduction, forms, interpolation, message integrity and turnaround; it does not invent artillery meteorology or grant a blanket hit-rate bonus.

## 0. 中央裁定

1. 日本軍砲兵には測量・標定・音響・気象組織が既に存在する。浅井が「砲兵気象」を発明したことにしない。
2. pilot balloon / upper-air observationもH側に置く。浅井差は観測器較正、計算表、標準message、転記検査、時刻/位置タグへ置く。
3. 命中率を一律+X%にしない。誤差源をgun/ammunition dispersion、survey、target location、met age/space、reduction、table interpolation/transcription、communication、observer correctionへ分解する。
4. 1938–41にtechnical workflowを標準化できるが、1941-12-08以後の部隊配備、観測回数、射撃効果はHISTORY/FROZEN。

## 1. H — 既存能力

既存のsurvey/plotting/sound detection/met section、地上気象観測、pilot-balloon/upper-air observationをHとして保持する。浅井の計算機・統計・光学・計測器事業は、既存組織へ「再現可能な処理工程」を供給する。

## 2. Survey / artillery-met temporal ledger

| 時期 | 項目 | v34 current判定 |
|---|---|---|
| 1935–37 | survey/calibration foundation | baseline、角度、時刻、座標変換、instrument zero/scaleの標準帳票と較正記録を整備。既存測量能力のQ改善 |
| 1936–39 | sound/flash location calculation | sensor position、時刻同期、weather correction、plot residualを同じ座標系で管理。装置自体の発明ではなくreduction/QC改善 |
| 1938–41 | pilot-balloon wind reduction | 観測角・時刻から層別windを標準計算し、ballistic用途のwind/density messageへ落とす。観測の存在と処理品質を分離 |
| 1938–41 | ballistic-met message | pressure/temperature/humidity/wind、観測時刻、高度層、station位置を標準message化。欠測/古い観測を明示する |
| 1938–41 | firing-table integration | 標準射表/射撃盤へmet correctionを補間入力し、二重計算・転記照合・版管理で人為誤差を減らす |
| 1940–41 | turnaround/Q acceptance | observation→reduction→message→battery reception→table entryの所要時間と誤差を演習で測り、古いmetを自動的に新鮮扱いしない |
| 1941-12-08+ | unit allocation / fire effect | CONDITIONAL/HISTORY。実際の気象班配置、通信状態、射撃量、命中/制圧効果は再計算しない |

## 3. 誤差会計

射撃結果は単一係数で扱わない。

- gun / ammunition intrinsic dispersion。
- gun position・orienting line・survey networkの位置/方位誤差。
- target locationとobserver geometry。
- met observationのage、horizontal/vertical representativeness。
- pilot-balloon/radiosonde等の観測誤差とwind/density reduction。
- firing-table interpolation、scale reading、転記、版違い。
- message transmission、battery set-up、observer correction cycle。

浅井が直接強く削れるのは、較正・計算・補間・転記・message integrity・turnaroundに属する部分である。弾薬散布界やtarget acquisitionを自動で消さない。

## 4. A — 採用形

1938–41の中央は、survey control、met observation、ballistic reduction、standard message、firing-table entryを一つの監査可能なchainとして運用すること。各messageへstation/time/validityを付け、古い観測や欠測を明示する。

1941-12-08以後の実戦効果はhistory gateを維持する。
