# CROSS-DOMAIN PREFLIGHT — v29r1

Purpose: prevent semantic omission and accidental promotion of conditional branches. Before dated design/history analysis, scan `CANONICAL-CHRONOLOGY-V29R1.*` and `CAPABILITY-TRIGGER-MATRIX-V29R1.tsv`.

## Mandatory order

1. **Chronology/status** — ordinary current analysis uses `current`/`scope`; `conditional` requires an explicit gate; `superseded` is provenance only; `mixed` requires source inspection.
2. **Requirement owner / historical counterpart** — ask who actually generates the requirement. Do not convert Asai's technology supply into platform omniscience.
3. **Availability R/P/X/N** — distinguish research, productization, external absorption and military/program availability.
4. **Propulsion/energy** — piston boost, diesel turbo, GT, TP/turboshaft, turbojet are separate technologies. Check part-load, installed mass and environment.
5. **Materials/environment** — separate steel/heat-treatment, resin/process, GFRP and CFRP maturity; do not backdate structural composites or treat GFRP as nonflammable.
6. **Mechanisms/controls** — gears, clutches, transmission, shaft/prop/cavitation, cooling, steering/traverse, electrics.
7. **Computation/QC/test** — computation shortens iteration and improves margins/repeatability; it does not create missing requirements or raw-physics bonuses.
8. **Production/maintenance/logistics** — tooling, spares, inspection, field/base/yard infrastructure and actual procurement remain separate gates.
9. **Integration tax / negative gate** — record attractive technology that was checked and rejected.

## v28 LARGE-MARINE gate

Current authority is `main/asai-works-surface-ship-large-marine-rebaseline-1934-41.md`.

Fixed calibration / decisions:
- Taigei No.11 and battleship No.13 are separate EHs. Taigei improvement is not proof of No.13.
- Historical No.13 Type 6: 480×600 mm, 350 rpm, 4,800 PS-class, 144 h endurance completed, 95+ score. Separate technical defects (smoke/ring/liner-piston wear) from adoption-risk defects (no No.13 service record; poor No.11 service record).
- Asai computation/QC may shrink the technical defect tail but cannot manufacture service history before the 1937 capital-ship decision. A-140F6 all-steam-turbine remains central; F5 mixed diesel/turbine is conditional/provenance.
- A free-power turbine is not a reversing device. Explicitly identify astern architecture: base steam/diesel, CPP, reversing gear, or electric transmission.
- Destroyer/cruiser/carrier GT boost or return-home installations are conditional until intake/filter/exhaust, reducer/shaft/clutch/torsion, salt MTBO, installed mass/volume, fuel and yard integration are closed.
- Do not revive legacy post-1941 carrier-count changes derived from assumed GT adoption; OOB/production/deployment/combat remains HISTORY/FROZEN.

## v27 TANK-EARLY gate retained

Current authority is `main/asai-works-tank-early-computation-materials-rebaseline-1928-41.md`.

Do not revive as current:
- Type 89 as a 120hp diesel throughout 1929–34;
- production turbo Type 89;
- Ha-Go 130–145hp as the production central or automatic 20–25mm armor growth;
- Chi-Ha as a later turbo retrofit rather than the worldline 1938 200/220hp production central;
- Shinhoto Chi-Ha 5-crew/3-man-turret worldline specification;
- Chi-He 260hp operational boost, 400mm initial track, powered coarse traverse or standard full-crew voice intercom.

For each early tank, first state the Army/manufacturer requirement independently of Asai. Then ask what turbo/materials/computation/QC actually buy in transmission, cooling, reliability, high-altitude performance, crew workload and production repeatability.

## v29 MARINE-GT-CRAFT gate

Current design authority is `main/asai-works-marine-gt-small-craft-design-closure-1938-43.md`; `main/asai-works-marine-gt-small-craft-rebaseline-1934-43.md` is historical/physics provenance.

Fixed calibration / decisions:
- ~20.5t Japanese No.1-class: ~1,800hp / 38–38.5kt / two 45cm torpedoes; T-51 is the heavy-boat failure calibration.
- Old 2×1,300hp GT + 350hp diesel independent-three-shaft central is superseded. E5 first marine qualification is two conventional piston shafts for cruise/astern plus one independent ~1,300hp E5 GT boost shaft.
- Trial speed is not operating/service speed. Treat E5 42–46kt and E6 42–44kt as clean/full-load trial design bands unless sea-state/service penalties are separately closed.
- Initial prop bands: E5 0.74–0.80m / 2,050–2,300rpm; E6 0.86–0.94m / 1,750–1,950rpm. Cavitation/ventilation remains a tank/sea-trial gate.
- Complete marine installed GT-path bands: E5 2.8–3.4kg/kW (central 3.1), E6 2.2–2.8kg/kW (central 2.5), excluding fuel/long shaft/prop.
- E5 qualification: ~150h cumulative, ~50h hot-section inspection. E6: ~300h cumulative, ~100h inspection, ~500h design-TBO target. Do not promote these to fleet historical MTBO.
- Pure-GT normal torpedo-boat mass production is NO for the E5/E6 period; sprint/test craft remains a conditional shadow.
- E6 50–55t / 4×45cm / nominal 5,200hp / ~42–44kt full-load trial / ~450–600nm planning-range technical shadow is valid, but actual requirement/procurement/series production is conditional. Hard 40kt service requires roughly 6,000–7,100hp or lower displacement.
- 2GT high-power craft require high-speed marine CPP/feathering or equivalent low-speed prop-drag mitigation; domestic implementation/endurance is conditional.
- 20–30t GFRP hull demonstration and any later 50t full-GFRP hull remain the next materials gate.

Always check: hull/trim/sea state, shaft/prop/cavitation/ventilation, installed mass, salt/intake/inspection, part-load fuel, reverse/harbor handling, weapons/crew/fuel weight and yard repair. Small-craft success is **not** the sole prerequisite for all naval GT applications.

## v26 aircraft gates retained

Aircraft role/rebaseline authority remains `main/asai-works-aircraft-computation-closure-1937-46.md`. AT-3/Ki-92 and Fugaku development milestones remain conditional. Do not revive B6A Tenzan, Tenzan-bomber→Ryusei, Ki-48TP production, old Ginga seven-seat total-replacement or old carrier-jet density-only speed rows.

## v25 TANK-NEXT gate retained

`main/asai-works-tank-next-generation-conditional-1939-45.md` remains a conditional technical shadow. Actual research authorization, threat-intelligence timing, prototypes, production and deployment are not current history.

## Minimum record

| Family | Result | Reason/source |
|---|---|---|
| chronology / semantic status | CHECKED / GATED-OUT / N/A | source |
| requirement owner / historical counterpart | CHECKED / GATED-OUT / N/A | source |
| propulsion / part-load / fuel / environment | CHECKED / GATED-OUT / N/A | source |
| materials / structure / corrosion | CHECKED / GATED-OUT / N/A | source |
| mechanisms / controls / shaft/prop/transmission | CHECKED / GATED-OUT / N/A | source |
| computation / optics / QC / test | CHECKED / GATED-OUT / N/A | source |
| production / maintenance / logistics | CHECKED / GATED-OUT / N/A | source |
| integration tax / negative gate | CHECKED / GATED-OUT / N/A | source |
