# E4 regeneration installed rebaseline 1931–33 — v42

> **v43 compressor follow-up.** The v42 7.16 kg/s / 475 kWe recuperated-continuous derivative is now compressor-side feasible as a distinct ~7.2 kg/s E4-S-HF trim; standard E4-R remains 6.7 kg/s / 440–450 kWe continuous. Exact low-load economic bypass crossover remains a 30–45% calibration band.

> **v42 current authority. 状態：E4 RECUPERATED INSTALLED CYCLE CLOSED / OLD 25%・0.33 SUPERSEDED / PART-LOAD MAP DEFERRED TO COMPRESSOR-OPERABILITY GATE / NO DOWNSTREAM H→A.**
>
> v40のcooled installed-cycle accountingとv41のE4 standard flow 6.7 kg/sを固定入力にする。本稿はE4定置・連続運転用の回生版について、heat-exchanger effectivenessだけでなく、cold/hot side pressure loss、熱交換器UA、重量・容積、bypass/start/transient、generator ratingまで同一帳簿に入れる。航空・艦船の性能・採用はまだ変更しない。

## 0. 中央裁定

1. **旧「回生でη≈25% / SFC≈0.33 kg/kWh」はSUPERSEDED。** v42中央のE4-Rは `epsilon=0.60`, air-side `Δp=1.5%`, exhaust-side `Δp=2.5%` とし、6.7 kg/sで **shaft 467.7 kW / ηshaft 19.34% / SFC 0.433 kg/kWh / fuel 202.5 kg/h**。
2. 同じコアのsimple/bypass中央はv41/v40で約507 kW shaft。したがって回生は燃費を改善する一方、圧損で**同一流量のshaft outputを約8%払う**。
3. 発電機効率95%なら回生連続は **約444 kWe**、electrical SFC **約0.456 kg/kWh_e**。cold/start/emergency bypassなら約482 kWe級。初期商品は**二重定格**で扱う。
4. 回収熱は中央 **約0.94 MW**、必要UAは **約9.8 kW/K**。1931–33量産用は高effectiveness薄肉plate-finを前提にせず、**低流速の金属tubular / finned-tubular recuperator**をworking architectureとする。
5. 回生器本体＋pressure shell/headers＋bypass/ductの追加重量は **0.6–1.1 t、中央約0.78 t**。installed hot-path volumeは **1.4–2.5 m³、中央約1.7 m³**。E4 engine 0.80–0.90 tと合わせ、recuperated shaft packageは概ね **1.4–2.0 t**。generator、foundation、external silencerは別帳簿。
6. 25% shaft efficiencyを同じ圧損条件で得るには **ε≈0.943**が必要で、E4量産標準から外れる。よって旧25%はgross/idealized regeneration provenanceに降格する。
7. 回生状態で475 kWeを維持するには95% generator前提で約500 kW shaft、中央specific workでは **約7.16 kg/s**が必要。S-band内には残るが、標準6.7 kg/s E4-Rとは別のhigh-flow derivativeであり、P1-3 map/shaft qualification前はCONDITIONAL。
8. part-loadでは「負荷が下がるほど必ず利得増」と固定しない。E4-Rは**start/cold/emergency bypass**、stable-speed後にrecuperatorを漸次投入する。低負荷の最適SFCと切替点はcompressor/control map依存なのでP1-3へ送る。

## 1. 固定入力

v42では次を変更しない。

- E4 standard design flow: **6.7 kg/s**（v41）。
- PR: **4.5**。
- TIT: **710℃**。
- compressor/turbine component efficiency coordinate: **0.82**。
- cooling bleed central: **3.0%**。
- combustor pressure loss: **4.0%**。
- baseline exhaust/diffuser pressure ratio reserve: **1.015**。
- mechanical efficiency: **0.990**。
- accessory debit: **1.0 kJ/kg**。
- combustion efficiency: **0.980**。
- LHV: **43 MJ/kg**。

v40 simple installed coordinateは `wshaft=75.73 kJ/kg`, ηshaft≈15.03%。v41 6.7 kg/sでは約507.4 kW。

## 2. 回生器をinstalled帳簿へ入れる

### 2.1 pressure accounting

回生器cold sideの圧損は燃焼器前のtotal pressureを落とし、hot sideの圧損はタービン出口背圧を上げる。中央では、

- air side Δp = **1.5%**,
- combustor Δp = **4.0%**,
- baseline exhaust reserve = **1.5%相当**,
- recuperator exhaust side Δp = **2.5%**

を支払い、turbine effective expansion ratioは約 **4.09**まで下がる。

冷却抽気3%は回生器を通らない。したがって回生器で予熱するのはcombustorへ行く主流だけで、冷却流まで「無料で」予熱された扱いにはしない。

### 2.2 heat recovery

中央計算：

- compressor discharge `T2 ≈ 476.6 K`（203℃）。
- pressure-loss込みmain-gas turbine exhaust coordinate `Texh ≈ 716.0 K`（443℃）。
- ε=0.60ならcombustor-bound airは `≈620.3 K`（347℃）まで上がる。
- recovered heat ≈ **938.6 kW**。
- combustor fuel inputが減るため、shaft efficiencyは **19.34%**へ上がる。

回生器はshaft workを増やす装置ではない。圧損によってspecific shaft workはsimpleの75.73から **69.81 kJ/kg**へ下がる一方、必要燃料熱をより大きく減らすことで効率を上げる。

## 3. central / audit envelope

| item | v42 central | audit envelope |
|---|---:|---:|
| effectiveness ε | **0.60** | **0.50–0.70** |
| air-side Δp | **1.5%** | **1.0–2.5%** |
| exhaust-side Δp | **2.5%** | **1.5–4.0%** |
| shaft power @6.7 kg/s | **467.7 kW** | **442.8–482.6 kW** |
| shaft η | **19.34%** | **17.26–21.26%** |
| shaft SFC | **0.433 kg/kWh** | **0.394–0.485** |
| fuel @central output | **202.5 kg/h** | point-dependent |

audit envelopeは製造公差ではなく、回生器性能・圧損の設計/汚損/熱状態を含む監査cornerである。

## 4. 発電商品としての二重定格

E4-Rを「475 kW級発電機」と一行で書くと、bypassとrecuperated continuousを混同する。

### v42 product rating coordinate

- **cold/start/emergency bypass**: shaft約507 kW → generator約**482 kWe** @95%。
- **recuperated continuous**: shaft約468 kW → generator約**444 kWe** @95%。
- recuperated continuous electrical SFC: **約0.456 kg/kWh_e**。

商品表現は **475–480 kWe short/bypass / 440–450 kWe recuperated continuous** とするのが自然。これなら起動即応性と連続燃費の両方を同じE4-R packageに与えられる。

### 475 kWe recuperated continuous derivative

475 kWeを回生状態で連続保証するなら、95% generatorで500 kW shaftが必要。v42 central `wshaft=69.81 kJ/kg` から必要flowは **約7.16 kg/s**。

- S-band内部ではある。
- ただしstandard 6.7 kg/s E4から+6.9%のflow increase。
- compressor annulus / diffuser / turbine flow area / shaft powerを再確認する必要がある。

従ってこれは **E4-R-HF conditional derivative** とし、P1-3 operabilityを通るまで標準商品へ昇格しない。

## 5. 回生器hardware coordinate

### 5.1 UA / surface

主流heat-capacity rateは約6.5 kW/K。balanced counterflowの一次式 `ε≈NTU/(1+NTU)` でε=0.60ならNTU≈1.5、したがって **UA≈9.8 kW/K**。

1931–33量産機では、整備性・漏洩・熱歪みを優先し、薄肉高密度plate-finを前提にしない。working sizingでは金属finned/studded tubular coreとして、effective overall Uを **45–70 W/m²K**の設計帯に置く。この場合必要heat-transfer areaは概ね **140–218 m²、中央約178 m²**。

これはhistorical constantではなく、v42 package sizing用の露出仮定である。Uを上げるには薄肉・高密度化・清浄度・接合品質を別途払う。

### 5.2 mass

heat-transfer surfaceの有効metal massを2.2–3.0 kg/m²、pressure shell/headers＋bypass/ductを280–400 kg級と置く一次帳簿から、

- recuperator hot-path system: **約0.59–1.05 t**。
- canonical rounded band: **0.6–1.1 t**。
- central: **約0.78 t**。

E4 dry engine 0.80–0.90 tを足したrecuperated shaft packageは **約1.4–2.0 t**。発電機本体・foundation・建屋duct/silencerは別。

旧「回生器+1–3 kg/kW」はv42では一般則として使わず、E4中央では回生連続出力467.7 kWに対してhot-path追加が約 **1.3–2.3 kg/kW**に相当する、と読み替える。

### 5.3 volume

中央exhaust coordinateは約443℃、背圧込み密度約0.51 kg/m³で、6.7 kg/sならvolume flow約 **13.1 m³/s**。排気側平均流速を22 m/s級、free-flow ratio 0.5級に抑えると、一次frontal areaは約1.2 m²。depth 0.8 m級でcore volume約0.95 m³。

headers、turning、thermal expansion allowance、bypass ductを含むinstalled hot pathは **1.4–2.5 m³、中央約1.7 m³**をworking envelopeとする。

したがってE4-Rは「E4へ小さな箱を足したもの」ではなく、**機関本体と同程度以上の設置容積を追加で要求する定置設備**である。

## 6. start / transient / part-load

### start

cold startでrecuperatorを常時直列に置く理由はない。v42標準制御：

1. air-side / exhaust-side bypass OPENでstart。
2. simple-cycle状態でself-sustain→rated speedへ。
3. exhaust temperature・shaft speed・combustion stabilityが安定後、bypassを漸次閉じる。
4. recuperator metal temperature gradientを抑えながら連続状態へ移す。

これによりstart時の余分な背圧、cold matrixの熱吸い込み、surge margin低下を避ける。

### transient

急負荷投入・emergency powerではbypassを開けてshaft outputを優先してよい。回生器はfuel-saving deviceであり、瞬時出力を優先する時に必須ではない。

### part-load

旧「100%より40%で利得が大きい」という一般的傾向を、E4の固定数値へはしない。部分負荷で `Texh > T2` が保たれれば回生余地はあるが、

- constant-speed generator control,
- fuel schedule,
- compressor operating line,
- bleed/VSVの有無,
- exhaust temperature,
- recuperator pressure loss fraction

で結果が変わる。したがって**40%負荷で+12.6%**のような旧一点値はE4 currentから外す。P1-3でcompressor/control mapを閉じた後に、load-by-load SFCを再計算する。

## 7. 用途裁定

v42のE4-Rは用途を限定する。

**採る**：
- 定置連続発電。
- 長時間ポンプ/工業原動機。
- 容積と保守を許容し、fuel savingが設備重量より重要な用途。

**採らない**：
- 航空機。
- 小型高速艇のboost/sprint。
- emergency-only短時間GT。
- 容積・重量・被弾面積が主要制約のinstallation。

したがって「E4は回生25%だから全用途で燃費改善」という伝播は禁止する。

## 8. supersession / downstream rule

v42でsupersedeするもの：

- E4-R `η≈25%`。
- E4-R `SFC≈0.33 kg/kWh`。
- 回生版をsimple E4と同じ500 kW級continuous outputで扱う記述。
- 「回生器重量は軽微で、短時間運転でも燃料で容易に回収」のE4への一般適用。
- E4 part-load improvementの固定一点値。

保持するもの：

- 回生は低PR GTで燃費改善方向に効く。
- 容積を許す連続原動機が主用途。
- bypassによって即始動・emergency outputとcontinuous economyを両立できる。

**航空・艦船H→Aはまだ開始しない。** v42はE4-Rの商品/設備境界だけを閉じる。E5/E6 compressor operabilityが次のlocal P1であり、その後にplatform installationを一つずつ再受領する。

## 9. reproducibility

計算正本：

- `computation-2026-08-22/e4_regeneration_installed_v42.py`
- `computation-2026-08-22/E4-REGENERATION-INSTALLED-V42.tsv`

回生器U、surface specific mass、duct/casing allowanceはhardware sizing coordinateとしてスクリプト内に明示し、熱力学結果と経験的packaging assumptionを分離している。
