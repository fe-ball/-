# 「未来CAD＋未来部下＝100%」能力収斂スコアリング枠組み

> **v38再監査用・細分化作業稿。v37r1正本は未変更。**
>
> 本稿は `89-COMPUTATION-ERA-CAPABILITY-INVENTORY-DRAFT-V38-2026-08-25.md` の companion document。目的は、「浅井がその時点の現地工業を使って、未来の設計環境へどこまで近づけるか」を一つの性能ボーナスに潰さず、設計最適化・開発探索・実機利得へ分けて評価すること。

---

## 0. まず100%を定義する

本稿の **100% benchmark** は、未来の工場・未来材料・未来工作機械を亜空間から持ち込む状態ではない。

### 100% benchmark = 「現地工業固定・設計環境だけ未来」

その年、その場所で実際に用意できる：

- 材料
- 素材品質
- 工作機械
- 治具
- 計器
- 工員
- 工場面積
- 電力
- 資金
- 調達網
- 試験設備
- 必要な実時間（creep、耐久、腐食、疲労等）

はそのまま固定する。

ただし主人公は亜空間の未来設計室へアクセスでき、そこから：

- その現地条件で作れる範囲の最善に近いCAD図面
- 公差・表面粗さ・材料指定
- 工程表
- 治具設計
- 検査計画
- 試験計画
- failure mode一覧
- 解析結果
- trade study
- 設計変更の優先順位
- 熟練した未来の部下によるレビュー

を受け取れる、と仮定する。

つまり100%でも「現地で作れないもの」は作れない。100%とは、**現地の物理・工業制約の中で設計側の探索損失をほぼゼロにした状態**である。

このbenchmarkなら、転生チートを強く評価しても工業基盤を消さない。

---

# 1. 主人公と計算機の距離——計算機はメイン分野ではない

主人公の本当のコアは：

1. 発動機
2. ガスタービン／ジェット
3. 冶金・耐熱材料
4. 航空への統合

である。

計算機はこの主系列から外れる。したがって、計算機だけを未来知識で一直線に作り込む扱いは避ける。

主人公の計算分野への介入は、中央では次の順とする。

### C-I0：需要を出す

「この計算を毎週100ケース回したい」「この表を翌朝返してほしい」「このデータを十年後も比較できる形で残せ」と要求する。

### C-I1：人を集める

数学、保険統計、会計機、電話、交換機、カード機、精密機械、電機、暗号、物理の人材を同じ問題へ当てる。

### C-I2：刺激を与える

自動順序、条件分岐、表参照、記憶、検算、標準化などについて、「こういうことはできないか」と問題を置く。

### C-I3：提案を食う

現地技術者が出した提案のうち、自分がかつて持っていた電子環境へ繋がるものを後知恵で選び、資金・需要・設備を与える。

### C-I4：限定的な強いヒント

行き詰まりが長い、または本職側のcritical pathを塞ぐ場合に限り、主人公が「その方向で正しい」と分かる具体的工夫を強く押す。

### C-I5：直接ベタ書きは例外

計算機本体について未来CPU/電子計算機の完全設計を直接投下するのは中央では行わない。暗号、記憶、論理、演算回路などで必要に迫られた局所発明はあり得るが、**計算機産業は人材・需要・刺激・選択の複利で育つ**のが中央。

要するに主人公は、時に遠慮がちに、時に強く、時に他人の提案を即座に採りながら、結果として「自分がかつて持っていた電子環境」に近づく方向へ市場と研究需要を曲げる。

---

# 2. 二つの主スコア

## 2.1 O-score：Optimization Proximity / 最適化接近率

**未来CAD＋未来部下100% benchmarkが出す設計解に、現行の設計・計算・試験文化がどの程度近いか。**

これは「完成品の性能」ではない。

見る対象：

- 構成選択
- 主要寸法
- 変数の組合せ
- 公差配分
- 材料選択
- 冷却配分
- 制御schedule
- 重量配分
- safety margin配分
- 試験点の選択
- failure modeの事前把握

例：O=70%とは、未来設計室なら避ける無駄な局所最適や見落としがまだかなり残るが、主要構成・主要寸法・重要gateの大半は正しい、という意味。

---

## 2.2 G-score：Gain Capture / 利得回収率

**100% benchmarkによって得られる「基準設計からの改善余地」のうち、実際に何%を回収できるか。**

OとGは一致しない。

理由：技術改善にはlow-hanging fruitがあるため、O=50%でも利得の70–80%を取れる場合がある。一方、最後の数%のOが寿命・歩留まり・surge margin等では非常に大きいこともある。

Gは必要に応じて3分割する。

- **Gp**：performance gain capture——出力、効率、重量、抗力、航続等
- **Gd**：development gain capture——試作回数、開発暦、人日、手戻り削減
- **Gq**：quality gain capture——寿命、信頼性、歩留まり、個体差、保守性

一つのGしか書かない場合は三者の総合評価ではなく、何のGかを必ず明記する。

---

# 3. 「額面の％」への変換

G-scoreを製品性能へ直接加算してはいけない。

未来100% benchmarkが史実的/従来設計Hに対して、ある指標で `Δ100` の改善余地を持つ場合：

`実際の改善 ≈ Δ100 × Gp`

と読む。

例：

- 同じ現地材料・工具で未来設計室なら燃費をHより10%改善できる
- 1934時点の当該分野Gp=0.70

なら、中央推定は約7%改善。

**「Gp=70%だから性能+70%」ではない。**

逆に、未来設計室でも現地材料ではH比+2%しか改善できないなら、Gp=90%でも実利は+1.8%程度。

この表現により：

- 近代設計への接近率
- 現地工業でそもそも取れる改善余地
- 実際の製品数値

を分離できる。

---

# 4. 問題クラス——同じ年代でも接近率は違う

一つの年代に一つのO%を置かない。問題を少なくとも5クラスへ分ける。

## L0：方式選択・離散的な正解

例：

- 適切な合金系を選ぶ
- 遠心/軸流の研究順を選ぶ
- 中空翼を採る
- VSV/bleedを採る
- limit gaugeを採る
- 適切な翼型系列を選ぶ
- 失敗すると分かっている方式を捨てる

**未来知識が最強に効く。** 計算機なしでも高Oになり得る。

## L1：低次元・閉形式・表計算問題

例：

- 熱収支
- 歯車比
- BMEP
- 重量重心
- 単純Brayton cycle
- 静的強度
- プロペラ基本matching
- shaft horsepower

紙・計算尺・卓上計算器でもかなり高Oへ行ける。計算機は主にcase数と検算を増やす。

## L2：多変数semi-empirical問題

例：

- 過給機map
- compressor stage stacking
- 燃焼器loss/pattern
- 熱処理条件
- fatigue/creep fit
- engine/prop matching
- 重量・空力・航続trade
- 公差stack

データ整備と反復計算が強く効く。

## L3：coupled nonlinear / dynamic問題

例：

- compressor/turbine/nozzle full matching
- start/acceleration/surge crossing
- two-spool matching
- flutter
- aeroelasticity
- rotor dynamics
- thermal transient
- automatic control
- 多状態damage/stability

自動順序・relay・電子計算でOが大きく上がる。

## L4：場・未知モデル・長時間物理gate

例：

- 3D separated flow
- secondary flow
- 実surge境界
- turbulent heat transferの細部
- creep/oxidation/thermal fatigueの長期寿命
- 実flutter
- rotor burst
- corrosion
- resin interface degradation

計算機があってもモデル・測定・実時間が律速。未来知識は「何を測るか」「どこで壊れるか」には非常に効くが、完全代替はしない。

---

# 5. 年代×問題クラス：浅井内部のO-score中央帯

> これは**性能ボーナスではなく、未来設計室への設計接近率**。浅井内部の本職領域（発動機・GT・冶金・航空統合）を主対象とする。外販先は別途U成熟度debitを掛ける。

| 時期 | 計算/組織像 | L0 方式選択 | L1 低次元 | L2 多変数semi-empirical | L3 coupled/dynamic | L4 場・長時間gate |
|---|---|---:|---:|---:|---:|---:|
| ～1922 | 主人公＋紙＋計算尺 | 80–95 | 55–75 | 25–45 | 10–25 | 5–15 |
| 1923–24 | C0機械計算室 | 82–95 | 65–80 | 30–50 | 12–28 | 5–15 |
| 1924–26 | C1カード/試験標準化 | 84–96 | 68–82 | 38–58 | 15–32 | 8–18 |
| 1925–27 | C2計算型 | 85–96 | 72–85 | 45–63 | 20–36 | 8–20 |
| 1926–28 | C3探索日常化 | 86–97 | 75–88 | 50–68 | 25–42 | 10–22 |
| 1929–31 | A1自動順序 | 88–97 | 80–90 | 58–74 | 32–50 | 12–25 |
| 1932–34 | R1数千relay | 89–98 | 84–93 | 65–80 | 42–60 | 15–30 |
| 1935–37 | R2/U4設計文化 | 90–98 | 88–95 | 73–86 | 55–72 | 20–38 |
| 1938–40 | E1電子＋relay＋drum | 91–99 | 91–97 | 80–90 | 65–80 | 28–48 |
| 1941–42 | E2電子計算研究基盤 | 92–99 | 93–98 | 84–93 | 72–85 | 35–55 |
| 1943–45 | E3計算センター | 93–99 | 94–99 | 87–95 | 78–90 | 42–62 |

### 読み方

- L0が非常に早く高いのは、転生知識が「正しい枝を選ぶ」ことに直接効くため。
- L1も早く高くなる。式が既知で計算量だけの問題なら、未来電子計算機がなくても正しい設計へかなり寄れる。
- L2からカード・データ・反復計算の複利が大きくなる。
- L3は1929以降で初めて大きく伸び、1935–40で設計文化そのものが変わる。
- L4は最後まで低い。これは悲観ではなく、計算で代替できない実物世界を明示したもの。

---

# 6. O-scoreからG-scoreへの一般変換

OとGの関係は技術ごとに違うが、中央の考え方を次で置く。

## 6.1 Low-hanging型

方式選択、基本配置、明白な損失削減など。

- O 30% → Gp 50–70%
- O 50% → Gp 70–85%
- O 70% → Gp 85–93%
- O 85% → Gp 93–97%
- O 95% → Gp 97–99%

「正しい大枝を選ぶだけで利益の大半を取れる」。主人公の初期チートが強く見える領域。

## 6.2 Smooth optimization型

翼角、圧力比配分、重量配分、冷却配分、燃料schedule等。

- GpはおおむねOと同程度〜やや上。
- 最後の10%にも意味はあるが、急激な崖は少ない。

## 6.3 Threshold / cliff型

surge margin、flutter、bearing instability、creep life、量産歩留まり、燃焼安定等。

- O 70%でも製品としては未合格になり得る。
- O 85→95%の最後の10%が、Gp/Gqを一気に0→大へ変える場合がある。
- この型では単純な「O×Δ」で性能を出さず、**qualification gateを別に置く**。

---

# 7. 開発速度の別勘定——D-score

最適化接近率と開発暦短縮は別。

**D-score = 100% benchmarkが削れる無駄な開発時間のうち、どれだけ削れているか。**

対象：

- 不要案の試作
- 手計算待ち
- 転記/検算
- 故障原因の再発見
- 試験点不足による再試験
- 版管理不足
- 部署間の計算やり直し

削れない：

- 長時間耐久
- creep時間
- corrosion exposure
- 新工場建設
- tool delivery
- worker training
- 大型鍛造/鋳造の物理cycle

浅井内部中央帯：

| 時期 | D-score：無駄時間回収率 | 備考 |
|---|---:|---|
| ～1922 | 15–30% | 主人公の正解選択で無駄枝を切るが、人手計算・手試作が重い |
| 1923–24 | 25–40% | routine算術待ちを外す |
| 1924–26 | 30–45% | データ検索・再発故障を減らす |
| 1925–28 | 35–55% | 計算型と粗探索 |
| 1929–31 | 45–62% | algorithm反復を機械へ移す |
| 1932–34 | 50–68% | 多変数caseを試作前に落とす |
| 1935–37 | 58–75% | 粗探索→重点試験→検算が標準化 |
| 1938–40 | 65–80% | 過渡・熱・振動も一部試作前へ |
| 1941–45 | 70–85% | numerical experimentが研究工程へ定着。ただしqualification実時間は残る |

D=80%でも「開発期間80%短縮」ではない。

もし全開発期間のうち、100% benchmarkでも削れる無駄時間が30%しかない案件なら、D=80%の暦短縮は最大でも約24%。残る76%は工場・試験・熟成等の物理時間。

---

# 8. 「主人公本人」と「組織」のスコアを分ける

## 8.1 P-score：Protagonist direct solution

主人公本人がその問題を扱う場合のO。

本職領域では高い。

- GT基本構成：極めて高い
- 耐熱材料の方向性：高い
- 航空用発動機統合：高い
- 計算機論理回路の詳細：中央では低〜中。需要・方向提示が主。

## 8.2 Org-score：組織として再現できるO

主人公がいなくても設計室・計算室・試験所が同じ方法を再利用できる程度。

物語の20年成長は、P-scoreの上昇より**Org-scoreがP-scoreへ追いつく過程**として読むと自然。

概念的には：

- 1920年代前半：P ≫ Org
- 1920年代後半：P > Org
- 1930年代前半：計算型・カード・標準試験により差が縮む
- 1935–40：U4化、計算室、試験標準化でOrgが高くなる
- 1940年代：主人公が直接図面を書かなくても、かなりの領域で組織が正しい探索を続けられる

これが「主人公が怪物」から「主人公が作った会社・技術文化が怪物」への移行。

---

# 9. GTへ適用した例

## 9.1 E-1以前～E-2

### 方式選択 L0

- axial compressorを早期に本命化
- cascade/spin rigを使う
- balance、bearing、seal、hot-sectionを別試験
- 将来のVSV/bleed/coolingを見越して設計余地を残す

O：85–95%級まであり得る。

ただしL2/L3は低い。

- 多段loss accumulation
- off-design
- surge
- rotor dynamics

は紙と実験頼み。

したがってE-1/E-2の主配当は「正しい壁を殴る」ことであって、完全最適化ではない。

## 9.2 E-3 1928–29

C3を前提に育つ最初のcore。

代表：

- L1 cycle：O 80–90%
- L2 stage/cascade semi-empirical：O 50–70%
- L3 full matching：O 25–45%

ここで性能値へ一律ボーナスは付けない。未来知識による正しい構成＋計算型により、**100% benchmarkの大枝利得をかなり回収しながら、細部最適はまだ実験で埋める**状態。

## 9.3 E-4 1931–33

A1/R1入口。

- stage-by-stageの繰返し
- multiple operating points
- critical speed candidate
- combustor pressure loss

が「人間が面倒なのでやらない」から「仕事として回る」へ移る。

中央例：

- L2 O=60–75%
- L3 O=35–55%
- Gpはbasic architecture利得について75–90%程度回収可能
- Gqはまだ低め。bearing/seal/hot-section durabilityが実物gate

このため「売れるGT」への到達は、単なる未来材料よりも**正しい開発順＋計算探索＋試験feedback**の複合結果とする。

## 9.4 E-5 1934–37

R1→R2、U4文化。

- PR6級
- stage stacking
- VSV/bleed schedule
- turbine/compressor matching
- gear/prop integration
- thermal margin

のL2はO 75–88%級へ。

L3も55–72%帯。

ここでは未来CAD100%との差は主に：

- off-design model精度
- secondary flow
- surge boundary
- exact thermal field
- manufacturing scatter

へ集中する。

つまり「全体像はかなり近いが、最後の危険域を実験で探る」。

## 9.5 E-6 1938–41

電子＋drumの配当が入る。

- start/acceleration time integration
- thermal network
- Campbell/rotordynamics case sweep
- semi-empirical combustor model
- high-altitude/flight installation trade

が大幅に増える。

L3 Oは65–82%帯。

ここから「future blueprintを知る主人公」より、**future-like engineering workflowを持つ組織**が効き始める。

## 9.6 E-7/E-8 1942–46 technical coordinate

E8 PR9–10/TIT940を考えるとき、100% benchmarkとの差は「PR9.5を思いつくか」ではない。

残る差：

- 15–16段全域のoff-design map
- clearance scatter
- surge/stall boundary
- vane/blade/root/disk thermal field
- cooling flow distribution
- creep/oxidation/thermal fatigue
- bearing/seal/oil coking
- manufacturing yield

L1/L2は90%前後へ近づけても、L4が50%前後なのでqualification gateは残る。

これが、E8を高端実用ratingとして成立側に置きながら、TBO/歩留まりを別会計にする理由になる。

## 9.7 E-9

E9は典型的な「Oの平均値では語れない」案件。

- component design O：高い
- two-spool basic matching O：高め
- dynamic transient O：中高
- hot-section durability O：中
- series manufacturing/qualification：threshold型

したがってcomponent/rig technical frontはcurrentでも、flight/seriesはCONDITIONALというv37裁定と整合する。

---

# 10. 冶金へ適用した例

冶金は未来知識の効き方がGTと違う。

## 10.1 早期Oが高くなりやすい部分

- 合金系選択
- 不純物管理
- 熱処理方向
- 脱酸/清浄溶解
- grain size管理
- surface treatment
- shot peening
- coating
- inspection philosophy

これらL0/L1は非常に早く高Oにできる。

## 10.2 Gqが遅れる部分

- creep scatter
- oxidation
- thermal fatigue
- corrosion
- casting defect distribution
- weld/interface life

は長期データが要る。

未来CAD100%でもこの実時間は消えない。

主人公の最大のチートは「20年後に必要になる試験を1920年代から始める」こと。

したがって冶金では、計算機高速化よりも**データ開始時点の前倒し**が極めて大きなGq利得を生む。

---

# 11. 航空へ適用した例

航空は「正しい設計を知る」だけでは重量・操縦・flutter・製造がcoupleするため、計算文化の配当が大きい。

## 11.1 ～1930

高O可能：

- 翼面荷重の方向
- clean-up
- cooling drag
- propeller tip Mach
- fairing/flush riveting
- basic weight/CG

低O：

- flutter
- aeroelasticity
- compressibility
- transient stability

## 11.2 1932–37

relay＋風洞/flight-test card化で：

- load cases
- spar/skin sizing
- CG migration
- engine/prop/cooling matching
- flutter simplified model

を同じledgerで回しやすくなる。

ここで「未来の機体形状を丸写し」より、現地エンジン・現地材料に合わせた**再最適化**ができる価値が大きい。

## 11.3 1938–45

- dynamic stability
- high-altitude schedules
- compressibility corrections
- gust response
- aeroelastic reduced-order model
- mission optimization

が日常計算へ寄る。

ただし3D separated flow、buffet、pilot handling、実flutterはL4に残る。

---

# 12. 計算機分野自身にはこの100%尺度をそのまま適用しない

計算機は主人公の本職ではないので、浅井本人P-scoreを高く置きすぎない。

むしろ別の指標を使う。

## EC-score：Electronic Environment Convergence

**主人公がかつて持っていた電子的作業環境の「機能」へ、現地の独立技術者集団がどこまで近づいたか。**

これは未来CPUの再現率ではない。

見る機能：

- 自動反復
- 記憶
- 条件分岐
- 表参照
- standard input/output
- job queue
- reusable procedure
- independent verification
- data archive
- remote/departmental service

主人公は「スマホやPCを作れ」ではなく、これらの**必要機能を需要として出す**。

概念帯：

| 時期 | EC-score | 主人公の典型的介入 |
|---|---:|---|
| 1923–26 | 5–12% | 人手算術を外せ、データを標準化せよ |
| 1926–28 | 10–18% | 計算型・カード・検算を繋ぐ |
| 1929–31 | 18–28% | 自動順序・反復需要を強く出す |
| 1932–34 | 25–38% | 記憶・連立・安全区画・顧客内利用を要求 |
| 1935–37 | 35–50% | 計算センター、job化、U4組織を育てる |
| 1938–40 | 45–62% | 電子演算＋drum、過渡/場計算需要 |
| 1941–45 | 55–72% | 研究インフラとして継続利用。機能は未来環境へ近づくが、UI/半導体/大容量記憶は遠い |

このEC-scoreは「電子計算機性能が未来の72%」という意味ではない。

**研究者が計算を道具として使う作業感覚がどこまで未来環境に近いか**、である。

---

# 13. 未来を知るからこそ先に整えるもの

計算機の速度が将来上がると知っている主人公は、計算機そのものを直接発明しなくても以下を早く押す。

## データ

- standard units
- fixed field test sheets
- serial/lot/version IDs
- raw data保存
- calibration history
- machine-readable-ish coding
- punch/card numbering

## モデル

- coarse model / detailed modelの階層化
- correlation式
- lookup table
- dimensionless data
- reusable calculation procedure

## 試験設備

- 多点圧力
- 高温温度計測
- 振動
- strain
- fuel flow
- torque
- rpm
- synchronized timestamp

## 人材

- 「計算する人」ではなく「問題を数値化する人」
- 数学者と試験技師を同じ部門へ
- 計算員から技術者へのcareer path
- 保守技師を重要職種として扱う

## 組織

- 計算結果の版管理
- independent check
- model validation
- test–model–redesign loop
- compute queue priority

これらは未来computerを直接ベタ書きしなくても、後に計算機が速くなった瞬間の利得を大きくする。

---

# 14. 外販先へは「浅井内部O」をそのまま渡さない

三菱・中島・軍・工廠等は既存U0–U4を使う。

暫定的な利用係数：

| U | 組織吸収係数 |
|---|---:|
| U0 | 0–10% |
| U1 | 20–35% |
| U2 | 40–60% |
| U3- | 55–70% |
| U3 | 65–80% |
| U4 | 80–95% |

外販先のOを単純式で近似するなら：

`O_customer ≈ H_local + (O_Asai - H_local) × U係数`

と読む。

ただし、顧客自身が強い既存技術を持つ場合はH_localが高くなる。中島寿のように元から設計が速い案件へ一律大ボーナスを付けない。

---

# 15. audit cardの標準書式

後続の各技術再監査では、最低限次を埋める。

```text
対象：
年：
分野：
問題クラス：L0/L1/L2/L3/L4
100% benchmark：この年の現地工業で未来設計室なら何ができるか
主人公直接関与：P-score
組織能力：Org-score
計算段階：P0/C0/C1/C2/C3/A1/R1/R2/E1/E2/E3
O-score：
Gp：
Gd：
Gq：
100%時の改善余地 Δ100：
実際の額面改善 Δactual：
残存hard gate：
必要な実試験：
暦を縮められない部分：
前世代から支払済みのもの：
次世代へ蓄積するもの：
```

---

# 16. この尺度で最初に再監査する候補

## P1-A：GT E1→E8

各世代について：

- cycle
- compressor
- turbine
- combustor
- cooling
- rotor/bearing
- controls
- manufacturing
- qualification

を別audit cardにする。

## P1-B：耐熱材料 1910s→1945

- alloy selection
- melting cleanliness
- heat treatment
- casting
- cooling passage
- coating
- creep/fatigue/oxidation database

を分ける。

## P1-C：航空統合 1928→1945

- engine/prop
- cooling drag
- structure
- flutter
- high-speed aero
- flight dynamics
- mission design

へ再伝播。

計算機自身の性能年表を主目的にしない。**本職側で「計算能力が増えた結果、何ができるようになったか」を回収する**のが目的。

---

# 17. 暫定総括

この枠組みでは、浅井の転生チートを次の三段で表現できる。

1. **初期：正しい枝を選ぶ能力**
   - L0で未来100%へ非常に早く近づく。
   - 計算機がなくても巨大な利得を取れる。

2. **中期：正しい探索方法を組織へ移す能力**
   - カード、計算型、試験標準化、自動順序。
   - 主人公の頭の中の「未来CAD的判断」を、粗い形で会社へ外部化する。

3. **後期：組織が未来設計室へ部分的に近づく**
   - relay/電子計算、計算センター、model–test loop。
   - 主人公本人の正解ベタ書きなしでも、かなりの問題で高Oへ到達する。

したがって「15年で実用、20年で怪物」の意味は、単に材料やPRが20年で上がることではない。

**20年をかけて、現地の工員と工具しか持たない組織が、設計・試験・判断の面では“未来CAD＋未来部下”にかなり近い仕事を始める。**

これを今後のGT/ジェット再監査の中心尺度とする。
