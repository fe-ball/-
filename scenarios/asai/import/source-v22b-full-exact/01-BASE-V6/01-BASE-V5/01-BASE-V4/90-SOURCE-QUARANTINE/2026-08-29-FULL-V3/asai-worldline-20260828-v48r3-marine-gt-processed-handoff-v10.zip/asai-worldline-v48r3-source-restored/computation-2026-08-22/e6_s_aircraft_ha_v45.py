#!/usr/bin/env python3
import math,csv
from pathlib import Path
OUT=Path(__file__).resolve().parent

def speed_scale(v_lo,v_hi,p_new,p_old):
    f=(p_new/p_old)**(1/3)
    return f,v_lo*f,v_hi*f

def breguet_prop_km(bsfc_kg_kwh, wi_kg, fuel_kg, usable_fraction, ld, eta_p):
    # R = eta_p/(g*c_m) * L/D * ln(Wi/Wf), c_m=BSFC/3.6e6 kg/J
    used=fuel_kg*usable_fraction
    wf=wi_kg-used
    return eta_p*ld*3.6e6/(9.80665*bsfc_kg_kwh)*math.log(wi_kg/wf)/1000

rows=[]
for name,old,new,lo,hi in [
    ('Tenzan_standard',1520,1300,480,510),
    ('Tenzan_HF_short',1520,1400,480,510),
    ('Ki40_standard',1700,1500,650,675),
    ('Ki40_HF_short',1700,1600,650,675),
]:
    f,a,b=speed_scale(lo,hi,new,old)
    rows.append({'case':name,'old_hp':old,'new_hp':new,'anchor_v_lo_kmh':lo,'anchor_v_hi_kmh':hi,'power_ratio':new/old,'cube_root_factor':f,'scaled_v_lo_kmh':a,'scaled_v_hi_kmh':b})
with (OUT/'E6-S-AIRCRAFT-SPEED-SCALING-V45.tsv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rows)

# altitude shadow ratios inherited from v5 ledger; v44 changes sea-level product ratings
alt=[]
for eng,hp in [('E6-S-T',1300),('E6-S-N-T',1500)]:
    for km,(lo,hi) in [(0,(1.0,1.0)),(4,(.70,.82)),(6,(.55,.70)),(8,(.43,.58)),(10,(.32,.48))]:
        alt.append({'engine':eng,'sea_level_hp':hp,'altitude_km':km,'ratio_lo':lo,'ratio_hi':hi,'shaft_hp_lo':hp*lo,'shaft_hp_hi':hp*hi})
with (OUT/'E6-S-ALTITUDE-POWER-SHADOW-V45.tsv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=alt[0].keys(),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(alt)

rng=[]
# Tenzan: loaded strike, internal fuel ~900kg, L/D implied by old range audit ~8.6.
for wi in [4550,4650,4750]:
    for usable in [.85,.90,1.0]:
        for eta in [.78,.80,.82]:
            rng.append({'aircraft':'Tenzan','wi_kg':wi,'fuel_kg':900,'usable_fraction':usable,'ld':8.6,'eta_p':eta,'bsfc_kg_kwh':.37234,'range_km':breguet_prop_km(.37234,wi,900,usable,8.6,eta)})
# Ki-40: v26 3.9-4.1t clean recon; 1.3-1.4t internal fuel; high-alt L/D working 11.5-12.5.
for wi in [3900,4000,4100]:
    for fuel in [1300,1400]:
        for usable in [.80,.85]:
            for ld in [11.5,12.0,12.5]:
                for eta in [.80,.82]:
                    rng.append({'aircraft':'Ki-40','wi_kg':wi,'fuel_kg':fuel,'usable_fraction':usable,'ld':ld,'eta_p':eta,'bsfc_kg_kwh':.35588,'range_km':breguet_prop_km(.35588,wi,fuel,usable,ld,eta)})
with (OUT/'E6-S-AIRCRAFT-RANGE-SHADOW-V45.tsv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rng[0].keys(),delimiter='\t',lineterminator='\n');w.writeheader();w.writerows(rng)

for ac in ['Tenzan','Ki-40']:
    vals=[r['range_km'] for r in rng if r['aircraft']==ac]
    print(ac,min(vals),max(vals))
