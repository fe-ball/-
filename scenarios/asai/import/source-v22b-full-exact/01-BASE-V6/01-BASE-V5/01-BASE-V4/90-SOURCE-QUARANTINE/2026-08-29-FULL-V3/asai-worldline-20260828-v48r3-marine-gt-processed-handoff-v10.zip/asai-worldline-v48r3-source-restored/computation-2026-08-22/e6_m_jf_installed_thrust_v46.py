#!/usr/bin/env python3
"""v46 E6-M turbojet / aft-fan installed-thrust rebaseline.

Keeps v43 E6-M compressor identity (PR7, 14 kg/s jet high-flow trim) and
uses the v44 installed-accounting conventions for staged bleed, combustor
loss, accessory/mechanical debit and combustion efficiency. The jet model
then closes main-turbine compressor work, turbine-exit total state and a
convergent nozzle. JF adds a separate free-LP-turbine/fan spool.

This is an engineering audit model, not a detailed map solver.
"""
from __future__ import annotations
import csv, math
from pathlib import Path

# shared v44/v43 coordinates
T0 = 288.0
P0 = 101.325  # kPa
R = 0.287      # kJ/(kg K)
CP_A = 1.005   # kJ/(kg K)
GAMMA_A = 1.4
CP_G = 1.10    # hot-gas effective cp, kJ/(kg K)
GAMMA_G = 1.33
PR_C = 7.0
ETA_C = 0.84
INLET_RECOVERY = 0.99
COMBUSTOR_DP = 0.03
ETA_COMB = 0.987
LHV = 43000.0  # kJ/kg
ETA_MAIN_T = 0.84
ETA_MAIN_MECH = 0.993
ACCESSORY = 1.2  # kJ/kg inlet air
ETA_NOZZLE = 0.94
FLOW = 14.0      # kg/s E6-M jet high-flow trim

# v44 staged-compressor work at E6 non-Ni central coordinate.
# It is effectively insensitive to the small 4.5-5.3% bleed variation here.
WC_STAGED = 254.30  # kJ/kg inlet air


def t2_comp() -> float:
    a = (GAMMA_A - 1.0) / GAMMA_A
    return T0 * (1.0 + (PR_C ** a - 1.0) / ETA_C)


def nozzle(mdot: float, Tt: float, Pt_kpa: float, cp: float, gamma: float,
           eta_n: float = ETA_NOZZLE):
    """Convergent nozzle; includes pressure thrust when choked."""
    critical_ratio = (2.0 / (gamma + 1.0)) ** (gamma / (gamma - 1.0))
    if P0 / Pt_kpa <= critical_ratio:
        pe = Pt_kpa * critical_ratio
        Ts_ideal = Tt * 2.0 / (gamma + 1.0)
        v = math.sqrt(eta_n * 2.0 * cp * 1000.0 * (Tt - Ts_ideal))
        T_static = Tt - v * v / (2.0 * cp * 1000.0)
        rho = pe / (R * T_static)
        area = mdot / (rho * v)
        force = mdot * v + (pe - P0) * 1000.0 * area
        return force, v, pe, area, True
    Ts_ideal = Tt * (P0 / Pt_kpa) ** ((gamma - 1.0) / gamma)
    v = math.sqrt(eta_n * 2.0 * cp * 1000.0 * (Tt - Ts_ideal))
    return mdot * v, v, P0, 0.0, False


def gas_generator(tit_c: float, bleed: float, flow: float = FLOW):
    T2 = t2_comp()
    T3 = tit_c + 273.15
    # v44 fuel-energy convention: combustor air excludes bleed; q_fuel is per
    # kg inlet air and includes combustion inefficiency.
    q_fuel = (1.0 - bleed) * CP_A * (T3 - T2) / ETA_COMB
    f = q_fuel / LHV
    fuel = flow * f
    mdot_gas = flow + fuel

    P2 = P0 * INLET_RECOVERY * PR_C
    P3 = P2 * (1.0 - COMBUSTOR_DP)
    turbine_work_needed = (WC_STAGED + ACCESSORY) / ETA_MAIN_MECH  # kJ/kg inlet
    dT = turbine_work_needed * flow / (mdot_gas * CP_G)
    T4 = T3 - dT
    T4s = T3 - dT / ETA_MAIN_T
    P4 = P3 * (T4s / T3) ** (GAMMA_G / (GAMMA_G - 1.0))
    return dict(T2=T2, T3=T3, T4=T4, P4=P4, fuel_kg_s=fuel,
                gas_kg_s=mdot_gas, q_fuel_kJkg=q_fuel)


def pure_jet(tit_c: float, bleed: float, flow: float = FLOW):
    g = gas_generator(tit_c, bleed, flow)
    F, v, pe, area, choked = nozzle(g['gas_kg_s'], g['T4'], g['P4'], CP_G, GAMMA_G)
    kgf = F / 9.80665
    tsfc = g['fuel_kg_s'] * 3600.0 / kgf
    return {**g, 'thrust_kgf': kgf, 'tsfc_kg_kgfh': tsfc,
            'nozzle_v_m_s': v, 'nozzle_pe_kpa': pe, 'nozzle_area_m2': area,
            'nozzle_choked': choked}


def aft_fan(tit_c: float = 835.0, bleed: float = 0.0525, flow: float = FLOW,
            bpr: float = 1.0, fpr: float = 1.30, eta_fan: float = 0.80,
            eta_free_t: float = 0.82, fan_drive_eff: float = 0.97,
            bypass_duct_recovery: float = 0.96):
    g = gas_generator(tit_c, bleed, flow)

    # Fan is on a separate free-LP-turbine spool. Bypass stream does not enter
    # the gas-generator compressor.
    mb = flow * bpr
    Tfs = T0 * fpr ** ((GAMMA_A - 1.0) / GAMMA_A)
    Tf = T0 + (Tfs - T0) / eta_fan
    fan_dh = CP_A * (Tf - T0)
    fan_power = mb * fan_dh  # kW
    free_turbine_power = fan_power / fan_drive_eff

    dTft = free_turbine_power / (g['gas_kg_s'] * CP_G)
    T5 = g['T4'] - dTft
    T5s = g['T4'] - dTft / eta_free_t
    P5 = g['P4'] * (T5s / g['T4']) ** (GAMMA_G / (GAMMA_G - 1.0))

    Fc, vc, pec, ac, cc = nozzle(g['gas_kg_s'], T5, P5, CP_G, GAMMA_G)
    Pb = P0 * INLET_RECOVERY * fpr * bypass_duct_recovery
    Fb, vb, peb, ab, cb = nozzle(mb, Tf, Pb, CP_A, GAMMA_A)
    Ft = Fc + Fb
    kgf = Ft / 9.80665
    tsfc = g['fuel_kg_s'] * 3600.0 / kgf

    return {**g,
            'bpr': bpr, 'fpr': fpr, 'fan_dh_kJkg': fan_dh,
            'fan_power_kW': fan_power, 'free_turbine_power_kW': free_turbine_power,
            'free_turbine_dT_K': dTft, 'post_free_turbine_T_K': T5,
            'post_free_turbine_P_kPa': P5,
            'core_thrust_kgf': Fc / 9.80665, 'fan_thrust_kgf': Fb / 9.80665,
            'thrust_kgf': kgf, 'tsfc_kg_kgfh': tsfc,
            'core_nozzle_v_m_s': vc, 'fan_nozzle_v_m_s': vb,
            'core_nozzle_choked': cc, 'fan_nozzle_choked': cb}


def fan_geometry(m_bypass: float = 14.0, axial_v: float = 110.0,
                 hub_tip: float = 0.72, rho_face: float = 1.225,
                 fpr: float = 1.30, eta_fan: float = 0.80,
                 loading_psi: float = 0.46):
    area = m_bypass / (rho_face * axial_v)
    d_tip = math.sqrt(4.0 * area / (math.pi * (1.0 - hub_tip ** 2)))
    d_hub = hub_tip * d_tip
    Tfs = T0 * fpr ** ((GAMMA_A - 1.0) / GAMMA_A)
    Tf = T0 + (Tfs - T0) / eta_fan
    dh = CP_A * 1000.0 * (Tf - T0)
    U = math.sqrt(dh / loading_psi)
    rpm = 60.0 * U / (math.pi * d_tip)
    tip_mach_abs = math.sqrt(U * U + axial_v * axial_v) / math.sqrt(GAMMA_A * 287.0 * T0)
    return dict(m_bypass_kg_s=m_bypass, axial_velocity_m_s=axial_v,
                hub_tip_ratio=hub_tip, annulus_area_m2=area,
                tip_diameter_m=d_tip, hub_diameter_m=d_hub,
                loading_psi=loading_psi, tip_speed_m_s=U, rpm=rpm,
                tip_relative_mach=tip_mach_abs)


def main():
    outdir = Path(__file__).parent
    cases = []
    for name, tit, bleed in [
        ('E6-M-J-longlife-835', 835, .0525),
        ('E6-M-J-nonNi-870', 870, .0500),
        ('E6-M-N-J-Ni-920', 920, .0450),
    ]:
        r = pure_jet(tit, bleed)
        cases.append(dict(case=name, kind='pure-jet', TIT_C=tit, bleed_pct=bleed*100,
                          flow_kg_s=FLOW, bpr='', fpr='', thrust_kgf=r['thrust_kgf'],
                          core_thrust_kgf=r['thrust_kgf'], fan_thrust_kgf='',
                          tsfc_kg_kgfh=r['tsfc_kg_kgfh'], fuel_kg_h=r['fuel_kg_s']*3600,
                          main_turbine_exit_T_K=r['T4'], main_turbine_exit_P_kPa=r['P4'],
                          free_turbine_power_kW='', post_free_turbine_P_kPa=''))
    base_pure = pure_jet(835, .0525)
    for fpr in [1.25,1.30,1.35,1.40]:
        r = aft_fan(fpr=fpr)
        cases.append(dict(case=f'E6-M-JF-FPR-{fpr:.2f}', kind='aft-fan', TIT_C=835,
                          bleed_pct=5.25, flow_kg_s=FLOW, bpr=1.0, fpr=fpr,
                          thrust_kgf=r['thrust_kgf'], core_thrust_kgf=r['core_thrust_kgf'],
                          fan_thrust_kgf=r['fan_thrust_kgf'], tsfc_kg_kgfh=r['tsfc_kg_kgfh'],
                          fuel_kg_h=r['fuel_kg_s']*3600, main_turbine_exit_T_K=r['T4'],
                          main_turbine_exit_P_kPa=r['P4'], free_turbine_power_kW=r['free_turbine_power_kW'],
                          post_free_turbine_P_kPa=r['post_free_turbine_P_kPa']))
    for bpr in [.85,.90,1.10,1.15]:
        r = aft_fan(bpr=bpr, fpr=1.30)
        cases.append(dict(case=f'E6-M-JF-BPR-{bpr:.2f}', kind='aft-fan', TIT_C=835,
                          bleed_pct=5.25, flow_kg_s=FLOW, bpr=bpr, fpr=1.30,
                          thrust_kgf=r['thrust_kgf'], core_thrust_kgf=r['core_thrust_kgf'],
                          fan_thrust_kgf=r['fan_thrust_kgf'], tsfc_kg_kgfh=r['tsfc_kg_kgfh'],
                          fuel_kg_h=r['fuel_kg_s']*3600, main_turbine_exit_T_K=r['T4'],
                          main_turbine_exit_P_kPa=r['P4'], free_turbine_power_kW=r['free_turbine_power_kW'],
                          post_free_turbine_P_kPa=r['post_free_turbine_P_kPa']))

    path = outdir / 'E6-M-J-JF-INSTALLED-THRUST-V46.tsv'
    with path.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(cases[0]), delimiter='\t'); w.writeheader(); w.writerows(cases)

    geoms=[]
    for vx in [105,110,115,120]:
        for htr in [.70,.72,.74]:
            for psi in [.42,.46,.50]:
                geoms.append(fan_geometry(axial_v=vx, hub_tip=htr, loading_psi=psi))
    gpath = outdir / 'E6-M-JF-FAN-SIZE-V46.tsv'
    with gpath.open('w', newline='', encoding='utf-8') as f:
        w=csv.DictWriter(f, fieldnames=list(geoms[0]), delimiter='\t'); w.writeheader(); w.writerows(geoms)

    central = aft_fan()
    geom = fan_geometry()
    print('PURE 835', base_pure['thrust_kgf'], base_pure['tsfc_kg_kgfh'])
    print('PURE 870', pure_jet(870,.05)['thrust_kgf'], pure_jet(870,.05)['tsfc_kg_kgfh'])
    print('PURE 920', pure_jet(920,.045)['thrust_kgf'], pure_jet(920,.045)['tsfc_kg_kgfh'])
    print('JF CENTRAL', central)
    print('JF gain pct', 100*(central['thrust_kgf']/base_pure['thrust_kgf']-1))
    print('JF TSFC change pct', 100*(central['tsfc_kg_kgfh']/base_pure['tsfc_kg_kgfh']-1))
    print('FAN GEOM', geom)

if __name__ == '__main__':
    main()
