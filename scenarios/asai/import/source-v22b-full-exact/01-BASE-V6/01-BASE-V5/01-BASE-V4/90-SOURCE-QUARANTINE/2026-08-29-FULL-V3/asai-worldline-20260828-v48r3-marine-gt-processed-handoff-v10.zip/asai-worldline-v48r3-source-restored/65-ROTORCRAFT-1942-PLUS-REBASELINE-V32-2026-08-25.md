# 回転翼1942+再基底化 v32 — 2026-08-25

## 判定

- 旧「最初の中型レ号系=4–5.5t / 1,000–1,500shp」を撤回。
- 1942–43中央を約3.2t / 15m / E6-S-S 900shp連続・1,000shp短時間のprototype/service-testへ再基底化。
- 1942–45任務は連絡・担架・短距離貨物・艦上試験・目視ASW・発見通報・条件付き爆雷投下。
- 戦時の「停空＋吊下ソナーで精密定位しhunter-killer」は撤回。dipping sonar＋攻撃兵装は1950年代技術較正へ移す。
- 艦上常用は専用/準専用甲板から。VTOLを理由に任意小艦へ拡大しない。
- 1944限定生産readyは主減速機150–200h級TBO等のgate次第。発注/配備/戦果はHISTORY/FROZEN。
- 旧回転翼起点の海防艦/CVE建艦差分はhistory再OPENまで技術的裏付けを失った凍結シナリオとして保持。

正準親：`main/asai-works-rotorcraft-1942-plus-rebaseline-1942-55.md`。
