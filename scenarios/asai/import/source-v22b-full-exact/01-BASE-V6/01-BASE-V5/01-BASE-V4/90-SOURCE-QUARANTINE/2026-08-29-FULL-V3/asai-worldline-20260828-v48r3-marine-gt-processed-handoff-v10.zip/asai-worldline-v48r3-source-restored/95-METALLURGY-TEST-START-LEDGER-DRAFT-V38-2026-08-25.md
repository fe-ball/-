# 95 — Metallurgy Test-Start Ledger / v38 DRAFT

> Status: DRAFT / audit aid only. v37r1 remains canonical.
> Purpose: determine how much of the metallurgy long-duration learning clock was actually started early enough to support E4/E5/E6, without backfilling missing programs by assumption.
> Parent method: `90-CAPABILITY-CONVERGENCE-SCORING-FRAMEWORK-DRAFT-V38-2026-08-25.md`, `94-METALLURGY-TIME-HEADSTART-CONVERGENCE-DRAFT-V38-2026-08-25.md`.

## 0. Rule

For each material capability, separate four dates:

- **T_concept**: Asai can name the failure mode / useful test.
- **T_fixture**: a locally buildable apparatus / procedure exists.
- **T_start**: Asai actually begins systematic testing and retains comparable records.
- **T_mature**: the data are broad enough to change design allowables, process control, or qualification.

Only **T_start** starts the long-duration learning clock. A future-known concept is not test data; a one-off coupon is not a material database.

Evidence classes used here:

- **FIXED** — v37 canonical text already gives an actual start / operational activity.
- **IMPLIED** — canonical activities necessarily generate some useful data, but no dedicated program is stated.
- **OPEN** — plausible and historically/local-technically available, but not currently paid for in canon.
- **LATER FIXED** — explicit only at a later date; cannot be backdated without a v38 decision.

Historical chronology is a feasibility anchor, not an Asai ceiling. Early metal creep was scientifically studied by Andrade in 1910/1914; Japanese publications document high-temperature elastic testing in 1922, apparatus and tests up to 1000°C including fatigue/impact in 1928, and a 1000-hour constant-load creep machine in 1939. Therefore an Asai 1920s long-duration materials program is locally conceivable, but it must still be explicitly funded and operated in-world rather than assumed.

## 1. Baseline already paid before the creep question

| Capability | Canonical state | Earliest fixed evidence | Audit interpretation |
|---|---|---:|---|
| alloy selection / tool & special steels | FIXED | 1914 start; 1917–18 AH-1/AH-2 import-good class | strong L0/L1 metallurgy base exists before E1 |
| clean melting / heat treatment culture | FIXED/IMPLIED | 1917–19 special-steel business | process discipline exists; exact furnace atmosphere/chemistry database not fixed |
| mechanical testing culture | IMPLIED | 1917–19 | product claims require tensile/hardness/tool-life testing, but exact high-T suite not named |
| high-T turbine exposure | FIXED | E1 1921, then E2 | real components expose material to temperature/stress, but prototype exposure is not long-time creep qualification |
| service hot-section feedback | FIXED | turbo prototype 1923–24; practical 1925 | 450–550°C class rotating hot-section field data becomes continuous income-generating test source |
| statistical process control | FIXED | 1924 | makes heats/processes/defects comparable and turns failures into reusable process information |
| dedicated inspection organization | FIXED by organization | 1928 reorganization | inspection becomes independent institutional function; specific NDT methods still need their own start dates |

This is already a powerful stack. It justifies better materials learning than an isolated laboratory, but it does **not** by itself prove that 800–940°C stress-rupture curves were being accumulated since 1921.

## 2. Test-start ledger

### 2.1 High-temperature tensile / short-time strength

- **T_concept:** ≤1919 — future knowledge makes the need obvious.
- **T_fixture:** plausibly 1919–22; Japanese high-temperature elastic test apparatus is documented in 1922.
- **T_start current canon:** **IMPLIED, not fixed**. Special-steel + E1 work makes some elevated-temperature testing almost unavoidable.
- **Candidate v38 T_start:** **1920–22**.
- **H_sat:** 2–3 y.
- **By E4 (1931–33):** TH essentially saturated if candidate is adopted.
- **Effect:** not a reason to raise TIT by itself; it strongly reduces the chance that E4/E5 are surprised by short-time strength loss.

**Audit judgment:** SAFE TO CANONICALIZE EARLY, provided it is described as ordinary furnace-loaded tensile/elastic testing rather than a future servo-hydraulic laboratory.

### 2.2 Creep / constant-load time-dependent deformation

- **T_concept:** ≤1919, certainly by E1 1921; protagonist knows hot rotating components fail by time, not merely yield stress.
- **T_fixture:** locally plausible by early 1920s: dead-weight / lever constant-load rigs + furnace + extensometry are conceptually simple compared with GT hardware.
- **T_start current canon:** **OPEN**. No v37 text explicitly says a systematic 100/300/1000 h creep program begins in the early 1920s.
- **Candidate v38 T_start:** **1921–24**, initially crude constant-load comparative rigs.
- **Candidate staged maturity:** 1924–27 repeatable multi-temperature series; 1928–32 heat/process comparisons; 1932+ stress-rupture/TBO-oriented datasets.
- **H_sat:** 8–12 y.
- **By E4 (1931–33):** 7–12 years of data if started 1921–24 — enough to change alloy/process ranking and conservative life bands.
- **By E5 (1934–37):** 10–16 years — mature comparative database for existing alloy families, though not a modern Larson–Miller law supplied from nowhere.

**Audit judgment:** THIS IS THE KEY REOPEN LEVER FOR E4/E5 LIFE. Do not raise life until v38 explicitly establishes T_start and the number of parallel rigs / temperatures / stresses.

### 2.3 Oxidation / hot corrosion mass-change testing

- **T_concept:** ≤1919–21.
- **T_fixture:** simple furnace exposure + weighing/metallography; locally easy.
- **T_start current canon:** **IMPLIED** by E1/E2 and especially 1923–25 service turbo, but no dedicated coupon program stated.
- **Candidate v38 T_start:** **1920–23**.
- **H_sat:** 4–6 y.
- **By E4:** should be mature for plain oxidation ranking of then-current steels.
- **Effect:** supports early recognition that composition/coating/surface condition and fuel ash are separate levers; does not automatically solve vanadium/hot-corrosion chemistry at much higher temperatures.

**Audit judgment:** LOW-COST EARLY PROGRAM; likely should be made explicit.

### 2.4 Thermal cycling / thermal fatigue

- **T_concept:** ≤1921.
- **T_fixture:** furnace cycling / burner rigs; simple versions are local.
- **T_start current canon:** **OPEN/weakly implied** by repeated E-engine and turbo starts/stops.
- **Candidate v38 T_start:** **1922–25** for coupons and simple components; full blade/root geometry later.
- **H_sat:** 5–8 y.
- **By E4:** useful comparative ranking; by E5, process-sensitive thermal-cycle database can be substantial.
- **Effect:** improves crack-origin knowledge, fillet/root design, heat-treatment selection, and inspection intervals more than peak TIT.

**Audit judgment:** strong candidate for explicit early start; product start/stop data alone are too confounded to count as a controlled program.

### 2.5 Rotating fatigue / blade-root / disk fatigue

- **T_concept:** E1 era.
- **T_fixture:** spin rigs and resonance/fatigue rigs scale with machinery capability; Asai already builds rotating machinery.
- **T_start current canon:** **IMPLIED** but not date-fixed.
- **Candidate v38 T_start:** **1921–24** simple overspeed/spin + coupon fatigue; **1925–29** systematic root/disk/component fatigue.
- **H_sat:** 5–8 y.
- **Effect:** may materially improve E3–E5 rotor reliability, inspection intervals, notch/radius practice, and allowable stress distribution.

**Audit judgment:** likely earlier than current prose makes visible; worth canonicalizing because this is protagonist-core machinery, not a peripheral computer field.

### 2.6 Metallography / failure-section archive

- **T_concept:** from special-steel business.
- **T_start current canon:** **IMPLIED STRONGLY** by alloy/heat-treatment business and 1924 control-chart culture.
- **Candidate v38 T_start:** **1917–20**, then linked to turbine failures from 1921.
- **Effect:** exceptionally high development gain (Gd/Gq) for low cost: heat number → microstructure → process → failure mode can be connected.

**Audit judgment:** should be treated as paid early unless contradictory text appears.

### 2.7 X-ray industrial radiography

- **T_concept:** future knowledge early.
- **T_fixture:** X-ray equipment exists; industrial practice is historically early but costly/specialized.
- **T_start current canon:** **OPEN**. `kufu-shu` says industrial radiography / magnetic particle are 1920s–30s feasible, but does not state Asai adoption year.
- **Candidate v38 T_start:** **1925–30** for high-value castings/welds, not universal inspection.
- **Effect:** raises Gq/yield by rejecting hidden defects and, more importantly, correlating reject type with process variables.

**Audit judgment:** do not silently set 1923. Needs a specific adoption decision and likely shared/contracted equipment initially.

### 2.8 Magnetic-particle inspection

- **T_start current canon:** **OPEN**.
- **Candidate v38 T_start:** late 1920s / early 1930s for ferromagnetic shafts/gears/disks.
- **Effect:** large on fatigue-critical rotating hardware; low relation to thermodynamic performance.

**Audit judgment:** likely an early high-value adoption once method is locally available; give priority over exotic inspection because it directly serves engine shafts/gears.

### 2.9 Investment casting / lost-wax turbine parts

- **T_concept:** early; process family itself ancient.
- **T_start current canon:** **OPEN** for turbine blades. `kufu-shu` lists it as an available trick but does not fix Asai's turbine application year.
- **Candidate v38 start:** **mid/late 1920s coupon/small-part experiments**, with actual high-temperature alloy blade process maturing in the 1930s.
- **H_sat:** 3–5 y for process repeatability, but every major alloy/geometry resets part of the clock.
- **Effect:** not merely shape freedom; controls cooling-passage feasibility, wall thickness, defect population, and therefore Gq.

**Audit judgment:** should not be used to improve E2/E3 life until the turbine-specific process start is paid explicitly.

### 2.10 Hollow / cooled blade coupons and passages

- **T_concept:** protagonist can know from the start that cooling substitutes for some material capability.
- **T_fixture:** crude drilled/fabricated passages can precede mature cast hollow blades.
- **T_start current canon:** **OPEN**. Hollow air cooling is part of the general trick compendium, but no early program date is fixed.
- **Candidate v38 sequence:**
  - **1925–28:** stationary coupon / vane / drilled or fabricated passage heat-transfer rigs;
  - **1929–33:** rotating simple cooled blade/component tests;
  - **1933–37:** manufacturing-controlled hollow-blade process;
  - later: high-yield E7/E8 passages and full metal-temperature maps.
- **Effect:** potentially large on E5+ TIT/life but strongly thresholded by passage repeatability and inspection.

**Audit judgment:** this is a major v38 decision. Future knowledge can start it early, but useful rotating hardware still requires a decade-scale manufacturing learning curve.

### 2.11 Diffusion / ceramic / protective coatings

- **T_start current canon:** **OPEN** for turbine-hot-section systematic use.
- **Candidate v38 start:** late 1920s / early 1930s comparative coupon work; component qualification later.
- **Effect:** oxidation margin and material substitution; does not create creep strength.

**Audit judgment:** separate oxidation protection from bulk creep strength. This prevents coating from becoming a magic TIT bonus.

### 2.12 Ni / non-Ni two-track material ladder

- **Current canon:** **LATER FIXED** as an explicit policy by mid/late 1930s; 1934 timeline already has high-Cr non-Ni work, 1938 allocates Ni line to best engines.
- **Earlier ingredients:** Ni procurement/stockpiling from 1926; special-steel competence from 1914–19.
- **Candidate v38 reinterpretation:** experimental alloy comparison can start earlier than formal strategic two-line policy. Do not backdate the mature two-line production organization automatically.
- **Effect:** allows data reuse before embargo pressure, especially if creep/oxidation programs are already running.

**Audit judgment:** distinguish **experimental ladder start** from **formal dual production line**.

## 3. Fixed / implied / absent summary

| Program | v37 status | Candidate T_start | Confidence for early adoption | Primary payoff |
|---|---|---:|---|---|
| special steel / heat treatment | FIXED | 1914–19 | very high | base metallurgy |
| metallography/failure archive | strongly implied | 1917–20 | high | Gd/Gq |
| high-T short-time strength | implied | 1920–22 | high | allowables |
| creep / stress rupture | **OPEN** | **1921–24** | medium-high | **E4/E5 life** |
| oxidation coupons | implied/open | 1920–23 | high | alloy/coating ranking |
| thermal cycling | open | 1922–25 | medium-high | crack/life behavior |
| rotor/component fatigue | implied/open | 1921–29 staged | high | rotor Gq |
| X-ray radiography | open | 1925–30 | medium | defect/yield |
| magnetic-particle | open | late 1920s–early 1930s | medium | shafts/disks fatigue |
| investment casting turbine process | open | mid/late 1920s experiment | medium | geometry/yield |
| cooled blade heat-transfer program | open | 1925–28 static; 1929–33 rotating | medium | E5+ TIT/life |
| coatings | open | late 1920s–early 1930s | medium | oxidation |
| formal Ni/non-Ni production policy | later fixed | 1934–38 | high | strategic line split |

## 4. E-generation consequences before changing any canonical number

### E1 (≤1921)

Do not add life from an invented long database. The protagonist can choose sensible materials, conservative stress, geometry, and inspection, but the long-duration clock has barely started. Existing early weakness remains desirable and causally correct.

### E2 (to ~1925)

If v38 fixes high-T tensile, oxidation, thermal-cycle, and creep programs at 1920–24, E2 gains mostly **development efficiency and fewer catastrophic wrong turns**, not a large headline TIT/life bonus. The practical turbocharger becomes an essential service-data source.

### E3 (1928–29)

This is the first generation that can benefit from several years of organized time-dependent material data. Reopen not the thermodynamic headline first, but:

- scatter of hot-section life;
- inspection interval;
- rotor/root defect rejection;
- confidence in derating curves.

### E4 (1931–33)

**First serious lifetime reopen candidate.** If creep starts by 1921–24, E4 has roughly 7–12 years of comparative exposure before qualification. That is enough to make its life prediction/process ranking materially better than a contemporary project starting the test clock late.

But this does not justify arbitrary thousands of hours. E4 still faces new geometry, higher stress, casting/welding defects, and higher gas temperature than the early turbo service regime.

### E5 (1934–37)

**Strongest candidate for a revised life band.** A 1921–24 creep start gives 10–16 years of long-duration data, plus a decade of turbo service, statistical process control, and increasingly systematic fatigue/oxidation work. The plausible v38 correction is therefore:

- narrower scatter;
- higher lower-bound / qualification life;
- better derating-life trade;
- better heat/process rejection rules;
- fewer late redesign loops.

It is **not yet justified** to change the canonical numeric TBO/life until the next ledger converts test volume and failure clocks into an explicit lower/median/upper band.

### E6–E8

For old failure phenomena the head-start is largely saturated. Their new gates are technologies that reset part of the clock:

- new alloy families;
- hollow/cooling passage manufacturing;
- hotter disk/root/vane regimes;
- coatings;
- much higher PR and transient cycles;
- new joining/casting routes.

Thus v38 should not let a 1922 creep program magically make E8 fully mature. It makes Asai much better at **recognizing, modeling, and qualifying** the new failure modes, but the new hardware still needs real duration.

## 5. Recommended v38 canonicalization package (not yet applied)

If the worldline accepts the early-test premise, canonicalize the **program starts**, not an instant performance bonus:

1. 1919–22: high-T tensile/elastic, metallography, oxidation comparison becomes part of the special-steel laboratory.
2. 1921–24: simple constant-load creep rigs and rotor fatigue/spin rigs begin alongside E1/E2.
3. 1923–25: turbocharger field returns are serial-numbered by heat/process and fed into the material archive.
4. 1924+: control charts are applied to heats, heat treatment, life tests, and defect classes—not only production dimensions.
5. 1925–30: dedicated thermal-cycle rigs, high-value radiography, turbine lost-wax experiments, stationary cooling-passage tests begin.
6. 1928–33: rotating cooled-component tests and more systematic NDT/fatigue integration.
7. 1934–38: formal Ni/non-Ni strategic two-line program emerges from the earlier experimental ladder.

This preserves the protagonist's role: he recognizes **which long clocks must be started before demand arrives**, funds the apparatus, and insists on comparable records. He does not receive future alloys or future furnaces from nowhere.

## 6. Decision

**P0 v38 finding:** the current canon under-documents the metallurgy time head-start. It contains enough early special-steel, turbine, turbocharger, QC, and organization history to make an early long-duration materials program highly natural, but does not yet explicitly pay for the crucial 1921–24 creep/thermal-cycle clocks.

Therefore:

- **Do not change E4/E5 life numbers yet.**
- **Do create an explicit early materials-test-program canon before re-rating them.**
- After that, compute E4/E5 life as lower-bound / median / upper engineering bands, with new-tech clock resets kept separate.

