# v24 横断技術閉鎖 — 計算機導入後の再伝播と戦車再基底化

## 1. semantic delta

v24は、v23でOPENへ再編した横断論点のうち、技術成立性を一巡させる。

閉鎖対象：

- 専用/現場搭載計算器、射撃指揮、光学/写真偵察。
- 水上戦闘機、水偵、飛行艇、晴嵐/伊400のwet/TP統合。
- 上陸舟艇・重大発・水陸両用輸送のvehicle↔craft feedback。
- 潜水艦残件のphenolic quieting、battery/motor/trim計算、Asai-linked receiver electronics。
- E6/E7 turboprop part-load mapと長距離多発機のengine-shutdown cruise。
- 九三/九五/九一式魚雷、航空雷撃投下包絡・照準補助。
- 九七式チハ→過給チハ→47mm新砲塔→一式中戦車チヘの計算/QC再基底化。

戦史/OOBは進めない。実際の戦果、配備数、太平洋初戦の航空隊比率、潜水艦作戦、戦車部隊戦果はFROZEN。

## 2. 主要正本

- `main/asai-works-cross-domain-computation-fire-optics.md`
- `main/asai-works-seaplane-flyingboat-rebaseline-1940-44.md`
- `main/asai-works-amphibious-landing-system-1938-44.md`
- `main/asai-works-seiran-i400-tp-integration-1942-44.md`
- `main/asai-works-turboprop-part-load-long-range.md`
- `main/asai-works-torpedo-air-attack-rebaseline-1938-44.md`
- `main/asai-works-tank-computation-rebaseline-1938-41.md`

## 3. 重要な修正

- E6-Mの設計点BSFCを低負荷へ固定適用しない。深山一一型の内部航続を下方修正し、E7長距離flat-rated＋一/二発停止巡航を後続本命とする。
- 水上機の封止は単なる寿命ではなく、海上基地での状態再現性・稼働率へ質的に効く。
- 強風は二重反転propellerを初期から捨て、500–505km/h級。火星21/23級強風改は525–535km/h級の技術上限候補。
- 紫雲は「全部盛り」を救済せず、固定低抗力補助float＋実機試験を通した非常主float投棄を中央とする。
- 九一式は最高水中速度を盛らず、1941→42→44で実用投下envelopeを広げる。
- 戦車は200hp連続/220hp戦闘増力のチハを中央とし、220–240hp試験車で伝動/冷却を壊してチヘ240/260へ返す。
- チヘの世代差は50mm装甲だけでなく、視察、全車radio設計前提、intercom、電動粗旋回、余裕ある3人砲塔による「車長が戦車長の仕事をできる」ことに置く。

## 4. 次の技術OPEN

v24後は「技術を全部先に閉じる」方式をやめ、歴史/OOBを進めて因果上必要になった個別技術だけ再度開く。

優先OPEN候補：

- E6/E7 compressor mapの実曲線、propeller/gear個別値（P2）。
- radio/radar reliability、mine/sweeping、survey/artillery meteorology等、歴史側で必要になったとき。
- 75mm砲塔戦車以後、1942+の車両枝は戦況要求が立ってから。

