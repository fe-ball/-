# Marine GT V7 — explicit test-craft takeoff, LL20 design duty, and Taiyo integration correction

## 1. Discipline carried forward

V7 continues the rule established in V3–V6: protagonist future knowledge changes **which clocks start early, which experiments are built, and which dead ends are skipped**. It does not apply a numerical multiplier to efficiency, mass, life or build time. Historical/later analogue machinery remains sanity/reference material unless the worldline itself has earned the component.

The terminology rule also remains: do not call a field "mature" as a blanket judgement. Record what has actually closed: map, environment, endurance hours, production repeatability, role qualification, etc.

## 2. E5 qualification craft: what is now closed

V7 builds an explicit fixed-hardware takeoff instead of importing the old Gatric kg/kW line. The selected new GT/test hardware totals **1.001–1.421 t**, central **1.199 t**, before GT sprint fuel. The central added-hardware longitudinal centroid is about **6.17 m forward of the transom**, because the engine/test bay is deliberately placed near the desired running LCG while the shaft/stern gear extends aft.

If one performs the deliberately conservative bookkeeping operation `historical 20.5 t full load + every new V7 item`, without crediting deleted live torpedoes/launch gear or replaced structure, the result is only about **21.61–22.08 t**. This is not the selected displacement; it is a bound demonstrating that the old 25–27 t target was not required by the corrected one-GT architecture.

The qualification article is therefore treated as a **controlled ballast laboratory**. It can be weighed/inclined as built, then trialled at several displacement/LCG points. At 2,800 hp total, retaining the First-Type-derived Crouch coefficient only as a scheduling sensitivity, the 20.5–22.5 t test matrix corresponds roughly to mid-40s knot clean-water trial values. Actual speed/C is earned in tank and sea trials.

## 3. Correction to V6 no-free-lunch wording

V6 correctly stated that the ship's required propulsive power does not fall merely because the cores are larger. But V6's table treated every module count as though a core could be sized continuously to the exact duty point, making total core airflow invariant.

That is not the real 10-module fallback. Ten modules use the already-defined **13.2 kg/s E6-M product**, so they install **132 kg/s of design-flow capacity**. Six LL20 modules are a new demand-sized family around **20–21 kg/s each**, so their installed design flow is around 120–126 kg/s. The difference is a **product-granularity tax** paid by the existing-core fallback, not a thermodynamic scale bonus for LL20.

## 4. LL20 R2 duty is refined

For R2 drawing work V7 chooses an explicit design sensitivity: **3% propulsive reserve above the present cube-law increment** and **95% engine-flange-to-prop-shaft retention as an acceptance target**. At fixed E6 installed specific work, this produces **20.561 kg/s and 3599 hp per core** for the 6-module / 3+3 branch.

The first-order E6-M similarity coordinates then become about **0.485 m inlet tip diameter, 109 mm front blade height and 10.82 krpm gas-generator speed**. These are drawing start points only. PR7, stage-load philosophy and release margins come from E6; large-hot casing distortion, exact compressor map, criticals, combustor pattern and endurance remain new R2 clocks.

The free-power-turbine exploration band is placed around **9.1–10.9 krpm** by same-tip scaling from the already-closed E5 free-turbine family. Again, this chooses a sensible test region; the LL20 PT must earn its own map/vibration/overspeed result.

## 5. Taiyo 6 vs 10 becomes an integration trade, not a cycle trade

With a 3% propulsive reserve and a 95% path target:

- 6 LL20 requires about **3599 hp / 20.56 kg/s per core**;
- 10 canonical E6-M requires about **2160 hp per core**, between the present 2,100 hp continuous headline and 2,300 hp short/sprint capability.

Therefore the 10-core fallback is not blocked by thermodynamics, but it needs a named marine boost-role rating/clock and carries ten sets of starters, controls, free turbines, clutches and gear inputs. The 6-core branch carries the expensive new-core R2/P tax but reduces those interfaces to six.

At equal half-ship power the final gear/bull-wheel torque is essentially common. The differentiator is whether the designer handles **three larger intermediate pinions per shaft or five smaller ones**, plus the different number of intake/exhaust penetrations and maintenance-removal paths.

V7 deliberately does not invent Taiyo's propeller-shaft rpm or machinery-room frame coordinates. Those are now explicit missing inputs for final tooth counts, bull-wheel diameter and routing drawings.
