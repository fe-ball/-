#!/usr/bin/env python3
from __future__ import annotations
import csv, math
from pathlib import Path

OUT = Path(__file__).parent
HP_KW = 0.745699872
RHO_SL = 1.225
GAMMA = 1.4
R_AIR = 287.0
T_SL = 288.0
CP = 1.005
PR = 7.0
ETA_C = 0.84
E6_FLOW = 13.2
E6_RPM = 13500.0
E6_TIP_D = 0.389
E6_BLADE_H = 0.0875
W_INST = 130.5427 # kJ/kg, v44 pre-product-output-transmission installed shaft work
V44_T_OUTPUT = 0.975
BSFC = 0.372 # kg/kWh, v44 central cycle-model planning value
LHV = 43.0 # MJ/kg
TAIYO_BASE_SHP = 25200.0
TAIYO_BASE_KT = 21.0
TAIYO_TARGET_KT = 25.5
SHIP_RESERVE = 1.03


def write_tsv(name, rows):
    p=OUT/name
    with p.open('w', encoding='utf-8', newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()), delimiter='\t')
        w.writeheader(); w.writerows(rows)
    return p

# Taiyo power requirement, same cube-law sensitivity used by V4-V8.
total_req = TAIYO_BASE_SHP * (TAIYO_TARGET_KT/TAIYO_BASE_KT)**3
inc_req = total_req - TAIYO_BASE_SHP
prop_boost_with_reserve = inc_req * SHIP_RESERVE

# LL20 R2 duty selected in V7 (95% all-in PT-shaft -> prop-shaft path)
path_sel=0.95
ll_raw_hp = prop_boost_with_reserve/path_sel/6.0
ll_raw_kw = ll_raw_hp*HP_KW
ll_flow = ll_raw_kw/W_INST
flow_ratio=ll_flow/E6_FLOW
D_scale=math.sqrt(flow_ratio)
ll_tip=E6_TIP_D*D_scale
ll_bh=E6_BLADE_H*D_scale
ll_hub=ll_tip-2*ll_bh
annulus=math.pi/4*(ll_tip**2-ll_hub**2)
axial_v=ll_flow/(RHO_SL*annulus)
a=math.sqrt(GAMMA*R_AIR*T_SL)
ll_rpm=E6_RPM/D_scale
tip_speed=math.pi*ll_tip*ll_rpm/60
T2s=T_SL*PR**((GAMMA-1)/GAMMA)
T2=T_SL+(T2s-T_SL)/ETA_C
comp_work=CP*(T2-T_SL)
comp_power=ll_flow*comp_work/1000
fuel_kg_h=ll_raw_kw*BSFC
fuel_kg_s=fuel_kg_h/3600
thermal_MW=fuel_kg_s*LHV
net_MW=ll_raw_kw/1000
nonshaft_MW=thermal_MW-net_MW

ll_rows=[
 dict(metric='Taiyo total cube-law shaft requirement',value=f'{total_req:.3f}',unit='shp',status='DERIVED',note='Same historical-anchor cube-law sensitivity used previously; not an achieved speed claim.'),
 dict(metric='Taiyo incremental boost requirement',value=f'{inc_req:.3f}',unit='shp',status='DERIVED',note='25.5 kt target minus historical 25,200 shp base.'),
 dict(metric='Incremental boost with explicit 3% reserve',value=f'{prop_boost_with_reserve:.3f}',unit='prop-shp',status='DERIVED',note='Reserve is explicit engineering sensitivity, not hidden performance.'),
 dict(metric='LL20 R2 raw free-power-turbine shaft duty',value=f'{ll_raw_hp:.3f}',unit='hp/core',status='DERIVED R2 DUTY',note='Six modules, 95% all-in PT-shaft to prop-shaft path target.'),
 dict(metric='LL20 R2 raw shaft duty',value=f'{ll_raw_kw:.3f}',unit='kW/core',status='DERIVED R2 DUTY',note='Same point in SI units.'),
 dict(metric='LL20 corrected flow',value=f'{ll_flow:.3f}',unit='kg/s',status='DERIVED R2 DUTY',note='Uses v44 pre-product-output-transmission installed shaft work 130.5427 kJ/kg; no scale-efficiency bonus.'),
 dict(metric='flow ratio vs E6-M',value=f'{flow_ratio:.5f}',unit='ratio',status='R0 SIMILARITY',note='Only a geometry-starting ratio.'),
 dict(metric='diameter scale vs E6-M',value=f'{D_scale:.5f}',unit='ratio',status='R0 SIMILARITY',note='sqrt(flow ratio) at same first-order inlet velocity/density.'),
 dict(metric='first-order inlet tip diameter',value=f'{ll_tip:.4f}',unit='m',status='R0 SIMILARITY',note='Drawing start only; full-core map can move annulus.'),
 dict(metric='first-order inlet hub diameter',value=f'{ll_hub:.4f}',unit='m',status='R0 SIMILARITY',note='Same E6-M hub/tip geometry at R0.'),
 dict(metric='first-order inlet blade height',value=f'{ll_bh*1000:.2f}',unit='mm',status='R0 SIMILARITY',note='Radial blade height.'),
 dict(metric='first-order inlet annulus area',value=f'{annulus:.5f}',unit='m2',status='R0 SIMILARITY',note='Derived from tip/hub diameters.'),
 dict(metric='first-order inlet axial velocity',value=f'{axial_v:.2f}',unit='m/s',status='R0 SIMILARITY',note='Sea-level density; preserves E6-M inlet velocity family.'),
 dict(metric='first-order inlet Mach',value=f'{axial_v/a:.3f}',unit='Mach',status='R0 SIMILARITY',note='Sea-level 288 K acoustic speed; not a measured inlet distortion result.'),
 dict(metric='same-tip GG speed starting point',value=f'{ll_rpm:.1f}',unit='rpm',status='R0 SIMILARITY',note='Rotor dynamics may move it; not an acceptance rpm.'),
 dict(metric='tip-speed check',value=f'{tip_speed:.2f}',unit='m/s',status='R0 CHECK',note='Approximately preserves E6-M ~275 m/s coordinate.'),
 dict(metric='compressor specific work at PR7 eta_c=0.84 target',value=f'{comp_work:.3f}',unit='kJ/kg',status='RELEASE-TARGET CONSEQUENCE',note='eta=0.84 is a release criterion, not assumed achieved efficiency.'),
 dict(metric='full compressor aerodynamic power at selected flow',value=f'{comp_power:.3f}',unit='MW',status='FACILITY CONSEQUENCE',note='Shows why a standalone full-flow motor-driven map is a >5 MW-class proposition; R1 stage/annulus rigs plus self-powered R2 full-core map are the information-efficient route.'),
 dict(metric='cycle-model fuel flow at R2 raw duty',value=f'{fuel_kg_h:.1f}',unit='kg/h',status='PLANNING SENSITIVITY',note='Uses v44 central BSFC 0.372 kg/kWh; actual R2 fuel flow must be measured.'),
 dict(metric='fuel LHV thermal input at R2 duty',value=f'{thermal_MW:.3f}',unit='MW',status='PLANNING SENSITIVITY',note='Facility heat/exhaust sizing input, not an efficiency claim beyond v44 cycle model.'),
 dict(metric='non-shaft heat/exhaust balance',value=f'{nonshaft_MW:.3f}',unit='MW',status='PLANNING SENSITIVITY',note='Fuel LHV input minus raw shaft output; site cooling/exhaust must dispose of this order of heat.'),
]
write_tsv('LL20-R2-V9.tsv', ll_rows)

# E6-M power station accounting for Taiyo 10-module fallback.
e6_raw_kw=E6_FLOW*W_INST
e6_raw_hp=e6_raw_kw/HP_KW
std_headline=2100.0
short_headline=2300.0
std_raw_equiv=std_headline/V44_T_OUTPUT
short_raw_equiv=short_headline/V44_T_OUTPUT
power_rows=[]
for path in (0.93,0.95,0.97):
    raw_req_hp=prop_boost_with_reserve/path/10
    raw_req_kw=raw_req_hp*HP_KW
    v44_equiv=raw_req_hp*V44_T_OUTPUT
    power_rows.append(dict(
        path_retention=f'{path:.2f}',
        raw_PT_required_hp=f'{raw_req_hp:.3f}',
        raw_PT_required_kW=f'{raw_req_kw:.3f}',
        v44_T_output_equivalent_hp=f'{v44_equiv:.3f}',
        delta_vs_2100_headline_pct=f'{(v44_equiv/std_headline-1)*100:.3f}',
        raw_margin_to_E6M_central_pct=f'{(e6_raw_hp/raw_req_hp-1)*100:.3f}',
        ten_core_fuel_plan_t_h=f'{raw_req_kw*BSFC*10/1000:.3f}',
        note='v44 2100/2300 headlines include 0.975 T-product output transmission; Taiyo path is treated separately from raw free-power-turbine shaft to prop shaft.'
    ))
write_tsv('E6M-MARINE-BOOST-ACCOUNTING-V9.tsv', power_rows)

# Common interface envelope using existing V7 geometry equations.
def intake_area(flow, face):
    return flow/(RHO_SL*face)

def exhaust_area(flow, temp_c, velocity=35.0):
    rho=101325/(R_AIR*(temp_c+273.15))
    return flow/(rho*velocity)

common_rows=[]
# Intake maxima between 6x LL20 and 10x E6M
for face in (12,15,18):
    a6=intake_area(ll_flow*6,face); a10=intake_area(E6_FLOW*10,face)
    common_rows.append(dict(interface='intake clear area',condition=f'{face} m/s face velocity',six_LL20=f'{a6:.3f}',ten_E6M=f'{a10:.3f}',common_envelope=f'{max(a6,a10):.3f}',unit='m2/ship',per_shaft_bank=f'{max(a6,a10)/2:.3f}',status='DERIVED GEOMETRY',note='Common plenum clear-area envelope; measured separator loss still gates final trunk size.'))
for temp in (400,475,550):
    a6=exhaust_area(ll_flow*6,temp); a10=exhaust_area(E6_FLOW*10,temp)
    common_rows.append(dict(interface='exhaust flow area',condition=f'{temp} C / 35 m/s',six_LL20=f'{a6:.3f}',ten_E6M=f'{a10:.3f}',common_envelope=f'{max(a6,a10):.3f}',unit='m2/ship',per_shaft_bank=f'{max(a6,a10)/2:.3f}',status='THERMAL GEOMETRY SENS',note='First-order gas-density geometry only; measured back-pressure and exhaust temperature remain gates.'))
# Common boost-load and fuel-service consequences
raw_half_hp=ll_raw_hp*3
raw_half_kw=raw_half_hp*HP_KW
torque_1200=raw_half_kw*1000/(2*math.pi*1200/60)/1000
common_rows += [
 dict(interface='raw boost power before final ship-path losses',condition='per shaft bank',six_LL20=f'{raw_half_kw:.3f}',ten_E6M=f'{raw_half_kw:.3f}',common_envelope=f'{raw_half_kw:.3f}',unit='kW',per_shaft_bank=f'{raw_half_kw:.3f}',status='DERIVED INVARIANT @95% BRANCH',note='Equal half-ship boost work before final path loss.'),
 dict(interface='intermediate torque load comparison',condition='1,200 rpm intermediate',six_LL20=f'{torque_1200:.3f}',ten_E6M=f'{torque_1200:.3f}',common_envelope=f'{torque_1200:.3f}',unit='kN m/shaft bank',per_shaft_bank=f'{torque_1200:.3f}',status='DERIVED LOAD',note='Architecture changes number of pinions, not total half-ship torque at equal raw boost power.'),
 dict(interface='fuel feed planning rate',condition='full boost / v44 central BSFC sensitivity',six_LL20=f'{fuel_kg_h*6/1000:.3f}',ten_E6M=f'{max(float(r["ten_core_fuel_plan_t_h"]) for r in power_rows):.3f}',common_envelope=f'{max(fuel_kg_h*6/1000,max(float(r["ten_core_fuel_plan_t_h"]) for r in power_rows)):.3f}',unit='t/h ship',per_shaft_bank=f'{max(fuel_kg_h*6/1000,max(float(r["ten_core_fuel_plan_t_h"]) for r in power_rows))/2:.3f}',status='PLANNING SENSITIVITY',note='Fuel-system flow envelope only; actual BSFC and duty cycle measured locally.'),
]
write_tsv('TAIYO-COMMON-INTERFACE-V9.tsv',common_rows)

print('WROTE V9 computation tables')
print(f'LL20 flow={ll_flow:.6f} kg/s, raw={ll_raw_hp:.3f} hp, Dtip={ll_tip:.4f} m, rpm={ll_rpm:.1f}')
print(f'E6 raw central={e6_raw_hp:.3f} hp; 2100 headline raw-equivalent={std_raw_equiv:.3f} hp; 2300 raw-equivalent={short_raw_equiv:.3f} hp')
