# 計算機・計算文化マスター索引（2026-08-22）

> **v25追補（2026-08-24）**：戦車側は `main/asai-works-tank-next-generation-conditional-1939-45.md` を追加。計算/QCを「未来性能の自動前倒し」でなく、現在要求・将来余裕・試験荷重・砲/機関/伝動のgateを分離する方法へ適用する。1942+の諸元はCONDITIONAL shadowであり、戦史/OOBへ自動反映しない。
>
> **v24追補（履歴）**：計算機の兵器内再伝播は `main/asai-works-cross-domain-computation-fire-optics.md`、`archive/aviation-pre-v48/v46-main/asai-works-turboprop-part-load-long-range.md`、`archive/aviation-pre-v48/v46-main/asai-works-torpedo-air-attack-rebaseline-1938-44.md`、`main/asai-works-tank-computation-rebaseline-1938-41.md` へ接続。大型計算所と専用現場器を分離し、命中/性能ボーナスではなく latency・workload・test/QC・integrationとして扱う。

本稿は2026-08-20仮置きと、その後の艦艇・民需・暗号・フェライト・磁気記憶・航空設計の検討を一本で辿るための索引。**2026-08-22 v4では下記4本を `main/` の正本へ昇格した。** 旧 `computation-2026-08-22/` は入力スナップショット、`provisional-2026-08-20/` は履歴である。

## 1. 出自

浅井計算部門は未来の電子計算機を突然作る計画ではない。

**手織り → 織機 → 動力化 → ジャカードカード → 手順を機械へ渡す文化**を祖業として、1923頃の機械式計算室から始まる。思想は「人間は例外を考え、反復手順は機械へ渡す」。

起点ではTiger等を大量購入し、一部を分解・電動化・連動試験で壊す。カード事務系列と技術計算系列は最初は別枝で、1925–27頃から人間が転記している中間値を機械的に繋ぎたくなり、順序制御へ向かう。

詳細: `main/asai-works-computation-origin-business.md`

## 2. 商売の四本柱

1930年代前半以降:

1. 最新高級科学計算機
2. 企業内リース・販売
3. 本土返却機を整備した中古/再生機（満州等）
4. 計算サービス・技師込み請負

普通の民間顧客を忘れない。保険、鉄道、港、海運、工場、造船、鉱山等が資金・データ・人材を供給する。

## 3. 計算の五配当

- 重量
- 出力/燃料
- 容積/重心
- 情報/精度
- 時間/産業

これらを全部重量へ換算しない。計算は横断的メタ技術で、Technique/Form → Design Architecture → Play → Real-world/Combat の全層へ段階的に届く。

## 4. 1923–45の技術階段

| 時期 | 主体 | 代表的な意味 |
|---|---|---|
| 1923–25 | 機械計算室 | 人間を並列化、腱鞘炎と転記を減らす |
| 1926–28 | カード＋機械計算 | 大量データと技術計算を同じ形式へ |
| 1929–31 | 電気機械・自動順序 | 中間結果を人間から少しずつ外す |
| 1932–34 | リレー制御 | 反復、比較、簡単な条件分岐 |
| 1935–37 | 大型リレー科学機 | 数十～数百案の設計探索 |
| 1938–40 | 真空管＋リレー＋初期磁気ドラム | 高速計数・反復、大容量作業記憶 |
| 1941–42 | 大型電子混成 | 大規模パラメータ走査 |
| 1943–45 | 電子＋磁気 | ENIAC級の生演算力＋大きい作業記憶・計算型資産 |

詳細: `main/asai-works-computation-machines-centers.md`

## 5. 最大単機だけで評価しない

1945最大機の生演算力はENIAC級に留める。一方、浅井の本当の差は:

- 同型/準同型機
- 旧式機
- カード処理機
- 異世代間の共通カード形式
- 計算型（ソフトウェア資産）
- スニーカー通信
- 前処理/検算/粗探索の分散

が一つの計算センターとして動くこと。

同一アルゴリズム一本勝負ならENIACと互角級でも、混合研究ジョブ、再設定、多数案探索、研究者との反復では実務ターンアラウンドが桁違いになりうる。

## 6. フェライト・暗号・磁気記憶

1930東工大フェライト発明 → 研究室時代から浅井が試料評価・測定を支援 → TDKは史実通り齋藤憲三中心で1935創業、浅井は初期大口顧客/技術スポンサー。工業化を何年も魔法のように前倒しせず、用途探索・測定・品質・艦載耐久を加速する。

暗号は海軍技研等との普通の官需契約から入り、担当サービス員に身辺調査、機密区画化。暗号機の機械信頼性と、暗号解析カード機の双方が育ち、結果として自軍方式を模擬攻撃する文化が自然に発生する。

フェライトは当初メモリではなく高周波コア、チョーク、ノイズ対策、磁気スイッチへ。1936以降の武井の磁気記録実験とTauschek型ドラムの世界史を繋ぎ、磁気ドラム → 小容量磁気状態保持 → 後年のコア記憶へ進む。

詳細: `main/asai-works-computation-ferrite-cipher-memory.md`

## 7. 航空への入口

1920年代末: 発動機・減速機・過給・プロペラ・燃料・重量重心。
1930–32: 風洞/翼型/性能データをカード化。
1932–35: 飛行試験データ処理、構造・空力の統合。
1934–38: フラッター・振動・冷却・多数案比較。
1937–39: 「計算を前提にした高出力機」へ。
1940年代: 動安定、過給/冷却、圧縮性、高高度、高速、試験→再設計のターンアラウンド短縮。

材料軽量化とは別会計にする。航空監査は `01-MATERIALS-MASTER-INDEX` のH/C/M/E/P/I/Aを使う。

詳細: `main/asai-works-computation-aviation-bridge.md`



## 7a. 発動機計算の社内起点（v6）

航空への入口を1920年代末から一括して読むのを改め、利用主体を分ける。

- **1923–24 浅井内部**：GT・過給機・歯車の反復四則、試験還元。C0＝「腱鞘炎軽減」。
- **1924–26**：カードはまず試験記録・分類・品質データ。演算本体はTiger級＋人。
- **1925–27**：入力票・演算順序・中間値・検算例を保存する「計算型」が成立。
- **1926–28**：多条件探索、既知法によるねじり振動粗探索へ。
- **1928–29以後 外販**：技術計算の受託・設備販売。ただし顧客の設計成熟には吸収遅延を置く。
- **軍・軍機**：外販・軍需メーカー内計算室・個別軍機計画を別段として扱い、1923の浅井内部能力を即時相続させない。

詳細: `main/asai-works-engine-computation-internal-1923-28.md`

## 7b. 発動機計算の外販・吸収（v7）

1928–34は「計算機が存在する」だけで外部発動機が即座に浅井内部C3化する、と読まない。

- **B0** 事務入口 → **B1** 技術受託 → **B2** 顧客内計算室 → **B3** 顧客固有計算文化。
- 外販先の利用成熟度は **U0–U4**。B2購入からB3へは1–3年級の吸収遅延を置く。
- 三菱A1–A3は救わず、A4を部分C世代として故障診断・系列学習へ配当。
- 中島寿は史実からして6か月突貫なので初試作を大幅に早めず、図面・検算・試験成熟へ配当。1933 NAMを中島初のU3級起点コアとする。
- 軍は事務、技術評価、安全区画、個別軍機設計を分離。軍中央の比較能力とメーカーの設計反復を二重計上しない。

詳細: `main/asai-works-engine-computation-externalization-1928-34.md`

## 7c. 発動機計算のU4成熟（v8）

1934–37は外販設備の存在から、顧客側が**計算前提の設計組織U4**へ移る段階。

- 三菱：A4故障系列を計算で救わず、A8/金星へ故障条件・比較型を移す。金星成立の暦を一年級で前倒ししない。
- 中島：1933 NAMをU3起点として育て、1936級にU4。ベンチ成熟/公式試験準備3–6か月級の余地はあるが、日程短縮分を耐久・燃費・冷却・図面へ再投資する。
- 瑞星：1937の二速試作は耐久未合格のまま。Cで故障地図は良くなるが、MQ/ES未監査で合格にしない。
- 軍：1935–36の評価側U3で、高度出力・燃費・温度・耐久・故障・P整合を同じ帳簿で比較。メーカー設計を代替しない。

発動機上流は `EH→EC→EMQ→ES→EI→EA`。詳細：`main/asai-works-engine-computation-maturation-1934-37.md`、`main/asai-works-engine-h-to-a-ledger.md`。

## 7d. 零戦顧客下の瑞星vs栄（v9）

1937–41は、計算文化U4が両社に入った後の**発動機系列競争**として扱う。

- 1939零戦初号の瑞星を史実A6M1用780 hp離昇型へ固定せず、1938実機のHa-26-I級900 hp枝をZ-900Nとして優先できる。
- 1939夏級のHa-26-II 940 hp枝はZ-940Nとして後続試験。
- 初期二速瑞星試作は耐久未合格を維持し、Ha-102/瑞星21級と混同しない。
- 1940主力EAは栄12。瑞星はA0-Z試験/予備枝として零戦顧客を保持。
- 1941はHa-102/瑞星21級をZ21NとしてS21と再比較。出力重量比はほぼ同等なので機体Iまで通す。
- exact BSFC差は未正準。栄の低燃料消費という定性錨だけを採る。

詳細：`main/asai-works-engine-competition-zuisei-sakae-1937-41.md`。

## 8. 競合処理（v4）

- 旧 `provisional-2026-08-20/01-...` の1937–45最大機性能は **superseded**。正本は `main/asai-works-computation-machines-centers.md`。
- ただし旧 provisional の「民間拡散」「差分を一律性能％にしない」「軍への段階的入口」は由来資料として保持し、正本と矛盾しない限り解釈補助に使える。
- 1945の浅井優位は単機の生演算速度ではなく、複数世代機・カード・ドラム・計算型・人員を束ねたセンター運用に置く。

## 9. 潜水艦水中系C（v21）

1939–41以後は、急速潜航を秒数一個でなくdepth/time・前進距離・pitch・overshoot・settlingのtrajectoryとして保存する。また振動/聴音/rpmを同期してOwn-Noise Mapを作り、quiet/avoid rpm帯を受領資料にする。batteryは容量だけでなくcycle/shock/H2/材料lotをcard化。正本=`main/asai-works-submarine-underwater-1938-43.md`。


## v23履歴: 設計室から現場搭載へ

[v24で技術P0閉鎖済み] 当時の次P0は、最大中央機の延長ではなく、限定目的の現場搭載計算器だった。機械式/電気機械式/リレー/真空管混成、電子化・非ラッチ化、入力transducer、表示/servo、電源、耐振動、湿気、EMI、製造数を含めて年代ゲートを引く。射撃・照準、光学/写真偵察、水上機/飛行艇、上陸システム、潜水艦trim/battery/motor/noiseが主要利用者候補。総合OPEN=`03-OPEN-ISSUES-2026-08-22.md` / `27-CROSS-DOMAIN-OPEN-QUEUE-V23-2026-08-23.md`。

## v24r2: 計算機統合後に残る再伝播

専用計算器・射撃/光学・水上航空・上陸・潜水艦残件・TP部分負荷・航空魚雷・Chi-Ha→Chi-Heはv24で技術P0閉鎖済み。現行の未更新/未決着は `36-POST-COMPUTATION-OPEN-AUDIT-V24R2-2026-08-24.md` を正本とし、特にE6凱風I、史実基準機H→Aの続行、TP個別完成機、radio/radar reliability等を区別する。


## v41 E4/E5 product resize computation

- `computation-2026-08-22/e4_e5_product_resize_p1.py` — v40 installed shaft coordinatesからE4/E5 product design flow、annulus一次寸法、working impeller/rpm、mass/fuelを再現。
- `computation-2026-08-22/E4-E5-PRODUCT-RESIZE-P1.tsv` — v41 P1-1再基線化の数値出力。


## v42 E4 regeneration installed computation

- `computation-2026-08-22/e4_regeneration_installed_v42.py` — v40 cooled installed accounting + v41 6.7kg/sへrecuperator両側圧損、effectiveness、UA、mass/volume、generator/bypass gateを追加。
- `computation-2026-08-22/E4-REGENERATION-INSTALLED-V42.tsv` — v42 P1-2 central / audit envelope / hardware coordinate。

## v43 E5/E6 compressor operability computation

- `computation-2026-08-22/e5_e6_compressor_operability_v43.py` — E5-S/E6-S/E6-Mのstage split、design corrected flow、tip/inlet一次寸法、qualification operating-line targetsを再現。
- `computation-2026-08-22/E5-E6-COMPRESSOR-OPERABILITY-V43.tsv` — v43 P1-3 architecture / surge / bleed / VIGV / clearance / rotordynamic acceptance coordinates。


## v44 E6 installed-cycle / product-power computation

- `computation-2026-08-22/e6_installed_cycle_product_power_v44.py` — PR7/TIT870/920/820にcooling bleed、combustor dp、exhaust margin、mechanical/accessory、output gearを払い、grossとinstalledを分離。
- `computation-2026-08-22/E6-INSTALLED-CYCLE-PRODUCT-POWER-V44.tsv` — E6 non-Ni/Ni/derateのspecific work、効率、BSFC、uncertainty envelope。
- `computation-2026-08-22/E6-PRODUCT-POWER-V44.tsv` — v43 flow identityからE6-S/E6-Mのflange powerと新headlineを再現。

## v45 E6-S aircraft H→A computation

- `computation-2026-08-22/e6_s_aircraft_ha_v45.py` — v44 1,300/1,500hp standard ratingsをv26 airframe anchorsへcube-root power scalingし、v44 BSFCでBreguet rangeを独立再検算。
- `computation-2026-08-22/E6-S-AIRCRAFT-SPEED-SCALING-V45.tsv` — 天山/Ki-40 standardおよびhigh-flow shortの速度再伝播。
- `computation-2026-08-22/E6-S-ALTITUDE-POWER-SHADOW-V45.tsv` — 1,300/1,500hpへv5 altitude shadow ratiosを再適用。
- `computation-2026-08-22/E6-S-AIRCRAFT-RANGE-SHADOW-V45.tsv` — 天山/Ki-40の重量・燃料・L/D・ηp・reserve感度。

## v46 E6-M jet/JF installed-thrust computation

- `computation-2026-08-22/e6_m_jf_installed_thrust_v46.py` — v43 14kg/s E6-M jet trimとv44型のbleed/combustor/mechanical/fuel accountingからmain-turbine work balance、convergent nozzle、free-LP-turbine/aft-fanを再現。
- `computation-2026-08-22/E6-M-J-JF-INSTALLED-THRUST-V46.tsv` — pure-J 835/870/920°C、JF FPR/BPR sensitivity、thrust/TSFC/free-turbine workを出力。
- `computation-2026-08-22/E6-M-JF-FAN-SIZE-V46.tsv` — 14kg/s bypass、axial velocity、hub/tip、stage loadingからfan tip径・rpm・tip Machを再現。
