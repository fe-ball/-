# Migration note — submarine underwater reconciled v22

v22は、新しい性能段階を追加する版ではなく、同一v21から分岐した二つのパッケージを正準化した統合版。

- 基幹：`asai-worldline-20260823-submarine-underwater-v21.zip`。1938–43水中系P0は閉鎖済みとして維持。
- 救済：`asai-worldline-20260823-submarine-underwater-checkpoint-v21.zip` から、旧「日本海軍は潜水艦騒音をほぼ重視しなかった」の撤回と、USNTMJ S-43 `Japanese Naval Vessels — Own Ships Noise` の独立史実錨を採用。
- 不採用：checkpoint側の `PARTIAL / CHECKPOINT` 状態、急速潜航・battery・motor・I統合を未監査へ戻す記述。これらは完成側v21ですでに閉鎖されているためsuperseded。
- 性能判断：v21完成側から変更なし。8kt級/鉛chemistry/基本motor出力を保持しつつ、battery構造/Q、潜航trajectory、motor rating、own-noise mapを正準化した状態を継承。
- 次P0：1941–44次世代潜水艦ニッチ再生成。水中高速枝H、sensor本体、battery量産/資源は別監査。

詳細な親ハッシュ・差分判定は `21-SUBMARINE-UNDERWATER-RECONCILIATION-V22-2026-08-23.md`。
