#!/usr/bin/env python3
from pathlib import Path
import csv,json,hashlib,sys,collections
ROOT=Path(__file__).resolve().parents[1]; MAIN=ROOT/'main'
F={'chron':ROOT/'CANONICAL-CHRONOLOGY-V46R1.tsv','jsonl':ROOT/'CANONICAL-CHRONOLOGY-V46R1.jsonl','schema':ROOT/'CHRONOLOGY-SCHEMA-V46R1.json','index':ROOT/'CANONICAL-MAIN-INDEX-V46R1.tsv','trig':ROOT/'CAPABILITY-TRIGGER-MATRIX-V46R1.tsv','preflight':ROOT/'CROSS-DOMAIN-PREFLIGHT-V46R1.md','manifest':ROOT/'SHA256SUMS.txt'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def txt(p): return p.read_text(encoding='utf-8')
def need(e,b,t,l):
    if t not in b:e.append(f'{l} missing {t}')
def check():
    e=[]
    for k,p in F.items():
        if not p.exists():e.append(f'missing {k}: {p.name}')
    if e:return e
    with F['chron'].open(encoding='utf-8') as f: rows=list(csv.DictReader(f,delimiter='\t'))
    if len(rows)!=667:e.append(f'unexpected chronology count {len(rows)}')
    ids=[r['record_id'] for r in rows]; expected={f'CHR-{i:04d}' for i in range(1,668)}
    if len(ids)!=len(set(ids)):e.append('duplicate chronology IDs')
    if set(ids)!=expected:e.append(f'chronology ID coverage mismatch missing={len(expected-set(ids))} extra={len(set(ids)-expected)}')
    allowed={'current','scope','conditional','superseded','mixed'}
    for r in rows:
        if r['semantic_status'] not in allowed:e.append('bad status '+r['record_id'])
        p=ROOT/r['source_file']
        if not p.exists():e.append('missing source '+r['record_id']+': '+r['source_file']);continue
        if sha(p)!=r['source_sha256']:e.append('stale source hash '+r['record_id'])
        try: ln=int(r['source_line'])
        except: e.append('bad source line '+r['record_id']);continue
        if ln<1 or ln>len(txt(p).splitlines()):e.append('source line range '+r['record_id'])
        try: json.loads(r['row_json'])
        except: e.append('bad row_json '+r['record_id'])
    counts=collections.Counter(r['semantic_status'] for r in rows)
    want={'current':496,'conditional':72,'superseded':56,'scope':34,'mixed':9}
    if any(counts.get(k,0)!=v for k,v in want.items()) or set(counts)!=set(want):e.append(f'status partition mismatch {dict(counts)}')
    st={r['record_id']:r['semantic_status'] for r in rows}
    for rid in ['CHR-0546','CHR-0565','CHR-0579','CHR-0595','CHR-0609','CHR-0621','CHR-0635','CHR-0648','CHR-0658']:
        if st.get(rid)!='scope':e.append('scope regression '+rid)
    for rid in ['CHR-0636','CHR-0637','CHR-0638','CHR-0639','CHR-0640','CHR-0641','CHR-0642','CHR-0643','CHR-0649','CHR-0651','CHR-0657','CHR-0659','CHR-0660','CHR-0661','CHR-0662','CHR-0663','CHR-0664']:
        if st.get(rid)!='current':e.append('current regression '+rid)
    for rid in ['CHR-0645','CHR-0646','CHR-0650','CHR-0652','CHR-0653','CHR-0655','CHR-0656','CHR-0666','CHR-0667']:
        if st.get(rid)!='conditional':e.append('conditional regression '+rid)
    for rid in ['CHR-0058','CHR-0144','CHR-0180','CHR-0591','CHR-0592','CHR-0593','CHR-0606','CHR-0607','CHR-0620','CHR-0632','CHR-0633','CHR-0644','CHR-0647','CHR-0654','CHR-0665']:
        if st.get(rid)!='superseded':e.append('expected superseded '+rid)
    if st.get('CHR-0440')!='conditional':e.append('E5 1300hp marine central not gated CHR-0440')
    jr=[json.loads(x) for x in txt(F['jsonl']).splitlines() if x.strip()]
    if len(jr)!=len(rows):e.append('jsonl count mismatch')
    else:
        for a,b in zip(rows,jr):
            if any(str(a.get(k,''))!=str(b.get(k,'')) for k in a):e.append('jsonl parity '+a['record_id']);break
    sc=json.loads(txt(F['schema']))
    if sc.get('release')!='v46r1' or sc.get('semantic_worldline')!='v46':e.append('schema version mismatch')
    bc=sc.get('build_counts',{}); expected_counts={'records':667,'carried_from_v45r1':657,'added_v46r1':10,'current_records':496,'conditional_records':72,'superseded_records':56,'scope_records':34,'mixed_records':9}
    for k,v in expected_counts.items():
        if bc.get(k)!=v:e.append(f'schema count mismatch {k}={bc.get(k)}')
    with F['index'].open(encoding='utf-8') as f: idx=list(csv.DictReader(f,delimiter='\t'))
    actual={str(p.relative_to(ROOT)) for p in MAIN.iterdir() if p.is_file()}; indexed={r['path'] for r in idx}
    if len(actual)!=201:e.append(f'unexpected main count {len(actual)}')
    if actual!=indexed:e.append(f'main index coverage mismatch actual={len(actual)} index={len(indexed)}')
    for r in idx:
        p=ROOT/r['path']
        if not p.exists():e.append('main index missing '+r['path']);continue
        if sha(p)!=r['sha256']:e.append('stale main index '+r['path'])
        if str(p.stat().st_size)!=r['size_bytes']:e.append('main index size '+r['path'])
        if 'incoming_text_refs_current' not in r:e.append('main index refcount column missing');break
    with F['trig'].open(encoding='utf-8') as f: tr=list(csv.DictReader(f,delimiter='\t'))
    for r in tr:
        for s in filter(None,r['canonical_sources'].split(';')):
            if not (ROOT/s).exists():e.append('trigger source missing '+r['capability_id']+': '+s)
    for cap in {'TIME','AVAIL'}:
        rr=next((x for x in tr if x['capability_id']==cap),None)
        if not rr or 'CANONICAL-CHRONOLOGY-V46R1.tsv' not in rr['canonical_sources']:e.append(cap+' chronology pointer regression')
    rr=next((x for x in tr if x['capability_id']=='GT-E6-JF'),None)
    if not rr or 'main/asai-works-e6-m-jf-installed-thrust-rebaseline-1938-43.md' not in rr['canonical_sources']:e.append('GT-E6-JF trigger missing')
    if rr:
        for tok in ['850 kgf','900 kgf','1,000 kgf','free turbine']:
            need(e,rr['trigger_terms_or_context']+' '+rr['mandatory_question'],tok,'GT-E6-JF trigger')
    cs=txt(ROOT/'CURRENT-CANONICAL-STATE.md')
    for tok in ['semantic v46 / machine v46r1','CANONICAL-CHRONOLOGY-V46R1.tsv','CANONICAL-MAIN-INDEX-V46R1.tsv','CAPABILITY-TRIGGER-MATRIX-V46R1.tsv','CROSS-DOMAIN-PREFLIGHT-V46R1.md','asai-works-e6-m-jf-installed-thrust-rebaseline-1938-43.md','~850 kgf','~900 kgf','~950–1,000 kgf','~984 kgf','+20.9%','−17.3%','~0.52 m','~9,000 rpm','~610–690 kg']:
        need(e,cs,tok,'current pointer')
    starttxt=txt(ROOT/'00-START-HERE-2026-08-22.md')
    if not starttxt.startswith('# 浅井世界線・完全版入口 — semantic v46 / machine v46r1'):e.append('START header regression')
    for tok in ['CANONICAL-CHRONOLOGY-V46R1.tsv','CANONICAL-MAIN-INDEX-V46R1.tsv','CAPABILITY-TRIGGER-MATRIX-V46R1.tsv','CROSS-DOMAIN-PREFLIGHT-V46R1.md','約850kgf','約900kgf','約950–1,000kgf','約984kgf','約0.52m','約9,000rpm']:
        need(e,starttxt[:5000],tok,'START current pointer')
    rules=txt(MAIN/'tensei-engineer-kufu-shu.md'); hand=txt(MAIN/'asai-works-handoff.md')
    for blob,label in [(rules,'rules'),(hand,'handoff')]:
        need(e,blob,'CROSS-DOMAIN-PREFLIGHT-V46R1.md',label); need(e,blob,'CAPABILITY-TRIGGER-MATRIX-V46R1.tsv',label)
    parent=txt(MAIN/'asai-works-e6-m-jf-installed-thrust-rebaseline-1938-43.md')
    for tok in ['~850 kgf/engine','~900 kgf/engine','~950–1,000 kgf/engine','~984 kgf','+20.9%','−17.3%','free-LP-turbine/fan spool','~0.52 m','~9,000 rpm','~610–690 kg/engine','A_old / conditional until dedicated H→A']:
        need(e,parent,tok,'v46 parent')
    pf=txt(F['preflight'])
    for tok in ['v46 E6-M J / JF INSTALLED-THRUST gate','~850 kgf/engine','~900 kgf/engine','~950–1,000 kgf/engine','+20.9% static thrust','−17.3% TSFC','separate one-stage free-LP-turbine/fan spool','~0.52 m tip','~610–690 kg','Hekireki 11/21']:
        need(e,pf,tok,'preflight')
    cr={r['record_id']:r for r in rows}
    for rid,toks in {'CHR-0659':['850 kgf'],'CHR-0660':['900 kgf'],'CHR-0661':['950–1,000 kgf','20.9%','17.3%'],'CHR-0663':['0.50–0.55 m'],'CHR-0664':['610–690 kg'],'CHR-0666':['Hekireki 11/21']}.items():
        for tok in toks: need(e,cr[rid]['search_text'],tok,rid)
    # Downstream old-thrust consumers must carry an explicit v46 fence or A_old wording.
    for fn in ['asai-works-jet-trainer.md','asai-works-aviation-variants.md','asai-works-cfrp-program.md','asai-works-jet-sakufu-prototype.md','asai-works-jet-carrier.md','asai-works-jet-hekireki-21.md','asai-works-jet-interceptor.md']:
        b=txt(MAIN/fn)
        if 'v46' not in b[:1800]: e.append('downstream v46 fence missing '+fn)
        if fn!='asai-works-jet-trainer.md' and 'A_old' not in b: e.append('downstream A_old fence missing '+fn)
    listed={}
    for line in txt(F['manifest']).splitlines():
        if not line.strip():continue
        h,n=line.split(None,1);n=n.strip().lstrip('*');n=n[2:] if n.startswith('./') else n;listed[n]=h
    actual_files={str(p.relative_to(ROOT)) for p in ROOT.rglob('*') if p.is_file() and p!=F['manifest'] and '__pycache__' not in p.parts and not p.name.endswith('.pyc')}
    if set(listed)!=actual_files:e.append(f'manifest coverage mismatch missing={len(actual_files-set(listed))} extra={len(set(listed)-actual_files)}')
    for n,h in listed.items():
        p=ROOT/n
        if not p.exists():e.append('manifest missing '+n)
        elif sha(p)!=h:e.append('manifest hash '+n)
    return e
if __name__=='__main__':
    e=check()
    if e:
        for x in e:print('ERROR:',x,file=sys.stderr)
        raise SystemExit(1)
    print('OK: v46r1 machine layer internally consistent; E6-M J/JF installed thrust and aft-fan hardware closed; downstream aircraft H→A remains gated')
