# POST-v32 OPEN AUDIT — v32r1

Closed now:
- rotorcraft 1942+ medium helicopter scale and transmission gate;
- shipboard footprint/sea-state gate;
- wartime rescue role;
- wartime ASW role, with dipping-sonar hunter-killer removed from 1942–45 central.

Next P1:
1. **radio/radar reliability** — valves, connectors, moisture sealing, vibration, alternators, antenna installation, maintenance and production yield.
2. **mine/sweeping** — magnetic/acoustic/contact mines, sweep gear, nonmagnetic material claims and fleet integration.
3. **survey / artillery meteorology** — geodesy, radiosonde/met, fire-control data and field organization.
4. submarine battery/motor/yard accounting.
5. requirement-driven E8/E9+ only when a customer/mission opens it.

History boundary: post-1941-12-08 OOB/production/deployment/combat remains FROZEN. Old fleet-number deltas derived from helicopter hunter-killer assumptions require history reopen before recomputation.
