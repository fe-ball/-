# UPDATE 2026-08-18 — MI後〜1942年9月入口

今回の主な更新：

1. MI中央線を1942-06-09〜12で確定方向へ整理。Hornet / Enterprise喪失、Saratoga中損、Midway日本占領。Akagi / Kaga / Soryuは損傷して浮航、Hiryu / Zuikaku健在。
2. 四川作戦は1942年秋までの準備計画。1943年2〜3月発動候補だが、他戦域急変時は剪定。
3. 一式中戦車チヘの運用解釈を中国戦線へ接続。
4. 1942年7〜8月Moresby / Midway補給を処理。Moresby GREEN、Midway YELLOWだが改善。
5. Lungaは米WATCHTOWER不発により8月上旬から日本基地として稼働。ラビ、Santo等へ航空的「運用税」を課す。
6. 一式大型輸送機L5Si1諸元をWORKING CANON化。Wake–Midway定期空輸、中国幹線輸送へ適用。
7. 1943素材適用L5Si2を設定。CFRP一次構造ではなく、接着金属・紙ハニカム・麻/GFRP・CFRPプロペラ。
8. 空中給油は1942限定運用、現場俗称「トンボ」。存在秘匿を優先し、作戦縦深の魔法的拡張にはしない。
9. MI勝利後の空母建造政策を修正。13〜19隻は産業上限ケース。史実型緊急空母大量転用は不発。STOL/回転翼で航空雑務を分解。
10. 史実BT作戦はGuadalcanalで中止されず継続する枝へ。Adduは8/17初発見、8/20〜21確認を中央。直後の爆撃はせず秘密監視。

最新読む順序：
- SESSION/.../29-MI-CANON-1942-06-09-12.md
- 30-POST-MI-WORLD-STRATEGY-SICHUAN-1942-06-07.md
- 31-JUL-AUG-PACIFIC-LOGISTICS-BASES-1942.md
- 32-AIRLIFT-NAVAL-AIR-POLICY-1942.md
- 33-AIRCREW-STATUS-1942-08.md
- 34-BT-ADDU-CANON-1942-07-09.md
- 35-HANDOFF-NEXT-1942-09-01.md
