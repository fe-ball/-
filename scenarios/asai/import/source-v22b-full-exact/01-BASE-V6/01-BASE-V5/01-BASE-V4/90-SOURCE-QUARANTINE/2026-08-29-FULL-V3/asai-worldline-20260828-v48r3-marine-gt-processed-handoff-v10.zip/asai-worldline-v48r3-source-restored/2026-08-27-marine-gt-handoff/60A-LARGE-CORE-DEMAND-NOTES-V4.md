# V4 large-core demand derivation notes

This is a demand-to-scale paper trade, not a product-availability statement.

For the Taiyo/Kasuga Maru pre-planned branch, the historical working baseline is 25,200 shp at 21 kt. A 25.5 kt cube-law sensitivity requires **45119.4 shp**, an increment of **19919.4 prop-shp**. The 25.5 kt requirement itself remains OPEN.

Using current E6 non-Ni 870C installed specific work **130.5427 kJ/kg** as a no-scale-bonus paper coordinate:

- 4 new cores: at least **28.45 kg/s/core** before marine transmission losses.
- 5 new cores: at least **22.76 kg/s/core**.
- 6 new cores: at least **18.96 kg/s/core**.
- 9 canonical 2,300 hp E6-M short modules provide 20,700 hp at engine output, so they require **96.23%** end-to-end retention merely to meet the incremental prop-shaft requirement. This is too tight to call closed without the combining/reduction path.
- 10 such modules require **86.61%** retention; this is the first branch with substantial arithmetic margin, but selection still depends on ducting, gear topology, maintenance, mass and procurement.

The old ~29.7 kg/s `E6-large-A` analysis scale is therefore not adopted as a product. It is noteworthy only because a four-module Taiyo boost architecture independently pulls a **~28.4 kg/s minimum paper scale** at the same E6 installed specific work, before marine losses. If a four-module carrier package becomes a named Navy product requirement, a ~30 kg/s R0/R1/R2 branch can be justified from demand. Without that decision, it remains research/trade space.
