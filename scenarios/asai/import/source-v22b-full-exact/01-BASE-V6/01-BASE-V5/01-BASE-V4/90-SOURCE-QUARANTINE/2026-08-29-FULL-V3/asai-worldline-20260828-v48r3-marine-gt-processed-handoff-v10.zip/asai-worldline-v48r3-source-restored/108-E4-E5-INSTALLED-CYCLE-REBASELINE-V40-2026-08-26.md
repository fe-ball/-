# 108 — E4/E5 installed-cycle rebaseline — v40

v40 closes the E4/E5 cooling-bleed / pressure-loss installed-cycle audit without yet propagating aircraft/ship/adoption/history effects.

Central decisions:

- E4 93 kJ/kg / 18% and E5 126 kJ/kg / 22.5% remain **gross Brayton comparison indices**.
- E4 cooling central 3%; E5 Ni@800 4%; E5 non-Ni@800 full 6%; E5 non-Ni@765 4%.
- E4 installed shaft coordinate ≈76 kJ/kg / 15.0% fuel-based shaft efficiency (audit band 69–80 / 13.8–16.0%).
- E5 Ni@800 ≈104 / 19.3% (98–110 / 18.1–20.2%).
- E5 non-Ni@800 ≈99 / 18.7% (90–105 / 17.2–19.7%).
- E5 non-Ni@765 ≈93 / 18.4% (87–98 / 17.2–19.4%).
- Old direct `P = w_gross * mass flow` product proof is no longer valid for E4/E5.
- 500 kW E4 and 1,000 hp E5 remain product targets pending dedicated mass-flow/size re-baseline; no downstream performance/adoption change is made in v40.

Canonical parent: `main/asai-works-e4-e5-installed-cycle-rebaseline-1931-37.md`.
