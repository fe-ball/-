# MIGRATION NOTE — Submarine next generation v23

- semantic worldline: v22 -> v23
- machine layer: v22r4 -> v23r1
- new canonical file: `main/asai-works-submarine-next-generation-1941-44.md`
- closes former OPEN items: 1941–44 next-generation niche, underwater-high-speed H integration, 22-go-10 niche, first/second generation battery-motor architecture.
- moves remaining submarine-specific questions into cross-domain applied-computation/materials work: quiet phenolic gears/bearings, onboard dedicated calculators, electronic/non-latched dedicated computation, and only the Asai-linked portion of sensing/signal processing.
- next-generation 2-stroke main engine is demoted from blocking P0 to optional P1 because neither the 12kt first generation nor 15kt second generation requires it.
- war history/OOB remains frozen.
