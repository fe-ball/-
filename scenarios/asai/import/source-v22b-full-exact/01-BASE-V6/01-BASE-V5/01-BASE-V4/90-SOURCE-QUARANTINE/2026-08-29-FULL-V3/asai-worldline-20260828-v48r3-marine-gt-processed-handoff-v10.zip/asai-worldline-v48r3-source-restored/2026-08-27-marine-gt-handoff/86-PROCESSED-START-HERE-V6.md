# Marine GT processed handoff V6 — start here

Base semantic authority remains **v48** and machine authority remains **v48r3**. V6 is an additive processing overlay; it does not silently rewrite the canonical main tree.

## V6 key decisions

- E5 marine qualification uses the current **E5-S 1,000 hp / 7.6 kg/s** product coordinate. The old 1,300 hp E5-S claim remains rejected.
- The first sea-qualification article is now a **purpose-built close derivative of the accepted Japanese First Type hull family**, retaining the twin piston shafts and adding one centerline E5 test path. This is a test-program choice, not a fleet-selection claim.
- High-speed-side freewheel is the selected working architecture; center shaft test band is 2.0–2.4 krpm; a 70 mm preliminary shaft is a shop-coordinate pending fatigue/coupling closure.
- Intake is deliberately oversized for qualification data: two removable parallel separator cells, total clear area 0.36–0.40 m2. Loss/removal performance is measured; no intake bonus is assumed.
- Full-load craft displacement remains **OPEN by discipline**. The old 25–27 t target is not restored; a new-build close derivative requires an actual structure/equipment/CG takeoff.
- The first >13.2 kg/s combusting research core is now **R2-AUTHORIZED-WORKING** as an audit-labelled `LL20-R2` article at roughly **20–21 kg/s**, with first hot work in the 1939–40 window. It remains a research article, not a product.
- LL20 scale is derived from the **Taiyo pre-planned 6-module / 3+3 boost trade**. At the same E6 installed specific work and path-retention sensitivity, larger modules do not reduce total power or airflow; they reduce interface count while paying a new-core scale tax.
- A ~3–4 MW absorption stand is a **program-created LL20 requirement**, not an automatically inherited facility from the old paper large-A/B calendar.

## Read order

1. `63-QUALIFICATION-TERMINOLOGY-V5.md`
2. `50-NUMERIC-DERIVATION-DISCIPLINE-V4.md`
3. `77-E5-QUALIFICATION-CRAFT-ARRANGEMENT-DECISION-V6.tsv`
4. `78-E5-SHAFT-INTAKE-DERIVATION-V6.tsv`
5. `79-E5-QUALIFICATION-INSTRUMENT-TEST-PLAN-V6.tsv`
6. `80-FIRST-LARGE-HOT-CORE-R2-DECISION-V6.tsv`
7. `81-TAIYO-MODULE-NO-FREE-LUNCH-V6.tsv`
8. `74-LARGE-CORE-ENABLING-INHERITANCE-V5.tsv`
9. `82-MARINE-DEMONSTRATION-LADDER-V6.tsv`
10. `84-V6-RECALC-NOTES.md`
11. `42-NAVAL-DESIGN-PROCUREMENT-BASELINE-V3.tsv`
12. `83-MARINE-GT-REWORK-QUEUE-V6.tsv`
13. `85-MARINE-GT-PRECEDENCE-OVERLAY-V6.tsv`
14. V2 layered decision matrix for downstream platform selection status

## Immediate next gates

1. Complete the E5 qualification craft **structural/equipment mass and CG takeoff** from the selected arrangement, then earn the hull/prop result by tank/sea evidence.
2. Turn LL20 R2 authorization into a **detailed compressor/rotor/casing/combustor/free-turbine/test-stand design ledger** without granting any scale-performance bonus.
3. Lay out Taiyo **6x LL20 vs 10x canonical E6-M** machinery rooms and actual combining gears; only then can 0.90–0.95 path-retention sensitivity be replaced by a designed loss budget.

Validation is recorded in `88-PROCESS-VALIDATION-REPORT-V6.txt`; V6 manifest is `SHA256SUMS-HANDOFF-PASS10.txt`.
