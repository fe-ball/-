# Marine GT V5 — qualification terminology and the misuse of "maturity"

## Rule

For Asai-worldline machinery, **"mature" is not a scalar performance state** and must not be used as shorthand for "good enough because time has passed". The protagonist repeatedly raises the acceptance bar as measurement, computation, materials and failure analysis improve. A machine can therefore be highly developed while still having open clocks under a newly tightened acceptance standard.

Use role-specific statements instead:

- `PHYSICS-CLOSED` — cycle/power/geometry coordinate is accepted for the stated condition.
- `RIG-PROVEN` — the named component/integration behavior has been demonstrated on the named rig.
- `ENVIRONMENT-PROVEN` — salt, intake, corrosion, wash or other environment item has passed the stated exposure.
- `ENDURANCE-nH` — actual accumulated endurance at the stated rating/environment; do not replace with "mature".
- `PRODUCTION-REPEATABLE` — manufacturing/QC repeatability is demonstrated for the named part/product and rate band.
- `ROLE-QUALIFIED` — the product is accepted for a specified duty/rating/maintenance regime.
- `APPLICATION-READY` — a named platform can receive it after platform-specific integration.
- `SELECTED` — the buyer actually chose it.

## Consequence

A later audit that demands better instrumentation, longer endurance, lower scatter or harsher salt exposure is **not a downward revision of the technology**. It is a redefinition of what has to be proven. Therefore V5 avoids phrases such as `E5 mature`, `E6 nearly mature`, or `gear maturity` unless the object and acceptance criterion are named.

This also prevents an opposite error: future knowledge may tell Asai which failure modes deserve a higher bar and may start those clocks earlier, but it does not supply an unexplained bonus when the bar is not yet passed.
