# Marine GT processed handoff V4 — START HERE — 2026-08-28

## State

Base semantic authority remains **v48 / machine v48r3**. V4 is a processing overlay on V3. It does not claim a semantic v49 rebaseline.

## What V4 closes/reframes

1. A strict numeric provenance discipline now governs future-knowledge effects and use of historical analogues (`50-NUMERIC-DERIVATION-DISCIPLINE-V4.md`).
2. The E5 marine-qualification craft is recalculated around the current standard E5 product. Central test rating is **1,000 hp**, not legacy 1,300 hp. The 1,130 hp E5-S-HF is a sensitivity/product option, not needed for first qualification (`51-...`).
3. The central E5-to-E6 scale-transition program uses **R0/R1 heavily but does not build a hot E5-M intermediate full core merely to bridge scale**. The first central hot M-scale full core is E6-M in the 1938-39 development band (`52-...`). This is an active consequence of future knowledge: avoid a low-information stranded intermediate while still starting the relevant rig clocks early.
4. The gear gate is split by power/torque/application. Special 0.5-2 MW test/small-craft reductions may precede the 1940-42 production-tooling maturation; >4 MW combining/main-reduction remains a distinct OPEN problem (`53-...`).
5. The 1934-41 marine demonstration ladder is rebuilt without E5 1,300 hp or V1 large-A/B products (`54-...`).
6. The small-craft Crouch baseline is re-anchored to the inherited Japanese First Type: **C=4.055-4.109**. C=4.2+ is now an improved-hull SENS requiring worldline tank/sea proof (`58-...`).
7. The marine mass ledger starts from the current E5 assembly **390-460 kg** and refuses to invent the remaining installation mass. Marine-specific increments and the 25-27 t craft full-load total remain OPEN (`59-...`).
8. Large-core scale is regenerated from named platform demand rather than diameter scaling. In the OPEN Taiyo 21->25.5 kt sensitivity, four equal new cores imply a **~28.4 kg/s/core minimum paper scale** at the current E6 installed specific work before marine losses; nine canonical E6-M short modules are arithmetically too tight unless path retention exceeds 96%, while ten provide more margin (`60-...`).

## Important non-closures

- The V29 small-craft complete-installation mass bands (E5 2.8-3.4 kg/kW; E6 2.2-2.8) are now treated as **H-SANITY**, because their central calibration came from the later Gatric installation. V4 does not replace them with another guessed multiplier. A worldline component-by-component marine installation mass ledger is still required.
- Exact small-craft propeller diameter/rpm imported from later US PT comparisons are likewise H-SANITY until the worldline hull/shaft/prop calculation closes them.
- Crouch speed rows in V4 are first-order trial sensitivities only. The inherited Japanese C band is 4.055-4.109; higher C must be earned by the actual enlarged hull.
- >13.2 kg/s product scale, >4 MW combining gears, carrier machinery packages, and actual platform selection remain OPEN.

## Read order

1. package-root `CURRENT-CANONICAL-STATE.md`
2. `33-DECISION-FRAMEWORK-REFRAME-V2.md`
3. `45-UPSTREAM-REFRAME-NOTES-V3.md`
4. `50-NUMERIC-DERIVATION-DISCIPLINE-V4.md`
5. `51-E5-MARINE-QUALIFICATION-RECALC-V4.tsv`
6. `52-E5-M-SCALE-RESEARCH-CLOSURE-V4.tsv`
7. `53-REDUCER-TORQUE-LADDER-V4.tsv`
8. `54-MARINE-DEMONSTRATION-LADDER-V4.tsv`
9. `58-CROUCH-HULL-CALIBRATION-V4.tsv`
10. `59-MARINE-INSTALLATION-MASS-LEDGER-V4.tsv`
11. `60-LARGE-CORE-DEMAND-DERIVATION-V4.tsv` and `60A-LARGE-CORE-DEMAND-NOTES-V4.md`
12. `42-NAVAL-DESIGN-PROCUREMENT-BASELINE-V3.tsv`
13. `44-UNIT-POWER-DEMAND-SEED-V3.tsv`
14. `55-MARINE-GT-REWORK-QUEUE-V4.tsv`
15. V2 downstream selection matrix and V3/V4 precedence overlays

## Next action

Close the still-OPEN rows in `59-MARINE-INSTALLATION-MASS-LEDGER-V4.tsv` from the actual worldline design: separator/intake geometry, clutch placement, mount/structure, exhaust and qualification-only instrumentation. Then rebuild the 25-27 t qualification-craft full mass statement and tank/sea-test its hull coefficient rather than assuming C=4.2+. In parallel, continue the demand map that determines the first >13.2 kg/s physical core and the >4 MW gear architecture. Only after those are closed should Taiyo/Unryu machinery be recalculated again.
