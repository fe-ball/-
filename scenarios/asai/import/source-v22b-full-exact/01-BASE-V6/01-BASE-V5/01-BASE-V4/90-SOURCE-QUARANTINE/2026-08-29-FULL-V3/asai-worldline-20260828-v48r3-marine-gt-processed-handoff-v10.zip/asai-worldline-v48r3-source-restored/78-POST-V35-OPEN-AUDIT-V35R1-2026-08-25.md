# POST-v35 OPEN AUDIT — v35r1

## CLOSED / REBASED
- submarine 3-group battery / 4-motor industrial and yard accounting.
- old 4–6-boat central pilot replaced by 1–2 hull-equivalent engineering programme; 3rd+ conditional.
- motor 1-hour thermal rating separated from battery high-rate endurance and 15 kt duration.
- charge/H2/temperature/SOC, high-current bus/switchgear, commutator/brush, shaft alignment and installation/replacement workflow made explicit acceptance gates.

## NEXT P1
1. optional next-generation 2-cycle integrated submarine prime mover only if a concrete requirement justifies reopening it.
2. E8/E9+ later-war propulsion only when a specific later-war requirement is introduced.

## P2 RETAINED
- first-generation/second-generation detailed propeller-cavitation map and exact full-bank speed-duration curve once final cell/motor ratings are specified.
- actual battery factory throughput, large-motor shop throughput and yard installation hours require a dedicated industrial-capacity source set before numerical production totals are assigned.

## HISTORY BOUNDARY
Post-1941-12-08 submarine construction totals, deployments, losses, combat outcomes and enemy-ASW response remain FROZEN.
