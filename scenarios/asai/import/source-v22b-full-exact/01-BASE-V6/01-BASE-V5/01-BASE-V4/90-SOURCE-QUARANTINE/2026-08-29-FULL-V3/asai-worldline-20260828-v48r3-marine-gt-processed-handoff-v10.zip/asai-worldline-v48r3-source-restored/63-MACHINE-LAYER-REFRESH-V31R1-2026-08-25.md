# v31r1 machine-layer refresh

- Chronology: `CANONICAL-CHRONOLOGY-V31R1.tsv/.jsonl` (**470 records**).
- Schema: `CHRONOLOGY-SCHEMA-V31R1.json`.
- Main index: `CANONICAL-MAIN-INDEX-V31R1.tsv` (**183 main files**).
- Trigger matrix: `CAPABILITY-TRIGGER-MATRIX-V31R1.tsv`; TIME/AVAIL point to v31r1 and `AIR-FIGHTER` requires the v31 Army-fighter authority plus piston/boost/naming sources.
- Preflight: `CROSS-DOMAIN-PREFLIGHT-V31R1.md`, adding requirement-origin, load-state, Ki-44 H, capability-vs-requirement, designation and history-split gates.

Five inherited chronology snapshots that encode the withdrawn early P-47-class Ki-64 production premise are demoted to `superseded` and explicitly mapped in `61-ARMY-FIGHTER-H-TO-A-REBASELINE-V31-2026-08-25.md`.

New v31 chronology records encode the Army-fighter authority, Ki-43 requirement/H/A0, Ki-44 requirement/H/I/A0, the 1941 two-role niche map, conditional sustained-high-altitude turbo branch and restored historical Ki-64 experimental branch.
