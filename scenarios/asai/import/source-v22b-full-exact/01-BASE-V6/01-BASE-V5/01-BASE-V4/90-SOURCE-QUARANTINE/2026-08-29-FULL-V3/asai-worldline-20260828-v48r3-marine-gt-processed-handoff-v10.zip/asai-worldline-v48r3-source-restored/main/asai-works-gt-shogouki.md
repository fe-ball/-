# 商品化初号機のガスタービン・コアと商品の形態

> **v42 regeneration installed update.** E4 simple productはv41どおりstandard design flow **6.7 kg/s**・500 kW rating ACCEPT。回生定置版はv42 `asai-works-e4-regeneration-installed-rebaseline-1931-33.md` が上位正本で、中央 **467.7 kW shaft / 19.34% / 0.433 kg/kWh**、発電端は**約444 kWe連続回生 / 約482 kWe bypass**。旧25% / 0.33 kg/kWhはsuperseded。

コアの進歩を踏まえ、発売可能な初号機のコアを構想し、その上に商品の形態（使用燃料・燃費・出力を含む）を起こす。本稿は `tensei-engineer-kufu-shu.md` の規則に従う。数値は【確認済み】【物理】【設定】【要確認】で区別する。

---

## 1. コアの進歩から初号機へ

- E-1（約1921）：正味出力の実証。史実が全員つまずいた一つ目の壁（圧縮機効率）を、軸流圧縮機の設計で外す。正味出力そのものはエリングが1903年に出している【確認済み】ので、これは壁を意図して破ること。
- E-3（約1928〜29）：将来性の実証。特殊鋼が育ち、二つ目の壁（タービン入口温度）が緩み、定置・ベンチで意味のある出力に届く。
- 初号機コア（E-4級、1930年代前半）：売れる水準。下記の諸元で、非常電源・ポンプ・舶用などの商品の心臓になる。試験段階まで核は共通で、ここから各商品へ枝分かれする。

---

## 2. 初号機コアの諸元

| 項目 | 値 | タグ |
|---|---|---|
| 形式 | 単純サイクル（再生サイクル版は§4）、軸流＋遠心圧縮機、缶型燃焼器、独立動力タービン | 設定 |
| 正味軸出力 | **約500 kW＝v41 product rating ACCEPT**。6.7kg/sでinstalled central≈507kW | v41 current |
| 圧力比 | 約4.5 | 設定 |
| タービン入口温度 | 約710℃（中空空冷翼＋特殊鋼。1939年ノイシャテルの550℃を上回る） | 設定 |
| 質量流量 | **standard design 6.7 kg/s**。旧5.4 kg/sはgross derivationとしてsuperseded | v41 current |
| 熱効率 | **18%＝gross Brayton比較**。simple installed shaftはcentral≈15.0%（13.8–16.0%）。E4-R installed centralは**19.34%**（ε0.60、air-sideΔp1.5%、exhaust-sideΔp2.5%）。旧再生25%はsuperseded | v42 current |
| 使用燃料 | 灯油・軽油 | 設定 |
| 比燃費 | simple installed central≈**0.56 kg/kWh**。E4-R shaft central **0.433 kg/kWh**、発電端@95% **0.456 kg/kWh_e**。旧0.46/0.33はgross/idealized provenance | v42 current |
| `TBO_prod`（定置・間欠/減格product、分解整備まで） | 数百〜千時間級 | 設定／要確認。E4 full-rating `L_core` とは別概念 |
| 乾燥重量 | **0.80–0.90トン、中央0.85t**（約1.6–1.8 kg/kW） | v41 working product band |

注【v40】：18%はgross comparisonであり、installed simple shaft efficiencyはcentral≈15%。したがって「ノイシャテル17.4%と同等以上」をinstalled efficiencyの主張としては撤回する。E4の初期商品価値は効率より出力密度・即始動・燃料柔軟性に置く。

---

## 3. 使用燃料・燃費・出力の正直な位置

- 燃料は灯油・軽油で、航空ガソリンのオクタンの制約を避ける（戦略的利点）。
- 燃費はディーゼルに劣る。v40 simple installed centralは約0.56 kg/kWh（audit約0.52–0.61）。v42回生版は圧損込みcentral **0.433 kg/kWh shaft / 0.456 kg/kWh_e**で、燃費は改善するが出力は6.7kg/sのままなら約467.7kW shaftへ下がる。
- だが間欠運転では問題化しない。月1〜5時間の非常運転なら月燃料は約230 kg〜1.2トンで、効率の悪さは費用に響かない【物理】。
- 出力重量比で勝つ。v41 E4 industrial productは500 kW級 **0.80–0.90t**。旧0.75tより重くしたが、同出力の小型ディーゼル数t級に対する出力密度・即始動の優位という商品軸は保持する。

---

## 4. 商品全体の形態（共通コアの上の商品群）

一つのコアを、用途ごとに違う形へ積む。各商品はその分野の同時期の同等品で測る。

| 商品 | 出力（全開） | 燃料消費 | 構成 | 同等品に勝てる軸 |
|---|---|---|---|---|
| 非常・尖頭発電装置 | 約475 kW（発電端target） | **旧220 kg/hはsuperseded／v40 product resize後再計算** | コア（単軸）＋発電機＋即始動 | 待機ディーゼル・蒸気に対し、出力密度・即始動・待機中の手間の少なさ |
| 回生サイクル定置版 E4-R | **475–480 kWe bypass / 440–450 kWe recuperated continuous** | central約202.5kg/h shaft side、発電端SFC約0.456kg/kWh_e | 金属tubular回生器＋air/exhaust bypass。追加0.6–1.1t・1.4–2.5m³ | 長時間運転で燃費を買う。compact/boost用途には載せない |
| 高出力ポンプ装置 | 約500 kW軸target | **旧230 kg/hはsuperseded／resize後再計算** | コア＋独立動力タービン＋ポンプ | ディーゼル・蒸気駆動に対し、出力密度・即始動・自社ポンプとの一体。消火・治水・排水 |
| 舶用増速装置 | 約500 kW軸target | **旧230 kg/hはsuperseded／resize後再計算** | コア＋独立動力タービン＋減速＋一方向クラッチ | 高出力ガソリン・ディーゼルに対し、出力重量比。巡航は経済的な機関、増速にGT |

すべて燃料は灯油・軽油で共通。発電は単軸が素直、ポンプ・舶用は独立動力タービンで可変速の軸出力を取り出す。

---

## 5. 同等品で見た初号機の位置

- 対ディーゼル発電：効率では負ける。しかし非常・尖頭という間欠用途では、出力密度・即始動・待機の手間で勝つ。世界初の商用GT（ノイシャテル、1939）が待機用だった事実が、この位置を裏づける【確認済み】。
- 対ノイシャテル：入口温度は上だが、小型E4のinstalled simple efficiencyはcentral≈15%でノイシャテル17.4%を下回り得る。利得の本命は出力密度・即始動・小型商品化であり、効率優位は主張しない。
- 総じて初号機は「効率で勝つ機械」ではなく「即始動の高出力を、小さく軽く出す機械」である。誇張せず、この軸でなら同等品に勝てる。

---

## 6. タグの区別

- 【確認済み】：エリング1903、ノイシャテル1939（550℃・17.4%・待機用）、当時ディーゼルの熱効率約34%、灯油・軽油の発熱量帯。
- 【物理】：質量流量、比燃費、全開燃料消費、間欠運転の月燃料。
- 【設定/現行】：500 kW simple product rating、standard flow 6.7 kg/s、PR4.5、TIT710℃、dry 0.80–0.90t。18%はgross、installed simple≈15%はv40、product sizeはv41、E4-R installedはv42（19.34% / 0.433kg/kWh、二重定格）。
- 【要確認】：寿命の具体、出力重量比の当時実数、再生サイクルの熱交換器の効き、自社ポンプ・舶用事業との接続の具体。

---

## 7. 次の作業

- 寿命と出力重量比を史実で詰める（【要確認】）。
- 各商品の最初の顧客（海軍基地・要塞の非常電源、濃尾平野の治水ポンプ、海軍の高速艇）を、同等品比較つきで具体化する。
- コアの世代を1930年代に延ばす（入口温度・効率・出力の上昇）際も、必ず同時期の同等品で測る。


## v38 lifetime semantics

上表の「数百〜千時間級」は非常電源等の定置・間欠/減格dutyにおける `TBO_prod` 候補として読む。E4世代全体のfull-rating `L_core` を1000 hとする根拠にはしない。`L_mat / L_core / H_qual / TBO_prod` は `asai-works-core-elements.md` のv38定義に従う。

## v39 E4 component-life closure

E4 full/normal-rating coreの代表 `L_core` は **250–450 h**。v40でinstalled shaft central≈75.7kJ/kg/15.0%へ分離し、v41で**6.7kg/s / 500kW / dry0.80–0.90t**をproductとして再受領、v42で回生installed performanceを**467.7kW / 19.34% / 0.433kg/kWh**へ閉じた。次はcompressor/control operability。
