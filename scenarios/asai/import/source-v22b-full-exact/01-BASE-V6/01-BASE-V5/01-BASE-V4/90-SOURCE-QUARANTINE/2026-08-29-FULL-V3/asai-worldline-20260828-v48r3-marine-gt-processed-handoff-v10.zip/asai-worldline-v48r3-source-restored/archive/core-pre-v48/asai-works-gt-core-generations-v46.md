# ガスタービン・コアの世代数値（再較正・比仕事ベース）と航空への展開

> **v44 installed-product authority.** The generation table below remains a **gross comparison** table. v43 compressor identity is unchanged; v44 converts E6 shaft products to installed accounting: non-Ni870 `w_inst≈130.5 kJ/kg / η≈22.5%`, Ni920 `≈148.7 / 23.5%`; E6-S standard ratings become 1,300/1,500hp while E6-M-T 2,100hp is retained as flat-rated at 13.2kg/s. Jet thrust remains separate.

> **v42 E4 regeneration supersession.** E4の「再生25%」はgross/idealized provenance。current E4-R installedは `asai-works-e4-regeneration-installed-rebaseline-1931-33.md`（19.34% central、0.433kg/kWh、二重定格）を優先する。

> **v41 product-size authority.** v40 installed-cycle値を固定し、`asai-works-e4-e5-product-massflow-size-rebaseline-1931-37.md` でE4 500 kWを6.7 kg/s、E5-S 1,000 hpをstandard 7.6 kg/sとして再受領済み。E4/E5の `93/126 kJ/kg` と `18/22.5%` は引き続きgross comparisonであり、product shaft proofには `w_inst×ṁ` を使う。exact compressor mapはP1-3。

> **v39 hot-section authority.** E4/E5の寿命は `asai-works-e4-e5-hot-section-component-life-rebaseline-1931-37.md` を現行authorityとする。E4代表rated `L_core=250–450 h`。E5は材料/格付けを分離し、Ni高端@800℃=`400–700 h`、非Ni@800℃ full=`150–300 h`、非Ni quantity@760–770℃=`350–600 h`。TITはblade metal temperatureではなく、generic long-clockとexact family/process clockを分離する。本v39ではPR/TIT/η/gross比仕事は変更しない。

> **v38 causal authority.** v38はE系列のPR/TIT/η/推力/寿命数値を一律変更しない。E5をU4組織化、E6をL3 electronic-computation回収の大きな転換として因果を補強し、E7/E8はL4 qualification gateを保持する。

> **v37 authority update.** E8/E9+の現行判定は `asai-works-e8-e9-later-war-propulsion-rebaseline-1942-47.md`。史実達成年は比較アンカーであって世界線の天井ではない。E8の194/31%はgross Brayton比較値、turbojet installed thrustへ直接変換しない。

コアの世代数値を、上昇の可能性と過大評価の可能性の両方を見て較正する。**芯（中央値）は「彼の実力が概ね揃った場合の中央」**——良い設計（着想）で部品効率を史実平均より上に取り、小型は寸法で頭打ち（基盤の壁）になることを尊重する。無理に高くはしない。出力は大きさに依るので、コア世代比較量は**gross比仕事**で書き、installed shaft比仕事はcooling/pressure/mechanical ledgerで別に閉じ、実出力は製品ごとに出す。本稿は `tensei-engineer-kufu-shu.md` の規則に従い、数値は【確認済み】【物理】【設定】【要確認】で区別する。

なお本表は世代＝**ベンチマークの帯**の中央値であって、達成の上限を定めるレールではない（構造模型は `asai-works-core-hierarchy.md`）。コアは世代→コア種類（寸法×軸構成×材料系統）→エンジン商品の三層で、能力は予算として帯の中で付け替え・迂回できる。機体・商品は帯の上端と迂回まで含めた達成可能から駆動され、中央値を天井として相続しない。

---

## 1. 較正の根拠（両側からの挟み込みと芯の置き方）

簡易サイクルの熱効率は、圧力比・タービン入口温度・部品効率で決まる。ブレイトンの式で計算し、史実で検算した【物理】。

| 条件 | 効率 |
|---|---|
| 検算：ノイシャテル級（大型・PR4・TIT550・部品0.85） | 約17%（実績17.4%と一致） |
| 下端：小型・手探り（PR3・TIT620・部品0.78） | 約11% |
| E-3 の芯（小型・早期：PR3.5・TIT690・部品0.80） | 約15% |
| 初号機の芯（小型：PR4.5・TIT710・部品0.82） | 約18% |
| 初号機の上端（好条件：PR5・TIT760・部品0.85） | 約23% |
| 上端＝E-7（PR8・TIT900・部品0.85） | 約28% |
| E-8 高端実用（1945–46 technical coordinate：PR9.5・TIT940・部品0.86） | 約31%（**gross** 比仕事194 kJ/kg。4–5%冷却debit代表でinstalled-core比較≈181–183 kJ/kg / 30.4–30.5%） |

【v40較正修正】旧ノイシャテル17.4%との直接一致は、単一η=0.85が実機component efficiencyより低く、pressure/mechanical lossを暗黙に吸収したlumped calibrationだった。式はgross世代比較には使えるが、installed efficiencyの検証にはloss ledgerが必要。芯の置き方——部品効率は良い設計で史実平均（0.76〜0.80）より上の0.82〜0.86（E-4〜E-8・小型・基盤で現代0.88には届かない）。入口温度は冷却＋特殊鋼で史実（無冷却550℃）より高め。芯は両端の間の「概ね揃った中央」で、上下は幅として残す。

---

## 2. 世代表（再較正・比仕事ベース）

軸出力機（定置・舶用・ターボプロップ）の値。比仕事は大きさに依らないコア固有量。中央値は【設定】、幅は【物理】。

| 世代 | 時期 | 圧力比 | 入口温度 | 部品効率 | 熱効率 | 比仕事（固有量） | 代表rated `L_core` | 位置づけ |
|---|---|---|---|---|---|---|---|---|
| E-1 | 〜1921 | 約2.5 | 約540℃ | 0.77 | 約8% | 約32 kJ/kg | 短い | 正味出力の実証（T1） |
| E-2 | 〜1925 | 約3 | 約620℃ | 0.79 | 約12% | 約56 kJ/kg | 改良 | 高温化の試行 |
| E-3 | 〜1928–29 | 約3.5 | 約690℃ | 0.80 | 約15% | 約77 kJ/kg | 数十〜百数十時間 | 将来性の実証（T2） |
| 初号機 E-4 | 約1931–33 | 約4.5 | 約710℃ | 0.82 | 約18% | 約93 kJ/kg | **250–450 h** | 売れる水準（T3） |
| E-5 | 約1934–37 | 約6 | 約800℃ | 0.83 | 約22.5% | 約126 kJ/kg | **Ni@800: 400–700 h / 非Ni@800: 150–300 h / 非Ni@760–770: 350–600 h** | ターボプロップ・舶用の核。材料×ratingで寿命を閉じる |
| E-6 | 約1938–41 | 約7 | 約870℃ | 0.84 | 約26% | 約155 kJ/kg | 数百時間超 | ジェット・後期の核 |
| E-7（＝従来の上端） | 約1942–44 | 約8 | 約900℃ | 0.85 | 約28% | 約173 kJ/kg | より長い | 西側最良級（Avon 1950級を先知で先取り）＝従来「上端＝前線」と呼んだ位置＝1942–44の前線 |
| E-8（高端実用） | 約1945–46 technical coordinate | 約9〜10 | 約940℃ | 0.86 | 約31% gross | 約194 kJ/kg gross（cooled installed-core比較≈181–183） | Ni/非Ni二系統。寿命・冷却・歩留まりを別受領 | **high-end practical / qualifiable technical rating**。15–16段single-spool+VSV/bleedが中央可能、two-spoolは代替 |
| E-9（technical front） | 約1945–47 technical coordinate | 約11〜12 | 約1000℃ | 0.86〜0.87 | component/rigで評価 | product値は未固定 | 冷却5–7%級・二軸/耐久/歩留まりgate | **design/component/rig current**。flight-qualified/series ratingはCONDITIONAL |

### v40 E4/E5 installed-cycle coordinate

| coordinate | gross w / η | installed shaft w | fuel-based shaft η |
|---|---:|---:|---:|
| E4 710℃ | 93.5 kJ/kg / 18.37% | **central 75.7; band 69–80** | **15.0%; 13.8–16.0%** |
| E5 Ni 800℃ | 125.5 / 22.58% | **104.3; 98–110** | **19.3%; 18.1–20.2%** |
| E5 non-Ni 800℃ full | 125.5 / 22.58% | **99.5; 90–105** | **18.7%; 17.2–19.7%** |
| E5 non-Ni 765℃ | 113.8 / 21.86% | **93.5; 87–98** | **18.4%; 17.2–19.4%** |

E4/E5のheadline PR/TIT/ηは変えない。gross→installedの差はcooling bleed、combustor pressure loss、finite exhaust margin、shaft/accessory loss。product gear/generator/propeller lossはさらに別帳簿。

**v39 E4/E5 hot-section解釈**：E4の710℃、E5の800℃はgas TITでありblade metal temperatureではない。一次監査ではE4 rotor local/hot-spot≈543–613℃、E5≈587–668℃。E4中央は耐熱austenitic/Cr-rich steel＋simple fabricated hollow coolingで閉じ、E5でNi high-end full-ratingと非Ni quantity/derated lineを明示分離する。combustor linerはreplaceable maintenance item、disk/rootはrim temperature/thermal-gradient cliff gate、bearing/seal/oilは別熱系として扱う。generic 1921–24 long-clockは試験法を継承するが、new alloy/joining/cooling processにはfamily/process clock resetを課す。

部品効率は単調に向上する芯（0.77→0.86、史実平均0.76〜0.80より上で現代0.88には届かない）。熱効率・比仕事はこの効率とPR・入口温度から閉じる。**比仕事（製品出力を支える達成値）を固定し、整合する部品効率と熱効率を逆算して定めた**——数値のブレは改訂の残滓であり、実際にできる数字（比仕事）を最優先する。

**v37再基線化——E8/E9を史実年代で止めない**：E-7（1942–44）はPR8/TIT900/η0.85の支払済み基盤。E-8（1945–46 technical coordinate）はPR9〜10/TIT940/η0.86を**high-end practical / qualifiable technical rating**として維持する。PR9.5を16段へ配分した平均stage ratioは約1.151で、一段負荷の魔法ではなく、多段matching・clearance・stall/surge・VSV/bleed・shaft critical speedを閉じる問題である。TIT940も旧Ni備蓄tailで自動停止させず、cooling passage/yield、vane/rotor/root/disk metal temperature、creep/oxidation/thermal fatigue、NDT/TBOをhard gateにする。

**grossとinstalledを分離**：E8の約194 kJ/kg・31%はcooling debit前のsimple-Brayton比較index。4〜5% cooling debitを代表的に払ったinstalled-core比較は約181〜183 kJ/kg・30.4〜30.5%級。これはturbojet推力そのものではない。

**E9はcalendarでpostwar固定しない**：PR11〜12/TIT約1000℃/η0.86〜0.87のdesign/component/rig workはE8から連続するcurrent technical front。flight/series ratingのみ、two-spool rotordynamics/bearing/control、5〜7%級staged cooling、full-core map、start/accel/surge、endurance、manufacturing yieldを通すまでCONDITIONAL。世代番号から1,000 kgf/基を自動導出しない（core scaleは別軸）。
圧力比は再確認（`asai-works-reverify-audit.md` §1）で**比仕事最適の少し上（熱効率側）へ置き直した**——E-5/E-6/E-7＝6/7/8。比仕事を大きく動かさず熱効率を買う軸である。史実Jumo004、Metrovick F.2、Avon、J47、J57等は**比較anchorのみ**で、浅井世界線のcalendar ceilingには使わない。v37ではE8 PR9.5/16段の平均stage ratio≈1.151を内部計算のanchorとし、実gateを多段matching、clearance、stall/surge、VSV/bleed、shaft critical speed、bearing/seal、start/accelerationへ置く。

熱効率の幅（両側）：E-3 約12〜17、初号機 約14〜23（再生約25）、E-5 約20〜24、E-6 約23〜27、上端 約26〜29。芯は中央値、上下は帯（レールでなく帯として読む。`core-hierarchy` §2）。

進化を駆動するのは既出の工夫——耐熱鋼＋中空空冷翼＋拡散皮膜で入口温度、多段軸流圧縮機で圧力比と部品効率、釣り合わせと燃料制御で運転と寿命。

---

## 3. 実出力は製品ごと（比仕事×質量流量）

コアは世代が決める「型」で、実出力は質量流量を製品ごとに選んで出す。**実出力＝比仕事×質量流量**。

- 【v41 product closure】旧 `w_gross×ṁ`（E4 93×5.4、E5 126×6）はsuperseded。E4 standard design flow=**6.7 kg/s**で500 kWを受領。E5-S standard gas path=**7.6 kg/s**でcommon **1,000 hp**を受領し、Ni余裕はlife/hot-highへ、non-Ni@765 quantityは約950 hpへ振る。product size/weightはv41 parentで閉鎖、exact compressor operabilityはP1-3。
- 流量を増やせば比例して大きくなる（ただし伸縮は**コア種類の帯の中の微調整**で、帯をまたぐ拡大は新しいコア種類＝離散の設計労力。`core-hierarchy` §6）。舶用は数 kg/s〜十数 kg/s を束ねて数百kW〜数メガワット級まで。
- ジェット実装（E-6以降）は軸出力でなく**推力**で測る（E-5級で約300 kgf、E-6級で約500 kgf。`asai-works-turbojet-demonstrator-saiko.md`）。

つまり「コアの出力」を一つの数で書こうとすると、製品へ展開した時点で型と実体が一対一でなくなり崩れる。固有量（比仕事）で書けば崩れない。

---

## 4. 航空への展開——実験と原型機の系列

### 4a. 共通の核と分岐

ターボプロップもジェットも、同じガス発生器（E号機の核）を使う。ターボプロップ＝核＋動力タービン＋減速＋プロペラ、ジェット＝核＋推進ノズル。**核の研究は共通で、後端だけが違う**。だから核の進歩が両者を同時に養う。後端は離散の二択ではなく、噴流速度と質量流量の配分を変える**連続体**（バイパス比という一本の摘み）で、両端の間に低・中バイパスのファンが置ける。ターボプロップはバイパス比を極端まで上げた端、純ジェットはゼロの端にすぎない。詳細は `asai-works-aviation-forms.md`。

### 4b. 並行か順次か

おおむね並行だが、ずれて始まる。ターボプロップは低速でプロペラが効くので低い核（E-4級）でも有用＝先に始まる。純ジェットは高い核（E-5級以上）でないと飛ばす価値が出ない＝2〜3年遅れて始まる。両方が動く1930年代中〜後期は並行で、共通の核が両者を養い、二つの後端が一緒に磨かれる。

### 4c. 段階（両系列とも四段。原型機＝懸架の飛行試験）

| 段階 | ターボプロップ | ジェット |
|---|---|---|
| 地上ベンチ | 約1931–33（E-4）。核＋動力タービン＋プロペラを試験台で | 約1935–36（E-5）。核＋推進ノズルを試験台で |
| 懸架の原型機 | 約1933–34（E-4）。発動機を母機に吊って「飛ぶ」ことを既存機で確かめる | 約1936–37（E-5）。同じく母機に積む（史実はW.2Bをウェリントン尾部に積む型、1942年が前例【確認済み】） |
| 試験機の初号機 | 約1934–36（E-4/E-5）。八八式偵察機の改造（液冷V12を撤去し機首にターボプロップ）。滑らかさ・燃料・低中速の作戦価値（射撃・撮影試験） | 約1936–39（E-5）。専用の実証機（`saiko`の六型——専用機ヤツメウナギ/ポッド/翼内、懸架、急造転換・混合、記録機、ターボプロップ＋ジェット増速、出力寄りバイパス〔後置ファン〕） |
| 実用の初号機 | 約1937–39（E-5）。ターボプロップを前提に設計した最初の専用機 | 約1940–42（E-6）。要撃に使えるジェット |

要点。**原型機＝懸架の飛行試験**で、これが最も早く安全に「発動機が飛ぶ」ことを示す（母機が生きているので発動機停止でも帰投可）。次の試験機初号機が「機体としての成立」を、実用初号機が「使える性能」を示す。ターボプロップが2〜3年先行し、中〜後期は両系列が並行する。年次はすべて【設定】、史実前例（八八式の素体・懸架試験・六型）は既出の裏取り済み。

---

## 5. 前の版からの修正点

- 出力欄を比仕事へ置換し、実出力を製品ごと（§3）へ移した。型と実体の崩れと、馬力・kWの混在を解消。
- 芯は前回再較正のまま（E-3 入口690℃・効率15%、初号機 効率18%・再生25%）。史実寄りに丸めず、高い圏の中央。
- 航空の実験系列（§4）を、原型機（懸架）を含む四段で追加。
- 再確認（`asai-works-reverify-audit.md` §1）：**圧力比を熱効率側へ上げ直した（E-5/E-6/上端＝6/7/8）**。比仕事は据置（出力・速度は不変）、熱効率のみ +1〜2.5点（E-5 21.5→22.5％、E-6 23.5→26％、上端 26→28％）＝比燃費 約9%改善で航続・滞空が伸びる。【設定・根拠付き：先知＋多段軸流、戦後Avon PR7・1950が同時代証拠】。

---

## 6. 上下両側（幅として残す）

- 上昇しうる：部品効率の上振れ、圧力比・入口温度の伸び、再生サイクル、用途の大型化。
- 過大評価しうる：小型機の部品効率の頭打ち、初期の信頼性、冷却翼の鋳造が基盤に縛られること、小型での失速・サージ。
- 芯は中央値、上下は幅。確定は芯を採る。

---

## 7. タグの区別

- 【確認済み】：ノイシャテル1939での式の検算、当時ディーゼル34〜40%、懸架試験の前例（W.2Bをウェリントン尾部に1942年）。実史ジェット前線＝Jumo004（PR3.1/TIT約775℃/1944）・RR Avon（開発1945/就役1950/PR7〜7.45）・GE J47（PR5.35/初飛行1948）・P&W J57（PR12/二軸9+7段/1952）、無冷却超合金のTIT天井≈900℃（〜1950頃）、空冷タービン翼の実験1950・量産1950〜60年代。
- 【物理】：ブレイトン効率、比仕事、実出力＝比仕事×質量流量。E-7/E-8の効率・比仕事はブレイトン検算で現行アンカー（ノイシャテル17.3/E-6 25.8/E-7 28.1%）を再現の上で算出。
- 【設定】：各世代の中央値、航空の各段階のtechnical coordinate、芯に採る部品効率0.77〜0.86、E8 PR9〜10/TIT940のhigh-end practical rating。**史実Avon/J57等の達成年は比較アンカーであってworldline ceilingではない**。E9 PR11〜12/TIT~1000/η0.86〜0.87はdesign/component/rig technical front。
- 【要確認】：小型機の部品効率・寿命、E8 cooling passage/鋳造・vane/rotor/root/disk温度とTBO、E9 two-spool/bearing/control・5–7% cooling・full-core map・endurance/yield、各installed-engineの推力/重量/外径。旧Ni 1943–44 cutoffとE9 postwar固定はv37でsuperseded。

---

## 8. 次の作業

- 各商品資料の数値を本世代表（中央値・比仕事）に揃える（初号機は更新済み）。
- 航空の各段階の素体・母機を具体化する（八八式以外の候補、懸架の母機）。
- E4 regeneration installed audit、E5/E6 compressor operabilityを詰める。E4/E5 `L_core` はv39、installed cycleはv40、product mass-flow/sizeはv41で再基線化済み。
- **E8/E9 installed-engine H→A**：E8 gross 194/31%から推力+10%を自動継承せず、mass flow・compressor/turbine map・cooling debit・nozzle・inlet・重量/外径で製品推力を再較正する。E9はcomponent/rig→flight/series gateを順に閉じる。
