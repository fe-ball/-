# 132 — E6-M-J / JF installed-thrust rebaseline — v46

> Status: **ACCEPTED v46 semantic rebaseline**. Base checkpoint = v45r1.
> Scope: E6-M pure-jet and aft-fan engine-side installed thrust, fan/free-turbine sizing, mass and package envelope. Aircraft performance propagation is deferred.

## Result

v46 closes the v44/v45 jet/JF gate using the corrected v43 E6-M 14 kg/s high-flow compressor trim and v44-style installed accounting.

- E6-M-J non-Ni 870°C: calculated ~854 kgf → **~850 kgf product**.
- E6-M-N-J Ni 920°C: calculated ~907 kgf → **~900 kgf product**.
- E6-M-JF production 835°C, BPR~1.0, FPR~1.30: calculated **~984 kgf**, TSFC ~0.649 kg/(kgf h) → **~950–1,000 kgf product band**.
- Same-TIT JF effect: **+20.9% thrust / −17.3% TSFC**, not the old blanket +30–40% / −20–30%.
- JF hardware: single-stage free LP turbine, ~0.41 MW extraction, single-stage aft fan ~0.52 m tip at ~9 krpm.
- Aft-module mass ~100–150 kg; total E6-M-JF dry mass ~610–690 kg, central ~650 kg; nacelle maximum OD ~0.66–0.72 m.

Architecture wording is corrected: the gas-generator compressor remains single-spool, but JF **adds a separate free-LP-turbine/fan spool**.

Full authority: `main/asai-works-e6-m-jf-installed-thrust-rebaseline-1938-43.md`.

Reproducible files:

- `computation-2026-08-22/e6_m_jf_installed_thrust_v46.py`
- `computation-2026-08-22/E6-M-J-JF-INSTALLED-THRUST-V46.tsv`
- `computation-2026-08-22/E6-M-JF-FAN-SIZE-V46.tsv`

## H→A fence

Do not rescale aircraft top speed from thrust alone. Existing Hekireki/Sakufu/CFRP values that inherit 500 or 650–700 kgf engines become A_old/conditional until intake, nacelle drag, engine mass/CG, fuel and field/carrier performance are recomputed.
