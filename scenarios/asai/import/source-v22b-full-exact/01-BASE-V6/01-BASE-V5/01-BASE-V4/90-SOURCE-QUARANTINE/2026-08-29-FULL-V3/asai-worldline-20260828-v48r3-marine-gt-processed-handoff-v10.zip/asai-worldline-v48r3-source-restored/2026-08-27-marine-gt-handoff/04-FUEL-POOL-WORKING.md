# Fuel-pool working model — GT / turbo-diesel / steam / aviation

> Status: strategic working model, not a closed national fuel balance.

## 1. What fuel the current marine-GT calculations assume

Thermal calculations have effectively assumed a clean petroleum distillate around LHV ~42 MJ/kg.

Best interpretation for large marine E6:

**a broad-range clean turbine distillate centered on kerosene-tail through gas-oil / light-diesel range**, not residual bunker fuel.

It need not equal commercial diesel-oil specification.

GT cares less about octane/cetane than piston engines, but cares strongly about:

- water/sediment
- ash
- residual carbon/deposit tendency
- Na/V and other hot-corrosion contaminants
- viscosity/atomization range
- storage stability
- flash point / shipboard safety

## 2. Proposed fuel-pool split

### Aviation turbine fuel

- kerosene-leaning cleaner/narrower pool
- stronger low-temperature and cleanliness requirements

### Marine turbine fuel

- wider cut
- can include kerosene tail + gas-oil front/middle within property limits
- intended to be cheaper and higher-yield than a narrowly specified premium diesel product

### Large turbo-diesel fuel

- push deliberately toward heavier gas oil / treated heavy distillate / where feasible cleaned fuel-oil range
- purpose: avoid making GT and diesel fight for the exact same premium distillate

### Steam boiler fuel

- residual heavy oil remains natural

## 3. Why `kerosene-quality can be mixed in; make it cheap` matters

The value is not a magic refinery process. It is **specification freedom**.

Instead of requiring a narrow commercial kerosene or diesel cut, Navy can buy a property-specified turbine pool spanning a wider boiling range.

Illustrative refinery worksheet used in discussion (NOT a historical average):

- gasoline/naphtha 20%
- kerosene band 12%
- gas-oil band 23%
- residue 38%
- other 7%

If only ~75% of gas oil is accepted, turbine pool ~17% of crude.
If ~70% of kerosene band + ~75% of gas-oil band is accepted, pool ~26% of crude.

This was an illustrative demonstration of why broad specification can matter. Do not canonize those crude yields without refinery/source work.

## 4. Aviation shift away from gasoline

Early turbine aircraft do **not** necessarily reduce fuel mass per shaft-kWh versus a good piston engine.
The major strategic benefit is different:

- high-octane aviation gasoline is a difficult premium product;
- turbine fuel can be a cleaner middle distillate with much less octane-oriented upgrading;
- thus aviation GT moves demand away from the refinery's most demanding gasoline pool into the middle-distillate pool.

This can increase total middle-distillate demand even while reducing high-octane gasoline bottlenecks.

## 5. National planning consequence

If main-propulsion GT proliferates, the issue becomes **product slate**, not only total petroleum tonnage.

Working order-of-magnitude example from discussion:

For a 20,000 shp-equivalent GT plant, annual 2,000 h operation at 50% average load and ~0.40 kg/kWh:

- one equivalent: ~6,000 t/year turbine distillate
- 10 equivalents: ~60,000 t/year
- 50: ~300,000 t/year
- 100: ~600,000 t/year

Meanwhile comparable turbo-diesel work at ~245 g/kWh uses materially less mass but can be pushed toward heavier fuel grades.

Therefore by dozens of major GT ships the Navy/Commerce Ministry must plan:

- crude import mix
- finished gas-oil/distillate import
- refinery cut points
- cracking severity and target slate
- shale / synthetic oil blending
- tankage
- tanker allocation
- reserve stocks

## 6. Direct distillate import

Treat direct import of gas oil / diesel oil / kerosene-like products as historically plausible. Japan was not an `import crude only, refine everything domestically` system.

Next chat should verify exact annual import/product statistics and any prewar contracts before converting this into a closed fuel-policy timeline.

## 7. Strategic non-conclusion

GT does **not** solve Japan's petroleum dependence.
It changes the shape of the bottleneck:

from `high-octane aviation gasoline is uniquely painful`

toward

`large volumes of clean middle distillate must be secured while diesel is pushed heavier and residual oil still has consumers`.

