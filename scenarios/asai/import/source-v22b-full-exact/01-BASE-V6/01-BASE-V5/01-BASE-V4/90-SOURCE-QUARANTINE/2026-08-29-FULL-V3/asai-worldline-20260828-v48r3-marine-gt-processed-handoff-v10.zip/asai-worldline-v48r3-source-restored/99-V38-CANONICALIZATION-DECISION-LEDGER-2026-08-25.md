# 99 — v38 Canonicalization Decision Ledger

> Status: DRAFT decision gate. v37r1 remains canonical until a v38r1 package passes machine/manifest/clean validation.

## 0. v38 should be a methodology + prepayment release, not a performance-inflation release

The v38 audit has found a large missing causal layer: the protagonist's future knowledge, computation environment, long-duration materials program and organizational learning improve **how close development gets to the best locally manufacturable design**. The safe first canonical step is to encode that method and the early clocks that must have been running.

Do **not** first change aircraft speeds, E-series PR/TIT, thrust, or TBO across the board.

## 1. Ready to canonicalize now

### R1 — Future-CAD benchmark and O/G framework

Canonical rule:

- 100% benchmark keeps local materials, tools, labor, factories and test time fixed.
- Only the design office is idealized: future-grade CAD/analysis + expert subordinates produce the best locally manufacturable blueprint/process/test plan.
- O-score measures optimization proximity.
- Gp/Gd/Gq measure capture of available performance/development/quality gain.
- O/G are audit coordinates, never automatic bonuses.

**READY.**

### R2 — Protagonist/computation role boundary

Canonical rule:

- engine is protagonist core;
- metallurgy and aviation are major extensions;
- computation is auxiliary infrastructure/business, not a second protagonist specialty;
- protagonist supplies demand, funding, people, correct problem selection, occasional strong hints and proposal selection;
- local computing specialists still invent/build/operate the machines.

**READY.**

### R3 — computation era interpretation

Canonical developmental shift:

- 1923–28: arithmetic/record/recalculation assistance;
- 1929–34: procedure/algorithm increasingly transferred to machines; repeated parameter work becomes practical;
- 1935–37 U4: coarse search → priority test → recalculation becomes organizational standard;
- 1938–40: electronic/relay/drum systems make more L3 coupled cases routine;
- 1941+ technical capability: broader reduced-order simulation and data loops, but no modern CFD/future computer assumption.

**READY**, while existing detailed machine roadmap remains authoritative for hardware.

### R4 — GT causal re-propagation

Canonical rule:

- E1–E4 values are not inflated merely because v38 adds scores;
- E5 is recognized as the major U4 organizational transition;
- E6 is first major electronic-computation payoff for L3 matching/transient/thermal/rotordynamic work;
- E7/E8 benefit from accumulated method/data but remain L4 qualification-gated;
- E9 pays a fresh coupling tax for two-spool/high-PR/high-TIT/full-core transient complexity.

**READY.**

### R5 — early hot-section materials clock

Canonical program-level decision:

- special-steel lab already provides short-time metallurgy before E1;
- systematic long-duration constant-load comparative testing begins **1921–24**;
- oxidation, thermal-cycle and rotor/fatigue records are deliberately accumulated in the 1920s;
- turbocharger service returns from 1925 are serial/heat/process linked into the material archive;
- the lab grows from simple manual stations, not future automatic creep machines;
- exact station counts in draft 96 remain engineering envelopes, not canonical exact inventory.

**READY at program/date-band level.**

Historical feasibility anchors: metal creep was experimentally studied by 1910/1914, and Japanese publications document high-temperature testing apparatus in 1922 and 1000°C fatigue/impact testing in 1928. The worldline advance is therefore selecting and industrializing the right long clock early, not importing impossible apparatus.

### R6 — life/TBO vocabulary split

Canonical definitions:

- L_mat = material/hot-section baseline life;
- L_core = representative rated core hot-section life;
- H_qual = cumulative qualification/endurance hours;
- TBO_prod = product-specific overhaul/inspection interval;
- hours and thermal/start cycles are separate ledgers.

**READY.** This repairs an existing ambiguity without requiring a number change.

### R7 — aviation method re-propagation

Canonical rule:

- H→C→M→E→P→I→A remains current;
- C is interpreted through problem-specific O/G, not blanket computer bonus;
- protagonist's strongest aviation contribution is the engine/airframe interface: inlet, cooling, prop/reduction, altitude map, CG, vibration, instrumentation;
- wind tunnel / structural / flight tests remain physical gates;
- no blanket speed/weight bonus.

**READY.**

## 2. Not ready to canonicalize numerically

### N1 — E4/E5 life re-rating

Current v37 values remain:

- E4: hundred-plus to several-hundred-hour order;
- E5: several-hundred-hour order.

Draft hypothesis after early test-clock audit:

- E4 mature representative L_core ~250–450 h;
- E5 mature representative L_core ~400–700 h.

But this requires part/duty decomposition before promotion.

**NOT READY.**

### N2 — `gt-shogouki` several-hundred–1000 h

Likely a stationary/intermittent product TBO rather than generic E4 core life. Needs semantic patch, not necessarily numerical deletion.

**READY FOR LABEL REPAIR, NOT NUMBER RE-RATING.**

### N3 — E5–E7 component efficiency

Computation and test method may improve attainment probability/upper tail, but no generic η increase is justified without compressor/turbine map audit.

**NOT READY.**

### N4 — individual aircraft performance

No automatic speed/weight/range correction from O/G. Each aircraft must expose a recoverable installation/drag/weight/control gap.

**NOT READY GENERICALLY.**

### N5 — E8/E9 installed thrust

v37 already correctly separates gross Brayton indices from installed thrust. Requires dedicated installed-engine H→A.

**NOT READY.**

## 3. Canonical v38 package recommended

New main parents:

1. `main/asai-works-capability-convergence-framework-1903-45.md`
2. `main/asai-works-hot-section-materials-long-clock-1919-38.md`
3. `main/asai-works-computation-repropagation-engine-aviation-1923-45.md`

Modify existing main files minimally:

- `main/tensei-engineer-kufu-shu.md` — add benchmark/O-G and computation role boundary.
- `main/asai-works-engine-computation-internal-1923-28.md` — point to v38 framework; preserve existing E3-onward standard-state rule.
- `main/asai-works-engine-computation-maturation-1934-37.md` — identify U4 as method transition.
- `main/asai-works-gt-core-generations.md` — add v38 causal note; do not change PR/TIT/η/life number yet.
- `main/asai-works-core-elements.md` — define L_mat/L_core/H_qual/TBO_prod and O/G no-bonus rule.
- `main/asai-works-gt-shogouki.md` — relabel lifetime semantics.
- `main/asai-works-historical-aircraft-rebaseline.md` — define C via O/G.
- `main/asai-works-aircraft-computation-closure-1937-46.md` — protagonist/computation boundary and no blanket bonus.
- timelines 1920s/1930s — add long-duration materials clock starts and U4 transition, without changing product dates.

## 4. Why this release boundary is useful

It creates a stable checkpoint before numerical re-rating.

Later, if another issue is reopened, the project can ask:

1. what was locally manufacturable?
2. what O/G was available at that date/problem class?
3. what physical long clocks had already started?
4. what new-tech clock reset applies?
5. what product-specific duty/TBO is being claimed?

This prevents both failure modes seen earlier:

- **over-pessimism**: historical date treated as a ceiling and protagonist/organization learning ignored;
- **over-optimism**: “computer/future knowledge” converted into a free performance percentage.

## 5. Next numerical audit after v38 method release

Recommended P1 order:

1. E4/E5 hot-section part/duty/life re-rating;
2. E5/E6 compressor/operability attainment (surge/start/accel rather than η bonus first);
3. E8 installed-engine thrust H→A;
4. aircraft installation/drag cases where C audit finds real unclaimed gain;
5. cross-domain propagation to naval/ballistics/control only after the engine/metallurgy/aviation core is stable.

