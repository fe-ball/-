# CROSS-DOMAIN PREFLIGHT — v26r1

Purpose: prevent semantic omission during design/history review. This is a recall gate, not a new worldline conclusion. Before evaluating a platform, retrofit, production choice, or historical consequence, scan `CANONICAL-CHRONOLOGY-V26R1.*` and `CAPABILITY-TRIGGER-MATRIX-V26R1.tsv`, then mark each relevant family `CHECKED`, `GATED-OUT`, or `N/A`.

## Mandatory order

1. **Chronology/status first** — ordinary current analysis uses `current` and `scope`. `conditional` requires an explicit development/counterfactual gate. `superseded` is provenance only; `mixed` requires source inspection.
2. **Availability** — separate R/P/X/N where product/customer adoption matters.
3. **Propulsion/energy** — distinguish piston boost, diesel turbo, GT, TP/turboshaft and turbojet; use altitude installation and part-load ledgers.
4. **Materials/environment** — separate steel, epoxy/process, plant FRP, GFRP, CFRP; do not backdate structural maturity.
5. **Mechanisms/controls** — gears, bearings, propeller, cooling, steering, turret/servo, electrics/EMI, battery/motor.
6. **Computation/QC/test** — central computation versus limited-purpose onboard devices; gains are iteration/margin/workload/repeatability, not raw-physics bonuses.
7. **Production/maintenance/logistics** — tooling, inspection, spares, training, field/base/runway/mother-platform handling.
8. **Integration tax and negative gate** — record attractive technologies that were checked and rejected.

## v26 aircraft gates

### AIR-REBASE / AIR-ROLE

For aircraft roles, current authority is `main/asai-works-aircraft-computation-closure-1937-46.md`. Historical Japanese aircraft/requirements are preferred before inventing a new Asai airframe.

Do **not** revive as current:

- Aichi B6A Tenzan;
- Tenzan bomber variant → B7A lineage;
- Ki-48TP mass/limited production branch;
- P1Y as an immediate seven-seat G4M total replacement;
- Shinzan→Renzan as one continuous model series;
- old carrier-jet density-only altitude-speed rows.

### AIR-HEAVY

AT-3/Ki-92 and Fugaku chronology rows are `conditional`. Their technical envelopes are usable for design studies, but prototype dates, procurement, bases and missions are not current history/OOB unless the explicit policy/development gate is opened.

For Fugaku also check:

- 36–40kg/s L-core altitude power;
- 5,000shp reducer and 5.0–5.3m prop;
- six→four-engine long-range shutdown/feather logic;
- 390m² wing/fuel bending relief;
- multi-wheel gear and 2.8–3.0km base;
- payload-range rather than the single 20t×16,000km×680km/h dream point.

### AIR-JET-STRIKE

Do not infer that early jets are good CAS aircraft. First ask whether a Hekireki strike derivative suffices. Kikka is conditional on a cheap/simple strike requirement; Ki-201 independent mass production is not automatic; R2Y2 is the v26 independent high-speed reconnaissance/strike airframe. Simple P1Y→Tenka jet conversion is dropped.

### Carrier jet/catapult

Initial Sakufu is technology-driven. FH-1 class is a later threat/comparison envelope, not future-knowledge requirement input. Current speed bands are E6 early 670–710km/h, mature E7/E8 750–780 central; 800 is upper conditional. Approach centers are 120–130 early / 105–115 mature. First carrier catapult is a 5.5–6t assist accelerator, not a zero-speed launcher.

## Other standing omission traps

- “Turbo” is not one technology.
- “FRP” is not one material.
- “計算機” is not only the central machine.
- Water aircraft/amphibious systems are integration problems.
- Tanks are powertrain + human-processing systems; `TANK-NEXT` conditional semantics remain in force.
- Type 91/93/95 gains are mainly entry/settling/dispersion/workload, not magical hit rates.

## Minimum record

| Family | Result | Reason/source |
|---|---|---|
| chronology / semantic status | CHECKED / GATED-OUT / N/A | source |
| role / requirement / historical counterpart | CHECKED / GATED-OUT / N/A | source |
| propulsion / altitude / part-load / fuel | CHECKED / GATED-OUT / N/A | source |
| materials / environment | CHECKED / GATED-OUT / N/A | source |
| mechanisms / controls / propeller | CHECKED / GATED-OUT / N/A | source |
| computation / optics / QC / test | CHECKED / GATED-OUT / N/A | source |
| production / maintenance / logistics / base | CHECKED / GATED-OUT / N/A | source |
| integration tax / negative gate | CHECKED / GATED-OUT / N/A | source |
