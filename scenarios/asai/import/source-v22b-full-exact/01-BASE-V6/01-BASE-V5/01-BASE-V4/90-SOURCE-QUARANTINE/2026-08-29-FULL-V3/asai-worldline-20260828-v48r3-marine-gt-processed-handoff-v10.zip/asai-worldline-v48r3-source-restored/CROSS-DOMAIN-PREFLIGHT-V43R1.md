# CROSS-DOMAIN PREFLIGHT — v43r1

Current semantic checkpoint: **v43**. Run this before domain-specific analysis. v42 and earlier gates remain cumulative.

## v43 E5/E6 COMPRESSOR OPERABILITY gate

Current authority: `main/asai-works-e5-e6-compressor-operability-rebaseline-1934-41.md`.

Mandatory questions:
- E5-S standard is **7.6 kg/s / PR6 / 5 axial + 1 centrifugal / 17.5 krpm**. Use fixed IGV + stage-3 bleed; release requires steady surge-flow margin >=13% and transient >=10%.
- E6-S standard compressor design is **7.8 kg/s / PR7 / 7 axial + 1 centrifugal / 18 krpm**, full-speed trim 7.6–8.2 kg/s. Use scheduled VIGV + stage-4 bleed; steady >=12%, transient >=9%.
- E6-M is **14-stage all-axial / PR7 / 13.2 kg/s central / 12.5–14.0 full-speed trim / 13.5 krpm**, average stage PR ~1.149. Use VIGV + two bleed bands; steady >=10%, transient >=8%.
- Do **not** use old E6-M TP **10 kg/s** as an exact full-PR7 compressor coordinate. It is superseded. A 10 kg/s operating point must carry reduced speed/PR/efficiency unless separately qualified.
- E6 product shaft outputs **1,520 / 1,700 / 2,100 hp remain legacy targets pending installed-cycle audit**. Do not scale them automatically with the new 13.2 kg/s E6-M flow.
- E4-R 7.16 kg/s is compressor-side accepted only as a distinct ~7.2 kg/s S-HF trim; standard E4-R remains 6.7 kg/s.
- E5-S-HF ~8.08 kg/s can support the old 1,130 hp compressor-side target, but standard headline remains 1,000 hp. E5 marine 1,300 hp / ~9.29 kg/s remains outside S-HF.
- E4-R exact low-load bypass crossover remains a **30–45% electrical-load calibration band**, not a fixed 40% canonical point.
- E5/E6 stage-map coordinates in the v43 TSV are **qualification targets**, not measured compressor maps.
- E5 downstream H→A may proceed platform by platform after local gates; **E6 H→A waits for E6 installed-cycle/product-power closure**.

# CROSS-DOMAIN PREFLIGHT — inherited v42 gates

Inherited semantic checkpoint: **v42**. Run this before domain-specific analysis. v38 capability-convergence rules and all inherited gates remain cumulative.


## v42 E4 RECUPERATED INSTALLED gate

Current authority: `main/asai-works-e4-regeneration-installed-rebaseline-1931-33.md`.

Mandatory questions:
- For standard E4-R use **6.7 kg/s**, `epsilon=0.60`, air-side `dp=1.5%`, exhaust-side `dp=2.5%` as the central installed coordinate.
- Current central output is **467.7 kW shaft / 19.34% / 0.433 kg/kWh**, not old 25% / 0.33.
- At 95% generator efficiency use **~444 kWe recuperated continuous** and **~482 kWe bypass**; product wording is 440–450 kWe continuous / 475–480 kWe bypass.
- Recuperator+headers+bypass/duct adds **0.6–1.1 t** and **1.4–2.5 m3**. Do not treat regeneration as a compact/free efficiency add-on.
- **25% shaft efficiency would require epsilon~0.943** at central pressure losses; old 25% is superseded for E4.
- A recuperated 475 kWe continuous derivative requires **~7.16 kg/s** and remains CONDITIONAL pending compressor/shaft operability.
- Start/cold/emergency operation uses bypass. Do not freeze a 40%-load SFC benefit before compressor/control-map closure.
- P1-3 compressor operability is the next local gate; aircraft/ship H->A remains blocked until it closes.

## v41 E4/E5 PRODUCT MASS-FLOW / SIZE gate

Current authority: `main/asai-works-e4-e5-product-massflow-size-rebaseline-1931-37.md`.

Mandatory questions:
- For E4 shaft products use **standard design flow 6.7 kg/s** and 500 kW rating. Do not revive 5.4 kg/s as installed product proof.
- E4 first industrial product working envelope is **0.66–0.74 m diameter / 2.0–2.4 m length / 0.80–0.90 t dry**. Aviation derivatives require their own installation ledger.
- For E5-S shaft products use **standard gas path 7.6 kg/s**. The old v40 7.25 kg/s value was a Ni-only minimum resize coordinate, not the standard product flow.
- E5 at 7.6 kg/s: Ni@800 central capability ~1,063 hp; non-Ni@800 full ~1,014 hp; non-Ni@765 quantity ~952 hp. **Common headline remains 1,000 hp**, quantity non-Ni central ~950 hp.
- E5 engine assembly working band **390–460 kg**; installed turboprop powerplant including prop/mount/duct **510–640 kg**.
- Do not promote old **E5-S-N 1,130 hp** or **E5-S marine 1,300 hp** as standard-7.6 product outputs. The latter needs ~9.29 kg/s even on Ni central and is a downstream H→A conflict.
- P1-1 size closure does **not** prove exact compressor operability. Axial/centrifugal stage split, surge margin, start/acceleration, bleed/VSV/control, clearance and rotordynamics remain P1-3.
- v39 life bands remain unchanged by resize; v40 installed-cycle `w_inst` remains the thermodynamic input.
- **Do not propagate aircraft/ship speed, range, adoption or procurement automatically.** Re-open platform H→A one installation at a time after local engine gates.

## inherited v40 installed-cycle gate

## v39 E4/E5 HOT-SECTION / LIFE gate

Current authority: `main/asai-works-e4-e5-hot-section-component-life-rebaseline-1931-37.md`.

Mandatory questions:
- Is the temperature claim gas TIT, coolant temperature, vane/blade metal temperature, disk rim temperature or bearing/oil temperature?
- Which clock is being used: generic 1921–24 test infrastructure or exact alloy/process/geometry clock? Do not give a new E5 Ni alloy a fictitious 1921 start.
- Is the E4 central blade route simple fabricated hollow construction or a special precision-cast branch? Do not require mature investment casting by default.
- Which life quantity is meant: `L_mat`, `L_core`, `H_qual`, `TBO_prod`, or starts/thermal cycles?
- E4 current representative rated `L_core` = **250–450 h**.
- E5 current split: **Ni@800°C 400–700 h; non-Ni@800°C full 150–300 h; non-Ni@760–770°C quantity 350–600 h**.
- Do not apply a universal `−15°C => life ×2` multiplier. `ΔTIT != ΔTmetal`; material/stress/environment/process must be stated.
- A replaceable combustor liner may have a shorter interval than `L_core`. Disk/root remains a rim-temperature/thermal-gradient cliff gate; bearing/seal/oil is a separate heat/lubrication gate.
- v39 does **not** change E4/E5 PR/TIT/eta/gross work, 500 kW product output, aircraft/ship performance or adoption. Close cooling bleed / pressure-loss installed-cycle accounting first.

## inherited v38+ gates

The following v38 semantics remain current under v39. Use the v39r1 machine files named above.

## v38 CAPABILITY-CONVERGENCE / LONG-CLOCK gate

- **100% benchmark = local industry fixed, design office idealized.** Do not import future materials, machines, instruments, factories or elapsed qualification time.
- **O-score is optimization proximity, not product performance.** Gp/Gd/Gq capture only a separately established recoverable gap. No blanket computer/ch cheat bonus.
- Protagonist core remains **engine / GT / jet**, with metallurgy and aviation as major extensions. Computing is enabling infrastructure grown through demand, people, stimuli, proposal selection and limited strong hints; local specialists build/operate the machines.
- **1923–28** arithmetic/record/recalculation assistance; **1929–34** algorithm/procedure transfer; **1935–37 U4** method transition (`coarse search -> priority physical test -> recalculation -> independent check`); **1938–40** electronic/relay/drum expands L3 casework; 1941+ opens broader reduced-order loops but not modern CFD.
- **1921–24 hot-section long-duration clock** begins with simple local constant-load apparatus. Computation can organize/fit the archive; it cannot manufacture elapsed creep/fatigue/corrosion time.
- Separate **L_mat / L_core / H_qual / TBO_prod** and separate hours from start/thermal cycles.
- v38 does **not** change E-series PR/TIT/eta/thrust, aircraft speed/weight/range, or product TBO numerically. Those effects require later dedicated H->A.
- H->C->M->E->P->I->A remains current for aircraft; C is problem-specific O/G and the strongest Asai aviation bridge is engine/airframe interface. No blanket speed/weight bonus.
- Post-1941 actual procurement/OOB/production/combat remains HISTORY/FROZEN.

# CROSS-DOMAIN PREFLIGHT — inherited v37 gates

Purpose: prevent semantic omission and accidental promotion of conditional branches. Before dated design/history analysis, scan `CANONICAL-CHRONOLOGY-V39R1.*` and `CAPABILITY-TRIGGER-MATRIX-V39R1.tsv`.

## Mandatory order

1. **Chronology/status** — ordinary current analysis uses `current`/`scope`; `conditional` requires an explicit gate; `superseded` is provenance only; `mixed` requires source inspection.
2. **Requirement owner / historical counterpart** — ask who actually generates the requirement. Do not convert Asai's technology supply into platform omniscience.
3. **Availability R/P/X/N** — distinguish research, productization, external absorption and military/program availability.
4. **Propulsion/energy** — piston boost, diesel turbo, GT, TP/turboshaft, turbojet are separate technologies. Check part-load, installed mass and environment.
5. **Materials/environment** — separate steel/heat-treatment, resin/process, GFRP and CFRP maturity; do not backdate structural composites or treat GFRP as nonflammable.
6. **Mechanisms/controls** — gears, clutches, transmission, shaft/prop/cavitation, cooling, steering/traverse, electrics.
7. **Computation/QC/test** — computation shortens iteration and improves margins/repeatability; it does not create missing requirements or raw-physics bonuses.
8. **Production/maintenance/logistics** — tooling, spares, inspection, field/base/yard infrastructure and actual procurement remain separate gates.
9. **Integration tax / negative gate** — record attractive technology that was checked and rejected.

## v37 E8/E9+ LATER-WAR PROPULSION gate

Current authority is `main/asai-works-e8-e9-later-war-propulsion-rebaseline-1942-47.md`. Historical achievement dates are **comparison anchors, not Asai-worldline ceilings**.

Fixed calibration / decisions:
- Start from paid capability: 20+ years of GT research, multi-stage axial compressor work, VSV/bleed, mechanical fuel control, Campbell/rotordynamics practice, precision clearance control, Pt/Pt-Rh instrumentation, NDT/QC, combustor rigs, hollow air-cooled blades, precision casting/joining/coatings, Ni/non-Ni lines and dedicated test/computation infrastructure.
- **E8 = high-end practical / qualifiable technical rating** at PR9–10 / TIT940C / component eta≈0.86. Do not demote it merely because historical analogues arrived later.
- E8 `194 kJ/kg / ~31%` is a **gross Brayton comparison index**, before cooling/accessory/installation debit. Representative 4–5% cooling debit leaves ~181–183 kJ/kg / ~30.4–30.5% installed-core comparison. Neither is product thrust.
- E8 compressor architecture may remain **15–16-stage single-spool + VSV/bleed**. Two-spool is an operability trade, not an automatic prerequisite. Check whole-compressor matching, clearance, stall/surge, critical speed, bearing/seal and start/acceleration.
- Old **Ni 1943–44 automatic cutoff is superseded** for the high-end line. Current hard gates are cooling-passage/yield, vane/rotor/root/disk metal-temperature map, creep/oxidation/thermal fatigue, NDT reject rate, endurance/TBO and manufacturing yield.
- **E9 PR11–12 / TIT≈1000C / eta≈0.86–0.87 design/component/rig work is a current technical front.** Flight-qualified/series rating remains CONDITIONAL on two-spool/bearing/control if used, 5–7% staged cooling, full-core map, start/accel/surge, endurance and yield.
- **Generation != thrust/core scale.** Do not infer `E9 = 1,000 kgf/engine`; E6-L-J already has a 1,000–1,150 kgf research shadow on a different scale axis.
- **Do not use `1/2 Ve^2 = gross Brayton w` for installed turbojet thrust.** Close inlet recovery -> compressor map/work -> combustor pressure loss/TIT -> turbine compressor/accessory work + cooling -> turbine-exit total state -> nozzle expansion -> mass flow. Existing E5–E7 product thrust numbers remain conservative empirical anchors pending dedicated installed-engine H->A.
- Single-engine fighter convergence is CONDITIONAL on installed thrust, core diameter/weight, inlet drag, fuel/TBO and airframe CG/structure; technical capability does not automatically create procurement.
- Post-1941-12-08 actual procurement, production, deployment and combat remain HISTORY/FROZEN.

Always separate **historical comparison anchor**, **technical coordinate/front**, **component/rig qualification**, **installed product rating**, **customer requirement**, and **history/procurement**.

## v36 SUBMARINE INTEGRATED 2-CYCLE PRIME-MOVER gate

Current authority is `main/asai-works-submarine-next-gen-2cycle-prime-mover-gate-1941-45.md`; v35 electrical/yard and v23 second-generation hull parents remain in force.

Fixed calibration / decisions:
- 22号10型 / Model No.22 is a 10-cylinder 4-cycle single-acting 2,350 hp-class engine. A two-engine set covers the current second-generation ~4,700 hp surface-power band.
- 31号6型 proves Japanese Navy single-acting 2-cycle hardware capability existed by 1937; it is a technology anchor, not a fleet-series submarine main-engine precedent.
- 1941 large-2-cycle work reaching design/single-cylinder test proves research plausibility, not full-engine/ship/series maturity.
- **Capability ≠ requirement.** The current ~19 kt second-generation niche does not open a new integrated-2-cycle production family merely because Asai can improve scavenging/boost/QC.
- Central surface machinery remains a 22号10型-class ~4,700 hp pair candidate. Do not infer exact 19 kt from horsepower alone; check hull resistance/displacement/propeller/shaft efficiency.
- Integrated 2-cycle is GATED-OUT for central 1942–44 series. Reopen only for a concrete higher-power, installed-volume/mass, mission-fuel, signature or industrial requirement.
- If reopened, compare installed system mass/envelope, representative-load BSFC, start/low-load/transient scavenging, smoke/EGT/thermal/torsional margins, endurance/maintenance, tooling/spares and yard service access before ship installation.
- Post-1941-12-08 actual engine orders, hull construction, deployment, losses, combat and enemy-ASW response remain HISTORY/FROZEN.

## v35 SUBMARINE BATTERY / MOTOR / YARD gate

Current authority is `main/asai-works-submarine-battery-motor-yard-rebaseline-1938-44.md`; v21 underwater materials/safety authority and the corrected v23 hull concept remain parents.

Fixed calibration / decisions:
- I-15/B1 electrical H: 240-cell-class battery, two main motors, 2,000 hp total, 8 kt-class submerged performance.
- I-400 Mark I Model 13 calibration: 360 cells as three 120-cell batteries in parallel; 5,500 Ah at 1 h and 11,200 Ah at 20 h. This proves architecture, not one-hour 4,500 hp endurance.
- I-200 special D many-small-cell battery is a caution branch for electrolyte/separator/sediment/parallel-charge/H2/life problems; do not backdate it as the 1941 central.
- First-generation central retains ~360 cells / 3 groups + four ~1,000 hp-class motors, but programme scale is **1–2 hull-equivalent complete electrical/yard sets**. 3rd+, old 4–6 boats and series conversion are conditional.
- Per-boat relative electrical load versus I-15: battery cell count ~1.5×; 1,000 hp-class motor count 2×. Check lead/acid/separator/jar, copper/commutator/brush, load-test capacity, high-current switchgear and yard bays.
- **Motor 1 h thermal rating ≠ battery 1 h endurance.** Do not infer one hour at 15 kt from a 4,400–4,500 hp motor rating.
- 15 kt duration requires full-bank high-rate discharge with SOC/battery temperature/depth fixed and voltage/current/group balance/motor temperature/H2/cavitation/noise logged to the first limiting gate.
- Yard critical path includes battery-room finish, cell handling/acid/formation, ventilation/H2, bus/switchgear, motor foundation/shaft alignment/cooling, dockside tests, sea trials and replacement/service access. Do not invent yard man-hours without industrial sources.
- Post-1941-12-08 actual construction, production totals, deployment, losses, combat and enemy-ASW response remain HISTORY/FROZEN.

## v34 MINE COUNTERMEASURES gate

Current authority is `main/asai-works-mine-countermeasures-rebaseline-1939-45.md`.

Fixed calibration / decisions:
- Split **moored / magnetic / acoustic** mines. Moored sweep is mechanical wire/cutter/depressor/otter work; nonmagnetic hull is not the universal answer.
- Wartime central hull is **wood low-magnetic craft**. `wood hull ≠ magnetically invisible`: engine, shaft, gear, generator, anchors, weapons, cables and load remain in the signature ledger.
- Magnetic countermeasures split ship-signature reduction/degaussing from the artificial magnetic sweep source. Check high-current generator, cable resistance/insulation/heating, current control, EMI, emergency jettison and recovery gear.
- Acoustic mine work splits own-ship quieting from the intentionally loud acoustic sweep source. Do not treat quiet propulsion as the sweep mechanism.
- GFRP is **not required** for wartime minesweeping. v30 GFRP scale-up remains; a 1945-class low-speed nonmagnetic GFRP demonstrator is conditional material work, not the MCM central.
- 1940–41 wood low-magnetic coastal-sweeper package may be TECHNICALLY READY; actual Navy requirement/procurement/gear issue is customer/history-gated.
- Post-1941-12-08 minesweeper production, gear deployment, minefields, clearance/losses and operational effects remain FROZEN.

## v34 SURVEY / ARTILLERY METEOROLOGY gate

Current authority is `main/asai-works-survey-artillery-meteorology-rebaseline-1935-45.md`.

Fixed calibration / decisions:
- Japanese artillery already has survey/plotting/sound-detection/meteorological organization; wartime military weather services also use pilot balloons/radiosondes. Asai does not invent these capabilities.
- 1938–41 central is standardized survey coordinate work plus **pilot balloon + theodolite + surface temperature/pressure/humidity/density → ballistic wind/density message → firing table/fire-control entry**. Radiosonde is useful upper-air input but not a prerequisite for artillery meteorology.
- Asai gains are instrument calibration, standardized forms, reduction/interpolation, transcription checks, message integrity and turnaround. Do **not** assign a blanket hit-rate or first-round-hit multiplier.
- Keep the error budget split: gun/ammunition dispersion, survey/orientation, target location, met age/spatial mismatch, wind/density reduction, table/transcription, communications/setting delay and observation cycle.
- Sound/flash ranging requires station geometry, time base/synchronization, communications, terrain/met correction and trained plotting. Detection is not an automatic target coordinate.
- Actual artillery-intelligence unit allocation, met-station density, radiosonde stocks, fire-direction doctrine and post-1941 combat effect remain customer/history-gated.

## v33 RADIO/RADAR RELIABILITY gate

Current authority is `main/asai-works-radio-radar-reliability-rebaseline-1935-45.md`.

Fixed calibration / decisions:
- Do **not** treat Japanese wartime radio as uniformly low-quality. Separate set/circuit construction from environment proofing, installation, EMI, power regulation, maintainability, standardization and production repeatability.
- Asai-ready gains are impregnation/local sealing, connector/wiring discipline, chassis bonding/ground return, ignition-noise suppression, power-conditioning/regulation/filtering, tube/socket QC, burn-in, acceptance testing and field-fault feedback. Do not apply blanket +range, -failure-rate or MTBF multipliers.
- Vacuum-tube materials/QC can improve filament/heater consistency, seals, sockets and microphonics. It does not automatically create new cathode chemistry, high-frequency tubes, magnetrons or sensor architectures.
- **Power/integration is a gate**: generator/dynamotor behaviour, regulation, surge/filtering, thermal/vibration mounting and equipment-level acceptance must be checked. Army/Navy/common standardization requires customer adoption.
- **Airborne-radar timing is not backdated**: H-6 research begins 1941-11 and completion is 1942-08 calibration. Reliability building blocks may improve debug, acceptance and field repair after a radar programme exists; they do not create a 1939 operational airborne radar.
- **Good set ≠ good combat system**. Operator/maintainer training, spares/test gear, plotting/voice circuits, same-ship interference, CIC/fighter-direction/weapon-direction procedures and command adoption are separate gates.
- Fighter radio reinvestment means service availability/maintainability, not automatic 100% fit or CAP control. Actual post-1941 fit/removal/use, radar production/deployment, training strength, detection and combat effects remain HISTORY/FROZEN.

Always distinguish **sensor/set invention**, **reliability/integration**, **operator/maintenance system**, **procurement/deployment**, and **combat doctrine/effect**.

## v32 ROTORCRAFT 1942+ gate

Current authority is `main/asai-works-rotorcraft-1942-plus-rebaseline-1942-55.md`.

Fixed calibration / decisions:
- 1941 end-state from `asai-works-rotorcraft.md` remains: medium Re-go is still design research. Do not jump from E6-S-S core capability to a mature heavy helicopter.
- Old first-step **4–5.5t / 1,000–1,500shp** medium central is superseded. 1942–43 central is **~3,200kg / 15m / E6-S-S derated ~900shp continuous / ~1,000shp short-time** prototype/service-test.
- Hover ledger: 3,200kg/15m gives ideal induced power ~358hp; early FM/tail/transmission losses put engine-side hover roughly **720–840hp**. The full ~1,500shp core capability is not automatically used.
- Main gearbox/rotor life is a gate: ~100h ground endurance before staged flight release; **150–200h-class TBO** is limited-use entry and 250–300h-class is a maturation target. These are programme gates, not historical facts.
- 1942–45 wartime roles: liaison, litter evacuation, short cargo, shipboard trials, visual/radar-assisted maritime search, suppression, report/contact hold and conditional depth-charge attack.
- **Wartime dipping-sonar hunter-killer is NO.** 1951–52 is early helicopter-ASW/sonar calibration; 1955+ is mature dipping-sonar + attack-weapon helicopter calibration. Do not backdate service maturity from a 1943 concept proposal.
- Rescue begins with landing-based confined-area recovery/litter evacuation. Sea-hover hoist requires a separate winch/cable/hover/salt/training gate.
- VTOL does not erase deck footprint. Check 15m rotor clearance, roll/pitch, tie-down, hangar/folding, salt spray, exhaust/intake, maintenance and deck crew. Dedicated/semi-dedicated decks first; ordinary destroyer use is conditional.
- Post-1941-12-08 OOB/production/deployment/combat remains FROZEN. Old sea-escort/CVE fleet-number deltas derived from helicopter hunter-killer assumptions require history reopen before recomputation.

Always separate **engine capability**, **airframe/transmission maturity**, **mission sensor maturity**, **procurement**, and **post-1941 history**.

## v31 ARMY-FIGHTER H→A gate

Current authority is `main/asai-works-army-fighter-rebaseline-1937-42.md`.

Fixed calibration / decisions:
- Start from the Army requirement owner, not from Asai capability. Ki-43 light-fighter and Ki-44 fast-climb-interceptor requirements exist independently of early exhaust-turbo technology.
- Ki-43 H: ~500 km/h requirement, 5,000m/5min, ~800km and Ki-27-class-or-better maneuverability. Performance anchor is **495 km/h @ ~3.7–4.0km with normal 2,017.5kg**. Do not silently merge the separate 2,048kg comparison weight into that test state.
- Ki-43 retrofit 507–511 km/h is a physical comparison, not automatic A0. Current A0 is **~503–508 km/h @ ~4km**, with standard exhaust turbo **NO** and margin reinvested in firepower, radio/electrics, local structure and production repeatability.
- Ki-44 H is the December 1941 review: **583.5 km/h @ 3,870–4,000m, normal 2,550kg, Ha-41 rated 1,260PS @3,700m, 4,000m climb 4:38**. Old 580@3,700/2,600kg is superseded.
- Ki-44 physical I using the current D01 exhaust/surface method is **596.9–601.5 km/h**. Current A0 is **~596–600 km/h** after reinvestment; standard exhaust turbo is **NO** because the original ~600km/h requirement is essentially closed without it.
- **Capability is not requirement.** Do not infer a 1941 P-47-class mass-produced fighter merely because an exhaust turbo exists. Requirement, airframe, engine, installation, production and service gates remain separate.
- **Ki-64 designation is restored** to Kawasaki's tandem-Ha-40/Ha-201 experimental heavy-fighter branch with contra-rotating propeller and wing surface cooling. It is a 1943-first-flight calibration branch, not a 1941 production high-altitude fighter.
- A sustained **7–10km** high-altitude turbo fighter remains an **unnamed CONDITIONAL** shadow until the Army states that requirement. Ki-87/Ki-94 may become later candidates only after such a requirement; old Ki-64 seat-preemption logic is invalid.
- Post-1941-12-08 OOB/production/deployment/combat remains FROZEN. Old OOB Ki-64 entries are history/provenance technical mismatches until the history gate is explicitly reopened.

Always distinguish H test load, retrofit I, design-origin A, and post-1941 history. Do not use frozen OOB to validate a withdrawn technical precursor.

## v28 LARGE-MARINE gate

Current authority is `main/asai-works-surface-ship-large-marine-rebaseline-1934-41.md`.

Fixed calibration / decisions:
- Taigei No.11 and battleship No.13 are separate EHs. Taigei improvement is not proof of No.13.
- Historical No.13 Type 6: 480×600 mm, 350 rpm, 4,800 PS-class, 144 h endurance completed, 95+ score. Separate technical defects (smoke/ring/liner-piston wear) from adoption-risk defects (no No.13 service record; poor No.11 service record).
- Asai computation/QC may shrink the technical defect tail but cannot manufacture service history before the 1937 capital-ship decision. A-140F6 all-steam-turbine remains central; F5 mixed diesel/turbine is conditional/provenance.
- A free-power turbine is not a reversing device. Explicitly identify astern architecture: base steam/diesel, CPP, reversing gear, or electric transmission.
- Destroyer/cruiser/carrier GT boost or return-home installations are conditional until intake/filter/exhaust, reducer/shaft/clutch/torsion, salt MTBO, installed mass/volume, fuel and yard integration are closed.
- Do not revive legacy post-1941 carrier-count changes derived from assumed GT adoption; OOB/production/deployment/combat remains HISTORY/FROZEN.

## v27 TANK-EARLY gate retained

Current authority is `main/asai-works-tank-early-computation-materials-rebaseline-1928-41.md`.

Do not revive as current:
- Type 89 as a 120hp diesel throughout 1929–34;
- production turbo Type 89;
- Ha-Go 130–145hp as the production central or automatic 20–25mm armor growth;
- Chi-Ha as a later turbo retrofit rather than the worldline 1938 200/220hp production central;
- Shinhoto Chi-Ha 5-crew/3-man-turret worldline specification;
- Chi-He 260hp operational boost, 400mm initial track, powered coarse traverse or standard full-crew voice intercom.

For each early tank, first state the Army/manufacturer requirement independently of Asai. Then ask what turbo/materials/computation/QC actually buy in transmission, cooling, reliability, high-altitude performance, crew workload and production repeatability.

## v29 MARINE-GT-CRAFT gate

Current design authority is `main/asai-works-marine-gt-small-craft-design-closure-1938-43.md`; `main/asai-works-marine-gt-small-craft-rebaseline-1934-43.md` is historical/physics provenance.

Fixed calibration / decisions:
- ~20.5t Japanese No.1-class: ~1,800hp / 38–38.5kt / two 45cm torpedoes; T-51 is the heavy-boat failure calibration.
- Old 2×1,300hp GT + 350hp diesel independent-three-shaft central is superseded. E5 first marine qualification is two conventional piston shafts for cruise/astern plus one independent ~1,300hp E5 GT boost shaft.
- Trial speed is not operating/service speed. Treat E5 42–46kt and E6 42–44kt as clean/full-load trial design bands unless sea-state/service penalties are separately closed.
- Initial prop bands: E5 0.74–0.80m / 2,050–2,300rpm; E6 0.86–0.94m / 1,750–1,950rpm. Cavitation/ventilation remains a tank/sea-trial gate.
- Complete marine installed GT-path bands: E5 2.8–3.4kg/kW (central 3.1), E6 2.2–2.8kg/kW (central 2.5), excluding fuel/long shaft/prop.
- E5 qualification: ~150h cumulative, ~50h hot-section inspection. E6: ~300h cumulative, ~100h inspection, ~500h design-TBO target. Do not promote these to fleet historical MTBO.
- Pure-GT normal torpedo-boat mass production is NO for the E5/E6 period; sprint/test craft remains a conditional shadow.
- E6 50–55t / 4×45cm / nominal 5,200hp / ~42–44kt full-load trial / ~450–600nm planning-range technical shadow is valid, but actual requirement/procurement/series production is conditional. Hard 40kt service requires roughly 6,000–7,100hp or lower displacement.
- 2GT high-power craft require high-speed marine CPP/feathering or equivalent low-speed prop-drag mitigation; domestic implementation/endurance is conditional.
- v30 hull authority supersedes the old GFRP next-gate wording: 1942–43 central is full-scale section + 8–12m demonstrator; 20–30t full high-speed and 50–55t full-GFRP remain conditional.

Always check: hull/trim/sea state, shaft/prop/cavitation/ventilation, installed mass, salt/intake/inspection, part-load fuel, reverse/harbor handling, weapons/crew/fuel weight and yard repair. Small-craft success is **not** the sole prerequisite for all naval GT applications.

## v30 GFRP SMALL-CRAFT HULL gate

Current materials/scale-up authority is `main/asai-works-gfrp-small-craft-hull-rebaseline-1940-46.md`.

Fixed calibration / decisions:
- Do not equate early resin/glass availability with a 20m/40kt primary hull. Historical scale-up is the calibration; Asai's epoxy/silane/QC moves the ladder earlier but does not erase it.
- 1940–41: coupons, bonded joints, curved panels, inserts and real seawater/hot-wet exposure.
- 1941–42: full-scale bottom/forebody/chine/keel/engine-bed sections plus repeated pressure/slam rigs; thick-section exotherm, voids and secondary bonds are explicit gates.
- 1942–43 central: **full-scale high-speed hull section + 8–12m low/medium-speed all-GFRP demonstrator**. Do not promote this to a 20–30t full high-speed boat.
- 1943–44+ 20–30t full-GFRP high-speed prototype is conditional. Initial construction uses solid GFRP bottom/keel/chine and only limited sandwich above the waterline.
- 1944–45 limited operational testing requires wet/slam/repair qualification; procurement/series production remains separate.
- 50–55t E6 wartime central hull remains wooden double-diagonal/laminated. Full-GFRP high-speed E6 is conditional at a 1946+ technical gate. Low-speed nonmagnetic experiments may precede it but do not imply minesweeper adoption.
- 19–20m / 20–30t planning mass band: primary GFRP structure 4.5–6.5t, glass 2.5–3.8t, resin 1.8–2.7t. The old generic 6–8t glass-per-boat value is not valid for this class.
- Wet qualification uses wet allowables; the inherited 60% dry-baseline interlaminar floor remains a reject floor, with ~70% dry-baseline retention as the primary-structure target band.
- Slam/fatigue is not a tensile-coupon problem. Working programme gates include 10^5-class full-scale panel pulses and staged sea trials; these are design programme targets, not historical facts.
- NDT and repair are mandatory: tap/ultrasound plus depot scarf/step repair and re-test for primary bottom/chine damage. Emergency patches restore watertightness, not automatic full-speed structural capability.
- **GFRP is not nonflammable.** Kerosene/diesel lowers fuel hazard; machinery spaces still need metal firebreak/liner, air gap/insulation and separate fire testing.

Always identify which scale is being discussed: coupon/panel, full-scale section, 8–12m demonstrator, 20–30t high-speed prototype, or 50–55t E6. Do not let a lower-scale pass satisfy a higher-scale adoption gate.

## v26 aircraft gates retained

Aircraft role/rebaseline authority remains `main/asai-works-aircraft-computation-closure-1937-46.md`. AT-3/Ki-92 and Fugaku development milestones remain conditional. Do not revive B6A Tenzan, Tenzan-bomber→Ryusei, Ki-48TP production, old Ginga seven-seat total-replacement or old carrier-jet density-only speed rows.

## v25 TANK-NEXT gate retained

`main/asai-works-tank-next-generation-conditional-1939-45.md` remains a conditional technical shadow. Actual research authorization, threat-intelligence timing, prototypes, production and deployment are not current history.

## Minimum record

| Family | Result | Reason/source |
|---|---|---|
| chronology / semantic status | CHECKED / GATED-OUT / N/A | source |
| requirement owner / historical counterpart | CHECKED / GATED-OUT / N/A | source |
| propulsion / part-load / fuel / environment | CHECKED / GATED-OUT / N/A | source |
| materials / structure / corrosion | CHECKED / GATED-OUT / N/A | source |
| mechanisms / controls / shaft/prop/transmission | CHECKED / GATED-OUT / N/A | source |
| computation / optics / QC / test | CHECKED / GATED-OUT / N/A | source |
| production / maintenance / logistics | CHECKED / GATED-OUT / N/A | source |
| integration tax / negative gate | CHECKED / GATED-OUT / N/A | source |


## v40 E4/E5 COOLED INSTALLED-CYCLE gate

Current authority: `main/asai-works-e4-e5-installed-cycle-rebaseline-1931-37.md`.

Fixed accounting rules:

- E4 `93 kJ/kg / 18%` and E5 `126 kJ/kg / 22.5%` are **gross simple-Brayton comparison indices**, not installed shaft values.
- `component efficiency` is compressor/turbine component performance; it does not silently include combustor pressure loss, cooling bleed, mechanical/accessory losses.
- E4 cooling central **3.0%** (audit 2.2–3.8%); E5 Ni@800 **4.0%** (3.2–5.0%); E5 non-Ni@800 full **6.0%** (5.0–7.5%); E5 non-Ni@765 **4.0%** (3.2–5.0%).
- E4 installed shaft coordinate **~75.7 kJ/kg / 15.0%**, audit **69–80 / 13.8–16.0%**.
- E5 Ni@800 installed shaft **~104.3 / 19.3%**, audit **98–110 / 18.1–20.2%**.
- E5 non-Ni@800 full central **~99.5 / 18.7%**; E5 non-Ni@765 central **~93.5 / 18.4%**.
- Cooling air is neither deleted nor given full hot-gas work. Tap pressure and reinjection position matter; use the reproducible v40 audit model/ranges.
- Old direct product proofs `E4 93×5.4≈500kW` and `E5 126×6≈1,000hp` are superseded. The **targets** remain open for product resize: E4 500kW implies roughly 6.2–7.2kg/s; E5 756kW roughly 6.9–7.8kg/s on the Ni line.
- Do not propagate aircraft/ship performance or adoption until compressor diameter/rpm, weight, power-turbine/reducer, installation and life close at the resized flow.
- E4 regeneration is closed by v42: use 467.7kW / 19.34% / 0.433kg/kWh central and the 0.6–1.1t / 1.4–2.5m3 package; old 25%/0.33 is superseded.

Historical Neuchatel/Jumo/NACA data are calibration anchors only; historical dates remain non-ceilings.
