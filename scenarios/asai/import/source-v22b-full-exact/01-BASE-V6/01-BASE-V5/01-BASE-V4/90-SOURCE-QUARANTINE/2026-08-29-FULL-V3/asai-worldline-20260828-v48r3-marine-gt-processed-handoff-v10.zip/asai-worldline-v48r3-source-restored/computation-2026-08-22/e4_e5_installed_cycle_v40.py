#!/usr/bin/env python3
"""v40 E4/E5 cooled installed-cycle audit.

All flows are normalized to 1 kg/s compressor-inlet air.
The canonical E4/E5 Brayton values are kept as *gross comparison indices*.
This model then pays, in order:
  1) staged compressor bleed for vane / rotor / root / seal cooling,
  2) combustor total-pressure loss,
  3) exhaust/diffuser pressure margin,
  4) shaft mechanical + accessory loss,
  5) combustion efficiency when reporting fuel-based thermal efficiency.

Cooling-stream 'recovery' coefficients are audit surrogates for where the coolant
re-enters the expansion path; they are NOT hardware constants. They let the
calculation avoid the two wrong extremes 'bled air vanishes' and 'all coolant
expands like hot gas'.
"""
from __future__ import annotations
import csv, math
from pathlib import Path

CP = 1.005       # kJ/(kg K)
GAMMA = 1.4
T1 = 288.0       # K
A = (GAMMA - 1.0) / GAMMA


def t_comp(pr: float, eta_c: float) -> float:
    return T1 * (1.0 + (pr**A - 1.0) / eta_c)


def comp_work(pr: float, eta_c: float) -> float:
    return CP * (t_comp(pr, eta_c) - T1)


def gross(pr: float, tit_c: float, eta: float):
    t3 = tit_c + 273.15
    t2 = t_comp(pr, eta)
    tau = pr**A
    t4 = t3 * (1.0 - eta * (1.0 - 1.0 / tau))
    wc = CP * (t2 - T1)
    wt = CP * (t3 - t4)
    w = wt - wc
    q = CP * (t3 - t2)
    return w, w / q


def installed(case):
    pr, tit_c, eta = case['pr'], case['tit_c'], case['eta']
    t3 = tit_c + 273.15
    t2 = t_comp(pr, eta)
    bleeds = case['bleeds']
    btot = sum(x['b'] for x in bleeds)

    # Only the mass that remains reaches compressor discharge; each bleed stream
    # pays compression only to its tap pressure.
    wc = (1.0 - btot) * comp_work(pr, eta)
    for x in bleeds:
        tap_pr = pr ** x['tap_frac']
        wc += x['b'] * comp_work(tap_pr, eta)

    # Combustor pressure loss and finite exhaust/diffuser pressure margin reduce
    # the useful turbine expansion ratio.
    rt = pr * (1.0 - case['dp_comb']) / case['exhaust_ratio']
    expansion = CP * eta * (1.0 - rt ** (-A))

    # Main gas receives fuel heat. Cooling streams re-enter at different points;
    # recovery factors represent the fraction of full expansion opportunity they
    # can contribute to shaft work after throttling/mixing.
    enthalpy_weight = (1.0 - btot) * t3
    for x in bleeds:
        tap_pr = pr ** x['tap_frac']
        enthalpy_weight += x['b'] * x['recovery'] * t_comp(tap_pr, eta)
    wt = expansion * enthalpy_weight

    w_gaspath = wt - wc
    w_shaft = case['eta_mech'] * wt - wc - case['accessory_kjkg']
    q_to_gas = (1.0 - btot) * CP * (t3 - t2)
    q_fuel = q_to_gas / case['eta_comb']
    eta_shaft = w_shaft / q_fuel
    return {
        'bleed_total': btot,
        'w_gaspath': w_gaspath,
        'w_shaft': w_shaft,
        'eta_shaft': eta_shaft,
        'wc': wc,
        'wt': wt,
        'rt': rt,
    }


def bleeds(vane, rotor, root, seal):
    return [
        {'name':'vane',  'b':vane,  'tap_frac':1.00, 'recovery':0.85},
        {'name':'rotor', 'b':rotor, 'tap_frac':1.00, 'recovery':0.55},
        {'name':'root',  'b':root,  'tap_frac':0.75, 'recovery':0.15},
        {'name':'seal',  'b':seal,  'tap_frac':0.55, 'recovery':0.00},
    ]

CASES = [
    dict(name='E4-central', pr=4.5, tit_c=710, eta=0.82,
         bleeds=bleeds(.0075,.0125,.006,.004), dp_comb=.040,
         exhaust_ratio=1.015, eta_mech=.990, accessory_kjkg=1.0, eta_comb=.980),
    dict(name='E5-Ni-800-central', pr=6.0, tit_c=800, eta=0.83,
         bleeds=bleeds(.010,.018,.008,.004), dp_comb=.035,
         exhaust_ratio=1.015, eta_mech=.992, accessory_kjkg=1.0, eta_comb=.985),
    dict(name='E5-nonNi-800-central', pr=6.0, tit_c=800, eta=0.83,
         bleeds=bleeds(.014,.030,.010,.006), dp_comb=.035,
         exhaust_ratio=1.015, eta_mech=.992, accessory_kjkg=1.0, eta_comb=.985),
    dict(name='E5-nonNi-765-central', pr=6.0, tit_c=765, eta=0.83,
         bleeds=bleeds(.010,.017,.008,.005), dp_comb=.035,
         exhaust_ratio=1.015, eta_mech=.992, accessory_kjkg=1.0, eta_comb=.985),
]

# Audit bands. These are uncertainty envelopes for cooling/pressure/mechanical
# accounting, not production tolerances.
BANDS = {
    'E4-central': dict(B=(.022,.038), dp=(.032,.050), ex=(1.010,1.025), mech=(.985,.993), acc=(.6,1.5), comb=(.970,.990)),
    'E5-Ni-800-central': dict(B=(.032,.050), dp=(.028,.045), ex=(1.010,1.022), mech=(.988,.995), acc=(.6,1.5), comb=(.980,.992)),
    'E5-nonNi-800-central': dict(B=(.050,.075), dp=(.030,.050), ex=(1.010,1.025), mech=(.988,.995), acc=(.6,1.7), comb=(.980,.992)),
    'E5-nonNi-765-central': dict(B=(.032,.050), dp=(.028,.045), ex=(1.010,1.022), mech=(.988,.995), acc=(.6,1.5), comb=(.980,.992)),
}


def scaled_bleeds(base, total):
    old = sum(x['b'] for x in base)
    return [{**x, 'b':x['b']*total/old} for x in base]


def corners(base):
    band = BANDS[base['name']]
    vals=[]
    for B in band['B']:
      for dp in band['dp']:
       for ex in band['ex']:
        for mech in band['mech']:
         for acc in band['acc']:
          for ce in band['comb']:
            c=dict(base)
            c['bleeds']=scaled_bleeds(base['bleeds'],B)
            c['dp_comb']=dp; c['exhaust_ratio']=ex; c['eta_mech']=mech
            c['accessory_kjkg']=acc; c['eta_comb']=ce
            vals.append(installed(c))
    return {
        'w_min': min(v['w_shaft'] for v in vals),
        'w_max': max(v['w_shaft'] for v in vals),
        'eta_min': min(v['eta_shaft'] for v in vals),
        'eta_max': max(v['eta_shaft'] for v in vals),
    }


def main():
    out=[]
    for c in CASES:
        wg, eg = gross(c['pr'], c['tit_c'], c['eta'])
        r=installed(c); b=corners(c)
        out.append({
            'case': c['name'], 'PR': c['pr'], 'TIT_C': c['tit_c'], 'eta_component': c['eta'],
            'cooling_bleed_central_pct': 100*r['bleed_total'],
            'combustor_dp_central_pct': 100*c['dp_comb'],
            'w_gross_kJkg': wg, 'eta_gross_pct':100*eg,
            'w_installed_shaft_central_kJkg':r['w_shaft'],
            'w_installed_shaft_band_low_kJkg':b['w_min'],
            'w_installed_shaft_band_high_kJkg':b['w_max'],
            'eta_installed_fuel_central_pct':100*r['eta_shaft'],
            'eta_installed_fuel_band_low_pct':100*b['eta_min'],
            'eta_installed_fuel_band_high_pct':100*b['eta_max'],
            'gross_to_installed_loss_pct':100*(1-r['w_shaft']/wg),
        })
    dest=Path(__file__).with_name('E4-E5-INSTALLED-CYCLE-V40.tsv')
    with dest.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=out[0].keys(),delimiter='\t')
        w.writeheader(); w.writerows(out)
    for row in out:
        print(row)

if __name__=='__main__': main()
