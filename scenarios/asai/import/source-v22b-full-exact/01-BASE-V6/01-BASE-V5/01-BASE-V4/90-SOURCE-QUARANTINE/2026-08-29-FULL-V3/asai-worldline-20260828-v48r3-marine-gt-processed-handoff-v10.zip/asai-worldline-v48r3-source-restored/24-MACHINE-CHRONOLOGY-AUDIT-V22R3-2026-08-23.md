# MACHINE CHRONOLOGY AUDIT — v22r3 — 2026-08-23

Worldline semantics remain **v22**. This revision adds a machine-first chronology/retrieval layer only.

## Build scope

- Scanned: every `main/*.md`.
- Temporal Markdown tables detected: **49**.
- Temporal source rows indexed: **329**.
- Rows whose date text could not be normalized to numeric year bounds: **0**. They remain searchable by `date_text` and `row_json`; no row is discarded for parse failure.
- The TSV and JSONL are generated from the same record set.
- Every record contains source file, source line, source SHA-256, original date text, full row JSON, and search text.

## Domain counts

- `aviation`: 59
- `business-product`: 40
- `computation`: 21
- `cross-domain`: 108
- `fuel-energy`: 9
- `ground-vehicle`: 18
- `marine`: 29
- `materials-structure`: 16
- `propulsion-core`: 29

## Semantics

The machine chronology is intentionally **source-preserving rather than deduplicating**. Several canonical documents describe the same year from different views. A machine must not collapse these into one fact merely because dates/names match. `authority_rank` is a retrieval preference: 100 = central gate/master tables, 95 = whole-period master/timeline layers, 90 = domain timeline/ledger, 80 = other current-main temporal tables.

`start_year`/`end_year` are retrieval hints. For `approx-*`, `open-*`, or any ambiguity, `date_text` and the cited source row control.

R/P/X/N fields are copied when the source table provides them. Blank stages mean “not encoded in this source row,” not “false.”

## Operational rule

For any question whose answer depends on *what existed when*, first query this chronology by year/range + domain/keyword. Then open the cited canonical source(s), run the capability trigger matrix, and only then perform the substantive calculation or narrative inference. This makes “forgot turbo / FRP / computation / product availability” detectable as a process failure rather than an invisible omission.
