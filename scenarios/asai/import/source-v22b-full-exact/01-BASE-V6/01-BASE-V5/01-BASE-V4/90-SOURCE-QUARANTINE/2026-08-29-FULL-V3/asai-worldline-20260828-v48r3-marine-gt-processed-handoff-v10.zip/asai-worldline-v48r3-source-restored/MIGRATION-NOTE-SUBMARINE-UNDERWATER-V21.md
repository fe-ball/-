# Migration note — submarine underwater v21

v20の「水中要求・battery/主電動機産業」を閉鎖。

- 8kt級/鉛chemistry/cell数は初期大型巡潜で維持する一方、旧「battery H据え置き」を撤回。
- 日本電池/湯浅を史実産業Hとし、浅井はseparator、glass mat、jar/support、sealing、ventilation、cycle/shock/Qを改善。
- 改良batteryは350–450cycleを受領目標帯。新品定格航続の+%は未固定。
- 1939–40から急速潜航をtrajectory受領へ。exact秒を捏造せず、世界線同一船体改善は10–20%感度。
- own-ship noise研究を1–2年前倒しし、1941新造艇からquiet/avoid rpm mapを標準化。近代的吸音tile/FRP propellerは与えない。
- 主電動機は2,000hp級維持、湿塩/温度/絶縁/整流/衝撃を含むrating mapを作る。
- 潜水艦総括の必須5軸（公称諸元/内部subsystem/設計自由度/任務戦術/艦隊program）を導入。
- 次P0は1941–44次世代潜水艦ニッチ再生成。
