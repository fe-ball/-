# Migration note — submarine-aircraft-v18

- 基底: submarine-maturation-v17。
- 新規正本: `main/asai-works-submarine-aircraft-1929-41.md`。
- 目的: 1938–41潜水艦本体の前に、E6Y/E9W/E14Yとエポキシ/FRPの年代ゲートを固定する。
- 変更: `00-START-HERE`, `03-OPEN-ISSUES`, `main/asai-works-handoff`, `main/asai-works-submarine-maturation-1934-37` を接続。
- 非変更: 戦史/OOB、M6A/伊400、Gasuden/Hitachi小型星型の性能、潜水艦1938–41本体の数値。
