# Migration note — engine-computation-maturation-v8 (2026-08-23)

v7を完全保持した上で、1934–37の発動機計算文化成熟と発動機H→A上流帳簿を追加した。

## New canonical files
- `09-ENGINE-COMPUTATION-MATURATION-P0-2026-08-23.md`
- `main/asai-works-engine-computation-maturation-1934-37.md`
- `main/asai-works-engine-h-to-a-ledger.md`

## Canonical changes
- 三菱/中島のU3→U4移行を1934–37で段階化。
- 三菱A4→A8/金星は暦の大幅前倒しを拒否。主配当は成熟・故障診断・次系列移植。
- NAM/栄前段は1933開始時からU3級で、ベンチ成熟3–6か月級の余地を中央感度化。ただし採用日は自動前倒ししない。
- 1937二速瑞星は未合格の継続試験枝。
- 零戦A0の栄12値は当面A0-S枝。瑞星vs栄監査まで唯一の発動機正準としない。
- 発動機上流 `EH→EC→EMQ→ES→EI→EA` を正式化。航空機EはEAを入力にする。

## Not changed yet
- 1937–41瑞星/栄の勝敗。
- 零戦A0/A1の最終発動機。
- BSFC、二速過給器故障原因、具体的な月産能力。
- 1941 OOB、凱風E6最終I。
