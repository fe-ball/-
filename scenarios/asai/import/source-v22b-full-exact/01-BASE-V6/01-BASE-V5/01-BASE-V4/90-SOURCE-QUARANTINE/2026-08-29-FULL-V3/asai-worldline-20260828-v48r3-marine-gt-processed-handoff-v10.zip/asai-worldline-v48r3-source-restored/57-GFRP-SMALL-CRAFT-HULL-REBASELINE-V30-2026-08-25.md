# v30 — GFRP小型艇一次艇体 rebaseline

Current parent: `main/asai-works-gfrp-small-craft-hull-rebaseline-1940-46.md`

## Central correction
- 旧v27の「1942–43に20–30t級完成GFRP高速艇を中央」を撤回。
- 1942–43 central = full-scale bottom/forebody section + 8–12m low/medium-speed all-GFRP demonstrator.
- 20–30t full-GFRP high-speed hull = conditional prototype from 1943–44+ after wet/slam/repair gates.
- 50–55t E6 full-GFRP high-speed hull = conditional 1946+ technical gate; wartime E6 central hull remains wood double-diagonal/laminated.
- low-speed nonmagnetic experimental hull may branch from 1945+, but mine-threat/procurement remains separate.

## Engineering corrections
- First high-speed prototype uses solid GFRP bottom/keel/chine; sandwich is restricted mainly to deck/topside until core wet/impact behavior is proven.
- Thick-section exotherm, voids and secondary-bond process are explicit gates.
- GFRP glass fraction uses a realistic working mass band rather than importing CFRP Vf≈50%.
- E5/20–30t planning mass: cured primary composite 4.5–6.5t; glass 2.5–3.8t; resin 1.8–2.7t. These are mass-balance bands, not scantling approval.
- Old glass-fiber 6–8t/boat assumption is removed from the 20–30t case.
- Qualification adds wet-conditioned full-scale slam panels, staged sea trials, NDT and depot repair/retest.
- GFRP is not fireproof. Kerosene/diesel reduces fuel hazard; metal firebreak/liner/air-gap/glass-wool protection remains mandatory.

## Historical calibration
- 1942 historical FRP boat anchor is dinghy scale.
- U.S. Navy BuShips began plastic 28-ft personnel-boat experiments in 1946 and larger experimental landing craft later.
- Asai epoxy/interface/QC can pull this test ladder forward, but does not justify skipping directly to a 20m 40kt current production hull in 1942–43.

## Status
- GFRP small-craft hull technical rebaseline: CLOSED/REBASED.
- 20–30t full high-speed GFRP prototype: CONDITIONAL.
- 50–55t full high-speed GFRP E6: CONDITIONAL.
- post-1941 OOB/production/deployment/combat: FROZEN.
