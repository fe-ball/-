#!/usr/bin/env python3
"""E4/E5 product mass-flow / size re-baseline — P1 working calculation.

Uses v40 installed shaft specific-work coordinates. Geometry is a first-order
sizing audit, not a compressor-map closure. Exact stage matching / operability
remains a later gate.
"""
from math import pi, sqrt
import csv

RHO_SL = 1.225       # kg/m3, sea-level static audit inlet
LHV = 43.0           # MJ/kg
HP_KW = 0.745699872
GAMMA = 1.4
CP = 1005.0          # J/kg/K
T1 = 288.0           # K

# v40 installed-cycle coordinates
CASES = [
    dict(name='E4-central', family='E4', mdot_design=6.70, w=75.7325933545, eta=0.15028253555,
         target_kw=500.0, axial_pr=1.60, centrifugal_pr=4.5/1.60,
         axial_stages='2-3', tip_speed=420.0, rpm=16000.0,
         dry_mass_low=800, dry_mass_high=900, outer_d_low=0.66, outer_d_high=0.74),
    dict(name='E5-Ni-800', family='E5', mdot_design=7.60, w=104.323534273, eta=0.19253553549,
         target_kw=1000*HP_KW, axial_pr=1.80, centrifugal_pr=6.0/1.80,
         axial_stages='3-4', tip_speed=455.0, rpm=17500.0,
         dry_mass_low=390, dry_mass_high=460, outer_d_low=0.68, outer_d_high=0.76),
    dict(name='E5-nonNi-800', family='E5', mdot_design=7.60, w=99.4719124001, eta=0.18748755314,
         target_kw=1000*HP_KW, axial_pr=1.80, centrifugal_pr=6.0/1.80,
         axial_stages='3-4', tip_speed=455.0, rpm=17500.0,
         dry_mass_low=390, dry_mass_high=460, outer_d_low=0.68, outer_d_high=0.76),
    dict(name='E5-nonNi-765', family='E5', mdot_design=7.60, w=93.4530302305, eta=0.18412278691,
         target_kw=1000*HP_KW, axial_pr=1.80, centrifugal_pr=6.0/1.80,
         axial_stages='3-4', tip_speed=455.0, rpm=17500.0,
         dry_mass_low=390, dry_mass_high=460, outer_d_low=0.68, outer_d_high=0.76),
]

def annulus(mdot, axial_velocity=110.0, hub_tip=0.50):
    area = mdot/(RHO_SL*axial_velocity)
    dt = sqrt(4*area/(pi*(1-hub_tip**2)))
    dh = hub_tip*dt
    blade_h = (dt-dh)/2
    return area, dt, dh, blade_h

def impeller_diameter(U, rpm):
    return 60*U/(pi*rpm)

def sfc(eta):
    return 3.6/(LHV*eta)  # kg/kWh

rows=[]
for c in CASES:
    area, dt, dh, bh = annulus(c['mdot_design'])
    p_kw = c['mdot_design']*c['w']
    mdot_target = c['target_kw']/c['w']
    row = dict(
        case=c['name'], family=c['family'], installed_w_kJkg=c['w'], shaft_eta_pct=100*c['eta'],
        design_mdot_kgs=c['mdot_design'], target_mdot_kgs=mdot_target,
        design_power_kW=p_kw, design_power_hp=p_kw/HP_KW,
        sfc_kg_kWh=sfc(c['eta']), target_fuel_kg_h=c['target_kw']*sfc(c['eta']),
        inlet_annulus_area_m2=area, inlet_tip_d_m=dt, inlet_hub_d_m=dh, inlet_blade_h_m=bh,
        axial_booster_PR=c['axial_pr'], centrifugal_stage_PR=c['centrifugal_pr'],
        axial_stage_count=c['axial_stages'], centrifugal_tip_speed_ms=c['tip_speed'],
        gas_generator_rpm=c['rpm'], centrifugal_impeller_d_m=impeller_diameter(c['tip_speed'], c['rpm']),
        outer_engine_d_low_m=c['outer_d_low'], outer_engine_d_high_m=c['outer_d_high'],
        dry_mass_low_kg=c['dry_mass_low'], dry_mass_high_kg=c['dry_mass_high'],
    )
    rows.append(row)

out='/mnt/data/asai-worldline-v40r1-work/computation-2026-08-22/E4-E5-PRODUCT-RESIZE-P1.tsv'
with open(out,'w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()),delimiter='\t')
    w.writeheader(); w.writerows(rows)

for r in rows:
    print(r)
print('wrote',out)
