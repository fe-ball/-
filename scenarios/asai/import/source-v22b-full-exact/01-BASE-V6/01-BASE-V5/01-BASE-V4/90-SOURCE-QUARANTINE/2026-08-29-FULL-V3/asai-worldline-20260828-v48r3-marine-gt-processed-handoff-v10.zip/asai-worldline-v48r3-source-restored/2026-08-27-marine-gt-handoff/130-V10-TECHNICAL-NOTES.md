# Marine GT V10 — qualification-craft dossier and test-platform information value

## 1. Scope

V10 stays inside the V8 history stop line. It does not decide that an E5 qualification craft, Momi, a dedicated laboratory ship, LL20, or any carrier installation was actually built or selected. It closes two technical questions: what the E5 qualification-craft design dossier can legitimately contain with the current source base, and what each test platform uniquely proves versus merely duplicates.

## 2. E5 qualification craft

The purpose-built close derivative of the First-Type family remains a **working engineering architecture**, not a historical event. The fixed new GT/test hardware takeoff remains 1.001–1.421 t dry (central 1.199 t) with a longitudinal centroid near 6.17 m from the transom. The craft keeps the inherited twin piston propulsion as safe-return/astern machinery and adds one 1,000 hp E5-S centerline test path.

V10 deliberately does **not** close total dry displacement, whole-craft LCG/KG or final scantling thickness. The source set lacks the First-Type lightship weight book, vertical moments and detailed mass of the deleted torpedo/launch/combat outfit. Because the craft is purpose-built, local structure intersecting the center test bay is replaced rather than simply added atop the historical 20.5 t full-load number. Any exact displacement derived by gross addition would therefore be false precision and likely double counting.

The dossier instead closes the design ledger: what stays, what is deleted, what is added, which load cases size the local structure, and which quantities must be measured or obtained from yard drawings before mass properties can be promoted.

## 3. Test platforms are complementary

The V10 coverage matrix rejects a single universal `marine qualification platform`. Shore rigs, a small high-speed qualification craft, an obsolete hull, a dedicated laboratory ship and an LL20 R2 stand answer different questions.

- **Shore rigs** are non-substitutable for controlled endurance, calibrated salt dose, repeatable teardown and fault isolation.
- **The E5 qualification craft** has unique value for high-speed small-craft prop/trim/ventilation, center-prop windmilling and compact marine-package transients. These data are not a gate for every large-ship GT application.
- **Momi / an obsolete hull** has high marginal value where an available hull can cheaply supply real pitch/roll/vibration, generous access, sea contamination and larger exhaust/machinery experiments. Its obsolete geometry cannot be promoted to a carrier or modern high-speed boat.
- **A dedicated 700–1,000 t laboratory ship** is not a technical prerequisite for E4/E5. Its nonduplicated value appears only when the program repeatedly needs large-module sea integration, interchangeable foundations/trunks and assured sea time, and opportunistic hulls would impose recurring redesign or availability penalties. That is an activation gate, not a selection.
- **LL20 R2** is non-substitutable for the scale-specific hot-core physics of a ~20.56 kg/s PR7 article; no small craft or old hull can pay that clock by analogy.

This structure is intentionally compatible with the protagonist's knowledge advantage. Future knowledge improves experiment choice, sequencing and observability; it does not make a sea trial substitute for a compressor map, a small engine substitute for a large hot core, or a generic laboratory ship substitute for a named carrier's geometry.

## 4. Consequence for the next pass

The next safe technical work is to refine the LL20 shop/facility drawing inputs and to partition E6-M marine-role evidence into shore-primary versus sea-primary tests. Program selection among Momi, the qualification craft and a dedicated lab ship remains an explicit later worldline choice.
