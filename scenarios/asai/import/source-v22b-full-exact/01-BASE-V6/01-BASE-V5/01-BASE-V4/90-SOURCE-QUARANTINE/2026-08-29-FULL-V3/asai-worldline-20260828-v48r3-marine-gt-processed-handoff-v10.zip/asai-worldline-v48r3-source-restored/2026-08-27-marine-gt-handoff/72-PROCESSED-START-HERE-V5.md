# Marine GT processed handoff V5 — START HERE — 2026-08-28

## State

Base semantic authority remains **v48 / machine v48r3**. V5 is a processing overlay on V4; it does not create semantic v49.

## V5 closes/reframes

1. Scalar `maturity` language is retired for this work. Use physics/rig/environment/endurance/production/role/application/selection states (`63-...`). This is not a downgrade: Asai's own rising acceptance standards mean a more advanced program can legitimately have more explicitly named open gates.
2. The E5 qualification craft no longer inherits **25–27 t as a target**. The worldline-closed arithmetic is only the 20.5 t First-Type starting craft + 390–460 kg E5 assembly + 108–162 kg sprint fuel. Every remaining marine/test increment must come from actual arrangement (`64-...`).
3. E5 air demand now fixes an intake geometry anchor: 7.6 kg/s = ~6.20 m3/s at sea-level density; 20–30 m/s face velocity implies ~0.31–0.21 m2 clear area. This constrains layout without inventing a salt-separator weight.
4. The 1,000 hp center shaft is similarly sized from worldline power/torque. A preliminary 40–60 MPa shear sensitivity at 2,050–2,300 rpm yields roughly 65–75 mm solid-shaft diameter before fatigue/keyway/coupling/strut/prop gates. The exact shaft/prop mass remains OPEN.
5. A speed consequence table is rebuilt over 21.5–25 t rather than assuming 25–27 t. No row is a selected displacement; the actual mass takeoff must select the craft first (`65-...`).
6. The 1934–41 unit-power demand map is broadened beyond Taiyo (`66-...`). Industrial turbomachinery is recognized as a **large-machinery enabler but not a large hot-core product**. Pre-1941 aviation does not currently pull beyond the 13.2 kg/s E6-M product.
7. The strongest current pre-1941 demand for >13.2 kg/s hot-core R0/R1 is the **pre-planned Taiyo/Kasuga Maru attack-speed branch**, because it couples ~20 kshp incremental demand to a material role change. Kagero/Agano boost studies are valid paper trades but weaker product pulls.
8. Taiyo 21→25.5 kt does not define a 29.7 kg/s engine. With no scale bonus and explicit 90–95% post-engine path sensitivities, a demand-derived trade is roughly 6 modules at 20–21 kg/s, 5 at 24–25, or 4 at 30–32. The module/core decision remains OPEN (`67-...`).

## Read order

1. `63-QUALIFICATION-TERMINOLOGY-V5.md`
2. `50-NUMERIC-DERIVATION-DISCIPLINE-V4.md`
3. `64-E5-QUALIFICATION-CRAFT-MASS-BUILDUP-V5.tsv`
4. `65-E5-QUALIFICATION-CRAFT-GEOMETRY-SPEED-V5.tsv`
5. `66-UNIT-POWER-DEMAND-MAP-V5.tsv`
6. `67-LARGE-CORE-PROGRAM-GATES-V5.tsv`
7. `68-MARINE-DEMONSTRATION-LADDER-V5.tsv`
8. `74-LARGE-CORE-ENABLING-INHERITANCE-V5.tsv`
9. `75-TAIYO-MODULE-ARCHITECTURE-TRADE-V5.tsv` and `75A-...`
10. `70-V5-RECALC-NOTES.md`
11. `42-NAVAL-DESIGN-PROCUREMENT-BASELINE-V3.tsv`
12. `69-MARINE-GT-REWORK-QUEUE-V5.tsv`
13. `71-MARINE-GT-PRECEDENCE-OVERLAY-V5.tsv`
14. V2 layered decision matrix for downstream selection status

## Immediate next gate

Draw/choose the E5 qualification-craft machinery arrangement strongly enough to close center shaft length/prop/supports, separator/intake route, exhaust route, disconnect device, local structure and instrument set. This will yield the first defensible full-load mass and only then a tank/sea-test C value.

In parallel, compare the Taiyo 4/5/6/8/10-module machinery integrations and identify whether the program buys a new large hot core or remains on canonical E6-M modules. Only after that decision should an R2 large-core calendar be written.

## Validation

V5 validation is recorded in `76-PROCESS-VALIDATION-REPORT-V5.txt`. The base v48r3 validator passes at 687 chronology records / 134 main files / 71 archive files / 169 carried source rows; all PASS8 parent checksums match; all handoff CSV/TSV and JSON structures parse; and the V5 mass/intake/fuel/Taiyo module calculations were independently recomputed. `SHA256SUMS-HANDOFF-PASS9.txt` is the V5 handoff manifest.
