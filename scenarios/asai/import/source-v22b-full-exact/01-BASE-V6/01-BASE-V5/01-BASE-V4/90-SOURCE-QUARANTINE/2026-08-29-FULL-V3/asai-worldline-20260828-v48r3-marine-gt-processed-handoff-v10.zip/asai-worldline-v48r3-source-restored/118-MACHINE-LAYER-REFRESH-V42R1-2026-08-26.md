# 118 — Machine-layer refresh v42r1 — 2026-08-26

v42r1 refreshes the machine layer after the E4 regeneration installed rebaseline.

- chronology: **620 records** (`CANONICAL-CHRONOLOGY-V42R1.tsv` / `.jsonl`)
- main canonical files: **197**
- status partition: **current 471 / conditional 64 / superseded 46 / scope 30 / mixed 9**
- new v42 chronology delta: CHR-0609..0620
- old product row CHR-0058 (~25% E4 regeneration) is superseded by v42 installed accounting.
- v40/v41 E4 regeneration audit gates CHR-0593/0607 are superseded by v42 closure.
- recuperated 475 kWe continuous derivative remains conditional because it requires ~7.16 kg/s and compressor/shaft qualification.
- P1-3 compressor operability remains the next local gate; downstream aircraft/ship H→A remains conditional.

Current recall layer:
`CURRENT-CANONICAL-STATE.md` → `CANONICAL-MAIN-INDEX-V42R1.tsv` → `CANONICAL-CHRONOLOGY-V42R1.tsv` → `CROSS-DOMAIN-PREFLIGHT-V42R1.md` → `CAPABILITY-TRIGGER-MATRIX-V42R1.tsv`.
