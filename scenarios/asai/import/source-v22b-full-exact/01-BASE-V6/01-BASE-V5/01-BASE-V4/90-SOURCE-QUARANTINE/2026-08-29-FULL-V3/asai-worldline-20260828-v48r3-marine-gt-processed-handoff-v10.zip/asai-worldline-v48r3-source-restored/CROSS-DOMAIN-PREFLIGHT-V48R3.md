> **Integrity note.** semantic rules are v48; machine references were reconstructed from the supplied v46r1 parent and v48r1 reset documents.

# CROSS-DOMAIN PREFLIGHT — v48r3 source-restored

個別検討へ入る前に、以下を確認する。v48は航空採用史を閉じた版ではなく、**旧航空史を退役させて上流を再配置した版**である。

## 1. BUSINESS ORIGIN gate

1903–30を扱う場合、先に `main/asai-works-business-origin-diversification-1903-30.md` を読む。

- 浅井は織機メーカー起源。
- 内製化→特殊鋼/工具/工作機械、内部需要→計算/集計、高温高速タービン研究→排気ターボ商品→独立GT、の複数枝。
- 転生者効果は**多角化を踏み石として操舵し、将来必要な長時計・設備・人材・顧客を先払いすること**。
- 1923を自動的に航空部創設年にしない。航空正式参入年はOPEN。

## 2. CORE v48 gate

発動機については `main/asai-works-engine-capability-core-e1-e9.md` を数値親とする。

- E世代 ≠ 一機種。E世代 = 技術前線。
- 小型core ~5–8 / 中型 ~10–15 / 大型 ~20–40 kg/s。帯越えは新core設計。
- 商品 = core + backend + installation + rating。
- 組織設計値 / 浅井直接調整値 / 浅井新方式値 / 浅井集中上端値を混同しない。
- v39–v46 installed監査は累積。
- E4/E5 pure jet ~300–330 / ~430–455 kgf は**pre-audit**。
- E5 aft-fan flight/product timingは**OPEN**。

## 3. AVIATION ARCHIVE gate

`archive/aviation-pre-v48/` の旧航空文書はprovenance only。

- 旧霹靂・凱風・朔風・旧Ki-40・旧零戦再配置・旧TP機体・旧CFRP戦闘機をcurrent採用史として使わない。
- v47 Hekireki H→Aは「新しい推力を旧機体へ入れると旧歴史が壊れる」ことを示した遷移計算。
- 旧航空文書から史実アンカー/物理アイデアを再利用する場合も、現行coreとmissionで再監査する。

## 4. AVIATION LAYER gate

航空は必ずどの層か明記する。

1. 技術開発史 — 何が研究/試験可能か。
2. 商品化・実証史 — bench/rig/飛行実証/軍共同試験/実用試験/量産候補のどこか。
3. 採用史 — 軍要求、予算、生産、基地/空母、戦訓から何を買うか。

能力があるだけで採用を自動生成しない。逆に史実採用年を能力天井にしない。

## 5. MISSION COMPARISON gate

航空採用を論じるときは、**同じ年代・同じ任務要求**へ更新済みの

- piston
- turboprop
- pure jet
- fan

を入れる。速度だけでなく、航続/滞空、搭載、上昇、field/carrier、信頼性、整備、生産数、燃料を比較する。

## 6. TURBOPROP gate

旧TPカタログ値を使わない。最新shaft core/productから、

- power turbine/reducer mass
- propeller absorption / diameter / tip Mach
- altitude power
- part-load BSFC
- installation / cooling / inlet
- field/carrier benefit

を用途ごとに再監査する。

## 7. TRANSONIC gate

E6中後半以後の高速戦闘機では、圧縮性を無視しない。

- M0.7台後半からdrag rise / trim / tail / control / flutterを確認。
- E7では遷音速を避けるなら、航続・搭載・低速等へ意図的に能力を配当している理由が要る。
- M1研究と実用超音速採用は別gate。

## 8. CFRP / FRP gate

FRP/epoxy/CFRP材料時計は概ねcurrent。

- jetが早くてもgalvanic corrosion、wet exposure、fatigue、BVID、furnace/yield、bond/repair clocksは消えない。
- 旧CFRP戦闘機完成案はarchive。
- 高速空力と合流する場合、薄翼、捩り剛性、flutter、燃料容積、接合/電食を同時に見る。

## 9. H→A gate

発動機推力/馬力の増加だけで機体最高速をscaleしない。

必ず intake recovery、nacelle/wetted drag、engine mass/CG、fuel flow、altitude thrust/power、cooling、prop/fan/nozzle、takeoff/climb、compressibility/control を払う。
