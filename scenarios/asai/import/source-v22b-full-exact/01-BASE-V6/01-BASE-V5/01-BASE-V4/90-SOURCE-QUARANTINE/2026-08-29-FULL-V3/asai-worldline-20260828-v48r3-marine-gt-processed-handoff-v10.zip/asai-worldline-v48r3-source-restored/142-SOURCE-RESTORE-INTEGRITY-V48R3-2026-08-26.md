# 142 — v48r3 source restore / integrity repair — 2026-08-26

## inputs

- supplied parent: `asai-worldline-20260826-full-cross-domain-v46r1-e6-m-jf-installed-thrust-checkpoint.zip`
- supplied reset checkpoint: `asai-worldline-20260826-full-cross-domain-v48r1-aviation-history-reset-checkpoint.zip`

## recovered invariants

- v46 parent chronology: **667** records.
- v48 documented archive: **71** old aviation main documents.
- those 71 recovered v46 files account for exactly **169** v46 chronology rows, matching the v48r1 refresh note.
- v48 new chronology delta: **20** records.
- rebuilt v48 chronology: **687** records.
- current main after archive + four v48 parents: **134** files.

## treatment

1. v46 complete tree is the physical parent.
2. v48 semantic/control documents overlay the parent.
3. The 71-file archive membership is reconstructed from v48 semantic scope and checked against both documented invariants (71 files and 169 carried chronology-source rows); those recovered files move verbatim to `archive/aviation-pre-v48/v46-main/`. The original v48 archive manifest itself was absent, so this is a high-confidence reconstruction rather than a bit-for-bit recovery of that missing manifest.
4. old GT core-generation full table moves to `archive/core-pre-v48/`; current path becomes a compatibility wrapper to the v48 E1–E9 core parent.
5. cross-domain timeline rows are fenced so non-aviation technology can remain while old aircraft applications become mixed/superseded.
6. machine chronology, main index, trigger matrix, schema, preflight and hashes are regenerated as v48r3.
7. v47 Hekireki transition-working source was absent from both supplied ZIPs and is not fabricated.

This is a source-restored integrity revision; semantic worldline remains **v48**.
