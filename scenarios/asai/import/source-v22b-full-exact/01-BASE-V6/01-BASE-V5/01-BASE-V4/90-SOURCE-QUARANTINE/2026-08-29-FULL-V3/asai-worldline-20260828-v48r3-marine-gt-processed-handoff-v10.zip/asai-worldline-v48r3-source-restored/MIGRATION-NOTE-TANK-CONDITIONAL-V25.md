# Migration note — Tank conditional next-generation v25

v24 left “75mm turret medium tank after Chi-He” as a conditional P1. v25 does **not** make a later tank current. It splits the issue:

- technical feasibility / staged research envelope → CLOSED in `main/asai-works-tank-next-generation-conditional-1939-45.md`;
- actual development authorization, intelligence inputs, requirements, prototype/production dates and OOB → CONDITIONAL OPEN / HISTORY-UNFIXED.

Semantic corrections:

1. Nomonhan is no longer the mandatory origin of Gen-3 tank requirements; pre-July 1939 institutional anti-tank concern is recognized.
2. 15–19t is an all-theater logistics band, not an absolute future ceiling.
3. 1942+ candidate specifications are marked conditional/hypothetical and machine chronology uses `semantic_status=conditional` for those records.
4. Chi-He current canon through 1941 is unchanged.
