# MACHINE LAYER REFRESH — v26r1 / 2026-08-25

## Purpose

Semantic v26 rebases the aircraft technical layer while preserving frozen post-1941 history/OOB and explicit conditional development shadows. The machine layer is refreshed so old B6A/Tenzan-bomber/Ginga/Ki-48TP/carrier-jet rows cannot silently override the new parents, and AT-3/Ki-92/Fugaku milestones cannot leak into current history.

## Inputs

- semantic parent: `40-AIRCRAFT-POST-COMPUTATION-TECHNICAL-CLOSURE-V26-2026-08-25.md`
- current aircraft parent: `main/asai-works-aircraft-computation-closure-1937-46.md`
- conditional parents: `main/asai-works-heavy-transport-at3-ki92-1939-44.md`, `main/asai-works-fugaku-technical-shadow-1942-46.md`
- prior machine base: v25r1

## Machine changes

1. `CANONICAL-CHRONOLOGY-V26R1.tsv` / `.jsonl`
   - **409 records total**.
   - 373 records carried from v25r1 with source hashes refreshed where aircraft sources changed.
   - 36 v26 records added: current/scope aircraft role rows plus conditional AT-3/Ki-92/Fugaku scope/milestones.
   - status counts: **current 352 / scope 10 / mixed 7 / superseded 12 / conditional 28**.
   - old 1943 Shinzan/Renzan standard-tanker row and old Sakufu speed-difference rows are reclassified `superseded`.
2. `CHRONOLOGY-SCHEMA-V26R1.json`
   - retains `conditional` semantics and records v26 aircraft authority/supersession rules.
3. `CANONICAL-MAIN-INDEX-V26R1.tsv`
   - **177 canonical files** under `main/`.
4. `CAPABILITY-TRIGGER-MATRIX-V26R1.tsv`
   - adds `AIR-ROLE`, `AIR-HEAVY`, `AIR-JET-STRIKE`; strengthens `AIR-REBASE`.
5. `CROSS-DOMAIN-PREFLIGHT-V26R1.md`
   - adds historical-aircraft-first, heavy-aircraft conditional, jet-strike and carrier-jet/catapult gates.
6. `tools/validate_machine_layer.py`
   - updated to v26r1 pointers, v26 parent coverage, conditional-parent guards, superseded-aircraft regression checks and manifest/index/hash parity.

## Result

Machine retrieval now distinguishes:

- **current aircraft technical line** — usable role/performance/design choices;
- **conditional development shadow** — AT-3/Ki-92/Fugaku and gated late jet branches;
- **superseded aircraft provenance** — old B6A/Tenzan-bomber/Ginga/Ki-48TP/old carrier-jet calculations;
- **frozen history/OOB** — not promoted by the machine chronology.
