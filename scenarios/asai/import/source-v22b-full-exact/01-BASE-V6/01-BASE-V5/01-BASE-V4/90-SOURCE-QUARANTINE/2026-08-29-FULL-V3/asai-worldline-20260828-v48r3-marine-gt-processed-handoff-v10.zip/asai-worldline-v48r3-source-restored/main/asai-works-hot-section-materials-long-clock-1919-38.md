# Hot-section材料の長時計画 1919–38 —— creep / oxidation / thermal-cycle の前払い

> **v38 authority.** 本稿は高温材料の「いつから実時間を払い始めていたか」を固定する。E4/E5等の寿命値そのものはv38では変更しない。

## 1. 中央裁定

特殊鋼・清浄溶解・熱処理文化はE1以前から存在する。これに加え、主人公は将来のhot-section failure modeを知るため、**1921–24に長時間定荷重の比較試験を系統的に開始する**。

これは未来自動creep試験機の召喚ではない。重錘/lever、炉、単純な伸び測定、定期記録から始める。目的は高度なcreep理論を先取りすることより、必要になる何年も前から実時間を払うことにある。

## 2. 1920年代に積む帳簿

- heat / composition / melt practice
- heat treatment / forging / casting process
- temperature / stress / elapsed time
- elongation / rupture / deformation history
- oxidation / scale / mass-loss observations
- repeated thermal-cycle observations
- rotor/blade/fatigue damage record
- fracture surface / NDT / reject reason

1925以後のturbocharger service returnはserial/heat/processへ結び、couponと実機returnを同一archiveへ戻す。

## 3. 発展

1921–24は少数の手動stationから始め、1920年代後半から1930年代にstation数、温度帯、応力条件、heat/processの組合せを増やす。具体台数はengineering envelopeでありv38正準の固定台数にしない。

計算能力が増すほど、time-temperature整理、寿命curve fit、heat/process比較、外れlot検出が速くなる。ただし**長時間clockそのものは計算で短縮しない**。

## 4. v38で回収する利得

まずGq/Gdへ回収する。bad heatの排除、寿命下限の把握、ばらつき縮小、derating/inspection条件、試験点の選択、手戻り削減である。PR/TIT/etaを無料で上げる理由にはしない。

## 5. 未確定

E4/E5の代表rated core life再評価、冷却翼・coating・precision-castingの個別開始年、部品別metal-temperature/stress/dutyは次の数値監査へ送る。

## 6. v39補足——generic clock と exact family/process clock

v39では1921–24 clockの意味を二分する。`generic clock`（試験方法・炉・記録・統計・NDT・station capacity）は後続programへ強く継承するが、`family/process clock`（exact alloy/heat treatment/section/forging-casting/joining/cooling passage）は新しいfamily/processの導入時に部分resetする。E5 Ni高端線へ「1921から同一合金を15年試した」成熟を与えない。利得は、成熟した試験組織が新材料のlower-tail / heat / process / stress / temperatureを早く見分けられることに置く。具体のE4/E5 clockと寿命帯は `asai-works-e4-e5-hot-section-component-life-rebaseline-1931-37.md` をauthorityとする。
