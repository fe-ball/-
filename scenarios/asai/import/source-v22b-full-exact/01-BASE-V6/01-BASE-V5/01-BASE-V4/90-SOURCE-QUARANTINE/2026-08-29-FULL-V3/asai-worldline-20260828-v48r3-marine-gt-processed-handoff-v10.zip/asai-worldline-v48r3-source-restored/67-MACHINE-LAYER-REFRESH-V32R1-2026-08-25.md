# v32r1 machine-layer refresh

- Chronology: `CANONICAL-CHRONOLOGY-V32R1.tsv/.jsonl` (**483 records**).
- Schema: `CHRONOLOGY-SCHEMA-V32R1.json`.
- Main index: `CANONICAL-MAIN-INDEX-V32R1.tsv` (**184 main files**).
- Trigger matrix: `CAPABILITY-TRIGGER-MATRIX-V32R1.tsv`; TIME/AVAIL point to v32r1 and `ROTOR` requires the v32 1942+ authority.
- Preflight: `CROSS-DOMAIN-PREFLIGHT-V32R1.md`, adding scale-up, hover-power, gearbox-life, shipboard, rescue-hoist, wartime-ASW versus 1950s-sonar and history-freeze gates.

`CHR-0329`, the inherited generic 1942+ medium Re-go row, is demoted to `superseded`. Thirteen v32 chronology records encode the new authority, 3.2t first-medium central, hover ledger, 1943 service test, wartime ASW role/no-dipping-sonar rule, 1944 technical readiness/rescue gate, conditional growth/heavy branches, 1951–55 sonar-ASW historical calibration and frozen-history boundary.
