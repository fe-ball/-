# E8/E9+ later-war propulsion rebaseline — semantic v37

v37 closes the P1 re-audit of E8/E9+ without using historical achievement dates as ceilings.

## Central decisions

- E8 PR9–10 / TIT940C / component efficiency ~0.86 remains a **current high-end practical/qualifiable technical rating**.
- Existing 194 kJ/kg / 31% values are relabeled **gross Brayton comparison indices**. Representative cooled installed-core comparison with 4–5% cooling debit is ~181–183 kJ/kg / ~30.4–30.5%.
- E8 does **not require two spools**. 15–16-stage single-spool + VSV/bleed is central-capable; two-spool is an alternative that buys operability at added bearing/control cost.
- The old Ni-stockpile 1943–44 cutoff is superseded for the high-end line. Current gates are cooling passage/yield, vane/rotor/root/disk temperature, creep/oxidation/thermal fatigue, inspection and endurance.
- E9 PR11–12 / TIT~1000C / efficiency 0.86–0.87 is no longer postwar-gated by calendar. Design/component/rig work is a **current technical front**; flight-qualified/series rating remains CONDITIONAL on spool, cooling, map, endurance and manufacturing gates.
- `E9 = 1,000 kgf/engine` is superseded. Generation and core scale are independent; E6-L-J already provides a 1,000–1,150 kgf research shadow. Fighter single-engine convergence must be solved as installed thrust + core scale + inlet/drag + TBO.
- The old `1/2 Ve^2 = net Brayton w` shortcut is not valid turbojet installed-cycle accounting. Existing E6 product thrust figures are retained as conservative empirical anchors pending a dedicated installed-engine H→A audit; future generation deltas must use compressor/turbine/nozzle/mass-flow accounting.
- Post-1941 actual procurement, production, deployment and combat remain HISTORY/FROZEN.

Canonical parent: `main/asai-works-e8-e9-later-war-propulsion-rebaseline-1942-47.md`.
