# GT計算配当・再分配監査——v37正本のどこを直し、どこを動かさないか

> **v38再監査用作業稿。v37r1正本は未変更。**
> 入力：`89` 能力総覧、`90` スコア枠組み、`91` GT能力収斂マトリクス。

## 0. 結論

現行v37のE1–E9数値を一括で上げ直す必要はない。むしろ既存の `asai-works-engine-computation-internal-1923-28.md` は、E3以後の浅井内部では計算利用を**既に標準状態へ吸収し、後からCボーナスを二重加算しない**と正しく規定している。

今回の問題は、数値表側の説明がその規則へ十分追いついていないこと。

したがってv38の第一作業は「+何%」ではなく、E世代の成立因を次へ組み替えることとする。

`未来知識による大枝選択 → 計算型/カードによる探索 → 自動順序/relayによるL2/L3反復 → 電子計算によるcoupled problem拡大 → 実物qualification`

この鎖を各E世代へ明記する。

---

# 1. 既存正本の良い部分——保持する

## 1.1 `asai-works-engine-computation-internal-1923-28.md`

保持。

特に以下はv38でも原則とする。

- E1は計算室以前の人力設計基準。
- E2はC0/C1を受けるが、性能値へ追加%を足さない。
- E3は**最初から計算型・カード・反復探索を前提に育つ最初のコア**。
- E3以後は計算利用が浅井内部のstandard stateであり、後からCボーナスを追加しない。
- 計算が縮めるのは無駄枝・人日・反応時間であり、材料データ、試作加工、長時間耐久を消さない。

この規則は今回のO/G体系と完全に整合する。

## 1.2 `asai-works-gt-core-generations.md` のE8/E9 v37裁定

保持。

- E8 PR9–10 / TIT940 / η≈0.86 high-end practical / qualifiable technical rating。
- E9 PR11–12 / TIT≈1000 / η≈0.86–0.87 component/rig technical front。
- E9 flight/seriesはtwo-spool / cooling / map / transient / endurance / yield gate。
- gross Braytonとinstalled thrustを分離。
- 史実達成年をcalendar ceilingにしない。

91のスコアでもこの構造は支持される。

---

# 2. 修正が必要な第一群——「E世代＝PR/TIT/ηの表」だけでは足りない

対象：

- `asai-works-gt-core-generations.md`
- `asai-works-core-hierarchy.md`
- `asai-works-core-elements.md`
- `asai-works-propulsion-roadmap.md`

現在のE世代は主にPR/TIT/component efficiency/比仕事/寿命で記述されている。

v38では各世代に**development-method coordinate**を付加する。

| 世代 | 現行の物理座標 | v38で追加すべき開発方法座標 |
|---|---|---|
| E1 | PR2.5 / TIT540 | 主人公のL0先知＋人力計算。Architecture O先行、System O低い |
| E2 | PR3 / TIT620 | C0/C1。試験還元・比較・データ形式化 |
| E3 | PR3.5 / TIT690 | C2/C3。計算型＋カード＋反復探索を前提に育つ最初のcore |
| E4 | PR4.5 / TIT710 | A1/R1入口。stage-by-stage・複数運転点・振動候補が機械工程へ |
| E5 | PR6 / TIT800 | **U4転換**。多段matching/VSV/bleed/gear/product integrationが組織作業化 |
| E6 | PR7 / TIT870 | **電子＋drumのL3配当**。start/accel/thermal/rotordynamics case sweep |
| E7 | PR8 / TIT900 | 設計残差よりL4 hard gateへ支配が移る |
| E8 | PR9–10 / TIT940 | 設計探索は十分強い。qualification/TBO/yieldを性能から分離 |
| E9 | PR11–12 / TIT~1000 | 新coupling taxでL3/L4比率が再上昇。component高O、series conditional |

この欄を入れることで、「E5→E6の差」が単にPR6→7、TIT800→870ではなくなる。

---

# 3. E5を再評価する——最重要の組織転換点

現行E5は「ターボプロップ・舶用の核」として物理性能中心に書かれている。

しかし1934–37は、別正本ではすでに：

- 浅井内部では計算型・カード・試験標準化が成熟済み。
- 三菱・中島でもU4化が始まる。
- 「計算するか」ではなく「どこまで計算してから試すか」が設計会議の前提になる。

とされている。

浅井GTは外販先より先にこの文化を持つため、E5では少なくとも：

- compressor stage stackingを複数運転点で比較。
- VSV/bleedのschedule候補を表として持つ。
- combustor loss / pattern / liner条件を同形式で比較。
- turbine/compressor work balanceを設計変更ごとに再計算。
- gear/prop/marine loadとのmatchingを同じ設計帳簿へ接続。
- rotor critical-speed候補を製図前に除外。
- failure cardを次coreへ持ち越す。

がroutine化する。

**v38判定：E5のPR/TIT/η値は当面据置。ただしE5を「U4 engineering core」と再定義する。**

性能数値の上積みより、同じ値を偶然のprototypeではなく**再現可能な設計系列**として作れることが配当。

---

# 4. E6を再評価する——最重要の計算転換点

E6 1938–41は、計算系正本の電子＋relay＋drumへの移行と重なる。

91ではSystem O 66–79%、Gp 75–85%、Gq 52–68%。

ここで新たに日常化し得る：

1. start/accelerationの簡易time integration。
2. fuel scheduleとsurge line回避のcase sweep。
3. rotor Campbell/critical-speed caseの大量比較。
4. thermal networkによるdisk/root/bearing/oil温度の過渡比較。
5. altitude / inlet / nozzle / mass-flowのinstallation trade。
6. test dataからsemi-empirical correctionを頻繁に更新。

この配当は、**TITやPRを勝手に増やすことではない**。

実際の効果は：

- 同じE6性能をより広いoperating envelopeで使える。
- prototypeで遭遇する危険runを減らせる。
- flight testへ持ち込む前にstart/surge/thermalの危険域を地図化できる。
- E7/E8へ渡すmap/dataが厚くなる。

**v38判定：E6数値据置を中央。operability / development maturity / dataset qualityを上方再評価。**

ここは後のE7/E8到達を支える前払いになる。

---

# 5. E7/E8を再評価する——「未来値」ではなく累積工程の帰結

E7/E8についてv37はすでに史実年代上限を廃止した。

v38でさらに重要なのは、E8を：

`主人公がPR9.5/TIT940という未来値を知っているから作れた`

だけで説明しないこと。

実際には：

- E1から正しい技術枝を選んだ。
- E2–E4で試験データ形式を作った。
- E3以後は計算型をcore設計のstandard stateにした。
- E5でU4組織化した。
- E6でL3の大量caseを電子計算へ移した。
- E7までにsurge、thermal、rotor、materials failureの大量データを蓄積した。

結果としてE8の15–16段single-spool+VSV/bleedを**設計できる組織**ができた、と読む。

91のE8：

- Architecture O 93–99%
- System O 75–86%
- compressor O 79–89%
- control O 81–91%
- hot-section O 69–82%
- Gq 63–78%

したがってE8の残る不確実性は、「PR9.5という概念を発明できるか」ではない。

- real stall/surge boundary
- clearance scatter
- cooling passage yield
- vane/root/disk thermal distribution
- creep/oxidation/thermal fatigue
- bearing/seal/oil coking
- TBO and production yield

へ集中する。

**v38判定：E8性能座標は維持。qualifiableの意味を、上記のhard gateを通した少数高端ratingと明示する。**

---

# 6. E9は一度Oが下がる——これは自然

E9の計算環境はE8より悪化しない。

それでも91ではE9 series/full-coreのSystem Oを70–83%、Gqを56–73%へ下げた。

理由は問題そのものが変わるから。

- two-spool matching
- concentric shaft / bearings
- start/accel control
- inter-spool transient
- higher PR compressor map
- staged cooling 5–7%
- hotter disk/root environment
- manufacturing tolerance interaction

つまり、未来環境への「距離」が増えたのではなく、**新しい山へ登り始めた**。

この読みならv37の：

- design/component/rig = current
- flight/series = conditional

を維持できる。

---

# 7. 数値を変える可能性がある場所——まだ確定しない

今回の監査で、次は再計算候補になる。

## 7.1 E4/E5の寿命帯

計算そのものでは寿命を作れないが、1920年代から：

- failure card
- 部品版管理
- 高温試験
- creep/oxidation testの前倒し
- 統計品質

が蓄積している。

したがって「E4百数十～数百時間、E5数百時間」が過小かどうかは**冶金Gq監査**で再OPENする価値がある。

ここは計算機ではなく、主人公が将来需要を知って長期試験を早く始める配当。

## 7.2 E5–E7 component η

現行0.83→0.85は、計算文化の蓄積を既に暗黙に含んでいる可能性が高い。

直ちに上げない。

ただしblade/cascade library、clearance control、rig feedbackがどこまで支払済みかを再監査し、中央値ではなく**bandの上端と量産中央の差**を詰める。

## 7.3 E6以降のoperability

現在の資料はPR/TIT/比仕事ほどstart margin、surge margin、accel time、restart envelopeを数値化していない。

計算革命の最も正当な配当先なので、ここは新しい性能表を作る価値が高い。

---

# 8. 直す必要がある個別ファイル

## P0

### `asai-works-gt-core-generations.md`

追加：各E世代のdevelopment-method coordinate。

禁止：O/Gを性能bonusとして足すこと。

### `asai-works-core-elements.md`

追加：TIT/PR/η等の物理軸とは別に、**design-convergence/qualificationは性能独立軸ではなく「その座標をどの確度で受領できるか」のメタ軸**とする注記。

### `asai-works-core-hierarchy.md`

追加：「能力予算」へ計算機出力を直接足さず、探索損失を減らすmechanismとして扱う。

### `asai-works-propulsion-roadmap.md`

E5=U4 transition、E6=electronic-computation L3 transitionを年表へ追加。

## P1

### `asai-works-gt-shogouki.md`

E4の商品化理由に、自動順序入口・standard test/failure ledgerを追記。性能値は維持。

### `asai-works-turbojet-demonstrator-saiko.md`

1935–39のジェット実証を「未来形状を知る」だけでなく、E5 U4 + E6入口の計算/rig workflowで説明する。

### `asai-works-jet-physics.md`

installed-engine H→Aで、単一design pointだけでなくmap/start/surge/cooling scheduleを入力にする。

## P2

marine GT、turboprop、airframe integrationへ同じ配当を再伝播。ただしE5/E6の数値を理由なく上積みしない。

---

# 9. v38へ持ち込む新規ルール案

1. **O/Gは監査尺度であって性能bonusではない。**
2. E3以後の浅井GTでは計算利用はstandard state。後からC bonusを加算しない。
3. E5をU4 engineering transition、E6をelectronic L3 transitionとして世代表に明示。
4. 計算利得は、まず探索・operability・test selection・failure feedbackへ配当する。
5. 寿命・歩留まりの上方修正は、冶金・長期試験・製造Gqを通してのみ行う。
6. E8の成立は未来数値のベタ書きではなく、20年の開発システム蓄積の帰結として説明する。
7. E9でSystem Oが一時低下しても後退ではない。新しいL3/L4 couplingを開いたことによる。

---

# 10. 次作業

次は冶金を91と同じ形式で採点する。

ここでは計算機より、主人公が「将来必要になる試験を20年前から始める」ことを独立の **time-head-start credit** として定量化する。

GTのGqが本当にE4/E5時点でどこまで上がるかは、この冶金監査を終えてから再判定する。
