# Marine GT processed handoff V2 — START HERE — 2026-08-27

## State

Base semantic authority remains **v48 / machine v48r3**. This is still a processing overlay, not a semantic rebaseline.

V2 preserves the useful V1 data work but corrects its adoption logic. Historical dates and technical gates are constraints; they are not automatic instructions to reproduce historical propulsion choices.

## Read order

1. package-root `CURRENT-CANONICAL-STATE.md`.
2. `33-DECISION-FRAMEWORK-REFRAME-V2.md` — methodological correction; read before interpreting V1 adoption files.
3. `34-MARINE-GT-LAYERED-DECISION-MATRIX-V2.tsv` — current status authority for marine GT.
4. `35-ADOPTION-REOPEN-NOTES-V2.md` — explicit Momi/test-ship/No.600/carrier/fuel reopen logic.
5. `10-HISTORICAL-TECH-CROSSWALK-V1.tsv` — historical opportunity structure.
6. `13-MARINE-LARGE-SCALE-AUDIT-V1.tsv`, `14-MARINE-LARGE-SCALE-AUDIT-NOTES-V1.md`, `16-LARGE-CORE-AVAILABILITY-GATES-V1.tsv` — technical/output arithmetic.
7. `24-MOMI-MARINE-TEST-PROGRAM-V1.tsv`, `25-LARGE-MARINE-LAND-RIG-GATES-V1.tsv` — test-program evidence, interpreted through V2.
8. `27-E6-TORPEDO-PROTOTYPE-CLOSURE-V2.md` — 1941 heavy-MTB requirement and design-space evidence; its hard E6 selection is superseded by V2.
9. `15-TAIYO-WORKING-RECALC-V2.csv`, `19-CARRIER-BOOST-COMPARISON-V1.csv`, `20-CARRIER-DECISION-PASS1.md` — carrier calculations/evidence; V1 adoption closure is superseded where V2 differs.
10. `21-FUEL-IMPORT-EVIDENCE-V1.tsv`, `22-FUEL-DEMAND-SENSITIVITY-V1.csv`, `23-FUEL-POLICY-PASS1.md` — fuel evidence and sensitivity; fleet allocation is provisional under V2.
11. `36-MARINE-GT-PRECEDENCE-OVERLAY-V2.tsv` — current precedence map.

## What remains closed enough to use

- E4/E5/E6 standard installed-cycle/product arithmetic already accepted upstream.
- E6-M product-plane rating basis.
- large-core calculations without undocumented `scale gain`.
- distinction between turbine output and propeller-shaft output through explicit reducer efficiency.
- historical ship/refit/requirement windows in the crosswalk, subject to ordinary source uncertainty.
- direct historical import of finished middle-distillate products.
- the 1941-12-08 evidence boundary.

## What V2 intentionally reopens

- Momi is the leading 1934–36 old-hull candidate, not a uniquely closed platform.
- a dedicated 700–1,000 t modular propulsion laboratory hull is an OPEN programmatic choice, not ruled out simply because Momi + shore rigs can work.
- No.600 provides a real 1941 heavy-MTB opportunity; E6-M hybrid is the leading proposal, not automatically selected canon.
- Kaga/Akagi/Soryu/Hiryu/Taiyo/Unryu decisions are separated into technical feasibility, demonstrated maturity, adoption opportunity, and actual worldline selection.
- the historical short Taiyo conversion window rejects an unprepared graft but does not reject an earlier pre-planned GT conversion architecture.
- Unryu steam standardization remains a strong competitor, but the final 1941 worldline standard depends on what marine GT has actually achieved by then.
- the marine-turbine distillate specification remains useful; Navy-wide product allocation waits the fleet-scale adoption result.

## Closure rule

Do not attempt to turn every row CLOSED. The 1941-12-08 state is sufficiently processed when it clearly distinguishes:

- technology available;
- demonstration actually achieved;
- real procurement/design opportunity;
- working selection where alternatives have been compared;
- intentionally open design studies.

Use `NOT-SELECTED-WORKING` only when a competing architecture has a stated worldline advantage. Historical precedent alone is not enough.

## Next processing order

1. close the yearly demonstration ladder for E5/E6 large machinery;
2. compare Momi-only, Momi + dedicated test ship, and dedicated-hull-later program architectures;
3. compare No.600 propulsion candidates;
4. revisit carrier cases with `short-notice` versus `pre-planned` branches;
5. then propagate selected platform counts into fuel, reducer production, yard load, and fleet consequences.

## Provenance

V1 files `28-OPEN-CLOSED-MATRIX-PASS3.tsv`, `29-MARINE-GT-PRECEDENCE-OVERLAY-V1.tsv`, and `30-PROCESSED-START-HERE.md` are retained unchanged so the previous processing path remains auditable. They are not the latest adoption authority.
