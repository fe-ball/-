# Marine GT V6 — arrangement and first large-hot-core program decision

## 1. What V6 closes

V6 closes two *program decisions*, not two finished products.

1. The first E5 sea-qualification article is a **purpose-built close derivative of the accepted Japanese First Type hull family**, with the two inherited piston shafts retained and a dedicated centerline E5-S 1,000 hp boost/test path. This is selected because a test craft should be designed around access, instrumentation and controlled interfaces; it is not evidence that a fleet torpedo boat should use the same arrangement.
2. A demand-derived **20–21 kg/s E6-tech-front experimental full-core article** is authorized as an R2 research article in the 1939–40 window. `LL20-R2` is an audit label only, not a canonical product name. The scale comes from the 6-module / 3+3 Taiyo pre-planned boost trade, not from diameter scaling or a later historical engine.

Neither decision closes full-load test-craft displacement, LL20 product availability, a large marine combining gear, or Taiyo selection.

## 2. How the protagonist's future knowledge is represented

Future knowledge does three concrete things here:

- it makes the E5 qualification craft an information machine: salt loss, wash response, PT/reducer/freewheel behavior, torsion, prop ventilation, trim and damage are instrumented from the beginning;
- it starts large-core R0/R1 work before a production order, because Asai knows which scale-transition failure modes will later be expensive;
- it avoids building an unnecessary 9–12 kg/s E5 hot product and waits until standard E6-M hot-core evidence exists before spending on the larger combusting R2 article.

Future knowledge does **not** add compressor efficiency, reduce mass by an unnamed percentage, supply a later gear plant, or convert component-rig hours into full-core endurance.

## 3. E5 craft: why displacement remains OPEN

The accepted First Type gives a useful hull/mission/hydrodynamic control at 20.5 t, but the V6 article is a newly laid close derivative with altered local structure and test equipment. It is therefore invalid to write `20.5 t + every new item` if some old frames/deck/equipment are replaced, and equally invalid to force the legacy 25–27 t target.

V6 closes the machinery arrangement and several directly calculable coordinates: 1,000 hp; 7.6 kg/s; 15–18 krpm free turbine; a 2.0–2.4 krpm shaft-test band; ~0.40–0.48 kN m high-side torque; a 70 mm preliminary center shaft; and 0.36–0.40 m2 total intake clear area. The actual full-load mass and CG must now come from the hull/scantling and equipment takeoff.

## 4. LL20-R2: no thermodynamic free lunch

At fixed Taiyo 21→25.5 kt incremental propulsive demand, fixed E6 installed specific work and the same post-engine path retention, the total engine power and total core airflow are the same regardless of whether the boost plant uses 4, 6 or 10 modules. At the 0.93 sensitivity the total core airflow is about 122.35 kg/s.

Therefore the 6-module plant does **not** win by a magic large-core efficiency gain. Its benefit is a lower count of gas generators, free power turbines, starters/controls, clutches and gear inputs. Its cost is a real new-core scale tax and a larger fraction of boost lost when one module is unavailable. This is why one LL20 R2 article has program information value.

## 5. Why R2 is authorized, but P is not

The current company canon already has deliberate 1936–38 turbine-factory over-expansion, a suburban turbine test site, E6-M hot-core work, and industrial-turbomachinery experience in large rotors/casings/bearings/metrology. That makes an additional ~2.6–2.8 MW experimental article and a program-created ~3–4 MW absorption stand plausible as an R&D investment.

But the new 20–21 kg/s PR7 hot core still owes its own full compressor map, large-hot-casing thermal behavior, combustor exit uniformity, rotor criticals, hot-section endurance and manufacturing-repeatability evidence. Marine salt/gear/shaft clocks are later still. Thus V6 authorizes R2; it does not promote the article to a product.
