# Migration note — aircraft rebaseline v5 (2026-08-22)

Base: `asai-worldline-20260822-computation-integrated-v4`.

v5 does not discard v4 computation integration. It changes the canonical aviation audit order from “preserve originals and add deltas” to **historical H → C → M → E → P → I → A → niche N → original-aircraft O**. Old aircraft tables are retained as provenance/comparison `A_old` where useful.

## Added canonical working documents

- `06-AIRCRAFT-REBASELINE-P0-2026-08-22.md`
- `main/asai-works-piston-installation-shadow-ledger.md`
- `main/asai-works-historical-aircraft-rebaseline.md`
- `main/asai-works-aviation-controls-gate.md`
- `main/asai-works-zero-rebaseline.md`
- `main/asai-works-f4f-rebaseline.md`
- `main/asai-works-carrier-fighter-niche-1940-41.md`
- `main/asai-works-kaifu-11-requirement-reaudit.md`
- `main/asai-works-turboprop-altitude-installation-ledger.md`
- `main/asai-works-kaifu-11-i0-feasibility.md`

## Reclassified / superseded

- A6M2 533→548–552 km/h: retained as **R-21 retrofit comparison**, no longer treated as design-origin A.
- A6M2 A0-1940: **2,430–2,450 kg / 543–550 km/h working band**. Historical ESD spar saving is already inside H and is not counted again.
- F4F 1940–41 A': no Asai technology is gifted to the opponent; prewar/early-war aircraft stays essentially on its historical technical path, with later reaction gated by observation and lead time.
- Old Kaifu 11: **3,800 kg / 560–600 km/h / ~1940 general carrier-fighter mainstay is rejected at I0**. E5 Kaifu remains as X/limited evaluation only.
- Old “Zero low / Kaifu middle / Sakufu high” 1941–42 mix is retained only as `A_old`; carrier-fighter OOB must be regenerated after E6 Kaifu I.
- Old turboprop statement “turbine keeps rated power at altitude” is superseded. E5/E6 receive altitude power shadow bands; flat-rating requires explicit thermodynamic/TIT/rpm/gear/torque margin.

## First niche result

Zero A0 closes most of the generic low/mid carrier-fighter niche. F4F-4 also demonstrates that carrier density is itself a combat-system variable. The remaining candidate niches for a turbine fighter are high-altitude persistence, long loiter with heavier equipment, kerosene/fire-safety, and later radar/night equipment — but E5 I0 shows that **E5 does not fill those strongly enough to justify a 1940 general carrier fighter**.

## E5 Kaifu I0 result

Representative 6 km calculation at 3.6 t / 620 shp shows that 560 km/h would require roughly `CD0S ≈ 0.25 m²`, versus the Zero calibration near `0.42 m²`; this is not a credible 1940 carrier installation. Plausible E5 shadows lie roughly in the **470–520 km/h** class depending on mass/drag/altitude. Therefore:

- X Kaifu / small evaluation series: retain.
- Kaifu 11 as general carrier main fighter: **not adopted**.
- Full combat Kaifu: **re-emerge from E6 requirements**, not by scaling the old E5 table.

## Next P0

1. Run E6 Kaifu I from the regenerated niche, including installed 600–770 kg class and non-constant altitude power.
2. Regenerate the 1941 carrier-fighter OOB.
3. Cross-correct Ki-40, Tenzan and other turboprop aircraft whose old altitude performance assumed automatic rated-power retention.
