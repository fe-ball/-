# CROSS-DOMAIN PREFLIGHT — v32r1

Purpose: prevent semantic omission and accidental promotion of conditional branches. Before dated design/history analysis, scan `CANONICAL-CHRONOLOGY-V32R1.*` and `CAPABILITY-TRIGGER-MATRIX-V32R1.tsv`.

## Mandatory order

1. **Chronology/status** — ordinary current analysis uses `current`/`scope`; `conditional` requires an explicit gate; `superseded` is provenance only; `mixed` requires source inspection.
2. **Requirement owner / historical counterpart** — ask who actually generates the requirement. Do not convert Asai's technology supply into platform omniscience.
3. **Availability R/P/X/N** — distinguish research, productization, external absorption and military/program availability.
4. **Propulsion/energy** — piston boost, diesel turbo, GT, TP/turboshaft, turbojet are separate technologies. Check part-load, installed mass and environment.
5. **Materials/environment** — separate steel/heat-treatment, resin/process, GFRP and CFRP maturity; do not backdate structural composites or treat GFRP as nonflammable.
6. **Mechanisms/controls** — gears, clutches, transmission, shaft/prop/cavitation, cooling, steering/traverse, electrics.
7. **Computation/QC/test** — computation shortens iteration and improves margins/repeatability; it does not create missing requirements or raw-physics bonuses.
8. **Production/maintenance/logistics** — tooling, spares, inspection, field/base/yard infrastructure and actual procurement remain separate gates.
9. **Integration tax / negative gate** — record attractive technology that was checked and rejected.

## v32 ROTORCRAFT 1942+ gate

Current authority is `main/asai-works-rotorcraft-1942-plus-rebaseline-1942-55.md`.

Fixed calibration / decisions:
- 1941 end-state from `asai-works-rotorcraft.md` remains: medium Re-go is still design research. Do not jump from E6-S-S core capability to a mature heavy helicopter.
- Old first-step **4–5.5t / 1,000–1,500shp** medium central is superseded. 1942–43 central is **~3,200kg / 15m / E6-S-S derated ~900shp continuous / ~1,000shp short-time** prototype/service-test.
- Hover ledger: 3,200kg/15m gives ideal induced power ~358hp; early FM/tail/transmission losses put engine-side hover roughly **720–840hp**. The full ~1,500shp core capability is not automatically used.
- Main gearbox/rotor life is a gate: ~100h ground endurance before staged flight release; **150–200h-class TBO** is limited-use entry and 250–300h-class is a maturation target. These are programme gates, not historical facts.
- 1942–45 wartime roles: liaison, litter evacuation, short cargo, shipboard trials, visual/radar-assisted maritime search, suppression, report/contact hold and conditional depth-charge attack.
- **Wartime dipping-sonar hunter-killer is NO.** 1951–52 is early helicopter-ASW/sonar calibration; 1955+ is mature dipping-sonar + attack-weapon helicopter calibration. Do not backdate service maturity from a 1943 concept proposal.
- Rescue begins with landing-based confined-area recovery/litter evacuation. Sea-hover hoist requires a separate winch/cable/hover/salt/training gate.
- VTOL does not erase deck footprint. Check 15m rotor clearance, roll/pitch, tie-down, hangar/folding, salt spray, exhaust/intake, maintenance and deck crew. Dedicated/semi-dedicated decks first; ordinary destroyer use is conditional.
- Post-1941-12-08 OOB/production/deployment/combat remains FROZEN. Old sea-escort/CVE fleet-number deltas derived from helicopter hunter-killer assumptions require history reopen before recomputation.

Always separate **engine capability**, **airframe/transmission maturity**, **mission sensor maturity**, **procurement**, and **post-1941 history**.

## v31 ARMY-FIGHTER H→A gate

Current authority is `main/asai-works-army-fighter-rebaseline-1937-42.md`.

Fixed calibration / decisions:
- Start from the Army requirement owner, not from Asai capability. Ki-43 light-fighter and Ki-44 fast-climb-interceptor requirements exist independently of early exhaust-turbo technology.
- Ki-43 H: ~500 km/h requirement, 5,000m/5min, ~800km and Ki-27-class-or-better maneuverability. Performance anchor is **495 km/h @ ~3.7–4.0km with normal 2,017.5kg**. Do not silently merge the separate 2,048kg comparison weight into that test state.
- Ki-43 retrofit 507–511 km/h is a physical comparison, not automatic A0. Current A0 is **~503–508 km/h @ ~4km**, with standard exhaust turbo **NO** and margin reinvested in firepower, radio/electrics, local structure and production repeatability.
- Ki-44 H is the December 1941 review: **583.5 km/h @ 3,870–4,000m, normal 2,550kg, Ha-41 rated 1,260PS @3,700m, 4,000m climb 4:38**. Old 580@3,700/2,600kg is superseded.
- Ki-44 physical I using the current D01 exhaust/surface method is **596.9–601.5 km/h**. Current A0 is **~596–600 km/h** after reinvestment; standard exhaust turbo is **NO** because the original ~600km/h requirement is essentially closed without it.
- **Capability is not requirement.** Do not infer a 1941 P-47-class mass-produced fighter merely because an exhaust turbo exists. Requirement, airframe, engine, installation, production and service gates remain separate.
- **Ki-64 designation is restored** to Kawasaki's tandem-Ha-40/Ha-201 experimental heavy-fighter branch with contra-rotating propeller and wing surface cooling. It is a 1943-first-flight calibration branch, not a 1941 production high-altitude fighter.
- A sustained **7–10km** high-altitude turbo fighter remains an **unnamed CONDITIONAL** shadow until the Army states that requirement. Ki-87/Ki-94 may become later candidates only after such a requirement; old Ki-64 seat-preemption logic is invalid.
- Post-1941-12-08 OOB/production/deployment/combat remains FROZEN. Old OOB Ki-64 entries are history/provenance technical mismatches until the history gate is explicitly reopened.

Always distinguish H test load, retrofit I, design-origin A, and post-1941 history. Do not use frozen OOB to validate a withdrawn technical precursor.

## v28 LARGE-MARINE gate

Current authority is `main/asai-works-surface-ship-large-marine-rebaseline-1934-41.md`.

Fixed calibration / decisions:
- Taigei No.11 and battleship No.13 are separate EHs. Taigei improvement is not proof of No.13.
- Historical No.13 Type 6: 480×600 mm, 350 rpm, 4,800 PS-class, 144 h endurance completed, 95+ score. Separate technical defects (smoke/ring/liner-piston wear) from adoption-risk defects (no No.13 service record; poor No.11 service record).
- Asai computation/QC may shrink the technical defect tail but cannot manufacture service history before the 1937 capital-ship decision. A-140F6 all-steam-turbine remains central; F5 mixed diesel/turbine is conditional/provenance.
- A free-power turbine is not a reversing device. Explicitly identify astern architecture: base steam/diesel, CPP, reversing gear, or electric transmission.
- Destroyer/cruiser/carrier GT boost or return-home installations are conditional until intake/filter/exhaust, reducer/shaft/clutch/torsion, salt MTBO, installed mass/volume, fuel and yard integration are closed.
- Do not revive legacy post-1941 carrier-count changes derived from assumed GT adoption; OOB/production/deployment/combat remains HISTORY/FROZEN.

## v27 TANK-EARLY gate retained

Current authority is `main/asai-works-tank-early-computation-materials-rebaseline-1928-41.md`.

Do not revive as current:
- Type 89 as a 120hp diesel throughout 1929–34;
- production turbo Type 89;
- Ha-Go 130–145hp as the production central or automatic 20–25mm armor growth;
- Chi-Ha as a later turbo retrofit rather than the worldline 1938 200/220hp production central;
- Shinhoto Chi-Ha 5-crew/3-man-turret worldline specification;
- Chi-He 260hp operational boost, 400mm initial track, powered coarse traverse or standard full-crew voice intercom.

For each early tank, first state the Army/manufacturer requirement independently of Asai. Then ask what turbo/materials/computation/QC actually buy in transmission, cooling, reliability, high-altitude performance, crew workload and production repeatability.

## v29 MARINE-GT-CRAFT gate

Current design authority is `main/asai-works-marine-gt-small-craft-design-closure-1938-43.md`; `main/asai-works-marine-gt-small-craft-rebaseline-1934-43.md` is historical/physics provenance.

Fixed calibration / decisions:
- ~20.5t Japanese No.1-class: ~1,800hp / 38–38.5kt / two 45cm torpedoes; T-51 is the heavy-boat failure calibration.
- Old 2×1,300hp GT + 350hp diesel independent-three-shaft central is superseded. E5 first marine qualification is two conventional piston shafts for cruise/astern plus one independent ~1,300hp E5 GT boost shaft.
- Trial speed is not operating/service speed. Treat E5 42–46kt and E6 42–44kt as clean/full-load trial design bands unless sea-state/service penalties are separately closed.
- Initial prop bands: E5 0.74–0.80m / 2,050–2,300rpm; E6 0.86–0.94m / 1,750–1,950rpm. Cavitation/ventilation remains a tank/sea-trial gate.
- Complete marine installed GT-path bands: E5 2.8–3.4kg/kW (central 3.1), E6 2.2–2.8kg/kW (central 2.5), excluding fuel/long shaft/prop.
- E5 qualification: ~150h cumulative, ~50h hot-section inspection. E6: ~300h cumulative, ~100h inspection, ~500h design-TBO target. Do not promote these to fleet historical MTBO.
- Pure-GT normal torpedo-boat mass production is NO for the E5/E6 period; sprint/test craft remains a conditional shadow.
- E6 50–55t / 4×45cm / nominal 5,200hp / ~42–44kt full-load trial / ~450–600nm planning-range technical shadow is valid, but actual requirement/procurement/series production is conditional. Hard 40kt service requires roughly 6,000–7,100hp or lower displacement.
- 2GT high-power craft require high-speed marine CPP/feathering or equivalent low-speed prop-drag mitigation; domestic implementation/endurance is conditional.
- v30 hull authority supersedes the old GFRP next-gate wording: 1942–43 central is full-scale section + 8–12m demonstrator; 20–30t full high-speed and 50–55t full-GFRP remain conditional.

Always check: hull/trim/sea state, shaft/prop/cavitation/ventilation, installed mass, salt/intake/inspection, part-load fuel, reverse/harbor handling, weapons/crew/fuel weight and yard repair. Small-craft success is **not** the sole prerequisite for all naval GT applications.

## v30 GFRP SMALL-CRAFT HULL gate

Current materials/scale-up authority is `main/asai-works-gfrp-small-craft-hull-rebaseline-1940-46.md`.

Fixed calibration / decisions:
- Do not equate early resin/glass availability with a 20m/40kt primary hull. Historical scale-up is the calibration; Asai's epoxy/silane/QC moves the ladder earlier but does not erase it.
- 1940–41: coupons, bonded joints, curved panels, inserts and real seawater/hot-wet exposure.
- 1941–42: full-scale bottom/forebody/chine/keel/engine-bed sections plus repeated pressure/slam rigs; thick-section exotherm, voids and secondary bonds are explicit gates.
- 1942–43 central: **full-scale high-speed hull section + 8–12m low/medium-speed all-GFRP demonstrator**. Do not promote this to a 20–30t full high-speed boat.
- 1943–44+ 20–30t full-GFRP high-speed prototype is conditional. Initial construction uses solid GFRP bottom/keel/chine and only limited sandwich above the waterline.
- 1944–45 limited operational testing requires wet/slam/repair qualification; procurement/series production remains separate.
- 50–55t E6 wartime central hull remains wooden double-diagonal/laminated. Full-GFRP high-speed E6 is conditional at a 1946+ technical gate. Low-speed nonmagnetic experiments may precede it but do not imply minesweeper adoption.
- 19–20m / 20–30t planning mass band: primary GFRP structure 4.5–6.5t, glass 2.5–3.8t, resin 1.8–2.7t. The old generic 6–8t glass-per-boat value is not valid for this class.
- Wet qualification uses wet allowables; the inherited 60% dry-baseline interlaminar floor remains a reject floor, with ~70% dry-baseline retention as the primary-structure target band.
- Slam/fatigue is not a tensile-coupon problem. Working programme gates include 10^5-class full-scale panel pulses and staged sea trials; these are design programme targets, not historical facts.
- NDT and repair are mandatory: tap/ultrasound plus depot scarf/step repair and re-test for primary bottom/chine damage. Emergency patches restore watertightness, not automatic full-speed structural capability.
- **GFRP is not nonflammable.** Kerosene/diesel lowers fuel hazard; machinery spaces still need metal firebreak/liner, air gap/insulation and separate fire testing.

Always identify which scale is being discussed: coupon/panel, full-scale section, 8–12m demonstrator, 20–30t high-speed prototype, or 50–55t E6. Do not let a lower-scale pass satisfy a higher-scale adoption gate.

## v26 aircraft gates retained

Aircraft role/rebaseline authority remains `main/asai-works-aircraft-computation-closure-1937-46.md`. AT-3/Ki-92 and Fugaku development milestones remain conditional. Do not revive B6A Tenzan, Tenzan-bomber→Ryusei, Ki-48TP production, old Ginga seven-seat total-replacement or old carrier-jet density-only speed rows.

## v25 TANK-NEXT gate retained

`main/asai-works-tank-next-generation-conditional-1939-45.md` remains a conditional technical shadow. Actual research authorization, threat-intelligence timing, prototypes, production and deployment are not current history.

## Minimum record

| Family | Result | Reason/source |
|---|---|---|
| chronology / semantic status | CHECKED / GATED-OUT / N/A | source |
| requirement owner / historical counterpart | CHECKED / GATED-OUT / N/A | source |
| propulsion / part-load / fuel / environment | CHECKED / GATED-OUT / N/A | source |
| materials / structure / corrosion | CHECKED / GATED-OUT / N/A | source |
| mechanisms / controls / shaft/prop/transmission | CHECKED / GATED-OUT / N/A | source |
| computation / optics / QC / test | CHECKED / GATED-OUT / N/A | source |
| production / maintenance / logistics | CHECKED / GATED-OUT / N/A | source |
| integration tax / negative gate | CHECKED / GATED-OUT / N/A | source |
