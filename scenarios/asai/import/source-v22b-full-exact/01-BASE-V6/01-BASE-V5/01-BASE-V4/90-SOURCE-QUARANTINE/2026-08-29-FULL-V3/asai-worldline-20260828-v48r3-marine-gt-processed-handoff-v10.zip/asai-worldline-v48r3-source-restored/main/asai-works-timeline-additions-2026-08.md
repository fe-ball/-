> **v48 aviation fence.** 旧航空platform固有の追加行は採用史へ自動接続しない。制御・与圧・燃調・材料・艦艇など独立技術は保持し、機体名を伴う適用は技術能力と旧platform例を分離して読む。

# 2026-08改訂で追加・確定した項目——年代順
> **[v29 marine authority]** 魚雷艇design currentは `asai-works-marine-gt-small-craft-design-closure-1938-43.md`。v27親は史実較正/provenance。旧1939=50t/5,000hp、旧2GT+350hp中央、1940=単一成功gate、1942–43=50t GFRP一発成形はsuperseded。

> **[v26 provenance note] 航空機命名列の天山B6Aはv26でB6Nへ訂正。current=`archive/aviation-pre-v48/v46-main/asai-works-aircraft-naming-canonical.md`。**

この改訂（名称修理・追加考察の全査読・技術の足元・所管の空白・兵器ツリーの空席）で本体へ入った項目を、**年代順に一列へ並べる**。各年表への接続は §末。

各項目の年次は、既存の律速（素材の可用年、E系世代、減速機、需要側の引き）から導いたもので、**新しく年次を発明していない**。

---

## 1. 年表

| 年 | 項目 | 分野 | 正本 |
|---|---|---|---|
| **1928** | **工作機械部**が部制へ入る（創業期の「織機→特殊鋼→工作機械」を受ける。歯切盤の本格化は1940〜42） | 会社 | `company-structure` |
| **1930年代前半** | **高炉送風機**の入口（製鋼所へは電気炉の炉内材・工具で既に扉がある） | 産業 | `industrial-turbomachinery` |
| **1936–37** | **気動車ディーゼルの過給**（史実キハ43000＝1937の潤滑失敗を正面から潰す。GT機関車は副次のまま） | 鉄道 | `gt-first-customers` |
| **1936–40** | **水素複合体の圧縮機**（HDS前倒しの10年の布陣に同期） | 産業 | `industrial-turbomachinery` |
| **1938** | **定速ガバナ標準化**（E-5単発＝Ki-40初期型から） | 航空・足元 | `propeller-control` |
| **1938–41** | **E5 marine-qualification艇**（木造25–27t、既存piston二軸＋中央E5 GT boostを低リスク中央。2GT枝はCPP/feathering gate）。史実型ピストン艇線は維持 | 舶用 | `marine-gt-small-craft-design-closure-1938-43` |
| **1939** | **燃調の機械式三点**（遠心ガバナ＋アネロイド＋加速絞り）をジェット実証機で確立 | 航空・足元 | `fuel-control` |
| **1939–40** | **特殊潤滑油の規格**制定（精製はしない。基油は石油各社、配合規定を浅井が持つ） | 会社 | `company-structure` |
| **1940–41** | 小型GT艇はmarine qualificationの一入力。**全舶用GTの単一採用gateにはしない** | 舶用 | `marine-gt-small-craft-design-closure-1938-43` |
| **1940** | **フルフェザリング標準化**（双発以上＝百式司偵TP・銀河） | 航空・足元 | `propeller-control` |
| **1940–** | **予備動力GT**の艤装開始（新造は民間船殻＋工廠艤装、既存艦は入渠改装＝**ドック回転が律速**） | 舶用 | `gt-gyorai-yobi` §1b |
| **1940–** | **海防艦 甲＝予備動力**（主機に触らないので敷居が最も低い） | 舶用 | `kaiboukan-gt` |
| **1940–41** | 陸戦の**工兵・架橋／装甲回収／指揮通信**の三車種（牽引車・装甲車の派生。台数は正準化しない） | 陸戦 | `military-diesel-vehicles` §4G |
| **1941** | **負トルク制限器**（浅井の工夫・機械式）。多発TPが片発停止で成立する条件 | 航空・足元 | `propeller-control` |
| **1941** | **部分与圧の入口**（Ki-40発展型・多座は差圧0.30 kg/cm²＝機内6.6 km） | 航空・足元 | `cabin-pressurization` |
| **1941–42** | **大鷹級の改装＋GT増速**（大鷹＝三菱長崎→佐世保工廠、雲鷹・冲鷹＝呉、海鷹＝三菱長崎、神鷹＝呉。**改装は船台でなく乾ドックを食う**） | 舶用 | `gt-carrier-taiyo` §5b |
| **1942** | **自動フェザリング**（四発＝深山／連山で標準） | 航空・足元 | `propeller-control` |
| **1942** | **複座ジェット転換練習機**（キ122。試製簡易局地戦闘機の複座化＋E6-M-J減格。**律速は教官**） | 航空 | `jet-trainer` |
| **1942–43** | **洋上哨戒・対潜固定翼 Q1Y**（銀河の内数。**律速は磁探・電探**。v33ではset研究暦を前倒しせず、成立後の電源/防湿/EMI/整備availabilityのみ改善可） | 航空 | `maritime-patrol` |
| **1942–43** | **GFRPは実寸bottom/forebody区画＋8–12m級実証艇が中央**。20–30t full high-speedは1943–44+ conditional、50–55t全面GFRPは1946+ conditional | 舶用・素材 | `gfrp-small-craft-hull-rebaseline-1940-46` |
| **1942–** | **海防艦 乙＝ディーゼル巡航＋GT増速**（追撃の足） | 舶用 | `kaiboukan-gt` |
| **1942–** | **給油艦へのGT増速適用**（低速の商船改装タンカーが艦隊随伴できるか変わる） | 舶用 | `naval-buildup` 補 |
| **1942–** | **工作艦の不足が顕在化**（E系は熱部モジュール交換とベンチ試験を要求＝ピストン機より前線整備の要求が高い） | 舶用 | `naval-buildup` 補 |
| **1942–43** | **着艦バリアの前輪式対応**（上下二段の張索＋朔風二一型の大翼で進入速度を下げる。作り手＝萱場・KXの延長） | 舶用・航空 | `gt-catapult` |
| **1943** | **海防艦 丙＝回生GT主機**（ディーゼル不足の迂回。丁型がタービンへ振られた席） | 舶用 | `kaiboukan-gt` |
| **1943** | **空中給油の給油型機体**（深山／連山の爆弾倉を灯油タンク＋巻取機へ。**四発重爆の内数から差し引く**） | 航空 | `turboprop-shinzan-renzan` §6b |
| **1944** | **単座の部分与圧**（白虹／飛廉・**差圧0.30 kg/cm²＝機内6.6 km**＋与圧酸素マスク。完全与圧はやらない。独Ta 152Hの0.37 barに合わせて旧案0.20から引き上げ） | 航空・足元 | `cabin-pressurization` |
| **1944末–45** | **白虹／飛廉 写真偵察型**（外装・内装換装のみ。追加ゼロ。専用機首型は作らない） | 航空 | `cfrp-program` §4.0b |
| **1945** | **低速非磁性GFRP実験艇/大区画はconditionalに試験可能**。掃海艇としての要求・量産・採用は磁気機雷脅威と生産gateを別途通す | 舶用・素材 | `gfrp-small-craft-hull-rebaseline-1940-46` |

---

## 2. 年次を持たないもの（判断・訂正）

年表に乗らないが、この改訂で確定した判断。

| 項目 | 内容 |
|---|---|
| 命名・採番 | 霹靂J2N／凱風A7M／朔風A8N／烈風A9M（繰り下がり）／天山B6A／白虹J9As／飛廉キ121／大型TP輸送機L5Si／STOL連絡機キ76「一式指揮連絡機」（襲名）。報告名＝FLOYD／OWEN／VERN／OPAL／CLYDE／TRUDY／STELLA |
| 彗星 | アツタ線が立つので存続。艦上席は天山爆撃型→流星、彗星は陸上高速軽攻撃＋二式艦偵 |
| CFRP実用機 | 浅井が組む（例外条項）。陸海軍は**艤装と領収で分ける** |
| CFRP実用機乙（TP型） | **制式採用しない**。甲が845〜860 km/hを出すのに乙は700止まり |
| Ni | 非Niと**両取り**。量＝非Ni／上端開発＝Ni |
| 深山／連山 翼面積 | 史実照合で型別化（深山175〜195 m²／連山112〜125 m²） |
| 非Ni基準寿命 | 減格則の逆算で**約105 h**（Ni 300 hの約1/2.9） |
| FH-1 | 813 km/hは誤り。**771 km/h（479 mph）** |
| 魚雷艇の諸元 | **25–27t E5 one-GT marine-qualification艇（42–46kt trial候補）**を中央、2GT high-powerはCPP/feathering必須。**E6 50–55t shadowは42–44kt full-load trial**、actual procurementはconditional。純GT通常量産はNO、20–30t full-GFRP高速艇と50–55t全面GFRPはCONDITIONAL |
| 艇の据付比重量 | 艦の3〜5 kg/kWを艇へ流用しない。**v29では完全installationをE5 2.8–3.4 / E6 2.2–2.8 kg/kWへ再較正** |

---

## 3. 各年表への接続

- 1930年代＝`asai-works-timeline-1930s.md` §7
- 1940年代＝`asai-works-timeline-1940s.md` §7
- 舶用＝`asai-works-timeline-marine.md` §7
- 航空＝`archive/aviation-pre-v48/v46-main/asai-works-aviation-timeline.md` 末
- 全体＝`asai-works-timeline-master.md` §8

親：`asai-works-handoff.md`／`asai-works-technical-delta-2026-08-14.md` §9。
