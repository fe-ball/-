# v3 → computation-integrated-v4 移行メモ

- 入力 `computation-full-v3` は無改変で保持。
- `computation-2026-08-22/` の4本を `main/asai-works-computation-*.md` へ正本統合。入力スナップショットは残す。
- 旧 provisional の1937–45機械系列は履歴保存し、supersededを明記。
- handoff / company-structure / timeline-master / 1920s / 1930s / 1940s に計算機史の参照入口を追加。
- CFRP住友共同プロペラの定量値を現役 `cfrp-program §2d` へ移し、P0–P3監査を `propeller-control` に追加。
- 横断監査は `04-INTEGRATION-AUDIT-2026-08-22.md`、航空影機は `05-AIRCRAFT-SHADOW-AUDIT-2026-08-22.md`。
