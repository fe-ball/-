# 134 — Machine-layer refresh v46r1 — 2026-08-26

v46r1 refreshes the machine layer after the E6-M pure-jet / aft-fan installed-thrust and hardware closure.

- chronology: **667 records** (`CANONICAL-CHRONOLOGY-V46R1.tsv` / `.jsonl`)
- main canonical files: **201**
- status partition: **current 496 / conditional 72 / superseded 56 / scope 34 / mixed 9**
- new v46 chronology delta: **CHR-0658..0667**
- old E6-M-J / E6-M-N-J **~500 kgf** and E6-M-JF **650–700 kgf** product anchors are superseded.
- E6-M-J non-Ni product authority is **~850 kgf/engine**; E6-M-N-J Ni is **~900 kgf/engine**.
- E6-M-JF production authority is **~950–1,000 kgf/engine**, central **~984 kgf** at **835°C / BPR~1.0 / FPR~1.30**.
- same-TIT JF effect is **+20.9% static thrust / −17.3% TSFC**; the old blanket +30–40% rule is superseded for E6-M.
- JF retains a single-spool gas generator but adds an **independent free-LP-turbine/fan spool**.
- fan release coordinate is **~0.50–0.55 m / 8.5–9.5 krpm**, central ~0.52 m / ~9,000 rpm; free-turbine extraction central ~0.406 MW.
- aft module adds **~100–150 kg**; E6-M-JF dry mass is **~610–690 kg/engine**, central ~650 kg; nacelle max OD ~0.66–0.72 m.
- old Hekireki/Sakufu/CFRP/trainer aircraft performance derived from 500 or 650–700 kgf is retained only as **A_old / conditional** pending dedicated H→A.

Current recall layer:
`CURRENT-CANONICAL-STATE.md` → `CANONICAL-MAIN-INDEX-V46R1.tsv` → `CANONICAL-CHRONOLOGY-V46R1.tsv` → `CROSS-DOMAIN-PREFLIGHT-V46R1.md` → `CAPABILITY-TRIGGER-MATRIX-V46R1.tsv`.
