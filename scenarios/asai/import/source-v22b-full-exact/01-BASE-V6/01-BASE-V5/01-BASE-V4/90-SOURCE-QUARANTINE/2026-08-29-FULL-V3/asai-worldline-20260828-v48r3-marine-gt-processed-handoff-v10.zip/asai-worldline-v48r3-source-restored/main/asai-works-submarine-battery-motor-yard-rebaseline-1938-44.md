# 潜水艦 battery / motor / yard 再基線化 1938–44 — 通常大型鉛電池、4主電動機、工業・工廠会計

> **v35 current canonical parent.** v23の船体概念を維持し、電池・主電動機・高電流配電・充電/換気・工廠据付/交換を一つの受領帳簿へ統合する。motorの1時間ratingとbatteryの高速持続時間を同一視しない。

## 0. 中央裁定

1. 第一/第二世代の中央電池は**通常大型鉛電池120 cell群×3**。多数小cellの特殊高出力電池を前提にしない。
2. 主電動機は約1,000–1,125 hp級×4を技術中央とするが、4,400–4,500 hpの**1時間ratingはmotor thermal rating**であり、15 ktを1時間維持できる意味ではない。
3. 旧「4–6隻級先行小量産」を撤回し、中央を**1–2 hull-equivalent complete electrical/yard sets**へ縮小する。3rd+はfactory/yard repeatability gate後のCONDITIONAL。
4. 15 kt高速持続はfull-bank高率放電で、end voltage、cell/group temperature、SOC偏差、H2、motor/commutator、shaft/prop/cavitationまで含めて別受領する。
5. 工業会計は架空のyard man-hourを置かず、cell数/重量/容積、motor個数、銅/bus/switchgear、charging/ventilation、搬入交換経路、絶縁、軸芯、brush/commutator、予備品で比較する。
6. 1941-12-08以後の実建造数、配備、損失、戦果、敵ASW反応はHISTORY/FROZEN。

## 1. H — 史実較正

- **I-15/B1級**：240 cell、主電動機2基、総計約2,000 hp級、水中8 kt級を工業比較の基準1.0とする。
- **I-400 Mark I Model 13**：360 cellを120 cell battery×3群並列、1 h率5,500 Ah、20 h率11,200 Ah。通常大型鉛電池で3群構成が成立する較正錨。
- **I-200 special D battery**：多数小cellで高出力を狙った負の較正錨。電解液量、separator/沈殿余裕、並列充電均等、H2/保守の税を示す。

## 2. temporal / acceptance ledger

| 時期 | 項目 | v35 current判定 |
|---|---|---|
| 1938–41 | I-15 electrical H baseline | 240 cell / 2 main motors / ~2,000 hp totalをresource index 1.0にする |
| 1944 | I-400 ordinary battery H anchor | 360 cell = 3×120 parallel groups; 5,500 Ah@1h / 11,200 Ah@20h。通常大型鉛電池の較正 |
| 1944 | I-200 special-D warning anchor | many-small-cell high-power architectureはelectrolyte/separator/parallel-charge/H2/maintenance税を持つ |
| 1941–43 | central electrical architecture | ordinary 3×120-cell groups + four ~1,000–1,125 hp-class DC motors。未知battery chemistryを使わない |
| 1941–43 | engineering programme | **1–2 hull-equivalent complete electrical/yard sets**を中央。instrumented full-bank/yard repeatabilityを閉じる |
| 1942+ | third and later sets | CONDITIONAL。cell/motor factory、high-current gear、yard installation/replacementの反復性を確認後に開く |
| 1941–43 | relative industrial ledger | I-15=1.0に対しcell count≈1.5、main-motor count≈2.0/boat。銅・switchgear・charger/ventilationを別に加算 |
| 1941–43 | motor rating rule | 4,400–4,500 hp **one-hour rating = motor thermal rating**。battery high-rate enduranceとは別変数 |
| 1941–43 | 15 kt full-bank acceptance | specified SOC/temperature/depthで高率放電し、end voltage、temperature、H2、motor current、cavitationとdurationを実測 |
| 1941–43 | charging / atmosphere gate | group別SOC/温度、充電電流、ventilation、H2 alarm/手順、acid/insulationを受領項目化 |
| 1941–43 | motor / high-current gate | busbar/switchgear、commutator/brush、巻線絶縁、冷却、shaft alignment、spares/test gearを工廠critical path化 |
| 1941-12-08+ | actual construction / operations | CONDITIONAL/HISTORY。艇数・起工・配備・損失・戦果は再計算しない |

## 3. power/energy separation

4,400–4,500 hpは約3.28–3.36 MWのmotor shaft-rating帯である。I-400較正の5,500 Ah×名目240 Vは単純積で約1.32 MWhなので、損失・電圧降下・高率容量低下を無視しても3.3 MW級を1時間支えない。したがって「motor 1h rating」と「15 kt duration」は同じ数字で閉じない。

世界線で15 ktを採る場合は、cell仕様が確定した時点でPeukert/high-rate容量、group voltage sag、motor efficiency、temperature、SOC偏差を含むfull-bank試験を行い、持続時間を結果として記録する。速度要求を先に1時間へ固定しない。

## 4. yard ledger

- battery: cell搬入/交換経路、tray/foundation、acid drain/neutralization、ventilation、温度計測、insulation、group isolation。
- high current: copper bus、breaker/contactor、arc management、接続トルク、発熱、絶縁抵抗、spares。
- motor: lifting route、foundation、shaft alignment、bearing、commutator、brush、winding insulation、cooling、test load。
- charging: diesel-generator capacity、shore/yard charger、充電時間、H2排気、crew/maintainer procedure。
- repeatability: 1号setで成立しても3号setを自動承認しない。factory yieldとyard rework率を次のgateにする。

## 5. A — 採用形

v23の約1,700 t級第二世代/15 kt requirement shadowは維持するが、中央programmeは1–2 hull-equivalent engineering setsまで。3rd+ series、exact 15 kt duration、actual hull constructionはそれぞれ別gateである。
