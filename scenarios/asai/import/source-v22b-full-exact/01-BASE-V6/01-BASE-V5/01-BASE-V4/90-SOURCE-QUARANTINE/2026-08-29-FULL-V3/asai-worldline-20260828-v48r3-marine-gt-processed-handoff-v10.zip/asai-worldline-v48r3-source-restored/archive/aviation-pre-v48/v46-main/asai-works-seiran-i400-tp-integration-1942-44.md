# 晴嵐・伊400型のターボプロップ統合 1942–44（v24正本）

## 0. 歴史順序と立ち位置

伊400型の戦略要求/概念が先行し、晴嵐の設計要求は1942年に並行して進む。瑞雲の経験は完成品の直接移植ではなく、parallel feedbackとして折畳、float、dive-brake、治具、封止等の試験方法を共有する。

## 1. 晴嵐の基本機体

- 3.5m級円筒格納庫、3機、翼/尾翼折畳、800kg爆弾/魚雷の基本要求は維持。
- main structureは金属。GFRPはfairing、cover、float端等の二次部。
- epoxyは湿気/腐食/電装封止、接着補助、修理。
- 浅井配当はtop speedより、折畳公差、治具、captured fastener、limit switch/relay ready表示、作業clearance、repeatability。

## 2. 発動機——E6-M-T海軍耐塩flat-rated型

既存世界線では液冷Atsutaも品質問題が史実より小さく、safe baselineとして成立する。したがってTPは「他が失敗したから仕方なく」ではなく、潜水艦航空の燃料/始動/塩害に合う積極選択。

本命：

- E6-M-T大コア。
- core capability海面約2,100shp。
- aircraft rating：**1,600–1,650shp flat-rated**。
- 4km shadow：1,470–1,720shp、6km：1,160–1,470shp級。
- 余裕は高温日、塩害、寿命、altitude marginへ返す。

fallback：小型Ni系1,500–1,550shp、誉12 derated 1,700–1,800hp、最終安全側Atsuta32。

## 3. 性能帯

- float装着最高速：**490–500 km/h、中央495**。500超は良好上端。
- float非装着：**575–590 km/h shadow**。使用頻度は歴史側。
- 800kg搭載combat range：**1,150–1,250km級**。
- 最大射出重量：**4.45–4.60t**。出力余裕を重量growthで食い切らない。

2,000shp超のaircraft ratingはpropeller torque、gearbox、structure、catapult taxが大きく採らない。

## 4. 海水・塩害package

浅井系marine GTで蓄積した塩水/塩霧試験を直接再利用する。ここは浅井由来の因果鎖が強い。

原則：

1. coarse seawaterを吸わせない。
2. 入った分に耐える。
3. 飛行後に洗い、乾かす。

実装：

- 格納中/始動前のsealed intake shutter。
- 上側吸気。
- SEA mode：inertial/vane separator、急曲がり、drain。E6-Mの**13.2kg/s central airflow**を処理する断面へ再評価が必要。旧約10kg/sはv43でsuperseded。本稿の既存duct寸法・機体性能はv44後のplatform H→Aまで未更新。
- catapult後、sprayを離れたらFLIGHT modeへbypassし圧損を減らす。
- front compressorの防食材/表面処理、hot section coating、最重要はderating。
- clean low-sulfur kerosene専用day tank。潜水艦diesel fuelと安易に共用しない。
- 回収後：清水compressor rinse、starter motoring、drain、warm/dry air。
- 格納庫：fan＋electric heat＋再生silica gel程度のmild dry store。未来的HVACにしない。
- deck上turbo-exhaustは外舷へ逃がし、heat shield/danger sectorを設定。残留推力を犠牲にして安全を取る。

## 5. 伊400型

airframe軽量化は潜水艦を大きく縮めない。3.5m pressure hangar、燃料航続、安定性、構造が支配。

- 長さ約120–122m、幅約12m。
- surface displacement **5,100–5,300t級**、submerged **6,400–6,600t級**。
- 3.5m×30–31m hangar、晴嵐3機。
- surface 7,500–8,000hp級成熟22号10型相当、18.5–19kt。
- underwater：4×約1,000hp motor、practical約3,600hp/short4,000hp。大hangar/appendage dragにより**7.5–8kt級**。攻撃潜水艦12–15kt線を輸入しない。
- battery候補：4×120-cell大形鉛群＝約480cells/約360t。hotel load、長時間潜航、冗長、電流分割を買う。
- 武装合理化候補：bow 6 tubes/約12 torps、14cm deck gunなし、AA限定。浮いた重量は電装/batteryへ。

## 6. 航空整備・発艦sequence

液冷piston用温水/温油preheatとaviation gasolineを削り、clean kerosene day tank、filter/water separator、electric starter power、compressor wash water、hangar drying、intake shutter、exhaust shieldを持つ。

engineはclosed hangar内で始動しない。

移動→展開/float装着→lock確認→外部電源TP始動→SEA intake→短い安定運転→catapult→FLIGHT intake。

3機float装着exercise-standardの準備/発艦は**20–25分級**を目標。10分奇跡値にはしない。価値は最短記録よりrepeatability。

## 7. 艦上専用計算・静音/受信

- trim calculator：航空機位置、tank、fuel、weaponから推奨trim waterを出す。人が実行し、紙表fallback保持。
- battery/motor state panel：各battery groupのamp-hour積算、電圧/温度補正、motor current/winding temp/timeからrating marginを表示。
- quiet/avoid rpmはcomputer不要。tachometer band/lightで受領noise mapを表示。
- phenolic fabric laminate gearsはfan、小pump、操舵/plane補機、instrument/selsyn等の選択部へ。main reduction gearには使わない。
- water-lubricated bearing等も実測own-noiseで対象を絞る。
- sonar/receiverはAsai-linked electronicsだけ：small ferrite transformer/choke、power-noise低減、moisture-sealed amp、switchable bandpass/notch、receiver blanking、simple AGC/level meter。FFT/digital beamforming/automatic classificationは置かない。

## 8. CLOSED / HISTORY BOUNDARY

伊400/晴嵐の技術統合、塩害package、艦上専用計算、静音材料、受信電子の浅井連鎖部分は閉鎖。敵ASW、作戦、損失、実戦戦訓は歴史側。
