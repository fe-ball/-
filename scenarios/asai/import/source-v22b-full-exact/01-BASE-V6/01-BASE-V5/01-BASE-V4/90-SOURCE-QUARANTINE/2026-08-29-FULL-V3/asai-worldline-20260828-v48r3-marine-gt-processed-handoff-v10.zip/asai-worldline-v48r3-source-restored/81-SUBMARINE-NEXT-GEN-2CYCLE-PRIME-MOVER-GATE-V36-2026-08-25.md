# 81 — SUBMARINE NEXT-GEN 2-CYCLE PRIME-MOVER GATE v36

v36 closes the optional next-generation integrated 2-cycle submarine prime-mover question as **requirement-gated, not central**.

Central result:
- historical Model No.22 / 22号10型 is a 10-cylinder 4-cycle single-acting 2,350 hp-class engine; a two-engine set covers the v23/v35 second-generation ~4,700 hp surface-power band;
- 31号6型 proves Japanese Navy single-acting 2-cycle design capability existed by 1937, but it was a ~1,900 BHP blower-drive engine, not a fleet-series submarine main-engine precedent;
- a 1941 B&W-linked 6,000 PS-class 2-cycle double-acting design reached single-cylinder test, showing research plausibility but not production maturity;
- therefore the 1942–44 ~19 kt second-generation submarine does not open a new 2-cycle production family merely because Asai can improve scavenging/boost/QC;
- central surface machinery remains a 22号10型-class ~4,700 hp pair candidate, with actual 19 kt still requiring hull/propulsive acceptance;
- integrated 2-cycle remains CONDITIONAL and may reopen only for a concrete higher-power, installed-volume/mass, fuel, signature or industrial requirement that the 22号 family cannot close.

Canonical parent:
- `main/asai-works-submarine-next-gen-2cycle-prime-mover-gate-1941-45.md`

Post-1941-12-08 actual engine procurement, hull construction, deployment and combat history remain FROZEN.
