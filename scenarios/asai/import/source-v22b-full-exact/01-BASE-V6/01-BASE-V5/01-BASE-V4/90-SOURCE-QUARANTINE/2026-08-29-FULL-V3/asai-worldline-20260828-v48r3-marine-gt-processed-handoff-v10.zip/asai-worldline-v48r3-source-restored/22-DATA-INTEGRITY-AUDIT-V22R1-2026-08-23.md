# 22 — Data integrity audit / v22r1 (2026-08-23)

## 0. Scope

This is a **data-hygiene repair only**. Worldline semantic state remains v22. No performance number, chronology conclusion, OOB conclusion, design choice, or NEXT P0 is advanced. Parent for this repair is `asai-worldline-20260823-submarine-underwater-reconciled-v22.zip`.

## 1. What was healthy in v22

- ZIP extraction was clean.
- 306 files were present.
- Current `SHA256SUMS.txt` contained 305 unique entries, covering every file except itself; every listed checksum verified.
- `main/` contained 163 files and no duplicate-content hash groups.
- `01-MATERIALS-MASTER-INDEX-2026-08-22.md` had 10 explicit file references and every one existed.
- `02-COMPUTATION-MASTER-INDEX-2026-08-22.md` had 11 explicit file references and every one existed.
- The v22 reconciliation itself did not introduce the index defects below; comparison with the completed v21 parent showed that the principal defects were already inherited.

## 2. Defects found in v22

### A. Index/changelog drift

1. `02-COMPUTATION-MASTER-INDEX-2026-08-22.md` section order was `7a → 7b → 7d → 8 → 7c → unnumbered submarine section`. This is content-preserving but structurally hostile to machine parsing and human scanning.
2. `00-START-HERE-2026-08-22.md` jumped from v16 to v13 in its top lineage and contained no v14/v15 entry, despite both stages being real and still materially relevant to later gates.
3. `03-OPEN-ISSUES-2026-08-22.md` still titled itself “v12” even though v22 state had been prepended. Its P0 list duplicated item 3.
4. `main/asai-works-handoff.md` top lineage jumped from v17 to v14; v15/v16 existed only deeper in the theme index.

### B. Reachability / filename hygiene

- Before repair, one `main/` file had zero incoming text references from the package: `main/asai-works-tank-rework-2026-08.md`. It is a change/audit report rather than the primary tank canon, but because `main/` is defined as canonical content, leaving it unreachable was undesirable.
- Several active `main/` documents used shortened filenames such as cfrp-program.md, gt-fuel.md, or kufu-shu.md even though the packaged filenames carry `asai-works-` / `tensei-engineer-` prefixes. These were uniquely resolvable but weak for automated auditing.
- Two active jet references used wildcard asai-works-jet-interceptor*.md; they are replaced by the three exact packaged filenames.
- NAME-MIGRATION-MAP.md is intentionally absent; the naming canon previously phrased it as something to consult. v22r1 makes the lack of dependency explicit.
- asai-works-turbojet-demonstrator-handoff.md is intentionally retired/deleted. The surviving replacement already says so; v22r1 removes machine-link syntax around the retired filename.

### C. Manifest/provenance ambiguity

- The root contains 17 historical manifests named with qualified SHA256SUMS-...txt filenames. They belong to earlier package states and are not expected to verify against v22.
- `SHA256SUMS-PRODUCT-CHRONOLOGY-V15.txt` is especially archival: all 281 entries contain the old absolute build prefix `/tmp/asai-worldline-20260823-product-chronology-v15/`. It is retained unchanged as provenance, not used as a current manifest.
- There is no need to fabricate missing stage-specific manifests for v19–v22. The current tree is governed only by the regenerated unqualified `SHA256SUMS.txt`; historical package identity is carried by package-level hashes and migration/reconciliation notes.

### D. Multiple historical “start here” documents

Three old root `README-HANDOFF...` files and the frozen air-war session contain historical “current/start here” wording. They are retained because they are provenance/work-session artifacts. Their authority is now explicitly subordinated by `CURRENT-CANONICAL-STATE.md`.

## 3. Repairs applied in v22r1

- Added `CURRENT-CANONICAL-STATE.md` as the single machine/human current-state pointer.
- Added `CANONICAL-MAIN-INDEX-V22R1.tsv`, enumerating every `main/` file with SHA-256, byte size, first heading, and pre-machine-index incoming-reference count.
- Restored v14/v15 lineage entries to `00-START-HERE-2026-08-22.md`; added v15/v16 bridge entries to the handoff/current-state surfaces.
- Reordered computation-index sections to `7a → 7b → 7c → 7d → 8 → 9`.
- Corrected `03-OPEN-ISSUES-2026-08-22.md` current title and deterministic numbering.
- Normalized uniquely resolvable shortened references in active `main/` files to exact packaged filenames.
- Explicitly indexed `main/asai-works-tank-rework-2026-08.md` as an audit/change-history document.
- Did not alter old session files, old handoff files, or historical checksum manifests merely to make history look clean.

## 4. Invariants for future packages

A future package should fail data QA if any of these become false:

1. `sha256sum -c SHA256SUMS.txt` passes completely.
2. `SHA256SUMS.txt` contains every packaged file except itself exactly once.
3. Every explicit file reference in the current control plane (`CURRENT-CANONICAL-STATE`, `00`, `01`, `02`, `03`, current handoff) resolves, unless visibly tagged as historical/not bundled.
4. Every file directly under `main/` appears in `CANONICAL-MAIN-INDEX-V22R1.tsv` (or its successor).
5. No `main/` file has zero incoming reachability without an explicit reason.
6. Master-index section numbering is unique and monotonic within its hierarchy.
7. Current state, historical/frozen session state, provisional state, and retired references are visibly distinguished.
8. Worldline semantic-version increments are kept separate from data-maintenance revisions.

## 5. Current semantic state after repair

Still v22: 1938–43 submarine underwater P0 is closed; the two v21 branches are reconciled; overall NEXT P0 remains 1941–44 next-generation submarine niche regeneration.
