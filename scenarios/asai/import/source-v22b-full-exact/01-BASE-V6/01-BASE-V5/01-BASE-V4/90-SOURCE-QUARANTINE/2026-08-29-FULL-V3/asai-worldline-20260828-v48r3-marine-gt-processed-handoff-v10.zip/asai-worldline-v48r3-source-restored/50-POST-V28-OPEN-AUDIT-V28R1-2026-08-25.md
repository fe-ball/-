# v28r1 post-audit OPEN queue

## CLOSED / REBASED
- v28 surface-ship / large-marine technical rebaseline closed.
- No.13/Yamato decision and GT astern architecture corrected.
- Legacy GT-derived post-1941 carrier-count changes demoted to conditional.
- v27 early-tank and marine small-craft historical/physics calibration retained.
- v26 aircraft closure and v25 conditional next-generation tank shadow retained.

## P1 — 未監査/未閉鎖
1. **GT小型艇 design gates**：水槽抵抗/trim、prop/cavitation、marine installed mass、salt MTBO、純GT量産採用、50t大型艇要求・兵装・量産。
2. **GFRP艇体**：20–30t実証の工法/曝露/疲労/修理、50t全面適用のconditional gate。
3. 史実基準戦闘機H→A、回転翼1942+、radio/radar reliability、mine/sweeping、survey/artillery meteorology。
4. 潜水艦battery/motor/yard会計、任意次世代2-cycle統合主機。
5. E8/E9+ later-war propulsion（具体要求時）。

## P2 — 定量化
- E5/E6 marine intake/filter/reducer/shaft/prop map。
- small-craft sea-state speed、fuel/patrol doctrine。
- large-ship GT individual design only when a class requirement is opened; v28 supplies the mandatory integration gate.
- Chi-He and inherited v26 quantitative details remain available as lower priority.

## CONDITIONAL / HISTORY
- A-140F5 diesel/steam mixed propulsion adoption is conditional/provenance; A-140F6 is central.
- Destroyer/cruiser/carrier GT installation/refit/procurement remains conditional.
- CHR-0330..0332 legacy GT-derived carrier-count worldline rows are conditional.
- 1941-12-08+ OOB, actual production, deployment, losses, combat and enemy reaction are FROZEN.
