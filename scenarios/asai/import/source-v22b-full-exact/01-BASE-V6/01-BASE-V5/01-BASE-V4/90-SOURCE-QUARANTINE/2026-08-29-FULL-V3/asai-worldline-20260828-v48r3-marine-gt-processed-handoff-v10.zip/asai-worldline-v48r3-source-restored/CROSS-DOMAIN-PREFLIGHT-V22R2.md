# CROSS-DOMAIN PREFLIGHT — v22r2

Purpose: prevent semantic omission during design/history review. This is a **recall gate**, not a new worldline conclusion. Before evaluating a new platform, retrofit, production choice, or historical consequence, first scan the capability trigger matrix and explicitly mark each relevant family as `CHECKED`, `GATED-OUT`, or `N/A`. Do not rely on conversational memory.

## 1. Mandatory preflight order

1. **Date / availability** — read `main/asai-works-product-availability-ledger-1903-41.md`; distinguish research R, product P, external sale X, and military use N.
2. **Propulsion / energy** — piston/diesel, boost, GT/TP/jet, fuel, battery/motor as applicable.
3. **Materials / structure** — conventional metals, heat treatment, epoxy/adhesive, sandwich, FRP/GFRP/CFRP as applicable.
4. **Mechanisms / controls** — gears, bearings, propeller, cooling, controls, electrics/EMI, computation/QC.
5. **Production / maintenance** — tooling, inspection, repair, workforce, supply, logistics.
6. **Integration tax** — weight, volume, cooling, intake/exhaust, vibration, center of gravity, maintenance access, reliability, production bottleneck.
7. **Negative gate** — explicitly record attractive technologies that were considered but are too early, unsuitable, or already superseded.

A completed analysis should not say merely “not used”; it should distinguish `forgotten` from `considered and gated out`.

## 2. Two known omission traps

### 2.1 “Turbo” is not one technology

Always split the word into branches before judging applicability:

- aircraft piston exhaust-driven supercharging → `main/asai-works-aero-turbosupercharger.md`
- 1930s diesel turbocharging → `main/asai-works-diesel-turbo-1930s.md`
- ground-vehicle diesel application → `main/asai-works-tank-diesel-turbo.md` / `main/asai-works-military-diesel-vehicles.md`
- submarine 2-stroke compound-scavenging branch → `main/asai-works-submarine-maturation-1934-37.md` / `main/asai-works-submarine-propulsion-1940-43.md`; **do not directly import the 4-stroke commercial turbo result**
- independent gas turbine → `main/asai-works-gt-core-generations.md` and GT program files
- turboprop/turboshaft → `main/asai-works-turboprop-program.md` / catalog and installation ledgers
- turbojet → jet program files

Thus a prompt mentioning “engine”, “altitude”, “diesel”, “submarine main engine”, “vehicle mobility”, or “aircraft propulsion” automatically triggers a turbo-family check even if the user does not say “turbo”.

### 2.2 “FRP” is not one material

Always split the family by constituent and maturity:

- epoxy/adhesive/process capability
- plant-fiber FRP / sandwich secondary structure
- GFRP
- CFRP
- CFRP propeller branch

Canonical entry: `01-MATERIALS-MASTER-INDEX-2026-08-22.md`, then `main/asai-works-materials-resin.md`, `main/asai-works-frp-manufacturing.md`, and the specific application file. A prompt mentioning “weight”, “structure”, “corrosion”, “radome”, “float”, “boat hull”, “propeller”, “armor/spall”, “tank”, “aircraft”, or “submarine fittings” automatically triggers a composites check. Availability year and environment may gate the technology out; silence is not an acceptable gate.

## 3. Minimum completion record

For each substantive design/retrofit review, retain a short preflight record:

| Family | Result | Reason/source |
|---|---|---|
| availability chronology | CHECKED / GATED-OUT / N/A | source |
| turbo/boost/GT family | CHECKED / GATED-OUT / N/A | source |
| fuel/energy storage | CHECKED / GATED-OUT / N/A | source |
| materials/FRP family | CHECKED / GATED-OUT / N/A | source |
| gears/bearings/propeller/controls | CHECKED / GATED-OUT / N/A | source |
| electrical/EMI/battery/motor | CHECKED / GATED-OUT / N/A | source |
| computation/QC/test/inspection | CHECKED / GATED-OUT / N/A | source |
| production/maintenance/logistics | CHECKED / GATED-OUT / N/A | source |

This record may remain internal to the working note, but the check itself is mandatory.

## 4. Machine-readable companion

`CAPABILITY-TRIGGER-MATRIX-V22R2.tsv` is the machine-readable trigger list. It is intentionally redundant with thematic indexes: thematic indexes answer “where is the material?”, while this file answers “what must I remember to ask?”.
