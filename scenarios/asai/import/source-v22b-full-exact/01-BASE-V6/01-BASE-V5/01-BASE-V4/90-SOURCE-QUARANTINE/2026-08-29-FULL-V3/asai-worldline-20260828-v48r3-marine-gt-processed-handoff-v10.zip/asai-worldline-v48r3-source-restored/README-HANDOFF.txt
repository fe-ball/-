浅井世界 2026-08-15 技術浅層監査 引継ぎパッケージ

中身:
- main/ : provenance修復済みmain。今回、隼D01.6だけ直接更新。
- HANDOFF-TO-MAIN-2026-08-15.md : 向こう側で最初に読む文書。
- TECHNICAL-SHALLOW-AUDIT-1941-20260815-v2.md : 技術・機体側の残論点。
- HISTORY-CARRY-FORWARD-1941-20260815.md : 歴史構想の再開用メモ（今回は進めない）。
- provenance関連README/notes/index : 基準zipからそのまま保持。

旧supplemental 21〜45は含めない・復活させない。
