# MACHINE LAYER REFRESH — v35r1

v35r1 updates the current machine layer after the submarine battery/motor/yard rebaseline.

Build target:
- semantic worldline: v35
- chronology: 522 records = 509 carried from v34r1 + 13 v35 records
- main canonical inventory: 188 files
- v35 statuses: current 412 / conditional 49 / superseded 34 / scope 23 / mixed 4

New machine-visible gates include the I-15 electrical H baseline, I-400 ordinary three-parallel-group battery calibration, I-200 special-D negative calibration, 1–2 hull-equivalent programme central, 3rd+ conditional series, relative battery/motor resource indices, motor one-hour thermal-rating separation, full-bank 15kt duration test, yard critical path and the post-1941 history boundary.

Validator additions:
- reject stale current-machine pointers in START-HERE;
- require BATT trigger to include the v35 parent and legacy underwater/next-generation parents;
- reject return of the old `1941型は4–6隻級の先行小量産` central wording in the current v23 parent;
- require motor 1h thermal rating and battery high-rate endurance to remain distinct;
- require the v35 chronology status partition and source hashes to remain exact.
