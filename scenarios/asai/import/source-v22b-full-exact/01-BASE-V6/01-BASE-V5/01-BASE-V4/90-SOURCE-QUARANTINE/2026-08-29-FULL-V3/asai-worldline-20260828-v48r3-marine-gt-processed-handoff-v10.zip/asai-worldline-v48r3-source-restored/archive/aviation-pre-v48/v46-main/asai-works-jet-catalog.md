# ジェット エンジン機種カタログ——コア系統 × ガワ

> **v43 compressor-operability authority.** E6-M compressor family is **13.2 kg/s central / 12.5–14.0 kg/s full-speed trim**, PR7 / 14-stage axial. Existing E6-M-J `~14 kg/s` is retained as the high-flow jet trim; it is not evidence that E6-M-T can be a separate 10 kg/s full-PR7 core. E5-S-J 8.4 kg/s is likewise a high-flow S trim, not the standard 7.6 kg/s shaft gas path.

> **v46 installed-thrust authority.** E6-M jet high-flow trim is **14.0 kg/s**. Installed nozzle audit gives **E6-M-J ~850 kgf**, **E6-M-N-J ~900 kgf**, and long-life **E6-M-JF ~950–1,000 kgf/engine** (central ~984 at 835°C, BPR~1/FPR~1.30). Old 500 / 650–700 kgf anchors and blanket +30–40% JF gain are superseded. Aircraft performance propagation remains gated.

> **[2026-08-15 provenance再認証]** 寿命欄は**材料基準寿命**（同一運転点で比べたときの材料の強さ）であって、運転点適用後の**部隊TBO**ではない。`asai-works-validated-derivations-2026-08-15.md` §D05の実装値は、霹靂一一型（Ni高温少数型）**OH 220〜320 h・中央260**、二一型（非Ni-JFを30〜40℃減格した量産長寿命型）**OH 450〜650 h・中央520**で、部隊TBOは非Ni側が長い。完成主機プールは装備基数の約1.38倍、1942夏の通常任務可は一一型62〜72%／二一型68〜76%。
> **非Ni系の基準寿命は逆算で確定**：二一型の中央520 hは非Ni-JFを30〜40℃減格した値。`core-elements`の減格則（−30℃＝×4／−50℃＝×10、対数内挿で−40℃＝×6.3）を当てると基準は520÷4＝130 h〜520÷6.3＝82 h、**中央約105 h**。Ni基準300 hに対し約1/2.9で、材料差として妥当。梯子は次のとおり。
>
> | 運転点 | Ni系 | 非Ni系 |
> |---|---:|---:|
> | 全力（基準） | 300 h | **105 h** |
> | −30℃ | 1,200 h | 420 h |
> | −50℃ | 3,000 h | 1,050 h |
> | −80℃ | 12,000 h | **4,200 h** |
>
> これで`core-elements`の「非Ni＋減格＝数千h級」は−80℃深減格（舶用・定置）の話、航空の−30〜40℃は520 h、と両立する。

`asai-works-turboprop-catalog.md` と同じ骨格（**コア系統 → ガワ**）を、ジェット枝に当てる。後端は **J＝推進ノズル（純ジェット）／JF＝後置ファン（出力寄りバイパス）**。ジェットは**推力**で測る（`core-generations` §3）。一つのコア系統に複数のガワが付いて機種が増えるが、ターボプロップ同様**有界**——大戦期ジェットは点防御短足なので規模は中型M中心、後端は二つ、用途で材料・格付けが決まる（§5）。命名は `core-hierarchy` §7 を後端まで拡張。規則は `tensei-engineer-kufu-shu.md`、数値は `core-elements`／`turbojet-demonstrator-saiko`／`jet-interceptor` から、【確認済み】【物理】【設定】【要確認】で区別。

---

## 1. 命名——世代 × 規模 × 材料 × 後端

後端を一字：**J＝純ジェット（ノズル）／JF＝後置ファン（バイパス）**。形は **E{世代}-{規模}[-N]-{後端}**。例：E6-M-N-J（E-6・中型・Ni・純ジェット）、E6-M-JF（同・非Ni・後置ファン）。既存総称 **E-6J／E-6JF** は規模・材料を省いた呼びで、本カタログはその具体化。

---

## 2. コア系統（ジェットが使うコア種類）——推力で測る

ジェットは**ターボプロップより大きな質量流量**を要する（プロペラは小流量から軸出力を取り出せるが、ジェットは推力のために大流量が要る。**だからターボプロップが低核E-4で先行し、ジェットはE-5以上**＝`core-generations` §4b）。推力はおおむね流量に比例【物理】。

| コア系統 | 世代/規模/材料 | 代表流量 | 推力（基） | 熱効率（参考） | 寿命の素性 |
|---|---|---|---|---|---|
| E5-S-J核 | E-5/小/非Ni | 約8.4 kg/s | 約300 kgf | 約22.5% | 数百h |
| E6-M-J核 | E-6/中/非Ni | **~14 kg/s high-flow trim（family central 13.2）** | **約850 kgf installed** | 約26% gross comparison | 数百h |
| E6-M-N-J核 | E-6/中/Ni | **~14 kg/s high-flow trim（family central 13.2）** | **約900 kgf installed** | 約26% gross comparison | 長（高温・長寿命） |
| 上端-M-N核（＝E-7・1942–44） | 上端/中/Ni | 約14〜16 kg/s | 約550〜600 kgf | 約28% | 長 |
| E8-M-N technical core | E-8/中/Ni | 約15〜17 kg/s planning band | **installed thrust TBD**（v37 H→A gate） | 約31% gross / 30.4–30.5% cooled-core比較 | endurance/yield受領 |

（E5/E6/E7の推力欄は既存の保守的empirical anchor。**v37以後、gross Brayton比仕事を `√(2w)` で推力へ直結しない**。E8のmass-flow bandは計画値だが、installed thrustはcompressor/turbine/nozzle/cooling/inlet H→Aで再較正する。generationとcore scaleは独立で、v26 E6-L-Jには既に1,000–1,150 kgf級research shadowがある。したがって「E9になれば1,000 kgf」は禁止。）

---

## 3. ガワ（後端・格付け・増強）

- **後端**：J＝推進ノズル／JF＝後置ファン。v46 E6-M-JFはBPR≈1・FPR≈1.30・835°C長寿命点で、同温度純ジェット比 **静止推力+約21%・TSFC−約17%**。gas-generator compressorは単軸のまま、後端に独立free-LP-turbine/fan spoolを追加する。
- **格付け（運転点）**：全力・高温（高価値要撃＝Ni）／中庸（廉価点防御＝非Ni）／量産（出力寄りバイパス）。
- **増強**：水メタノール噴射（離陸・緊急）／**再燃焼＋可変ノズル**（上端期・短時間の高速、`propulsion-roadmap` §2）。
- **艤装**：単発（廉価）／双発ポッド（本命要撃）／翼内。前輪式・全金属。

---

## 4. エンジン機種カタログ（コア × ガワ ＝ 製品）

| 機種（社内） | コア系統 | ガワ（後端/格付け） | 推力 | 当てる機体・用途 |
|---|---|---|---|---|
| **E5-S-J** | E5-S | ノズル/全力 | 約300 kgf | 専用実証機（`saiko` 専用機型・記録機。世界初He178 1939より前） |
| **E6-M-N-J** | E6-M-N | ノズル/高温(Ni) | **約900 kgf/基** | **双発要撃「霹靂」一一型**。旧2基=約1,000 kgfからの機体性能はA_old、v46 H→A待ち |
| **E6-M-J** | E6-M | ノズル/中庸 | **約850 kgf** | **単発の廉価点防御**。旧500 kgf機体性能はA_old、v46 H→A待ち |
| **E6-M-JF** | E6-M | 後置ファン/出力寄り | **約950〜1,000 kgf/基**（中央~984；835°C、BPR~1、FPR~1.30） | **量産主力要撃/戦闘「霹靂」二一型**／艦上型＝**朔風試作型・朔風一一型・朔風二一型**。旧650〜685 km/h等の機体性能は**A_old / v46 H→A待ち** | |
| **上端-M-N-J** | 上端-M-N | ノズル/全力＋再燃焼＋後退翼 | 高亜音速（約0.85M） | **上端の高速要撃**（薄翼・後退翼・再燃焼。超音速は狙わない） |


> **v26大型航空jet shadow**：R2Y2景雲改用に、E6-L-J≈1,000–1,150kgf、E6-L-JF≈1,250–1,450kgf級を研究shadowとして解禁する。これは戦闘機Mコアを置き換える一般則ではない。実重量・高度推力・TBOはP2。正本=`asai-works-jet-strike-rebaseline-1941-46.md`。

推力は比推力×流量の物理【物理】、機種名・当て先は【設定】。同じ E-6・14 kg/s の核でも、**Ni高温ノズルの E6-M-N-J が最速の「霹靂」、非Ni中庸の E6-M-J が廉価点防御、後置ファンの E6-M-JF が使える量産主力**——ガワだけで別機種（ターボプロップと同じ作り分け）。双発要撃は同一M-family jet coreを二基ポッドで据えたもので、新コアではない。v46の推力増を機体速度へ自動伝播してはならない。

---

## 5. なぜ有限か——ジェットの縛り

ジェットはプロペラ吸収の制約が無い分、規模は理屈上は大きくできるが、**大戦期の用途が点防御短足の要撃に限る**ので、結局有界になる。

1. **戦闘機用途は中型Mが中心**：v46のM高流量trimは非Ni純ジェットで約850 kgf、Niで約900 kgf、JFで約950〜1,000 kgf/基を成立させる。旧「約500 kgf必要」という要求値は製品能力の下限説明としてはsuperseded。ただしv26では**R2Y2級高速偵察/軽爆、富嶽用大型航空コア研究**のためL航空化を例外解禁する。Lは一般戦闘機用ではない。
2. **後端は二つ**：ノズル（J）か後置ファン（JF）。中間バイパスは上端期の選択（`propulsion-roadmap` §3）。
3. **用途マッピング**：最速要撃＝Ni高温ノズル、廉価＝非Ni、量産＝ファン、と用途が材料・格付け・後端をほぼ決める。総当たりしない。

結果、ジェット枝も**約5機種に収束**する。ターボプロップ（約8）と合わせ、分野全体の後端軸を十数機種で覆う——多製品だが有限。

---

## 6. ターボプロップ枝との接続（同じ九軸）

両カタログは `core-elements` の同じ九軸の上にあり、違いは後端だけ：ターボプロップ＝プロペラ/軸（T/S）、ジェット＝ノズル/ファン（J/JF）。**ジェットが規模一段上（E-6で14 vs 7.2 kg/s）なのは、推力が大流量を要するから**で、これがターボプロップの低核先行（E-4から）とジェットの後発（E-5以上）を生む（`core-generations` §4b）。舶用・戦車・定置も同じ九軸の別の点。

---

## 7. タグ・次の作業

- 【物理】：推力＝比推力×流量、ジェットがターボプロップより大流量を要すること、後置ファンの静止推力/比燃費/最高速のトレード。
- 【設定】：機種名・当て先、比推力の芯350、約5機種への収束、上端の再燃焼/後退翼配置。
- 【要確認】：後置ファンの重量・前面積、Ni系の入口温度上限、再燃焼の可変ノズル・噴管、双発ポッドの据付・抵抗。
- 次：需要の高い一機（E6-M-N-J「霹靂」一一型 か E6-M-JF 量産主力）を機体側まで詰める（`jet-interceptor-airframe` を更新）。上端-M-N-J の高亜音速要撃を一枚で試算。

---

## 8. 索引への接続

- 親：`asai-works-core-elements.md`（九軸）／`asai-works-core-hierarchy.md`（三層・§7命名）。
- 機体側：`asai-works-jet-interceptor.md`（契約・機種・性能）／`asai-works-jet-interceptor-airframe.md`（機体構成・戦術）／`asai-works-jet-interceptor-program.md`（開発史・諸元）／`asai-works-turbojet-demonstrator-saiko.md`（実証機の六型）／`asai-works-propulsion-roadmap.md`（後端軸のロードマップ）。
- 物理：`asai-works-jet-physics.md`（v37でgross Brayton workとinstalled nozzle thrustを分離。既存比推力350は経験anchor、速度の壁＝臨界マッハ・後置ファンη_p）。
- 対：`asai-works-turboprop-catalog.md`（ターボプロップ／軸の枝）。
