# Migration note — v23 → v24 cross-domain technical closure

v24 advances technical semantics but does not advance war history/OOB.

New canonical files are listed in `29-CROSS-DOMAIN-TECHNICAL-CLOSURE-V24-2026-08-24.md`. Supersession points of special importance:

- `main/asai-works-turboprop-part-load-long-range.md` supersedes constant-BSFC low-load assumptions in `main/asai-works-turboprop-shinzan-renzan.md`.
- `main/asai-works-tank-computation-rebaseline-1938-41.md` refines the existing tank family without replacing the 18t/240hp/50mm Type 1 Chi-He landing point.
- `main/asai-works-seaplane-flyingboat-rebaseline-1940-44.md` is the current water-aircraft technical parent.
- `main/asai-works-torpedo-air-attack-rebaseline-1938-44.md` closes torpedo hardware/drop-envelope technology but leaves battle hit rates and force composition to history.

Historical v23 files remain provenance snapshots.
