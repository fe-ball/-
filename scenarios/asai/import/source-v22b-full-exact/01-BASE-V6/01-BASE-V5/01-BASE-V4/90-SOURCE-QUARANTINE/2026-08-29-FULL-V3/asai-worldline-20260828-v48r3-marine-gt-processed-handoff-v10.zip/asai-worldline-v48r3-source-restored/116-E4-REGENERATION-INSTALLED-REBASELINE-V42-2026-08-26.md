# 116 — E4 regeneration installed rebaseline — v42

v42 closes P1-2 without yet propagating aircraft/ship/adoption effects.

Central decisions:

- old E4 regeneration **25% / ~0.33 kg/kWh is superseded**.
- standard E4-R retains v41 **6.7 kg/s** core flow.
- central recuperator: **epsilon 0.60 / air-side dp 1.5% / exhaust-side dp 2.5%**.
- central recuperated shaft: **467.7 kW / 19.34% / 0.433 kg/kWh / 202.5 kg/h**.
- recovered heat **~0.94 MW**; required **UA ~9.8 kW/K**.
- generator @95%: **~444 kWe recuperated continuous** versus **~482 kWe cold/start/emergency bypass**.
- product rating coordinate: **475–480 kWe bypass / 440–450 kWe recuperated continuous**.
- recuperator+headers+bypass/duct: **0.6–1.1 t**, installed hot-path volume **1.4–2.5 m3**.
- 25% shaft efficiency would require **epsilon ~0.943** at central losses; rejected as E4 standard.
- 475 kWe recuperated continuous requires **~7.16 kg/s**, therefore remains a conditional high-flow derivative pending compressor-operability qualification.
- exact part-load SFC is not frozen; start and emergency operation use bypass, and load-map closure moves to P1-3.

Canonical parent: `main/asai-works-e4-regeneration-installed-rebaseline-1931-33.md`.
Reproducible computation: `computation-2026-08-22/e4_regeneration_installed_v42.py` / `E4-REGENERATION-INSTALLED-V42.tsv`.
