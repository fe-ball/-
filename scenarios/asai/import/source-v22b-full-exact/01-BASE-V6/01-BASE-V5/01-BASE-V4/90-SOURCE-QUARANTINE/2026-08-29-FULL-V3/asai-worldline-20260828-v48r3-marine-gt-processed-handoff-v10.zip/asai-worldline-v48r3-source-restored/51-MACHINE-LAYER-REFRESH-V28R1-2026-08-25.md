# v28r1 machine-layer refresh

- Chronology: `CANONICAL-CHRONOLOGY-V28R1.tsv/.jsonl` (438 records).
- Schema: `CHRONOLOGY-SCHEMA-V28R1.json`.
- Main index: `CANONICAL-MAIN-INDEX-V28R1.tsv`.
- Trigger matrix: `CAPABILITY-TRIGGER-MATRIX-V28R1.tsv`, adding `MARINE-LARGE`.
- Preflight: `CROSS-DOMAIN-PREFLIGHT-V28R1.md`, adding the v28 No.13/Yamato/large-GT gate.

v27r1 records are carried forward. New CHR-0431..0438 encode the v28 large-marine authority, No.13 historical calibration, Yamato F6 central decision, F5 conditional branch, No.11/No.13 causal split, large-GT baseline, class-installation conditional gate, and free-power-turbine reversal correction. CHR-0330..0332 are demoted to conditional because their modified post-1941 carrier counts depend on an unproven class GT adoption.
