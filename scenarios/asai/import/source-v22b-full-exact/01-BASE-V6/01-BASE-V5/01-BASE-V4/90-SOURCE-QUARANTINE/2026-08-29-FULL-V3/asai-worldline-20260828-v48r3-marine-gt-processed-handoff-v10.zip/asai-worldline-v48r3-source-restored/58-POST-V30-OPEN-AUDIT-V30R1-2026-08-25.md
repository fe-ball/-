# v30r1 post-audit OPEN queue

## CLOSED / REBASED
- v30 GFRP small-craft hull scale-up rebaseline completed.
- 1942–43 central is full-scale bottom/forebody section + 8–12m low/medium-speed all-GFRP demonstrator, not a complete 20–30t high-speed hull.
- 20–30t full-GFRP high-speed prototype is conditional from 1943–44+; limited 1944–45 operation requires wet/slam/repair gates.
- wartime E6 50–55t central hull remains wooden double-diagonal/laminated; full-GFRP high-speed E6 is a 1946+ conditional technical gate.
- old 6–8t glass-per-20–30t-boat general planning value is withdrawn; current planning band is primary GFRP 4.5–6.5t, glass 2.5–3.8t, resin 1.8–2.7t.
- GFRP fire semantics corrected: it is not nonflammable; fuel hazard and structural fire protection are separate.
- v29 stale 2GT+350hp current-timeline wording has been removed; one-GT boost remains propulsion central.
- v29/v28/v27/v26/v25 gates remain inherited.

## P1 — next
1. Historical-fighter H→A / rotorcraft 1942+ / radio-radar reliability / mine-sweeping / survey-artillery meteorology.
2. Submarine battery/motor/yard accounting and optional next-generation 2-cycle integrated propulsion.
3. E8/E9+ later-war propulsion only when a specific requirement opens it.

## CONDITIONAL / HISTORY
- 20–30t full-GFRP high-speed prototype actual build, limited operation, procurement and series production.
- 50–55t full-GFRP E6 and low-speed nonmagnetic branch actual procurement/minesweeper adoption.
- high-speed marine CPP/feathering domestic implementation and E6 actual procurement.
- large-ship GT class installations / A-140F5.
- 1941-12-08+ actual OOB, production, deployment, losses, combat and enemy reaction remain FROZEN.
