# Marine GT processed handoff — START HERE V9

V9 sits on semantic **v48** / machine **v48r3** and preserves the V8 engineering/history boundary. It advances only the safe P0 technical work.

Read in this order:

1. `119-V9-TECHNICAL-NOTES.md`
2. `113-POWER-STATION-ACCOUNTING-CORRECTION-V9.tsv`
3. `114-LL20-R2-TECHNICAL-PACKAGE-V9.tsv`
4. `115-LL20-R2-FACILITY-AND-TEST-LOADS-V9.tsv`
5. `116-E6-M-MARINE-BOOST-ROLE-QUALIFICATION-V9.tsv`
6. `117-TAIYO-DUAL-PATH-COMMON-INTERFACE-V9.tsv`
7. `118-MARINE-GT-REWORK-QUEUE-V9.tsv`
8. `120-MARINE-GT-PRECEDENCE-OVERLAY-V9.tsv`
9. Then use V8 `102`-`106` for the history stop rules and V7 `89`-`95` for prior engineering provenance.

Reproducible calculation files are under `computation-2026-08-28-v9/`.

Key V9 correction:

> The v44 2,100/2,300 hp E6-M-T headlines include a 0.975 T-product output-transmission debit. Taiyo's 95% marine path is a different accounting station. At the same raw PT-shaft station, the nominal ten-E6-M Taiyo branch does not demand a materially new engine rating; it demands marine role, environment, PT and gear-path qualification.

LL20 remains different: its new 20.56 kg/s scale still owes full hot-core R2 evidence.

No V9 file asserts an LL20 authorization/date, an E6-M marine qualification pass, or an actual Taiyo GT reservation/adoption.
