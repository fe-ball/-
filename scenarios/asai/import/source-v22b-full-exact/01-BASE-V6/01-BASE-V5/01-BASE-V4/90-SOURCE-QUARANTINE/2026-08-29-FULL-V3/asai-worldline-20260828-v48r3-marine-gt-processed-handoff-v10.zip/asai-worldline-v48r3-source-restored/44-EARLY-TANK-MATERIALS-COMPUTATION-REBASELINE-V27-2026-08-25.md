# v27 初期戦車 材料×計算×QC 再基底化

## 判定

**TECHNICAL CLOSED / HISTORY FROZEN。**

v25は1940+条件付き次世代戦車を閉じたが、1928–41の八九式・ハ号・チハ・新砲塔・チヘには旧「ターボディーゼル中心」時代の残滓があった。v27では、浅井を未来知識の戦車設計者にせず、陸軍/三菱の史実的要求へ早期材料・計算・QCを横断適用した。

### current
- 八九式甲=約100hp gasoline、乙=1934から120hp diesel。
- 140–150hp過給八九式=試験枝。
- ハ号=120hp自然吸気量産中央。高地補償120–125hp枝。140–145hp=試験。
- チハ=1938量産時点から200hp連続/220hp短時間過給が中央。
- 新砲塔チハ=4名二人砲塔/手動旋回/47mm。
- チヘ=約17.5t/240hp連続/5名3人砲塔/50mm主前面/330mm級履帯/手動旋回/radio標準。
- チヘ260hp operational boost、400mm履帯、電動粗旋回、全乗員intercom標準をDROP。

親=`main/asai-works-tank-early-computation-materials-rebaseline-1928-41.md`。
