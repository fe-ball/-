# v27r1 machine-layer refresh

- Chronology: `CANONICAL-CHRONOLOGY-V27R1.tsv/.jsonl`.
- Schema: `CHRONOLOGY-SCHEMA-V27R1.json`.
- Main index: `CANONICAL-MAIN-INDEX-V27R1.tsv`.
- Trigger matrix: `CAPABILITY-TRIGGER-MATRIX-V27R1.tsv`.
- Preflight: `CROSS-DOMAIN-PREFLIGHT-V27R1.md`.

v26r1 rows are preserved as provenance, but obsolete early-tank and small-craft-GT rows are reclassified `superseded`. New tank technical/current rows and marine historical calibration rows are added. E5/E6/pure-GT/GFRP craft designs are explicitly `conditional` so the open design/procurement questions cannot be recovered as fixed history.
