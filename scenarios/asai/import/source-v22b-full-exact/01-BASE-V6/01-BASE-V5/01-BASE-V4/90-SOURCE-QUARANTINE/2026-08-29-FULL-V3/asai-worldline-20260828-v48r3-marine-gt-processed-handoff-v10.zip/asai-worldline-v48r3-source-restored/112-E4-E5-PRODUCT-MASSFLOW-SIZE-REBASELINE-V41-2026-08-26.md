# 112 — E4/E5 product mass-flow / size rebaseline — v41

v41 closes P1-1 without yet propagating aircraft/ship/adoption effects.

Central decisions:

- E4 500 kW: **ACCEPT**; standard design flow **6.7 kg/s**; central capability ~507 kW.
- E4 first industrial product: working envelope **0.66–0.74 m diameter / 2.0–2.4 m length**, dry mass **0.80–0.90 t**.
- E5 ~1,000 hp: **ACCEPT**; standard E5-S gas path **7.6 kg/s** rather than the v40 Ni-only minimum coordinate.
- E5 at 7.6 kg/s: Ni@800 ~1,063 hp, non-Ni@800 full ~1,014 hp, non-Ni@765 quantity ~952 hp.
- Standard E5 headline remains **1,000 hp**; Ni margin is preferentially spent on life/hot-high margin; non-Ni quantity central is ~950 hp.
- E5 working envelope **0.68–0.76 m diameter / 2.0–2.3 m length**; engine assembly **390–460 kg**; installed TP powerplant **510–640 kg**.
- Exact compressor stage matching / surge / start / VSV-bleed / rotordynamics remain OPEN for P1-3.
- Existing E5-S 1,300 hp marine sprint target is not compatible with the standard 7.6 kg/s S core; it becomes a downstream H→A conflict, not an automatic v41 platform change.

Canonical parent: `main/asai-works-e4-e5-product-massflow-size-rebaseline-1931-37.md`.
Reproducible computation: `computation-2026-08-22/e4_e5_product_resize_p1.py` / `E4-E5-PRODUCT-RESIZE-P1.tsv`.
