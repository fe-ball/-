# Marine GT V8 — engineering/history boundary hardening

## 1. Why V8 exists

V3–V7 repaired the marine-GT technical stack: E5 qualification-craft power/mass assumptions, E5-to-E6 inheritance, LL20 demand sizing, Taiyo 6-vs-10 integration, and the rule that protagonist future knowledge starts the right research clocks rather than adding an unnamed performance multiplier.

The remaining risk is different. Once an engineering branch becomes plausible, it is easy to write a plausible exact approval date, test success, procurement action, or ship selection and accidentally convert analysis into alternate-history canon. V8 prevents that.

## 2. Two independent questions must remain separate

Every future marine-GT statement now answers two separate questions:

1. **What does the engineering evidence support?**
2. **What, if anything, has actually been selected as altered-worldline history?**

A calculation can be fully closed while the corresponding historical event remains open. A historically available hull can be certain while its use by Asai remains unselected.

## 3. The six evidence/history classes

V8 introduces: `FIXED`, `DERIVED`, `HISTORICAL-ANCHOR`, `WORLDLINE-PROBABLE`, `SCENARIO`, and `SELECTED`.

`SELECTED` is deliberately narrow. It requires explicit user/canon selection. An assistant label such as `LEADING TRADE`, `W-SELECTED`, or `R2-AUTHORIZED-WORKING` is not sufficient by itself to make history happen.

Accordingly, V6/V7 working selections remain valid engineering coordinates but are not worldline chronology events unless independently canonized.

## 4. Protagonist future knowledge remains fully active

V8 does **not** weaken the cheat.

Future knowledge can:

- identify the correct variables and failure modes early;
- start creep, salt, rotor-dynamic, compressor-map, gear, and endurance clocks years earlier;
- avoid low-information intermediate products;
- justify self-funded rigs and reversible option-preserving studies before customer demand is explicit;
- improve the probability that scarce prototype/test money is spent on the right experiment.

It cannot silently add compressor efficiency, material life, production yield, shipyard speed, or successful endurance hours. If the protagonist raises the acceptance bar, the larger number of open gates is not a nerf; it is a more demanding evidence culture.

## 5. Immediate reclassification of the current marine-GT front

- E5-S 1,000 hp qualification architecture and the V7 mass/shaft/intake calculations remain valid technical work.
- Actually building the purpose-designed close-derivative test craft remains unselected history.
- LL20 `~20.56 kg/s / ~3599 hp` remains a derived R2 design duty for the named Taiyo 6-module study.
- The argument that a 20–21 kg/s R2 article has high information value is worldline-probable; the exact authorization, first-fire date, and endurance achievements are scenarios until selected.
- Taiyo 6xLL20 remains a leading integration trade and 10xE6-M remains a lower-new-core-risk fallback. Neither is selected propulsion.
- Early GT interface study for a conversion candidate can be worldline-probable without asserting that irreversible structure or long-lead machinery was actually committed.

## 6. How to continue

Continue technical work aggressively where it remains safe: E5 test-craft drawings, LL20 R2 drawings and test requirements, Taiyo common interface envelopes, E6-M marine boost qualification requirements, No.600 equal-hull trades, and test-platform information-value comparisons.

When a result reaches an actor decision — build this ship, authorize this prototype, reserve this structure, buy this gear, adopt this propulsion architecture — stop at `WORLDLINE-PROBABLE` or `SCENARIO` unless the user/canon selects it.

This converts future work from "writing the most plausible history" into "narrowing the technically and institutionally plausible decision space".
