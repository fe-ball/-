# ターボプロップ／軸出力 エンジン機種カタログ——コア系統 × ガワ

> **v44 E6 installed-product authority.** v43 compressor identity remains: E6-S **7.8 kg/s** (7 axial + 1 centrifugal), E6-M **13.2 kg/s central / 12.5–14.0 trim** (14-stage axial). v44 now pays cooling/pressure/mechanical/accessory/output-gear debits: E6-S non-Ni standard **1,300 hp**, E6-S-N standard **1,500 hp**, E6-M-T **2,100 hp retained as flat-rated** below ~2,250 hp central capability. Jet/JF thrust remains a separate audit. E5-S-HF ~8.08 kg/s is compressor-feasible but standard E5 headline remains 1,000 hp.

> **v41 E4/E5 product update.** E4-S standard flow **6.7 kg/s / 500 kW class**、E5-S standard gas path **7.6 kg/s / common 1,000 hp**を再受領済み。Ni@800の7.6kg/s central capabilityは約1,063hpだがheadlineを自動上げず、non-Ni@765 quantityは約950hp。旧E5-S-N 1,130hpはhigh-flow derivative gateへ戻す。E6+は本v41未監査。

> **[v26 Fugaku exception]** 通常航空prop機はS/Mまでという原則を維持するが、**富嶽級160t六発だけは36–40kg/s級L航空化を専用研究として例外解禁**する。5.0–5.3m・650–700rpm級propと専用5,000shp reducerを伴うため一般機へ波及させない。正本=`asai-works-fugaku-technical-shadow-1942-46.md`。

> **v5 E-T6再監査（2026-08-22）**：表の軸出力は原則**海面/商品定格点**として読み、高度一定出力と解釈しない。高度別は `asai-works-turboprop-altitude-installation-ledger.md`。旧「Ni=高度保持」は「TIT余裕で高度特性を改善」に読み替える。


`asai-works-core-elements.md` の九軸（要素分解）を、ターボプロップ／軸出力の分野で**具体的な製品の表**に落とす。骨格は **コア系統（世代×規模×材料＝コア種類）→ ガワ（後端・艤装・格付け）**。一つのコア系統に複数のガワが付いて機種が増えるが、**無限ではない**——プロペラの吸収限界（規模の頭打ち）と、用途マッピング（材料×格付けは用途でほぼ一意に決まる）で有界になる（§5）。命名は `asai-works-core-hierarchy.md` §7 を後端まで拡張。規則は `tensei-engineer-kufu-shu.md`、数値は要素モデル（`core-elements`／`core-generations`）から、【確認済み】【物理】【設定】【要確認】で区別。

---

## 1. 命名——世代 × 規模 × 材料 × 後端

`core-hierarchy` §7（世代E-n × 寸法{S小・M中・L大} × 材料{無印＝非Ni・N＝Ni}）に、後端を一字足す：**T＝ターボプロップ（プロペラ）／S＝ターボシャフト（軸）**。

- 形：**E{世代}-{規模}[-N]-{後端}**。例：E6-S-T（E-6・小型・非Ni・プロペラ）、E6-S-N-T（同・Ni）、E6-M-T（E-6・中型・非Ni・プロペラ）、E6-S-S（E-6・小型・軸）。
- 既存の総称 **E-5T／E-6T／E-6S** は、規模・材料を省いた呼び。本カタログはそれを具体化したもので、矛盾しない（E-6T ⊃ {E6-S-T, E6-S-N-T, E6-M-T, …}）。

---

## 2. コア系統（ターボプロップ／軸が使うコア種類）

通常の機体プロペラ／回転翼が使うのは**小型S・中型M**。大型Lは原則舶用・定置だが、v26では富嶽級超大型機のみ専用航空L研究を例外解禁（§5）。

| コア系統 | 世代/規模/材料 | 代表流量 | 比仕事 | 熱効率 | 寿命の素性 |
|---|---|---|---|---|---|
| E4-S | E-4/小/非Ni | **6.7 kg/s** | installed≈75.7 kJ/kg | installed≈15.0% | `L_core` 250–450h |
| E5-S | E-5/小/非Ni | **7.6 kg/s** | installed≈99.5@800 / 93.5@765 | installed≈18.7 / 18.4% | full150–300h / quantity350–600h |
| E5-S-N | E-5/小/Ni | **7.6 kg/s** | installed≈104.3@800 | installed≈19.3% | 400–700h |
| E6-S | E-6/小/非Ni | **7.8 kg/s compressor design** | **installed≈130.5 kJ/kg @870°C**（gross 155.3） | **installed≈22.5%** | 数百h |
| E6-S-N | E-6/小/Ni | **7.8 kg/s compressor design** | **installed≈148.7 kJ/kg @920°C**（gross 173.3） | **installed≈23.5%** | 長 |
| E6-M | E-6/中/非Ni | **13.2 kg/s central / 12.5–14.0 trim** | **installed≈130.5 kJ/kg @870°C**（gross 155.3） | **installed≈22.5%** | 数百h |

（比仕事×流量＝軸出力。Ni系は入口温度を上げられるので比仕事がやや高く、高高度の出力保持と長寿命に振れる。実出力は §4。）

---

## 3. ガワ（後端・格付け・増強）

同じコア系統に被せる「外側」で、ここが機種を増やす。

- **後端**：T＝動力タービン＋減速ギヤ＋プロペラ（推進）／S＝動力タービンで軸へ（回転翼・補助）。
- **格付け（運転点）**：全力（高価値・高高度）／中庸（攻撃）／**減格長寿命**（輸送・練習＝−50℃級で寿命×10・数千h、`core-elements` §5）。
- **増強**：水メタノール噴射で離陸・緊急の数分だけ上乗せ（日本native、`aviation-forms` §5）。
- **艤装**：単発／双発／四発の据付、与圧・高高度装備、艦上艤装（灯油で火災抗堪）。

---

## 4. エンジン機種カタログ（コア × ガワ ＝ 製品）

出力は**軸馬力**表示。残留ジェット推力を加えた**ESHP（当量軸馬力）**＝巡航で+5〜11%（主に航続に効く）は `asai-works-turboprop-exhaust.md`。

| 機種（社内） | コア系統 | ガワ（後端/格付け） | 軸出力 | 熱効率 | 寿命 | 当てる機体・用途 |
|---|---|---|---|---|---|---|
| **E4-S-T** | E4-S | プロペラ/減格 | 約630馬力（6.7kg/s central capability≈680hp） | installed≈15% | 250–450h core | 実証・軽偵察・**オートジャイロ「カ号観測機」タービン上位型（艦上・跳躍離陸）推進**（観測主力はピストン型＝`autogyro-ka-go`） |
| **E5-S-T** | E5-S | プロペラ/全力 | **約1,000馬力@800 full / 約950馬力@765 quantity** | installed≈18.7 / 18.4% | 150–300h full / 350–600h quantity | **司令部偵察「Ki-40」初期**・軽攻撃（機体H→A未伝播） |
| **E5-S-N-T** | E5-S-N | プロペラ/高温(Ni) | **common 1,000馬力、central capability≈1,063hp** | installed≈19.3% | 400–700h | 高高度偵察候補。旧1,130hpはhigh-flow derivative gate |
| **E5-S-S〔小端〕** | E5-S小流量派生（代表流量約2.5kg/s・PR5〜5.5・TIT760〜780℃・非Ni。標準流量6kg/sのE5-S軸出力型とは別＝未設定） | 自由動力タービン軸出力（出力軸8,000〜10,000rpm・内蔵減速一段含む）/回生なし | 定格約330馬力・短時間約360 | 約18.5〜20%（SFC約0.42〜0.45kg/kWh） | 100h級反復→200〜300h目標 | **小型ヘリ試験機（1940〜41）**＝工程B採用（`rotorcraft` §3。ヘリ主減速機・主軸・尾部分岐は機体側の別帳簿） |
| **E6-S-T** | E6-S | プロペラ/中庸 | **約1,300馬力 standard**（8.2kg/s S-HF短時間≈1,400hp） | installed≈22.5% | 数百h | **艦上攻撃「天山」**・双発偵察/軽中爆（機体H→A要再計算） |
| **E6-S-N-T** | E6-S-N | プロペラ/高温(Ni) | **約1,500馬力 standard**（8.2kg/s high-flow短時間≈1,600hp conditional） | installed≈23.5% | 長 | **高高度偵察「Ki-40」発展**（機体H→A要再計算） |
| **E6-M-T** | E6-M | プロペラ/全力 | **約2,100馬力 retained flat-rated**（13.2kg/s central capability≈2,250hp） | installed≈22.5% | 数百h | **戦略重爆**（四発・×4）・大型機（吸気/据付H→A要更新） |
| **E6-M-T〔減格〕** | E6-M | プロペラ/減格長寿命＋水メタ | **約1,870馬力 retained flat-rated**（820°C central capability≈2,000hp） | **installed≈21.6%** | **数千h目標** | **大型輸送ワークホース**・練習（非Ni・燃料置換の本丸） |
| **E6-S-S** | E6-S | 軸（ターボシャフト） | **標準能力 約1,350軸馬力**（~1,500shpはhigh-flow/開発天井） | installed≈22.5%級 | 数百h | **レ号系1942+**：初期3.2t機900shp連続/1,000shp短時間は維持。重型は別gate（`rotorcraft-1942-plus-rebaseline`） |

軸出力は **installed比仕事×流量×出力伝達効率** で出す【物理】。gross世代表×流量の直結は禁止。機種名・当て先・格付けは【設定】。同じ E-6 でも、**中庸の E6-S-T が「天山」、高温Niの E6-S-N-T が高高度「Ki-40」、大型減格の E6-M-T〔減格〕が輸送ワークホース**——ガワだけで別機種になる。これが「面で扱う」（`core-elements` §7）の実体。双発偵察・四発重爆は、単発機種（E6-S-T／E6-M-T）を多発で据えたもので、新コアではない。

---

## 5. なぜ有限か——「増えるが無限でない」

コア系統×ガワで機種は増えるが、三つの縛りで有界になる（だから自然に約8機種に収束する）。

1. **プロペラの吸収限界＝規模の頭打ち**：単発プロペラが吸収できる軸出力に上限（おおむね2,000〜3,000馬力）。超えると二重反転や多発に移る（ただし二重反転は戦中不採用＝単回転4〜5翅が本線・棚の迂回札、`turboprop-fighter` §3）。だから**通常機は小型S・中型Mまで**。ただし富嶽級では5m超低回転prop＋専用大型減速機を払うため、36–40kg/s級Lを航空化する例外が成立する。これは一般単発/双発機へLを広げる根拠ではない。
2. **用途マッピング＝材料×格付けが用途でほぼ一意**：高高度偵察＝Ni高温、攻撃＝中庸、輸送・練習＝非Ni減格、と用途が運転点と材料をほぼ決める。全組み合わせ（世代×規模×材料×格付け）の総当たりは作らない——意味のある点だけ打つ。
3. **後端は二つ**：プロペラ（T）か軸（S）。ターボプロップ分野ではこの二択。

結果、増殖は「コア系統（約6）× 意味のあるガワ（各1〜2）」＝**約8機種**に収束する。減っていた多製品性は回復するが、青天井にはならない。

---

## 6. ジェット側への接続（同じ骨格で横展開）

同じ骨格はジェット側にもそのまま当たる——後端を **ノズル（純ジェット）／ファン（バイパス）** に替えるだけ。E6-S-J（純ジェット要撃「霹靂」）、E6-S-JF（後置ファンの量産主力）、上端で後退翼・再燃焼（`propulsion-roadmap`）。舶用・戦車・定置も同じ九軸の点。本カタログはターボプロップ／軸の枝で、`core-hierarchy` §7命名を各分野へ降ろす横展開（`handoff` §6）の最初の実装。

---

## 7. タグ・次の作業

- 【物理】：各機種の軸出力（比仕事×流量）、減格⇄寿命のトレード、プロペラ吸収の上限が規模を縛ること。
- 【設定】：機種名・当て先・格付けの割り付け、Ni系の比仕事の上振れ幅、約8機種への収束。
- 【要確認】：減速ギヤ・動力タービンの実重量（出力重量比の実数）、Ni系の入口温度の実上限、プロペラ吸収限界の具体値、双発/四発の据付。
- （済）E6-S-N-T「Ki-40」発展の機体側詰め＝`asai-works-turboprop-ki40.md`（重量内訳・高度別性能・航続）／ジェット側の同型カタログ＝`asai-works-jet-catalog.md`。次：E6-S-T「天山」（艦上攻撃）を同じ深さで（低振動の射撃・灯油の甲板火災抗堪・`gt-carrier-taiyo` 編成と接続）。

---

## 8. 索引への接続

- 親：`asai-works-core-elements.md`（九軸＝この表の座標）／`asai-works-core-hierarchy.md`（三層・§7命名）。
- 機体側：`asai-works-turboprop-program.md`（開発史・名称・諸元）／`asai-works-turboprop-second.md`（E-6の複数機種）／`asai-works-rotorcraft.md`（軸出力E-6S）。
- 横展開：ジェット（`asai-works-jet-interceptor.md`／`propulsion-roadmap`）・舶用・戦車も同じ九軸の点。
