# v24r2 machine-layer semantic-recall repair — 2026-08-24

Semantic worldline: **v24**. Machine release: **v24r2**.

## Repairs

- Rebuilt chronology as `CANONICAL-CHRONOLOGY-V24R2.tsv/.jsonl` with 366 records (34 added temporal scope/fact records over v24r1).
- Added `semantic_status` / `semantic_note`: current, scope, superseded, mixed. Explicit A_old Kaifu records are retained as provenance but no longer look current to machine queries.
- Repointed seven rotorcraft chronology records from `tank-rework` to `rotorcraft` / `autogyro-ka-go`, changed primary domain from ground-vehicle to aviation, and removed the duplicated `上位型上位型` typo in current canonical prose.
- Corrected the stale `双発以上＝凱風...` feathering examples: Kaifu is single-engine; twin/multi-engine engine-out feathering examples now use the actual multi-engine TP aircraft.
- Added v24 canonical document scopes and explicit dates for embedded computation, water aviation, Seiran/I-400, TP part-load/shutdown, torpedo-air attack, plus vertical-table Ki-40/Tenzan milestones.
- Generated `CANONICAL-MAIN-INDEX-V24R2.tsv` with both historical `incoming_text_refs_pre_machine_index` and newly recomputed `incoming_text_refs_current`.
- Added `ROTOR` and `AIR-REBASE` gates to `CAPABILITY-TRIGGER-MATRIX-V24R2.tsv`.
- Consolidated post-computation residual work in `36-POST-COMPUTATION-OPEN-AUDIT-V24R2-2026-08-24.md` and current `03-OPEN-ISSUES-2026-08-22.md`.

No war-history/OOB outcome is changed by v24r2.
