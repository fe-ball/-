# MACHINE LAYER REFRESH — v36r1

v36r1 carries v35r1 forward and adds the submarine integrated-2-cycle requirement gate.

Machine state:
- chronology records: **531**
- carried from v35r1: **522**
- added v36r1: **9**
- semantic statuses: **current 419 / conditional 50 / superseded 34 / scope 24 / mixed 4**
- canonical `main/` files: **189**

v36 machine records separately encode:
- v36 canonical authority;
- 31号6型 single-acting 2-cycle technology anchor;
- 22号10型 2,350 hp-class / ~4,700 hp pair existing-family anchor;
- 1941 large-2-cycle design/single-cylinder research anchor;
- no current engine-output requirement gap for the ~19 kt second-generation niche;
- integrated 2-cycle GATED-OUT for central 1942–44 series;
- conditional design/land-test development shadow;
- explicit reopen acceptance ledger;
- post-1941 operational/history freeze.

Validator additions:
- v36 exact chronology/status/count checks;
- BOOST-SUB2 must point to the v36 canonical parent and retain the requirement-first GATED-OUT question;
- `00-START-HERE`, `CURRENT-CANONICAL-STATE`, canonical rules and handoff current-recall pointers must all resolve to v36r1;
- integrated 2-cycle central-series promotion and downstream v23/v20 override regressions are checked.
