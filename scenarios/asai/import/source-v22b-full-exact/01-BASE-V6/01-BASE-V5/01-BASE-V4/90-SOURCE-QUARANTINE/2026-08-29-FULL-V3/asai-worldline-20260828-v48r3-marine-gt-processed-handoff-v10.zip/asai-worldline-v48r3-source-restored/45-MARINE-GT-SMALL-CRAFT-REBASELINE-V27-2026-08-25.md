# v27 舶用GT小型高速艇 再基底化

## 判定

**PHYSICS/HISTORICAL CALIBRATION REBASED / DESIGN & PROCUREMENT OPEN。**

### 訂正
- 20t級第一号型は1,800hp/38–38.5ktで成立。旧24kt失敗較正はT-51大型枝との混同。
- 1939の第一世代を50t/5,000hpへ固定する旧値を撤回。
- 1940魚雷艇成功を全舶用GTの唯一の採用儀式とする因果を撤回。
- 1942–43の50t全面GFRP自動採用を撤回。GFRPは不燃ではない。

### current design candidates
- **25–30t E5試験艇**：中央27t、2×1,300hp GT＋350hp diesel、3軸、43–44kt中央。史実ピストン艇を全置換しない。
- **純GT27t枝**：3×900hp、41–43kt候補。短距離/試験向け、量産採用OPEN。
- **50t E6大型候補**：2×2,300hp GT＋600hp diesel、総5,200hp、43–45kt、45cm魚雷4本候補。T-51級大型要求が立つ場合の比較案。
- GFRP一次構造：1942–43は20–30t級実証。50t全面適用はconditional。

親=`main/asai-works-marine-gt-small-craft-rebaseline-1934-43.md`。
