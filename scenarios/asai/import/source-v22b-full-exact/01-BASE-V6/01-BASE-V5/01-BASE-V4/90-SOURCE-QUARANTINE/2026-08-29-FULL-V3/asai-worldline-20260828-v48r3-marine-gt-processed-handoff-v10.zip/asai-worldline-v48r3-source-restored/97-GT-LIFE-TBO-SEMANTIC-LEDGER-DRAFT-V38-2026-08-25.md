# 97 — GT Life / TBO Semantic Ledger / v38 DRAFT

> Status: DRAFT. No v37 canonical number is changed by this document.
> Purpose: separate material life, core rating life, qualification accumulation and product TBO before E4/E5 life re-rating.

## 0. Problem found in v37

The corpus uses 「寿命」 for several different quantities.

Examples:

- `gt-core-generations`: E4 = 百数十〜数百時間, E5 = 数百時間.
- `gt-shogouki`: E4 first commercial engine = 分解整備まで数百〜千時間級.
- `marine-gt-small-craft-design-closure`: E5 marine cumulative qualification = 150 h limited-service gate; this explicitly is **not** fleet MTBO.
- `jet-catalog`: Ni 300 h / non-Ni 105 h are **material baseline life** at comparable operating point, not unit TBO; actual E6 jet OH is 220–320 h or 450–650 h depending material/rating.
- `turboprop-catalog`: “数千h” applies to deep-derated workhorse operation, not E-series full-rating core life.

These can coexist only if the semantics are split.

## 1. Required four-layer vocabulary

### L_mat — material / hot-section baseline life

A comparative life of the limiting material/process system at a defined metal temperature, stress, environment and specimen/component class.

It is **not an engine TBO**.

Examples already in v37: jet-catalog Ni 300 h / non-Ni ~105 h baseline ladder.

### L_core — rated core hot-section engineering life

Expected/qualified operating-hours band of an established core at a specified full/normal rating under laboratory/representative duty, before limiting hot-section removal/major inspection.

This is the best quantity for the E-generation table if a single life column must remain.

### H_qual — cumulative qualification / endurance hours

Total hours accumulated across one or several test engines, components, rigs or marine tests to pass a gate.

`H_qual = 300 h` does **not** imply one engine has TBO 300 h.

### TBO_prod — product overhaul / inspection interval

Operational interval for a particular installation and rating after accounting for:

- derating;
- starts/cycles;
- salt/dust/environment;
- inlet quality;
- gearbox/shaft/accessory limits;
- mission duty;
- maintenance doctrine;
- material line.

This is what an operator sees.

## 2. Also track cycles, not hours only

Hot-section damage is not only clock hours.

Minimum product ledger should contain:

- operating hours;
- hot starts;
- start/stop thermal cycles;
- time above metal-temperature bands;
- overspeed/overtemperature events;
- salt/dust ingestion exposure;
- emergency/sprint minutes;
- inspection findings.

An emergency generator with 500 h accumulated across hundreds of starts is not equivalent to a continuously running compressor set with 500 h.

## 3. Reinterpretation of existing E4/E5 text

### E4 current phrases

`core-generations`: “百数十〜数百時間”

**v38 semantic reading:** preliminary `L_core` full/normal-rating band, not every product TBO.

`gt-shogouki`: “分解整備まで数百〜千時間級”

**v38 semantic reading:** product-side `TBO_prod` target/band for stationary/intermittent/possibly derated commercial package. The upper end should not be used as E4 full-rating hot-section life.

`marine program`: E4 “数百時間; intermittent boost only”

**v38 semantic reading:** product eligibility statement; marine environmental gates can shorten usable interval below dry-land core life.

### E5 current phrases

`core-generations`: “数百時間”

**v38 semantic reading:** `L_core` generic full/normal-rating engineering band.

`turboprop catalog`: E5 full-rating products “数百h”

**v38 semantic reading:** product TBO remains in same order as core life for high-power aviation duty.

`marine qualification`: 150 h cumulative gate

**v38 semantic reading:** `H_qual`, explicitly not `TBO_prod`.

`E5-S-S small turboshaft`: 100 h repeated → 200–300 h target

**v38 semantic reading:** development/qualification maturity of a new small-flow derivative; new geometry/small-machine penalties reset part of inherited E5 maturity.

## 4. Product duty classes

### D0 — laboratory short-rating / record

- performance first;
- very low TBO requirement;
- frequent teardown accepted.

### D1 — sprint / emergency / peaking

- high power acceptable;
- low annual hours;
- starts and thermal cycles may dominate;
- short core life can still be commercially/militarily useful.

E4 first customers deliberately target this class.

### D2 — intermittent operational aviation / marine

- high power for meaningful fractions of missions;
- hundreds of hours become valuable;
- installation/environment begins to dominate.

### D3 — normal aviation workhorse

- reliability, restart, inspection interval and predictable lower tail matter at least as much as peak power.

### D4 — continuous / fleet workhorse / transport / industrial

- long TBO and availability dominate;
- deep derating, regeneration, non-Ni production line and modular maintenance can be preferable to peak rating.

## 5. Preliminary E4 product matrix — interpretation, not new canon

| Product | Duty | Relevant life quantity | Current text | v38 interpretation |
|---|---|---|---|---|
| E4 test core | D0 | L_core / teardown | 100+ to several hundred h | keep as full-rating maturity band |
| standby generator | D1 | TBO_prod + cycles | several hundred–1000 h in `gt-shogouki` | plausible only as intermittent/derated package; do not export to core table |
| drainage/pump/peaking | D1–D2 | TBO_prod | first customer 1931–33 | several-hundred-hour class can be economically useful |
| marine boost | D1 | H_qual + environment TBO | E4 short life | salt/gear/intake can be limiting before dry core life |
| E4 turboprop demonstrator | D0–D2 | flight TBO | experimental | full-rating hot-section and prop reduction/installation both gate |

### E4 consequence

The early metallurgy program in 96 should primarily improve:

- lower-tail confidence;
- rejection of bad heats/processes;
- planned teardown interval;
- derating tables;
- fewer catastrophic sub-100 h surprises after process maturity.

It need not move E4's headline `L_core` dramatically above the existing several-hundred-hour order.

## 6. Preliminary E5 product matrix

| Product | Duty | Relevant life | v38 audit expectation |
|---|---|---|---|
| E5 full-rating generic core | D2 | L_core | several hundred h, but with narrower scatter than v37 prose implies |
| E5 full-rating turboprop | D2–D3 | TBO_prod | several hundred h; gearbox/prop/accessory and flight cycle gates separate |
| E5 Ni high-altitude TP | D2 | L_mat + TBO_prod | material line raises hot-section margin, but high rating spends much of it |
| E5 derated workhorse TP | D3–D4 | TBO_prod | four-figure h becomes plausible only after explicit derating/duty analysis |
| E5 small turboshaft derivative | D2 | H_qual + TBO_prod | 200–300 h target remains plausible because small-flow/new derivative resets maturity |
| E5 marine sprint | D1 | H_qual + TBO_prod | 150 h qualification gate remains; fleet MTBO is not inferred |
| E5 stationary/industrial | D3–D4 | TBO_prod | can be much longer than full-rating aviation if derated/steady; needs separate package number |

## 7. Proposed v38 life coordinates

Instead of one unqualified “寿命” number, every GT product should be describable by:

`{material line, rating temperature, L_core, H_qual, TBO_prod, cycles, environment}`

For E-generation summary tables, use:

`L_core @ representative normal/full rating`.

For product catalogs, use:

`TBO_prod @ product rating/duty`, and cite inherited `L_core` only as upstream evidence.

For development docs, use:

`H_qual cumulative` plus minimum single-engine run if known.

## 8. Preliminary E4/E5 L_core hypothesis after the early-material-program audit

Still DRAFT; not yet accepted.

### E4

- early development failures: <100 h still allowed;
- established-process lower bound: ~150–250 h;
- mature representative `L_core`: **~250–450 h**;
- no generic 1000 h full-rating claim.

### E5

- new-geometry/process development lower tail: ~100–200 h still possible;
- established-process lower bound: ~250–400 h;
- mature representative `L_core`: **~400–700 h**;
- four-figure product TBO requires derating/steady duty or superior material line, not generation label alone.

This is a **clarification/upward tightening**, not a ×2 blanket bonus.

## 9. Important interaction with 91 O/G scores

The early metallurgy clock should raise mainly **Gq and Gd**, not Gp.

For E4/E5:

- O was already high enough to choose good architecture;
- Gp is dominated by PR/TIT/component efficiency;
- metallurgy head-start removes bad-tail engines and late redesigns;
- therefore benefit appears as a higher lower-bound life, more predictable TBO and higher yield.

This is exactly the type of benefit that a simple headline performance table misses.

## 10. Canonical repair candidates later

If accepted after subsystem review:

1. `asai-works-gt-core-generations.md` — rename life column to representative core life / qualification meaning.
2. `asai-works-gt-shogouki.md` — label “数百〜千時間” explicitly as stationary product TBO target under intermittent/derated duty, or revise.
3. `asai-works-turboprop-catalog.md` — distinguish core life from product TBO and retain deep-derated four-figure line as product-specific.
4. `asai-works-marine-gt-small-craft-design-closure-1938-43.md` — keep H_qual language; already unusually clean.
5. `asai-works-jet-catalog.md` — model to copy: it already distinguishes material baseline from operational OH.

## 11. Decision

**P0 finding:** current E4/E5 life values are not obviously too low; their semantics are under-resolved. The v38 early-material-program most strongly justifies making the several-hundred-hour band **more predictable and better bounded**, while allowing specific derated/intermittent products to achieve much longer TBO.

Before numerical canonical changes, decompose hot-section metal temperatures/stresses and duty by product.

