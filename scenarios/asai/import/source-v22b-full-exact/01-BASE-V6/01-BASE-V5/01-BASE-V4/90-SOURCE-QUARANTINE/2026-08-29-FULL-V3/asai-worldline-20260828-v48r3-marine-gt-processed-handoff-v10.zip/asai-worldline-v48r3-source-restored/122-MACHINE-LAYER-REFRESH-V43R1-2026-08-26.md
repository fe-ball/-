# 122 — Machine-layer refresh v43r1 — 2026-08-26

v43r1 refreshes the machine layer after the E5/E6 compressor-operability rebaseline.

- chronology: **634 records** (`CANONICAL-CHRONOLOGY-V43R1.tsv` / `.jsonl`)
- main canonical files: **198**
- status partition: **current 482 / conditional 64 / superseded 48 / scope 31 / mixed 9**
- new v43 chronology delta: CHR-0621..0634
- old compressor audit gates CHR-0606/0620 are superseded by v43 closure.
- E4-R high-flow 7.16 kg/s derivative is compressor-side released as E4-S-HF; E5 old 1,130 hp is compressor-side feasible as E5-S-HF.
- E5 marine 1,300 hp remains conditional because ~9.29 kg/s exceeds the S-HF family.
- E6-M old 10 kg/s exact full-PR7 TP coordinate is superseded; M-family central is 13.2 kg/s / trim 12.5–14.0.
- E6 shaft/thrust product ratings remain conditional pending installed-cycle/product-power rebaseline; E6 downstream H→A remains gated.

Current recall layer:
`CURRENT-CANONICAL-STATE.md` → `CANONICAL-MAIN-INDEX-V43R1.tsv` → `CANONICAL-CHRONOLOGY-V43R1.tsv` → `CROSS-DOMAIN-PREFLIGHT-V43R1.md` → `CAPABILITY-TRIGGER-MATRIX-V43R1.tsv`.
