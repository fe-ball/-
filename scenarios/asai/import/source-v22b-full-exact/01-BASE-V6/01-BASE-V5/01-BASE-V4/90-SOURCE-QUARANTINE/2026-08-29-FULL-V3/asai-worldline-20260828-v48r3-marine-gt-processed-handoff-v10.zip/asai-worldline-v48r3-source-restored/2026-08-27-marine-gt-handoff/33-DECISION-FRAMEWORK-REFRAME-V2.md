# Marine GT decision-framework reframe V2 — 2026-08-27

Status: methodological correction and adoption-layer reframe on top of the processed V1 handoff. Numerical audits, historical crosswalk rows, and source checks from V1 remain usable unless explicitly superseded below.

## Why this reframe exists

The V1 processing pass correctly improved the technical arithmetic and historical calendar, but it compressed several different questions into a single adoption verdict. In particular, historical refit/build windows were sometimes used as a negative adoption gate: if a historical window was short or the historical ship retained steam, the worldline GT option was closed too quickly.

That is too restrictive for this project. Historical chronology is a constraint and opportunity structure, not a command to reproduce historical machinery choices. An earlier and more mature marine-GT program can itself change design freezes, conversion planning, yard preparation, machinery-space allocation, fuel policy, and standardization choices.

The correction is therefore not to discard the V1 work. It is to restore the missing decision layers.

## Four-layer decision rule

For each marine-GT question, keep these fields separate:

1. **TECHNICAL** — can the engine/core/reducer/installation exist at the required rating and date?
2. **DEMONSTRATED** — what has actually been proven on a land rig, old hull, qualification craft, or comparable machinery train?
3. **OPPORTUNITY** — is there a real Navy requirement, design freeze, conversion window, obsolete hull, yard slot, or procurement decision where the technology could be selected?
4. **SELECTED** — after comparing alternatives, what does this worldline Navy actually choose?

A negative result in layer 3 does not automatically prove layer 4. Conversely, a positive technical result does not automatically produce adoption.

## Status discipline

Use the following distinctions in V2:

- **CLOSED-TECH**: technical/numeric authority is stable enough for downstream use.
- **CLOSED-HIST**: the historical date/window/requirement is sufficiently fixed.
- **DEMONSTRATED**: the relevant installation behavior is already proven at the required or comparable scale.
- **PARTLY-DEMONSTRATED**: some key sea/rig behavior is proven, but scale or architecture gaps remain.
- **PHYSICALLY-POSSIBLE**: engineering is plausible at the date, subject to stated installation constraints.
- **PROGRAMMATICALLY-AVAILABLE**: a real procurement/design opportunity exists and the industrial preparation can plausibly meet it.
- **LEADING-CANDIDATE**: currently the strongest worldline selection, but not yet hard canon.
- **SELECTED-WORKING**: chosen for the working worldline because the competing alternatives have been compared; still below semantic rebaseline.
- **NOT-SELECTED-WORKING**: rejected for a stated worldline reason, not merely because history chose differently.
- **OPEN**: keep the design space live.
- **FROZEN**: do not use post-boundary evidence to backfill pre-1941 state.

`OPEN` and `CONDITIONAL` are deliberate outputs, not processing failures.

## Historical chronology rule

Historical dates may close facts such as:

- when a hull was available;
- when a refit or conversion occurred historically;
- when a requirement or construction program appeared;
- when a yard or class design was frozen.

They may not, by themselves, close a worldline machinery choice. A worldline choice can diverge if upstream Asai/Navy development has plausibly altered preparation before the historical event.

For example:

- `Taiyo historical conversion May–September 1941` is a strong constraint on a **short-notice** co-main conversion.
- It does not prove that a **pre-planned** GT conversion architecture could not have been selected earlier and prepared before May 1941.
- `Unryu historical urgent 1941 design` makes standardization a strong competitor.
- It does not prove that the worldline's 1941 standard propulsion architecture must still be historical steam if large marine GT had already accumulated credible service experience.

## Treatment of V1 processed decisions

The following V1 results remain strong and should be retained:

- E4/E5/E6 installed-cycle and output-plane arithmetic;
- retirement of undocumented large-core scale-gain multipliers;
- explicit reducer/propeller-shaft accounting;
- historical ship/refit/requirement crosswalk;
- Taiyo power/speed recalculation as an engineering comparison;
- fuel-demand sensitivity arithmetic;
- post-1941-12-08 evidence boundary;
- distinction between a 1941 heavy-MTB requirement and later prototype success.

The following V1 decisions are downgraded from hard adoption closure to layered working judgments:

- Momi / 廃駆二号 as the unique central old-hull platform;
- no dedicated prewar new-build propulsion test ship;
- No.600 automatically selecting the E6-M hybrid rather than treating it as the leading propulsion proposal;
- carrier `steam central / GT not adopted` closures derived mainly from historical conversion/build timing;
- marine turbine distillate allocation as a settled Navy-wide policy before fleet scale is chosen.

## Closure target at 1941-12-08

The handoff does not need every platform row to be `SELECTED`. It should close the 1941-12-08 state in five categories:

1. technology that exists;
2. test infrastructure and demonstrators that exist;
3. prototype/ship projects physically present or ordered;
4. propulsion architectures already selected for specific programs;
5. design studies still open for later selection.

The goal is a coherent worldline state, not maximal closure.
