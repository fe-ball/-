# GT魚雷艇・高速艇と予備動力——v29 design closure反映

> 魚雷艇のcurrent親=`asai-works-marine-gt-small-craft-design-closure-1938-43.md`。v27親は史実較正/provenance。v29では旧2GT+350hp独立三軸中央を撤回し、E5 one-GT marine-qualification艇を低リスク中央、2GTはCPP/feathering等を要するbranchへ降格。

## 1. 史実入口

- 日本の20t級第一号型は約1,800hpで38–38.5kt級。小型高速艇そのものは成立している。
- 30kt未達/重量・振動で苦しむ失敗較正は後の86–90t級T-51側。
- よって浅井GTは「40ktを初めて可能にする」より、軽量高出力で**大型化・長脚・重武装時の重量膨張を抑える**ところに効く。

## 2. 二つのGT候補

| 候補 | 時期 | 満載 | 推進 | 全力 | 速度中央 | 位置 |
|---|---|---:|---|---:|---:|---|
| E5 marine-qualification中央 | 1938–41 | 25–27t | 既存piston 2軸＋中央E5 GT約1,300hp boost | 約2,700–3,100hp級 | **42–46kt trial** | marine qualification中央。operating speedとは分離 |
| E5 2GT high-power branch | 1938–41 | 約27t | 2×1,300hp GT＋500–700hp cruise engine | 約3,100–3,300hp nominal | **conditional** | CPP/feathering等の停止GT prop drag対策必須 |
| E6大型GT魚雷艇 shadow | 1941+要求時 | 50–55t（中央52） | 2×2,300hp GT＋600hp級 cruise engine branch | 約5,200hp | **42–44kt full-load trial** | 4×45cm/長脚。40kt service保証せず、採用conditional |

## 3. 純GT

3×約900hp/27t級は短距離sprint/試験枝としてのみ残す。v29で**E5/E6通常魚雷艇の量産中央には採用しない**と閉鎖。CPP/part-loadが後に大幅改善した場合だけ再OPEN。

## 4. GFRP

v30では1942–43中央を**実寸bottom/forebody大区画＋8–12m級低～中速全GFRP実証艇**へ下げる。20–30t full high-speed GFRPは1943–44+ conditional、50–55t E6全面GFRP高速艇は1946+ conditional。GFRPは不燃ではなく、火災安全の主利得は灯油/軽油燃料＋metal firebreak。

## 5. 予備動力

予備動力GTは魚雷艇だけに依存しない。定置・舶用ベンチ、小型艇marine qualification、個別艦種の入渠/艦政要求を合わせて評価する。魚雷艇の成功を全艦種の単一gateにしない。
