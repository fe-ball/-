# Migration Note — Zero Operational Rebaseline v14

- Parent: v13 `asai-worldline-20260823-zero-a6m3-rebaseline-v13`.
- New canonical file: `main/asai-works-zero-operational-1941-42.md`.
- Resolved: 1941-12-08 Zero-only OOB band, 1942 H1 Mitsubishi/Nakajima production split, first combat-lesson package.
- Canonical naming: historical designations on the front; `A1-1` is internal audit code only.
- Important freeze: old combat-history references to `改良零戦548–552` and Kaifu carrier mix remain A_old until unit-by-unit 1942 allocations are regenerated.
- No full self-sealing tanks are granted to all Zeros in 1942 H1. Radio reliability/retention is the earliest substantial A1 operational gain; low-mass fire protection and local pilot armor follow.
