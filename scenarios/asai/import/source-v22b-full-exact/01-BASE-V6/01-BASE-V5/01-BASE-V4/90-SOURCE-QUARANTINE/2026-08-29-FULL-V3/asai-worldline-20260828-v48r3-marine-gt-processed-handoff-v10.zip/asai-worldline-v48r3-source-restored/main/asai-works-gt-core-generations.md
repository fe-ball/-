# ガスタービン・コア世代表 — v48互換wrapper

> **v48 authority redirect.** このファイルは旧参照を壊さないための互換入口だけを残す。E1–E9、規模帯、後端方式、installed/product authorityの現行数値親は `main/asai-works-engine-capability-core-e1-e9.md`。
>
> v46以前の旧世代表本文は `archive/core-pre-v48/asai-works-gt-core-generations-v46.md` に保存した。旧本文のjet/TP機体への展開や旧代表推力はcurrent採用史へ接続しない。

## current rule

- E-generation = 技術前線。単一エンジン型式ではない。
- 規模帯をまたぐ流量拡大は新core設計。
- 商品 = core + backend + installation + rating。
- v39–v46 installed監査は累積して有効。
- 航空採用は `main/asai-works-aviation-reconstruction-framework-v48.md` の三層分離とmission comparisonを通す。
