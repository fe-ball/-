# Marine GT upstream ledger reframe V3 — 2026-08-28

Status: **processing overlay on v48 / machine v48r3; not a semantic rebaseline.** V2 adoption-layer separation remains in force. V3 adds the missing upstream distinction between future-knowledge-led research, physical demonstrators, customer productization, and naval design/procurement timing.

## 1. What V3 changes

V3 does not weaken the capability-convergence premise. The protagonist/organization may recognize the correct future problem early, start long-clock tests early, choose informative rigs, and prune dead branches. The constraint is that research capability is not the same thing as a customer product.

For marine-GT processing, canonical `R/P/X/N` is temporarily expanded as an audit view:

- `K`: future need/problem is recognized;
- `R0`: paper design, trade study, test planning;
- `R1`: component/sector/system rig;
- `R2`: full-core or integrated demonstrator / sea demonstrator;
- `P/X/N`: retain their canonical meanings from the product-availability ledger.

This is an audit decomposition of `R`, not a replacement schema for the main canon.

## 2. E5-M correction

Current v41/v43 authority rejects legacy `E5-S marine 1,300 hp` as an S-core rating. Standard E5-S is 7.6 kg/s / 1,000 hp headline; E5-S-HF around 8.08 kg/s can support the old ~1,130 hp high-flow level. A 1,300 hp E5 requires roughly 9.29 kg/s and therefore a different high-flow/M-scale core.

V3 therefore does **not** create an E5-M product merely to preserve the old marine number. The preferred audit path is:

`E5-S product` → `marine environmental/powertrain qualification at ~1,000–1,130 hp` + `M-scale R0/R1 research` → `E6-M 13.2 kg/s product`.

A 9–12 kg/s E5 full-core demonstrator remains plausible if it has sufficient information value for E6-M or another named program. It is not yet selected as a historical fact and does not imply a production E5-M family.

## 3. Large-core correction

V1 `E5-large-A/B` and `E6-large-A/B/C` are useful arithmetic scale classes, but they are not canonical product identities. Their previously derived earliest design/rig/marine dates must not be read as product availability dates.

Future knowledge and computation justify paper scaling and selected component rigs before a customer exists. A physical large full-core and its production tooling require a named purpose: unit power, duty, quantity, decision date, reducer/shaft architecture, and expected follow-on value.

The first >13.2 kg/s core should therefore be regenerated from the demand ledger instead of inheriting 17.1/29.7/52.8/82.5 kg/s labels by default.

## 4. Naval computation / ship-design baseline

Existing submarine and engine authorities establish the correct treatment of computation gains:

- planned engineering work saved by computation is often reinvested in better design, especially in peacetime;
- unplanned rework, failed trial iterations, drawing changes, vibration fixes, and post-trial modification are cleaner calendar/cost savings;
- as mobilization pressure rises, a larger part of the computation dividend can be converted into schedule protection and standardization;
- no single percentage may be applied to design time, build time, cost, and performance simultaneously.

For conversions, the relevant date is not automatically dock-entry. If a technology is a credible program candidate, the Navy may have completed studies, reserved interfaces, or ordered long-lead machinery earlier. Conversely, future knowledge does not justify hindsight reservations for every speculative technology.

## 5. Current processing consequence

Downstream V2 adoption rows remain OPEN/working unless otherwise stated. V3 mainly changes what is allowed upstream:

- legacy E5-S 1,300 hp marine calculations are not current engine authority;
- E5 M-scale research may exist without an E5-M product;
- large-core scale classes stay analysis-only until demand regenerates exact core choices;
- 1930–41 ship-design opportunities must be evaluated with the naval computation/procurement baseline, including pre-planned conversion branches;
- reducer capability is to be treated as a torque/power ladder, not a single 1940–42 binary gate.

The next closure work is listed in `43-MARINE-GT-REWORK-QUEUE-V3.tsv`.
