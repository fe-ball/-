# Marine large-scale audit notes V1 — 2026-08-27

Status: working computation on top of v48r3 source-restored. This closes arithmetic/accounting ambiguities only; it does not promote the E5/E6 large analysis classes to canonical products.

## 1. Output-plane correction

The previous `06-ENGINE-SCALE-WORKING.csv` mixed two output planes:

- gas-generator / free-power-turbine output available at the engine output coupling;
- propeller-shaft power after the ship reduction path.

For this pass, `12-MARINE-LARGE-SCALE-AUDIT-V1.py` reproduces the accepted v40/v44 installed-cycle accounting and then applies an explicit **0.975 marine reduction efficiency**. Both values are retained in `13-MARINE-LARGE-SCALE-AUDIT-V1.tsv`.

This is deliberately not hidden in a scale factor. A later ship design may use a different reducer efficiency, but it must say so explicitly.

## 2. E6 large classes

The old E6 large-A/B/C figures are close to **engine-output-coupling power**, not a clean propeller-shaft figure. Recomputing without an undocumented large-core efficiency gain gives, for E6-large-A/甲:

| TIT | v44-derived bleed | engine output | propeller shaft @0.975 |
|---:|---:|---:|---:|
| 780 C | 3.38% | 4,162 hp | 4,058 hp |
| 800 C | 3.74% | 4,396 hp | 4,286 hp |
| 820 C | 4.10% | 4,628 hp | 4,513 hp |
| 870 C | 5.00% | 5,199 hp | 5,069 hp |

For B/乙 and C/丙 the same specific-work model is applied at 52.8 and 82.5 kg/s. No geometric `scale gain` is added. Therefore the old matrix item **`E6 甲/乙/丙 scale gains` can be retired as a required assumption**; the classes themselves remain OPEN because hardware, dates, rotor stress, casings, bearings, gear train and life are not closed.

## 3. E5 700 C long-life warning

The previous E5-large working sheet gave approximately 1,875 hp (A) and 3,350 hp (B) at ~700 C. Under the v40 installed model those values sit very close to a **zero-bleed thermodynamic ceiling**:

- A, 700 C, zero bleed: 1,869 hp engine / 1,822 hp propeller shaft.
- B, 700 C, zero bleed: 3,322 hp engine / 3,239 hp propeller shaft.

A modest 2.5% total cooling/seal bleed sensitivity instead gives:

- A: 1,750 hp engine / **1,706 hp propeller shaft**.
- B: 3,111 hp engine / **3,034 hp propeller shaft**.

Therefore the old `~700 C long-life = 1,850–1,900 / 3,300–3,400 hp` rows are **not robust central ratings**. They should remain sensitivity ceilings until a low-TIT hot-section/seal bleed schedule and life target are explicitly derived.

The stronger E5 anchors are still the accepted v40 accounting at 765 C / 4% bleed and 800 C / 6% non-Ni bleed. At 0.975 marine reducer efficiency they give:

- E5-large-A: 2,089 hp @765 C; 2,226 hp @800 C at the propeller shaft.
- E5-large-B: 3,715 hp @765 C; 3,957 hp @800 C at the propeller shaft.

## 4. Consequence for ship calculations

Any carrier/destroyer/cruiser worksheet should select one output plane and remain on it. The revised Taiyo worksheet uses **propeller-shaft hp** because the historical steam baseline is stated in shp. Fuel remains calculated from the engine thermodynamic fuel flow; equivalently, the propeller-shaft effective BSFC is engine BSFC divided by reducer efficiency.

The correction is small in speed terms because the cube law damps a ~2.5% power change, but it prevents a hidden accounting mismatch from propagating into later comparisons.
