# 104 — E4/E5 Hot-section Component / Life Rebaseline — v39

> Status: ACCEPTED v39 semantic rebaseline. Base checkpoint = v38r1.
> Scope: E4 (1931–33) and E5 (1934–37) hot-section / life only.
> This document does **not** yet propagate changes into aircraft speed, ship performance, procurement, OOB, combat history, or adoption decisions.
> Method authority: `main/asai-works-capability-convergence-method.md`, `main/asai-works-hot-section-materials-long-clock-1919-38.md`, `main/asai-works-core-elements.md`.

## 0. Question

v38 established that Asai starts long-duration high-temperature materials testing in 1921–24 and develops a design/testing organization that approaches a future design office unevenly by problem class. The remaining question is no longer “is 710/800°C too early for the calendar?” It is:

**At E4/E5, which actual component first spends the available life budget once gas temperature, metal temperature, centrifugal/thermal stress, cooling manufacture, starts/cycles and process scatter are separated?**

The engine life is closed by the weakest relevant series element; turbine material alone is not engine TBO.

---

# 1. Quantities and vocabulary

Use the v38 life vocabulary without exception:

- `L_mat` — material / hot-section baseline at a defined metal temperature, stress, environment and process.
- `L_core` — representative rated core hot-section engineering life.
- `H_qual` — cumulative qualification/endurance hours across rigs/engines/components.
- `TBO_prod` — product-specific overhaul/inspection interval at stated rating and duty.

Also track starts/thermal cycles independently from hours.

# 1.1 Two clocks: generic test infrastructure vs exact material/process family

The 1921–24 long-clock must not be inherited as if every later alloy had already been under test since 1921. v39 therefore separates two clocks.

- **generic clock** — constant-load furnace practice, temperature/stress bookkeeping, oxidation/thermal-cycle observation, fracture/NDT discipline, data reduction and station capacity. This begins in 1921–24 and is inherited by every later hot-section program.
- **family/process clock** — the exact alloy family, heat treatment, forging/casting/joining route, section size and cooling geometry actually used in the part. This starts when that family/process enters the program and partially resets whenever a new alloy or a new hollow-blade process is introduced.

For the E4/E5 audit use the following conservative maturity interpretation, not a claim of exact historical lot dates:

| item | inherited generic maturity | component/family-specific clock available by rating date | audit consequence |
|---|---|---|---|
| E4 heat-resistant austenitic / Cr-rich steel family | strong | roughly **4–8+ y** through special-steel work plus 1923–25 turbocharger/service feedback | E4 material allowables can be meaningfully statistical; hollow joining still resets part of Gq |
| E4 hollow fabricated blade process | generic metallurgy only partly transfers | roughly **2–5 y** of direct geometry/joining maturation by established E4 | early weld/braze/passage failures remain a lower-tail gate |
| E5 non-Ni quantity line | strong inheritance from E4 material/process family | roughly **5–10+ y** family/process continuity | good yield and predictable derating are its main advantage |
| E5 Ni high-end alloy/process | generic test method transfers, exact alloy does not | roughly **2–5 y** exact-alloy/heat/process clock unless an earlier dedicated program is separately evidenced | higher material capability but initially worse yield/scatter; no 1921-to-1936 fictitious alloy clock |

Thus long-clock head start mainly gives Asai a mature **measurement and discrimination system**. It does not give a newly selected E5 alloy fifteen years of specific rupture data for free.

For thermal analysis use cooling effectiveness

`epsilon_c = (T_gas - T_metal) / (T_gas - T_coolant)`.

This is an audit index, not a claim that 1930s engineers use modern CFD. Asai can know the useful nondimensional form; the local organization still has to calibrate it by burner/rig/component testing.

---

# 2. Thermodynamic boundary conditions

Assume sea-level reference 288 K, gamma=1.4 and compressor efficiency approximately equal to the E-generation component-efficiency coordinate for this first-order audit.

| coordinate | E4 | E5 |
|---|---:|---:|
| PR | 4.5 | 6.0 |
| compressor efficiency audit input | 0.82 | 0.83 |
| TIT | 710°C | 800°C |
| calculated compressor-discharge temperature | **~204°C** | **~247°C** |

The cooling source is therefore already warm. TIT cannot be read as blade metal temperature.

### 2.1 Conservative early cooling envelopes

These are engineering envelopes, not yet frozen manufacturing specifications.

| item | E4 epsilon_c | E5 epsilon_c | reason |
|---|---:|---:|---|
| rotor airfoil | 0.27–0.37 | 0.32–0.43 | simple hollow passage first; later narrower passages/inserts and better flow distribution |
| first vane/nozzle | 0.30–0.42 | 0.36–0.48 | no centrifugal stress, more freedom for wall thickness and cooling routing |

NACA's 1947 cooling studies are only a physics anchor: direct hollow-blade cooling could produce very large differences between gas and permissible metal temperature, and small rim-temperature reductions materially increased life. The Asai envelope above is intentionally less optimistic than the ideal NACA analytical cases because passage geometry, heat-transfer coefficients and process repeatability are still primitive.

### 2.2 Derived metal-temperature bands

Using the above cooling envelope:

| part | nominal metal T, E4 | local/hot-spot design envelope, E4 | nominal metal T, E5 | local/hot-spot design envelope, E5 |
|---|---:|---:|---:|---:|
| rotor blade airfoil | ~523–573°C | **~543–613°C** | ~562–623°C | **~587–668°C** |
| first vane/nozzle | ~497–558°C | **~527–608°C** | ~535–601°C | **~565–651°C** |

Interpretation:

1. E4 does **not** need a 1931-vintage Nimonic-80 equivalent merely to survive TIT 710°C. With cooling, the rotating metal can live mainly in the ~550–600°C class.
2. E5 pushes the rotating hot spots into roughly the ~600–650°C class. Here the value of a Ni-rich / precipitation-strengthened high-end line rises sharply.
3. The non-Ni line can still exist, but at the E5 800°C coordinate it either spends substantially more cooling/manufacturing effort or accepts shorter `L_core`; moderate derating is the natural quantity route.

---

# 3. Rotor blade and root

## 3.1 Process route

E4 should not be forced to depend on mature hollow investment casting.

**E4 central route:** simple fabricated hollow airfoil (pressed/folded sheet or simple shell construction) + controlled seam weld/braze + replaceable inserted root; cast/forged solid root pieces where useful. Future knowledge tells Asai to prefer a simple manufacturable cooling passage and to proof-flow every blade rather than pursue an elegant but low-yield internal geometry too early.

**E5:** two routes are allowed.

- non-Ni quantity line: improved fabricated hollow blade, aluminized/diffusion-protected where useful;
- Ni high-end line: forged/precision-cast high-temperature alloy with a more controlled internal passage, accepting lower initial yield.

The historical Jumo 004 later demonstrated that folded/welded hollow non-Ni blades cooled with compressor bleed were manufacturable; this is a feasibility anchor, not an Asai calendar ceiling.

## 3.2 Attachment

`tensei-engineer-kufu-shu.md` already lists the fir-tree root as a future-known useful device. Use it where broaching/tooling maturity permits; otherwise a simpler dovetail/inserted root is acceptable in the earliest engines.

The key life advantage is not magic strength: an inserted root allows differential thermal expansion, controls contact stress and lets blades be individually replaced and statistically inspected.

## 3.3 Centrifugal-stress envelope

Exact E4/E5 turbine diameter and rpm are not yet canonical. Use a sensitivity envelope rather than invent a single rotor.

- E4 turbine tip-speed planning band: ~280–320 m/s.
- E5: ~310–350 m/s.
- hub/tip ratio audit band: 0.68–0.78.
- average airfoil area/root-area taper factor: 0.55–0.70.

For a steel/Ni-alloy blade, the uniform-radial first-order centrifugal root stress is then approximately:

- E4 nominal centrifugal: **~70–150 MPa**;
- E5 nominal centrifugal: **~80–180 MPa**.

Gas bending, attachment stress concentration, vibration and local thermal stress raise the relevant local design band approximately to:

- E4: **~120–230 MPa**;
- E5: **~140–280 MPa**.

These are audit bands, not certified allowables. The purpose is to show why a 600°C blade cannot be assessed from short-time tensile strength alone and why the 1921–24 stress-rupture clock matters.

## 3.4 Blade-life audit result

### E4 established process

At ~550–600°C airfoil metal and the above stress class, with 7–12 years of generic long-duration-test infrastructure but a partial reset for the actual hollow-blade joining/process:

- development failures below 100–150 h remain possible;
- established blade-system lower band: **~250–350 h**;
- mature blade-system typical band: **~350–600 h**.

### E5 Ni high-end, 800°C TIT

At ~600–650°C hot-spot metal, using a more creep-resistant Ni-rich line but with a new-alloy/process reset:

- development lower tail: ~150–300 h;
- established blade-system lower band: **~350–500 h**;
- mature blade-system typical band: **~500–900 h**.

### E5 non-Ni, 800°C TIT

The same gas coordinate spends much more material life:

- full-rating blade-system typical: **~150–300 h** unless exceptional cooling/yield is demonstrated;
- this is a performance/sprint line, not the natural quantity-workhorse rating.

### E5 non-Ni, moderate derating

At roughly 760–770°C TIT (30–40°C below the E5 headline coordinate), metal temperature drops enough that the existing worldline temperature-life rule and the long-clock database make **~350–650 h core-relevant blade life** plausible after process maturation. Exact multiplier remains product/material-specific and is not derived by a universal “15°C = ×2” law.

---

# 4. First-stage vane / nozzle

The vane receives the hottest gas but has no centrifugal blade load. Its main problems are:

- oxidation / scale;
- thermal gradient and thermal fatigue;
- local leading-edge hot spots;
- cooling passage blockage or weld/casting defect;
- distortion that changes turbine throat area.

Because it can be thicker, more heavily cooled and made as a replaceable segment, it should normally **not** be allowed to determine the entire core life after E4 maturation.

Audit bands:

| | E4 | E5 |
|---|---:|---:|
| mature vane segment life at representative rating | ~400–800 h | ~500–900 h |
| scheduled inspection/replacement can be earlier | 200–400 h | 250–500 h |

A vane change is maintenance, not necessarily core retirement.

---

# 5. Blade root / turbine disk / rotor thermal field

This is a separate clock from airfoil alloy life.

The disk should be deliberately kept much colder than TIT by:

- shielding from direct gas radiation;
- routing compressor/cooling air around root/rim where useful;
- limiting conductive heat from airfoil/root;
- controlling start/stop thermal gradients;
- using a replaceable blade attachment rather than integrating hot airfoil material into the wheel.

### v39 design target bands

| quantity | E4 target | E5 target |
|---|---:|---:|
| disk rim bulk metal | **~300–380°C** | **~330–410°C** |
| local attachment/root hot region | ~380–470°C | ~410–500°C |

These are target envelopes to be verified by thermocouple/paint/soak tests; they are not claimed measured values.

For a profiled rotating disk at the above tip-speed class, centrifugal stresses are naturally several hundred MPa. Thermal gradients can add or subtract materially at the rim and attachment. NACA's later disk work confirms that severe thermal gradients can materially reduce disk operating safety, while changing temperature distribution can shift the dangerous stress region.

### v39 audit life

If the target rim bands are met:

- E4 disk/root should normally support **~600–1200 h** before major replacement, with much earlier inspection of attachment fretting/cracks;
- E5: **~800–1500 h** is an engineering target band.

Therefore a correctly cooled disk is **not expected to be the normal E4/E5 first life limiter**. If rim temperature drifts above the target or the attachment has fretting/resonance, this conclusion collapses and disk/root can become the cliff gate.

---

# 6. Combustor liner

Combustor life is not controlled by average TIT. Local flame attachment, dilution pattern and thermal gradient dominate.

Later NACA I-40 work measured very large circumferential/local liner-temperature gradients and identified local thermal gradients as a principal cause of short liner life; later metallographic work found louver-hole cracking associated with thermal/mechanical fatigue, punching defects and oxidation.

This is exactly the kind of failure Asai can anticipate organizationally without pretending to know each local hot spot before testing.

### E4/E5 design response

- can combustors retained because individual cans/liners are replaceable;
- louver/dilution-hole geometry is systematically varied on burner rigs;
- hole edges are deburred/finished and punching-induced fissures are treated as a process defect;
- liner temperature is mapped at multiple circumferential/axial stations;
- liner is a scheduled consumable module rather than allowed to define “engine death”.

Audit life bands:

| | E4 | E5 |
|---|---:|---:|
| liner inspection/replacement interval | **~150–300 h** | **~200–400 h** |
| well-developed liner segment potential | ~250–450 h | ~300–600 h |

A liner replacement interval shorter than `L_core` is acceptable if the can/module is accessible. Therefore liner durability is a maintenance-rate gate, not necessarily the E-generation headline life.

---

# 7. Cooling-passage manufacture and process scatter

This is the main reason future knowledge does not turn E4/E5 into a modern engine.

Every cooled blade must carry a process ledger for:

- wall thickness;
- passage minimum area;
- flow at proof pressure;
- weld/braze/cast-core integrity;
- blockage/oxide/debris;
- mass and balance;
- NDT result;
- heat/material lot;
- engine position and removal condition.

### E4

The hollow-process clock is younger than the generic metallurgy clock. Retain only roughly 35–60% of generic Gq maturity for a new hollow/joining route. After maturation:

- process-induced early-failure floor: still ~150–250 h in bad/new batches;
- screened mature population supports the blade-system ~350–600 h band.

### E5

The fabricated non-Ni route inherits most E4 process learning. A new Ni casting/joining route partially resets it. Hence high-end E5 may have better material but initially **worse yield/scatter** than the quantity non-Ni line. This is the correct meaning of “Ni line = performance line, non-Ni = quantity line”.

---

# 8. Bearing / seal / oil system

Bearings are outside the flame path but can still close `L_core` if heat soak, oil coking, cage failure, seal leakage or rotor dynamics are neglected.

Later NACA high-speed-bearing work shows that turbojet bearing temperature depends strongly on oil flow/viscosity and that engine inner-race temperature can exceed outer-race temperature; the bearing problem is therefore a heat-transfer/lubrication system, not merely a steel-hardness question.

For E4/E5, Asai's useful future knowledge is to insist early on:

- directed oil-jet lubrication rather than mist-only practice at critical bearings;
- scavenging that prevents oil pooling/coking;
- heat shields and cooling-air isolation from the turbine cavity;
- soak-back testing after shutdown;
- balance/critical-speed ledger;
- filter/cleanliness and magnetic-debris inspection where practical.

Without locking a modern synthetic-oil assumption, use the following audit bands:

| | E4 | E5 |
|---|---:|---:|
| stationary/controlled-environment bearing/seal system | ~400–800 h | ~500–900 h |
| aviation/high-cycle installation before mature refinement | ~250–500 h | ~350–700 h |

These are package limits and can be lower than hot-section material life in early aviation derivatives.

---

# 9. Component minimum and revised L_core hypothesis

## 9.1 E4 representative normal/full rating

| subsystem | mature engineering band |
|---|---:|
| rotor blade system | 350–600 h |
| vane/nozzle | 400–800 h |
| disk/root | 600–1200 h |
| liner as replaceable item | 150–300 h inspection/replacement; 250–450 h well-developed |
| bearing/seal | 400–800 h stationary; 250–500 h aviation |
| hollow-process/yield lower-tail gate | ~250–500 h after screening/maturation |

**v39 result:** representative E4 `L_core` should be **~250–450 h**, with early/new-process engines allowed below this. This is a tightening/clarification of “百数十〜数百時間”, not an order-of-magnitude increase.

`gt-shogouki`'s stationary/intermittent “数百〜千時間級” remains plausible as `TBO_prod`, because that product can be derated, has low annual full-power hours and can replace liners/inspect hot section without claiming a 1000 h full-rating turbine blade.

## 9.2 E5 — material/rating split

### E5 Ni high-end @ ~800°C headline coordinate

| subsystem | mature engineering band |
|---|---:|
| rotor blade | 500–900 h |
| vane | 500–900 h |
| disk/root | 800–1500 h |
| liner | 200–400 h scheduled; 300–600 h well-developed |
| bearing/seal | 500–900 h stationary; 350–700 h aviation |
| cooling/process-yield gate | 400–800 h mature population |

**representative `L_core`: ~400–700 h.**

### E5 non-Ni @ 800°C full rating

Rotor blade/material becomes the dominant limiter. **~150–300 h core-relevant band** is the prudent central audit result. This is useful for sprint/experimental/high-value short duty, not the natural mass workhorse.

### E5 non-Ni @ ~760–770°C derated quantity rating

Cooling + mature fabricated process + moderate derating recover a **~350–600 h representative `L_core`** band, before product-specific cycle/environment taxes.

This matches the existing worldline strategy: non-Ni is the quantity line because it spends some headline temperature to buy life/yield/supply robustness; Ni is the upper-performance line and does not have to be the mass line.

---

# 10. What this audit does **not** change yet

Do not yet propagate:

- E4 500 kW product output;
- E5 126 kJ/kg gross cycle coordinate;
- turboprop/jet installed output or thrust;
- aircraft speed/range;
- marine speed/range;
- procurement/adoption/OOB/history.

The hot-section audit exposes a new installed-performance item that must be closed next:

**cooling bleed / pressure-loss debit.**

The existing E4/E5 Brayton numbers are gross comparison coordinates. Actual cooling air does not simply disappear, but it changes combustor flow, turbine work, mixing and available power. A separate installed-cycle audit is required before changing product output.

---

# 11. Canonical decision recommendation

Ready to canonicalize at the hot-section layer:

1. E4 TIT 710°C is retained; cooled rotor metal is roughly mid-500°C to low-600°C rather than 710°C.
2. E5 TIT 800°C is retained as a high-end coordinate; cooled rotor hot spots are roughly high-500°C to mid-600°C.
3. E4 central does not require mature Ni-base superalloy; heat-resistant austenitic steel + simple hollow cooling + long-clock testing can close it.
4. E5 explicitly splits into Ni high-end full-rating and non-Ni quantity/derated lines.
5. E4 representative `L_core` = **250–450 h**.
6. E5 Ni high-end full-rating representative `L_core` = **400–700 h**.
7. E5 non-Ni full 800°C = **150–300 h**; non-Ni ~760–770°C quantity rating = **350–600 h**.
8. Combustor liner replacement interval is allowed to be shorter than `L_core`; it is a module/maintenance item.
9. Disk/root is not assumed limiting if rim-temperature targets are met; failure to meet them is a hard cliff gate.
10. Generic 1921–24 long-clock and exact alloy/process clock are separate; a new E5 Ni family receives the mature test method but a partial family/process clock reset.
11. Cooling bleed / installed-cycle performance remains OPEN and is the next quantitative audit before downstream performance/adoption effects.

---

# 12. Historical calibration anchors — not calendar ceilings

- NACA RM E7B11b / related 1947 turbine-cooling work: rim temperature and cooling materially alter blade life; gas temperature alone is insufficient.
- NACA 1947 turbine research talks: hollow-blade direct cooling can create large gas-to-metal temperature margins; experimental data were required because analytical heat-transfer data were incomplete.
- NACA TN 1603 (1948): blade failure times show large statistical scatter; average/dispersion matter, not only first failure.
- NACA RM E8F29 (1948): burner-liner local gradients were severe and associated with short life.
- NACA TN 1938 (1949): liner cracks concentrated around louver/stress-relief features, with thermal/mechanical fatigue and oxidation/process defects implicated.
- NACA TR 864 / related disk studies: thermal gradients can materially change rotating-disk stress safety.
- NACA high-speed-bearing studies (1950–52): oil flow/viscosity/cooling and inner/outer race temperature are coupled bearing-life variables.
- Jumo 004 production practice: fabricated folded/welded hollow non-Ni blades with compressor-air cooling demonstrate that a simple fabricated cooling route is physically manufacturable without mature investment-cast superalloy technology.

These sources calibrate mechanisms and feasible manufacturing ideas. Their historical dates are not used as Asai-worldline arrival limits.
