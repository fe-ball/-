# 126 — Machine-layer refresh v44r1 — 2026-08-26

v44r1 refreshes the machine layer after the E6 installed-cycle / product-power rebaseline.

- chronology: **647 records** (`CANONICAL-CHRONOLOGY-V44R1.tsv` / `.jsonl`)
- main canonical files: **199**
- status partition: **current 489 / conditional 67 / superseded 50 / scope 32 / mixed 9**
- new v44 chronology delta: CHR-0635..0647
- old E6 installed-cycle gate CHR-0632 and broad H→A wait CHR-0633 are superseded by the v44 split closure/gates.
- E6-S-T standard is now **1,300 hp**; old 1,520 hp standard is superseded.
- E6-S-N-T standard is now **1,500 hp**; old 1,700 hp standard is superseded.
- E6-S-S is **~1,350 shp standard capability**; old ~1,500 shp is development/high-flow ceiling.
- E6-M-T **2,100 hp remains current as flat-rated** at the corrected 13.2 kg/s compressor coordinate.
- E6-M marine ~2,300 hp short / ~2,000–2,100 hp continuous is cycle-side current but installation remains conditional.
- E6 downstream gates are split into S-core aircraft H→A, M-core aircraft intake/installation H→A, marine installation H→A, and jet/JF installed-thrust audit.

Current recall layer:
`CURRENT-CANONICAL-STATE.md` → `CANONICAL-MAIN-INDEX-V44R1.tsv` → `CANONICAL-CHRONOLOGY-V44R1.tsv` → `CROSS-DOMAIN-PREFLIGHT-V44R1.md` → `CAPABILITY-TRIGGER-MATRIX-V44R1.tsv`.
