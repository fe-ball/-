# Marine GT adoption reopen notes V2 — 2026-08-27

Status: explicit supersession note for adoption conclusions in V1 files. The underlying calculations and cited historical windows remain evidence; only the decision layer is changed where stated here.

## Momi / 廃駆二号

V1 made Momi the central 1934–36 integration platform because the hull was historically available and cheap to use. V2 retains that as the **leading candidate**, not a unique closed selection.

Reason: availability plus low opportunity cost proves suitability, not exclusivity. If the Navy institutionalizes continuous marine-GT development, a purpose-built modular laboratory hull can coexist with Momi rather than being ruled out as duplication.

## Dedicated propulsion test ship

V1 `CONDITIONAL / NOT CENTRAL PREWAR` is reopened to **OPEN**.

The correct comparison is not `can shore rigs and an old hull technically suffice?`; it is whether a long-running Navy/Asai GT program values repeatable machinery-space geometry, replaceable reduction sets, controlled intake/exhaust experiments, instrumentation, and assured sea time enough to pay for a dedicated hull.

This remains a programmatic decision; no new-build test ship is asserted merely to make the worldline more ambitious.

## No.600 heavy-MTB branch

The 1941 heavy-MTB requirement remains a closed historical opportunity. The E6-M hybrid remains the strongest current propulsion proposal because it aligns with the available E6-M power band.

V2 changes only the selection status: `CLOSED CENTRAL` becomes **LEADING-CANDIDATE** until piston and alternate GT architectures are compared against installation mass, low-speed handling, astern capability, propeller drag, salt endurance, fuel/range, and production readiness.

Post-1941 trials remain frozen.

## Carrier branch

V1 carrier calculations remain valid as comparisons. The main correction is to stop treating the historical machinery choice or short historical refit window as sufficient proof of worldline non-selection.

### Kaga

A mature large co-main GT installation remains too early for the 1934–35 refit. This is still a strong negative result for **full propulsion adoption**.

However, research/auxiliary insertion is left open: instrumentation, intake/exhaust experiments, generator drives, or machinery-space provision can participate in the marine program without pretending that E4/E5 is a carrier main plant.

### Akagi

The 1935–38 refit is long enough that the question should remain a genuine programmatic choice. Large-GT maturity is still weak early in the window, so full co-main propulsion is not the default; nevertheless, planned partial integration or a research installation should not be closed by historical precedent alone.

### Soryu / Hiryu

Steam remains the strongest main-plant choice because their design/build windows precede mature E6 large machinery. V2 therefore keeps **full GT main propulsion not selected working**, while avoiding the stronger claim that the ships are irrelevant to GT development.

### Taiyo / Kasuga Maru

The V1 propeller-shaft calculation is retained. A short-notice May–September 1941 machinery graft remains unattractive because the combining gear, shafting, machinery spaces, intake/exhaust, and controls require real redesign.

But V2 splits the scenario:

- **short-notice historical conversion path**: co-main GT is not selected;
- **earlier pre-planned conversion architecture**: physically possible and remains OPEN.

Thus the ~24.8–25.6 kt result is not promoted to adoption, but it is no longer killed solely by the historical four-month conversion interval.

### Unryu

Historical urgent standardization makes steam a strong 1941 competitor. V2 reopens the final selection because the worldline's standard machinery in 1941 depends on what was actually demonstrated and selected during 1938–41.

If large GT has only rig/prototype experience, steam likely wins. If E6-A/B has accumulated credible sea service, yard tooling, reducer production, and fuel doctrine before the urgent program, a co-main or other GT architecture must be compared on those worldline facts rather than on historical machinery alone.

## Fuel policy

The historical availability of direct kerosene/gas-oil/diesel imports remains closed. The broad clean marine-turbine distillate concept remains technically useful.

What is reopened is the **fleet-wide allocation policy**. Exact turbine/diesel/boiler fuel partition should follow the platform decisions and expected annual GT duty. It should not be used upstream to discourage adoption before the fleet scale is known.

## How to close from here

The next processing pass should close rows in this order:

1. large-rig and sea-demonstration state by year;
2. Momi versus dedicated-test-ship program architecture;
3. No.600 propulsion competition;
4. carrier opportunity cases with separate `short-notice` and `pre-planned` branches;
5. only then fleet-scale fuel allocation and downstream procurement.

A `NOT-SELECTED-WORKING` result should state what competing architecture wins and why. `History used steam` is not sufficient by itself.
