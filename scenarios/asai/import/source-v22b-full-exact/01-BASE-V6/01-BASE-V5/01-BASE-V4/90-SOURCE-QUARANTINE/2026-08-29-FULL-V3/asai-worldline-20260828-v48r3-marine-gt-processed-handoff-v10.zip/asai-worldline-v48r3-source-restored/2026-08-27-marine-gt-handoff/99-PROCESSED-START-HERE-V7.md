# Marine GT processed handoff — START HERE V7

This V7 overlay sits on semantic **v48** / machine **v48r3** and preserves the 1941-12-08 history boundary.

Read in this order:

1. `97-V7-RECALC-NOTES.md`
2. `89-E5-QUALIFICATION-CRAFT-FIXED-MASS-AND-CG-V7.tsv`
3. `90-E5-QUALIFICATION-CRAFT-TRIAL-BALLAST-MATRIX-V7.tsv`
4. `91-LL20-R2-DESIGN-COORDINATES-V7.tsv`
5. `92-LL20-R2-ACCEPTANCE-TEST-LEDGER-V7.tsv`
6. `93-TAIYO-6VS10-INTEGRATION-V7.tsv`
7. `94-TAIYO-GEAR-PATH-REQUIREMENT-V7.tsv`
8. `95-TAIYO-AIR-TRUNK-AND-EXHAUST-V7.tsv`
9. `96-MARINE-GT-REWORK-QUEUE-V7.tsv`
10. `98-MARINE-GT-PRECEDENCE-OVERLAY-V7.tsv`

Key V7 findings:

- The E5 sea-qualification article no longer needs a 25–27 t target. Explicit new GT/test hardware is about **1.00–1.42 t** plus sprint fuel, and the article should use controlled ballast and measured as-built CG rather than pretend to be a finished combat torpedo boat.
- The conservative `20.5 t historical full load + every new item` bookkeeping band is only about **21.61–22.08 t**, before crediting deleted warload/launch equipment. It is a bound, not a selected displacement.
- LL20 R2 is refined to a **~20.56 kg/s / ~3599 hp per-core drawing duty** for a 6-module Taiyo study with explicit 3% propulsive reserve and a 95% mechanical-path acceptance target. Product and ship selection remain open.
- V6's power no-free-lunch remains, but total-airflow invariance is corrected: 10 canonical E6-M modules install **132 kg/s** of design-flow capacity, whereas a demand-sized six-LL20 family is around **123.4 kg/s** at the selected R2 duty. That is product granularity, not a large-core efficiency bonus.
- The 10xE6-M fallback needs roughly **2160 hp/core** at the selected design sensitivity, a plausible marine boost-role point between the current 2,100 continuous and 2,300 short coordinates, but it owes role qualification.
- Final Taiyo gear tooth geometry is intentionally not closed because exact propeller-shaft rpm / yard machinery-space drawings are not present in the current corpus. Do not fill that gap with a generic contemporary ship.

Next P0: execute the E5 build/weigh/inclining + empirical prop trials; build and run LL20 R2 acceptance; recover Taiyo shaft/machinery drawing inputs; then choose 6xLL20 versus 10xE6-M on actual integration evidence.
