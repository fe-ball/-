# 計算導入前から電子計算期までの「何ができるか」能力総覧

> **作業稿 / v38候補。v37r1正本は未変更。**
>
> 数値評価の companion：`90-CAPABILITY-CONVERGENCE-SCORING-FRAMEWORK-DRAFT-V38-2026-08-25.md`。未来CAD＋未来部下を100%とする最適化接近率・利得回収率はそちらで定義する。
> 
> 目的は、浅井世界線で「転生チート＋現地基盤＋長期蓄積＋計算能力」の組合せにより、各時点で何が可能になるかを広範に列挙すること。個別製品の性能を直ちに上方修正する文書ではない。後続の再監査で、各項目を `AVAILABLE / USEFUL / GATED / N/A` に落とすための母表とする。

## 0. 旧リストの残存状況

元の「投入可能チートの総覧」そのものは現行パッケージでは確認できない。ただし `main/tensei-engineer-kufu-shu.md` が明示的にその役割を継承しており、以下の思想は残っている。

1. 現地に既に存在する複数の選択肢から、後知恵で実る方式を最初から選ぶ。
2. 原理的には可能だが着想・需要・制度のため遅れた方法を、自分で早期に押す。
3. 史実では長い試行錯誤の末に出た「地味な工夫」を、天才技術者の発明として早期投入する。
4. 正解の構造・寸法・式・手順・判断基準を、根拠を現地向けに組み直しつつ直接提示する。
5. 成熟に年数を要するものを、必要が生じる前から仕込んで時間を前払いする。
6. 他分野で成立した手法を早期転用する。

本稿では、これを「計算機が無い時代」から連続的に扱う。

---

# 1. 能力を読むためのタグ

- **K（Knowledge）**：未来知識・正しい問題設定・方式選択だけで開く。
- **H（Human）**：紙、表、計算尺、手回し計算器、人間計算班で実施可能。
- **D（Data）**：測定・カード・版管理・統計蓄積が必要。
- **M（Machine arithmetic）**：機械式四則演算・カード処理で量が増える。
- **A（Automatic sequence）**：自動順序機により反復算法を機械へ渡せる。
- **R（Relay）**：連立・反復・時間刻み・大量caseを日常工程へ入れやすい。
- **E（Electronic）**：高速反復・数値積分・大規模parameter sweep・場の離散計算が現実的になる。
- **P（Physical gate）**：材料、加工、計測、耐久、実物試験、量産歩留まりなど計算で代替不能。

同じ項目に複数タグが付く。例えば「空冷タービン翼」は K で着想、H/R/E で熱計算、D で熱伝達係数同定、P で鋳造・孔加工・耐久を支払う。

---

# 2. 計算能力の時代区分

| 段階 | 時期 | 中央像 | 開くもの |
|---|---|---|---|
| **P0** | ～1922 | 人間＋計算尺＋表＋少数卓上機 | 正しい式・正しい方式を知っていれば少数案を深く解ける |
| **C0** | 1923–24 | 機械計算室 | 反復四則、試験還元、検算を設計者から外す |
| **C1** | 1924–26 | カード＋試験標準票 | データ検索、ロット比較、故障分類、管理図の母体 |
| **C2** | 1925–27 | 「計算型」標準化 | 手順を会社資産化し、同じ問題を何度でも再利用 |
| **C3** | 1926–28 | カード＋機械計算ライン | 多条件探索、Holzer等の反復、粗map、重点試験 |
| **A1** | 1929–31 | 自動順序電気機械 | 「算法」を人から機械へ移し、parameter sweepを定常業務化 |
| **R1** | 1932–34 | 2千–5千relay級 | 連立、反復解、簡単な時間積分、多変数設計 |
| **R2** | 1935–37 | 8千–1.5万relay＋U4組織 | 粗探索→重点試験→検算が設計工程そのものになる |
| **E1** | 1938–40 | 真空管＋relay＋磁気drum | 大量反復、熱伝導、動力学、簡略流れ場、制御過渡 |
| **E2** | 1941–42 | 3千–6千真空管級 | reduced-order simulation、大量caseの設計最適化、反復同定 |
| **E3** | 1943–45 | 8千–1.2万真空管級＋計算センター | 場の数値解、統計・最適化・時間積分を研究インフラ化 |

重要なのは演算速度そのものより、**問題設定→入力標準化→粗探索→高価な本計算→独立検算→実験→モデル更新**の循環が形成されること。

---

# 3. 計算機以前から可能な「転生チート」一般

## 3.1 方式選択・発明・順序

- **K/P0**：史実で勝った方式を、競合案の中から初手で選ぶ。
- **K/P0**：史実で失敗した方式を早く捨て、必要な経験だけ試験枝として残す。
- **K/P0**：方式を「最終形」から逆算し、先に必要な材料・計測・工作設備を育てる。
- **K/P0**：長期熟成技術を需要前に開始する。GT、耐熱材料、精密鋳造、NDT、計算、燃料、制御など。
- **K/P0**：複数の新規性を、故障帰属可能なtestbedへ分離して載せる。
- **K/P0**：実験の順序を「安く戻せる→高価」「低速→高速」「部材→全機」にする。
- **K/P0**：現地では別分野と認識されている技術を同じ物理として束ねる。過給機→GT、音響→超音波NDT、電話/電機→制御、ジャカード→計算など。
- **K/P0**：将来の制約を知って先買い・設備投資を行う。ただし実需・資金・保管劣化は別勘定。

## 3.2 数学・設計手法

- **K/H**：次元解析、無次元数、相似則を早く標準化。
- **K/H**：誤差予算を最初に作り、「どこを高精度化しても意味がないか」を判断。
- **K/H**：感度解析。結果に効く変数だけを重点試験。
- **K/H**：線形化、摂動、区分近似、lookup table化。
- **K/H**：設計余裕を一律安全率ではなく、故障モード別に配分。
- **K/H/D**：実験計画法的に複数要因を同時に振り、交互作用を観測。
- **K/H/D**：統計的工程管理、管理図、受入検査、工程能力の概念。
- **K/H/D**：故障解析、部品版管理、failure feedback、configuration control。
- **K/H**：標準計算票・検算例・単位規約を最初から用意。

---

# 4. 計測・データ・品質——計算革命の土台

- **P0–C1**：試験番号、部品版、材料lot、加工条件、運転条件を固定欄で記録。
- **C1**：故障を「壊れた」で終えず、rpm、温度、圧力、時間、lot、部位へ分解。
- **C1**：管理図による常因/異常原因の分離。
- **C1–C2**：校正履歴、計器serial、補正式の版管理。
- **C2**：計算結果にも入力版・式版・物性表版を付ける。
- **C2–A1**：測定点を将来のモデル同定に使える形で標準化。
- **A1以後**：実験を「合否」だけでなく係数同定・model calibration用に設計。
- **R1以後**：残差を見て次の測定点を選ぶ。
- **R2以後**：複数工場・複数試験所のデータを同じ形式で比較。
- **E1以後**：大量データから経験式、補正式、寿命分布、異常傾向を反復推定。
- **P gate**：センサーが存在しない量、測定誤差より小さい現象は計算しても分からない。

---

# 5. 材料・冶金・化学

## 5.1 計算以前から大きく効く

- **K/P0**：適切な合金系を早く選ぶ。高速度鋼、耐熱鋼、非Ni/Ni二系統、Cr/Mn代替など。
- **K/P0**：熱処理温度・保持時間・冷却法を系統実験する。
- **K/P0**：清浄溶解、脱酸、介在物低減、温度管理を工程化。
- **K/P0**：中空冷却翼、拡散皮膜、ショットピーニング、もみの木翼根などを先取り。
- **K/P0**：investment casting、粉末焼結、超硬工具を適切な用途へ早期転用。
- **K/P0**：NDTを「不良選別」ではなく工程改善のfeedbackに使う。

## 5.2 計算で増幅される

- **C1–C3**：heat/lot/property database、平均だけでなくばらつき・外れを追跡。
- **A1–R1**：熱処理条件×組成×強度×硬さの多変数探索。
- **R1–R2**：拡散、熱伝導、残留応力の簡略モデル。
- **R2–E1**：creep/疲労データの時間–温度整理、寿命曲線の反復fit。
- **E1–E3**：翼・円板・溶接部の温度場/応力場の粗い離散解。
- **E1–E3**：樹脂配合、硬化条件、湿熱劣化、積層方向のparameter sweep。
- **P gate**：新材料は試験片・長時間暴露・製造歩留まりを必ず払う。計算のみでcreep/腐食/界面劣化を確定しない。

---

# 6. 工作機械・製造・量産

- **K/P0**：limit gauge、標準公差、治具、工程分割、流れ作業。
- **K/P0**：DFM/DFA的に「作れる形」へ設計を寄せる。
- **K/P0**：高精度が必要な面だけを高精度化し、全体を無駄に高価にしない。
- **C1**：不良位置・機械番号・工具寿命・作業班を統計化。
- **C2**：工程票と検査票を版管理。
- **C3–A1**：歯車組合せ、工具経路、加工順序、tolerance stackの反復計算。
- **R1**：line balancing、材料所要、機械稼働、工数の多条件計画。
- **R2**：工程能力と設計公差を相互調整。設計が工場の実力を前提に変わる。
- **E1以後**：生産計画、在庫、保守、交換部品の大規模集計・予測。
- **P gate**：実加工精度、工具材、熱変形、技能、設備台数は計算で生成しない。

---

# 7. レシプロ・ディーゼル・過給機

- **P0**：BMEP、熱収支、燃費、圧縮比、ピストン速度、軸受荷重、歯車比を正しい式で設計。
- **P0–C0**：試験runの馬力・燃費・体積効率・熱効率を高速還元。
- **C1**：気筒温度、油温、故障部位を部品版と紐付ける。
- **C2–C3**：過給器回転数、圧力比、切替高度、減速比をcase比較。
- **C3**：Holzerでクランク/減速/プロペラ系のねじり振動危険帯を粗探索。
- **A1–R1**：高度×rpm×boost×混合比×点火のgrid計算。
- **R1–R2**：supercharger map、engine map、propeller matchingを同じ帳簿へ統合。
- **R2**：設計候補を多く残したまま、試験資源を重点配分。
- **E1**：始動、加速、過給切替、冷却過渡の簡易時間積分。
- **E1–E3**：多気筒振動、熱分布、燃費/高度scheduleの最適化。
- **P gate**：燃焼、knock、潤滑、リング/ライナ摩耗、軸受、耐久runは実機試験が必要。

---

# 8. ガスタービン・ターボ機械——物語の原点

## 8.1 計算以前でもチートが強い領域

- **K/P0**：遠心→軸流の実証順序を選ぶ。
- **K/P0**：多段軸流、速度三角形、反動度、stage loadingの正しい方向を知る。
- **K/P0**：VSV、bleed、燃料制御、釣合せ、冷却翼、皮膜、適切な軸受/シールを先取り。
- **K/P0**：simple/recuperated/free-power/turboprop/turbojetを用途で使い分ける。
- **K/P0**：試験用cascade、単段compressor、combustor can、単段turbine、spin rigを早く整備。

## 8.2 計算の進歩で開く順

- **C0**：圧力比、温度比、軸仕事、燃費、単純Brayton cycleの反復。
- **C1**：compressor/turbine test pointを同一形式で蓄積。
- **C2**：標準cycle deck、物性表、損失補正を再利用。
- **C3**：PR×flow×rpm×Tの格子、work balance、粗map、Holzer/critical-speed候補。
- **A1**：stage-by-stage計算を機械へ渡し、数十～数百のstacking案を比較。
- **A1–R1**：cascade data→loss/deviation correlation→stage stackingの反復。
- **R1**：compressor/turbine/nozzleのmatched operating pointを多数条件で解く。
- **R1–R2**：VSV/bleed schedule、surge margin、start/acceleration scheduleを設計変数として扱う。
- **R2**：16段級compressorでも、一段ごとの速度三角形・clearance・loss・stage ratioを系統探索。
- **R2–E1**：Campbell図、shaft critical speed、torsional/whirl、bearing loadを多数caseで評価。
- **E1**：compressor spool acceleration、fuel schedule、surge crossingの簡易時間積分。
- **E1**：blade/vane/root/diskの1D/2D thermal network、cooling fractionのparameter sweep。
- **E1–E2**：cooling passage geometry×flow×metal temperature×creep lifeを反復。
- **E1–E2**：combustor pressure loss、pattern factor、residence timeのsemi-empirical設計。
- **E2–E3**：二軸compressor/turbine matching、spool間のstart/acceleration transient。
- **E2–E3**：compressible 2D flowのrelaxation/finite-difference的粗解析。現代CFDではない。
- **E3**：full-engine reduced-order modelを試験データで継続更新。

## 8.3 計算しても残るhard gate

- blade/vaneの実際の流れ場、secondary flow、失速、surge境界。
- cooling hole/中空翼の加工再現性。
- hot-section metal temperatureの実測。
- creep、oxidation、thermal fatigue、coating剥離。
- rotor burst、bearing/seal、oil coking。
- compressor/turbine製造公差と量産歩留まり。
- endurance/TBO。

**示唆**：E3以後のGT世代は「未来知識だけの怪物」ではなく、主人公が1920年代から育てた計算・試験・記録系が複利で効く。E4以後は全世代を再監査候補とする。

---

# 9. ターボプロップ・プロペラ・回転翼

- **P0**：プロペラ運動量理論、blade element、減速比、tip Machを正しく使う。
- **C0–C3**：径、pitch、rpm、gear ratio、flight conditionの多数比較。
- **A1–R1**：engine map×prop map×高度/速度のmatching。
- **R1–R2**：constant-speed governor schedule、overspeed/negative torque条件。
- **R2–E1**：flutter、torsion、blade stress、propeller/gear train dynamics。
- **E1以後**：rotorcraftのhover/forward-flight performance、blade loading、transmission/engine matchingの多条件計算。
- **P gate**：propeller aeroelasticity、gear durability、rotor vibration、tail rotor authority、flight handlingは実試験必須。

---

# 10. 航空機——空力・構造・飛行力学

## 10.1 早期

- **K/H**：翼型選択、誘導抗力、重量重心、翼面荷重、出力荷重、基本性能。
- **K/H**：Meredith effect、推力式排気、clean-up、flush riveting等の地味な工夫。
- **C0–C1**：飛行試験/風洞データの補正・カード化。
- **C2–C3**：翼型・プロペラ・重量・CGの多数比較。

## 10.2 自動順序・relayで変わる

- **A1**：風洞polarの大量整理、airfoil/interference候補のparameter sweep。
- **R1**：荷重case、spar/skin sizing、重量分布、重心移動の連立比較。
- **R1–R2**：flutterの簡略固有値/反復、control surface balance。
- **R2**：粗案数十→詳細案十程度を普通に維持できる。
- **R2**：engine/prop/cooling/structure/missionを同じdesign ledgerへ入れる。

## 10.3 電子計算期

- **E1**：linear flight dynamics、stability derivative、gust responseの時間積分。
- **E1**：高高度performance、compressibility補正、drag build-upの大量case。
- **E1–E2**：翼/尾翼/胴体の簡略aeroelastic model。
- **E1–E3**：2D compressible flow、shock位置のrelaxation計算、風洞との反復。
- **E2–E3**：mission optimization、fuel/weapon/altitude/speed schedule比較。
- **E2–E3**：automatic pilot/servoの制御則設計を数値応答で比較。
- **P gate**：3D separated flow、buffet、pilot handling、実flutter、構造疲労、manufacturing qualityは風洞/飛行試験で閉じる。

---

# 11. 艦船・舶用

- **P0**：排水量、復原性、重量重心、推進出力、shaft horsepower、プロペラ基本計算。
- **C0–C1**：試運転データ、燃費、shaft load、故障履歴の整理。
- **C2–C3**：多状態復原、loading condition、shaft torsion、propeller候補。
- **A1–R1**：船型抵抗/推進器の経験式を多数caseで探索。
- **R1–R2**：GT/steam/diesel/electricのinstalled mass・volume・fuel・airflow・shaft arrangement比較。
- **R2**：damage condition、electrical load、auxiliary distributionの多数case。
- **E1以後**：propeller cavitation/shaft vibrationのsemi-empirical exploration、航続/速力/搭載量trade study。
- **P gate**：水槽試験、cavitation、seakeeping、実船振動、船台/工廠能力、吸排気ductingは実物を払う。

---

# 12. 潜水艦

- **P0–C0**：浮力、trim、battery Ah/Wh、motor output、surface/submerged resistance。
- **C1**：cell lot、SOC、temperature、故障、ventilation dataの標準化。
- **C3–A1**：battery discharge curve×speed×hotel loadの多数case。
- **R1**：motor thermal rating、bus current、cable loss、propeller loadを統合。
- **R2**：充電schedule、H2換気、diesel-generator、mission energy ledger。
- **E1**：transient power、motor heating/cooling、depth/speed/energy schedule。
- **E1–E2**：pressure hull stressの簡略shell model、propulsor/hull interactionの経験モデル。
- **P gate**：cell chemistry/cycle life、motor commutator/brush、shaft/seal、yard installation、pressure test、noiseは実物gate。

---

# 13. 電力・電機・制御

- **K/H**：発電機/電動機の正しい拓扑、励磁、保護、power factor、短絡保護。
- **C0–C3**：load calculation、copper loss、thermal balance、gear/motor matching。
- **A1–R1**：電力network、fault current、regulator tuningの反復。
- **R1–R2**：servo/resolver/synchro、feedback loopを目的別に設計。
- **E1**：control transient、filter response、motor-generator dynamicsの数値積分。
- **E1–E3**：複雑なmulti-loop controlを簡略モデルで比較。
- **P gate**：絶縁材料、接点、ブラシ、整流、EMI、耐振/耐湿、現場整備は計算外。

---

# 14. 無線・レーダー・電子

- **P0–C0**：LC回路、周波数、antenna length、power budget、basic propagationを正しく計算。
- **C1**：tube lot、socket、connector、power supply、故障modeを統計化。
- **C2–A1**：filter/network、matching、IF chain、oscillator stabilityの反復設計。
- **R1**：antenna array、beam pattern、receiver chain、noise budgetの多数case。
- **R2**：radar equationを使ったrange/PRF/pulse width/antenna trade。
- **E1**：signal/filter transient、plotting、tracking algorithmの地上研究。
- **E1–E3**：大量の観測/plot dataからoperator procedureやfilter constantを改善。
- **P gate**：magnetron/tube/material、frequency stability、EMI、antenna manufacture、operator skill、CIC/doctrineは別gate。

---

# 15. 弾道・射撃指揮・光学・写真

- **P0**：射表、外弾道、風/密度補正、range tableを正しい式で作る。
- **C0–C3**：射表作成・補間・大量条件計算を高速化。
- **A1–R1**：砲種/弾種/装薬/気象条件の表を体系生成。
- **R1**：survey/target/met/fire-control error budgetを分離。
- **R2**：fire-control gearのcam/function table設計、servo response比較。
- **E1**：tracking/filtering、target motion extrapolationの地上計算。
- **光学 P0–C3**：ray tracing、lens prescription比較、公差計算。
- **R1–R2**：多数ray/波長/視野の反復、公差感度、glass choice。
- **E1**：航空写真の歪曲補正、stereo photogrammetry、座標計算。
- **P gate**：測距誤差、weapon dispersion、servo、glass homogeneity、研磨/芯出し、乗員操作は別。

---

# 16. 測量・砲兵気象・航法

- **P0–C0**：三角測量、座標変換、pilot balloon reduction、ballistic wind。
- **C1–C3**：観測様式、時刻、station、instrument calibrationを標準化。
- **A1–R1**：大量の測量点・気象観測を迅速に整理し、fire-control messageへ落とす。
- **R1–R2**：sound ranging/flash spottingの幾何、時刻補正、met correction。
- **E1**：航法fix、dead reckoning、風補正、複数観測のleast-squares的統合。
- **P gate**：観測網密度、theodolite/radiosonde、通信、訓練、地形遮蔽は現地資源。

---

# 17. 燃料・化学工業

- **K/P0**：触媒系、工程順序、硫黄管理、適切な原料cutを後知恵で選ぶ。
- **C0–C1**：収率、物質収支、熱収支、lot品質を標準化。
- **C2–A1**：温度/圧力/contact time/触媒組成のparameter sweep。
- **R1**：反応器・熱交換器network、recycle、compressor dutyの連立計算。
- **R2–E1**：semi-empirical kineticsとplant dataを反復fit。
- **E1以後**：refinery/product blending、fuel property optimization。
- **P gate**：触媒寿命、poisoning、腐食、高圧equipment、seal/compressor、plant scale-upは実機gate。

---

# 18. 物流・事業・軍需生産

- **P0–C1**：原価、在庫、標準部品、部品番号、maintenance record。
- **C1–C3**：カードによる在庫・消耗・補修・故障統計。
- **A1**：大量の部品所要・生産schedule・補給表。
- **R1–R2**：複数工場、設備能力、材料割当、代替部品のwhat-if計算。
- **E1–E3**：大規模production planning、fleet spare demand、maintenance interval analysis。
- **P gate**：資源が存在しない、船腹がない、工場が破壊される、組織が採用しない、という現実は計算で消えない。

---

# 19. 計算機自身が次の計算機を作る複利

- **C0–C2**：歯車、cam、relay timing、接点寿命、電源の設計を自分の計算室で支援。
- **C3–A1**：自動順序機の論理設計、検算、sequence tableを機械で補助。
- **R1**：relay network、timing、fault diagnosis、power supplyを大量caseで検討。
- **R2**：新計算機の回路・論理・ドラム配置を旧計算機群で設計。
- **E1以後**：電子回路定数、timing、memory addressing、numerical methodを前世代機で開発。
- **D**：旧機を粗探索・検算・前処理へ残すことで、新機を本計算へ集中。

これにより、計算機は単なる外生的ボーナスでなく、**工作機械・電機・材料・真空管・磁気材料・品質管理を相互に育てる自己強化系**になる。

---

# 20. 「計算能力の進歩を見込んで先に動く」項目

主人公は将来の演算能力を知っているため、機械がまだ遅い段階でも以下を仕込む合理性がある。

1. **測定を機械可読化しやすい形式へ統一**：固定欄、番号、単位、校正、時刻。
2. **試験装置をparameter sweep向けにする**：圧力、温度、rpm、流量を素早く変更・記録。
3. **部品版管理**：変更点を一つずつ追えるようserial/variantを厳密化。
4. **物性・翼型・歯車・燃焼・材料のlibrary化**。
5. **次元解析とcorrelation**：将来、大量caseを回す際に入力次元を減らす。
6. **計算型library**：同じ問題を別製品へ転用できるよう手順を標準化。
7. **粗いmodelと高価なmodelを階層化**：多数案は粗模型、少数案だけ詳細計算。
8. **independent check culture**：別式・別機・縮約模型で検算。
9. **試験をmodel calibrationとして設計**：最も情報量が増える測定点を選ぶ。
10. **future sensor demandを先に作る**：高温熱電対、圧力計、流量計、振動計、高速記録。
11. **計算員ではなく方法技術者を育成**：数値計算・誤差・近似・物理モデルの専門職。
12. **顧客側へ計算文化を外販**：機械だけでなく帳票、計算型、保守、教育を売る。
13. **共通カード/コード体系**：異世代機・異工場間の「ネットワーク」を先に作る。
14. **試験データを捨てない**：失敗runも将来の統計・モデル改善用資産として保存。
15. **計算可能な設計へ技術を変える**：測れない・定義できない「職人の感覚」を可能な範囲で変数・公差・試験値へ分解する。

---

# 21. 計算で縮まるもの / 縮まらないもの

## 強く縮む

- 反復算術、補間、表引き、転記、検算。
- 候補案比較。
- 既知方程式の連立・反復。
- 試験データ還元。
- 故障条件検索。
- parameter sweep。
- 既知モデル内の最適化。
- 実験計画と重点試験選定。
- 設計変更後の再計算。
- 複数部門の共通帳簿。

## 中程度に縮む

- 風洞/ベンチ→次試作の反応時間。
- 複雑振動の危険領域特定。
- cooling/thermal設計。
- aeroelastic/flight dynamics。
- production planning。
- service-failure feedback。

## 原則として縮まらない

- 新材料の長時間creep/腐食寿命。
- 量産歩留まりが安定するまでの工場学習。
- full-scale endurance。
- 実際のstall/surge/buffet/flutter境界の最終確認。
- 新しい製造法のfixture/tooling立上げ。
- 人員教育・整備文化の浸透。
- 顧客・軍・官僚組織の採用判断。
- 工廠/船台/工場の物理capacity。
- 戦史・配備・損耗。

ただし、これらも「どこで失敗するかを早く知る」「無駄な試験を減らす」「次の試験を正しく選ぶ」ことで間接的には短縮される。

---

# 22. v38再監査の優先候補

## P0——最優先

1. **GT E1→E9の計算能力再伝播**：各世代で利用可能な計算型、試験rig、モデルを明示。
2. **E6/E7/E8/E9 installed engine**：compressor map、cooling、spool dynamics、nozzle、mass flow、inletを統合。
3. **GT開発設備の先行投資年表**：cascade、spin rig、high-T instrumentation、cooling rig、data library。
4. **計算機進展を見越した計測体系**：何を何年から測れるようにするか。

## P1

5. レシプロ/過給機——U4以後の設計探索を再評価。
6. 航空機——flutter、compressibility、stability、mission integration。
7. 材料——creep/thermal fatigue/cooling modelの計算化。
8. 舶用/潜水艦——shaft/prop/electrical/energy ledger。
9. 射撃指揮・光学・写真——専用計算器へ落ちる計算型。
10. radio/radar——回路・antenna・signal処理と整備品質の分離。

## P2

11. 化学工業、燃料、触媒、plant operation。
12. 造船、生産計画、物流、spares。
13. 戦車・車両の振動/冷却/伝動/運動性。
14. 気象・測量・航法。
15. computation自身の自己加速。

---

# 23. この一覧を正本へ昇格するときの規則

- 「計算できる」だけで製品性能を加算しない。
- 史実年号を上限として使わない。
- 逆に、未来知識・数値解法・計算資源・蓄積データを無視して史実の試行錯誤時間をそのまま課さない。
- 各技術を最低でも `知識 / 計算 / 計測 / 材料 / 製造 / qualification / adoption` に分解する。
- 計算前の主人公個人能力と、計算文化が組織へ外部化された後の能力を分ける。
- 1928–29以後、浅井内部では計算文化を標準状態として扱い、後から「計算ボーナス」を二重加算しない。
- 外販先は吸収遅延を置くが、U4化後はその会社自身の能力として扱う。
- 1941-12-08以後の技術可能性と、実発注・量産・配備・戦果を分離する。

---

# 24. 暫定結論

この世界線の計算史で本質的なのは、1938年に突然「コンピューターが出現」することではない。

- **1910s–22**：主人公本人が正しい問題を知る。
- **1923–28**：その問題を繰り返し解く算術・データ処理を組織へ外す。
- **1929–34**：計算手順そのものを機械へ移す。
- **1935–37**：粗探索→重点試験→検算が会社・発動機メーカーの標準設計工程になる。
- **1938–45**：大量case、時間積分、場の粗い数値解、モデル同定が研究インフラへ成長する。

したがって、GTを15年で実用、20年で怪物へ育てた旧設定は、計算導入によって単純に壊れるのではなく、**後半10年の「怪物化」の因果が、主人公個人の天才から、主人公が育てた計算・計測・試験・品質システムへ移る**と読むのが自然である。
