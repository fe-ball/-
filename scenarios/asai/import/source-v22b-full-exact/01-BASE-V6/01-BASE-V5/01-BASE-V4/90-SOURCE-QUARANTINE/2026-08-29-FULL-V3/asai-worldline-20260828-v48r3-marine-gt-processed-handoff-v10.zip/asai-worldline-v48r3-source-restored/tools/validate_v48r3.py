#!/usr/bin/env python3
from pathlib import Path
import csv,json,hashlib,collections,sys
ROOT=Path(__file__).resolve().parents[1]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    e=[]
    req=['CANONICAL-CHRONOLOGY-V48R3.tsv','CANONICAL-CHRONOLOGY-V48R3.jsonl','CHRONOLOGY-SCHEMA-V48R3.json','CANONICAL-MAIN-INDEX-V48R3.tsv','CAPABILITY-TRIGGER-MATRIX-V48R3.tsv','CROSS-DOMAIN-PREFLIGHT-V48R3.md','CURRENT-CANONICAL-STATE.md']
    for n in req:
        if not (ROOT/n).exists(): e.append('missing '+n)
    if e: print('\n'.join(e)); return 1
    rows=list(csv.DictReader(open(ROOT/'CANONICAL-CHRONOLOGY-V48R3.tsv',encoding='utf-8'),delimiter='\t'))
    if len(rows)!=687:e.append(f'chronology count {len(rows)}')
    ids=[r['record_id'] for r in rows]
    if ids!=[f'CHR-{i:04d}' for i in range(1,688)]:e.append('ID coverage/order mismatch')
    for r in rows:
        p=ROOT/r['source_file']
        if not p.exists(): e.append('missing source '+r['record_id']+' '+r['source_file']); continue
        if sha(p)!=r['source_sha256']: e.append('stale source hash '+r['record_id'])
        try: ln=int(r['source_line']); total=len(p.read_text(encoding='utf-8').splitlines())
        except: e.append('bad source line '+r['record_id']); continue
        if not 1<=ln<=total:e.append('source line range '+r['record_id'])
        try: json.loads(r['row_json'])
        except: e.append('bad row_json '+r['record_id'])
    jr=[json.loads(x) for x in (ROOT/'CANONICAL-CHRONOLOGY-V48R3.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]
    if len(jr)!=687:e.append('jsonl count')
    idx=list(csv.DictReader(open(ROOT/'CANONICAL-MAIN-INDEX-V48R3.tsv',encoding='utf-8'),delimiter='\t'))
    actual={str(p.relative_to(ROOT)) for p in (ROOT/'main').iterdir() if p.is_file()}
    if len(actual)!=134:e.append(f'main count {len(actual)}')
    if actual!={r['path'] for r in idx}:e.append('main index coverage')
    for r in idx:
        p=ROOT/r['path']
        if sha(p)!=r['sha256']:e.append('main index hash '+r['path'])
    am=list(csv.DictReader(open(ROOT/'archive/aviation-pre-v48/v46-main/MANIFEST.tsv',encoding='utf-8'),delimiter='\t'))
    if len(am)!=71:e.append(f'archive count {len(am)}')
    if sum(int(r['v46_chronology_records']) for r in am)!=169:e.append('archive chronology-source total')
    for r in am:
        p=ROOT/r['archive_path']
        if not p.exists() or sha(p)!=r['sha256']:e.append('archive hash '+r['filename'])
    tr=list(csv.DictReader(open(ROOT/'CAPABILITY-TRIGGER-MATRIX-V48R3.tsv',encoding='utf-8'),delimiter='\t'))
    for r in tr:
        for s in filter(None,r['canonical_sources'].split(';')):
            if not (ROOT/s).exists():e.append('trigger source missing '+r['capability_id']+': '+s)
    for cap in ['BIZ-ORIGIN','CORE-V48','AIR-RESET']:
        if not any(r['capability_id']==cap for r in tr):e.append('missing trigger '+cap)
    sc=json.loads((ROOT/'CHRONOLOGY-SCHEMA-V48R3.json').read_text(encoding='utf-8'))
    if sc.get('release')!='v48r3' or sc.get('semantic_worldline')!='v48':e.append('schema release')
    if sc.get('build_counts',{}).get('records')!=687:e.append('schema record count')
    # No current index entries may point to archived old aviation files.
    if any('/aviation-pre-v48/' in r['path'] for r in idx):e.append('archive leaked into current main index')
    print('PASS' if not e else '\n'.join(e))
    if not e:
        c=collections.Counter(r['semantic_status'] for r in rows)
        print('records=687 main=134 archive=71 archived_source_rows=169 status='+json.dumps(c,ensure_ascii=False,sort_keys=True))
    return 0 if not e else 1
if __name__=='__main__': raise SystemExit(main())
