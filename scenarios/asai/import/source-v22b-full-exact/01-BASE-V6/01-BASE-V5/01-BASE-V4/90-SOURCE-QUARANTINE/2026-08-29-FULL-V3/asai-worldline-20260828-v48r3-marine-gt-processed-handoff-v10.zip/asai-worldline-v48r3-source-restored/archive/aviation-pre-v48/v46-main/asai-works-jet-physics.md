# ジェット推進の物理——コアから推力・速度の壁まで

> **v46 installed-thrust authority.** E6-M pure jet/JF has now passed the dedicated installed-engine audit: non-Ni J ~850 kgf, Ni J ~900 kgf, JF ~950–1,000 kgf. For E6-M, same-TIT JF gain is ~21% thrust and ~17% TSFC reduction; the old +30–40% blanket is superseded.

> **v37 authority update**：本稿の旧短絡 `½Ve²=w → Ve=√(2w)` を、installed turbojet の推力導出には使用しない。`w` は core の **gross Brayton comparison index** であり、ノズルへそのまま渡る運動エネルギーではない。推力は **inlet recovery → compressor map/work → combustor pressure loss/TIT → turbine compressor/accessory work + cooling debit → turbine-exit total state → nozzle expansion → mass flow** の鎖で求める。E5/E6/E7の既存製品推力値は保守的な経験較正anchorとして当面保持し、E8/E9の増分は dedicated installed-engine H→A で再較正する。正本の世代判定は `asai-works-e8-e9-later-war-propulsion-rebaseline-1942-47.md`。

ジェット枝の**物理の背骨**を一本に通す。会社側のあれこれ（顧客・契約・命名・戦術・所管）は意図的に薄く、他資料（`jet-interceptor`／`jet-catalog`／`jet-hekireki-21`）に置く。本稿は、コアの gross cycle 指標と mass flow を出発点にはするが、それだけから推力を直接導かない。規則は `tensei-engineer-kufu-shu.md`、数値の芯は `asai-works-gt-core-generations.md`、連続体の定性は `asai-works-aviation-forms.md`。数値は【確認済み】【物理】【設定】【要確認】で区別する。

---

## 0. 立場——cycle index と installed thrust を分離する

- **gross Brayton comparison index**：PR、TIT、component efficiency から、世代間の熱効率・gross specific work を比較する。これは compressor/turbine technology の指標。
- **cooled installed-core comparison**：cooling/bleed、accessory load、代表圧損を差し引き、core が実装時にどれだけ余裕を残すかを見る。v37のE8では代表4〜5% cooling debitを入れても約181〜183 kJ/kg、約30.4〜30.5%の比較値を残す。
- **installed turbojet thrust**：上記だけでは決まらない。入口回復、実compressor map、燃焼器圧損、turbine work balance、冷却混合、排気total pressure/temperature、ノズル面積・効率、外気状態、ṁを解いて初めて決まる。
- よって、**generation ≠ thrust**。同じE世代でもcore scale/ṁ/外径/重量/軸構成によって推力帯は変わる。

---

## 1. コア→ノズル——タービンはまず圧縮機を駆動する

単純ターボジェットでは、燃焼器出口の高温ガスが持つenthalpy riseを全部ノズルへ渡すわけではない。タービンはまず compressor と accessory を駆動し、さらに冷却空気の抽気・混合を支払う。したがってノズルが利用できるのは **turbine-exit の total enthalpy と total pressure** である。

概念鎖は次の通り。

> `inlet → compressor(PR, map, ηc) → combustor(ΔPt, TIT) → turbine(Wc+Waux, ηt, cooling) → nozzle(Pt5,Tt5,A8,ηn) → Ve, pressure thrust`

理想収縮ノズルなら、出口速度は nozzle enthalpy drop から

> **Ve²/2 = cp(Tt5 − Te)**【物理】

で求める。ここで `Tt5` は turbine-exit total temperature、`Te` は出口static temperature。旧式の `Ve²/2 = w_net` は **installed turbojet には適用しない**。

---

## 2. 比推力と静止推力——既存値は経験anchor、E8以降はinstalled H→A

静止推力の一般形は、一次元近似では

> **F = ṁ(Ve − V0) + (pe − p0)Ae**【物理】

である。適正膨張ならpressure-thrust項は小さくなり、静止時の比推力はおおむねVeへ近づくが、Ve自体は§1のinstalled cycleから求める。

同時代機の実測推力÷流量は、既存コーパスの保守較正を点検するanchorとして残す：

| エンジン | 静止比推力 N/(kg/s) | 備考 |
|---|---:|---|
| Jumo 004B | 415 | 既存較正anchor【確認済み】 |
| Whittle W2/700 | 420 | 既存較正anchor【確認済み】 |
| Ne-20（橘花） | 536 | 既存較正anchor【確認済み】 |
| **コーパス計画床** | **350** | E5/E6/E7の既存製品値を保持する保守的empirical anchor【設定】 |

- **350 N/(kg/s)** をE-6中型 ṁ=14 kg/sへ置くと単機約499 kgf、双発約999 kgfとなり、既存「双発 約1,000 kgf」と一致する。この一致は**経験較正**であって、gross Brayton `w` からの物理導出ではない。
- E8/E9はgross specific workの増分をそのまま推力増分へ写さない。mass flow、compressor/turbine matching、cooling、nozzle、inlet、外径・重量を含むinstalled-engine H→Aを通す。
- 推力を上げる別軸としてcore scale/ṁがある。v26のE6-L-Jには既に1,000〜1,150 kgf級research shadowがあり、「E9になれば1,000 kgf」という世代番号短絡は禁止する。

---

## 3. 速度による推力——ジェットが高速で推力を保つ理由

正味推力は飛行速度で下がる。適正膨張近似なら **F ≈ ṁ(Ve − V₀)**、一般形は **F = ṁ(Ve − V₀) + (pe−p0)Ae**【物理】。噴流速度Veに飛行速度V₀が近づくほど推力は減る。

- ただし**吸気のラム回復**が速度とともに流量と圧力比を上げ、(Ve−V₀)の目減りを部分的に相殺する。結果、正味推力は高亜音速まで概ね保たれる。
- 対照的に**プロペラ推力は F = P·η_p/V₀ で速度に反比例して落ちる**。これが「高速・高高度はジェット、低速はプロペラ」の物理的な根（`aviation-forms` §7）。ジェットは、プロペラが推進効率と推力で崩れる速度帯に立つ。

---

## 4. 高度による推力減衰と「なぜ高空で速いか」

推力はおおむね空気密度に比例：**F ∝ ρ**（流量が密度で落ちる）。ISA（実計算）：

| 高度 | 気温 K | 密度 ρ | 海面比 | 音速 a (km/h) |
|---|---|---|---|---|
| 0 km | 288.1 | 1.225 | 1.00 | 1,225 |
| 7 km | 242.6 | 0.590 | 0.48 | 1,124 |
| 8 km | 236.1 | 0.525 | 0.43 | 1,109 |
| 11 km | 216.6 | 0.364 | 0.30 | 1,062 |

7–8 kmで推力は海面の約半分に落ちる。**にもかかわらず最高速（真対気速度）は高度で上がる**——抗力 D=½ρV²S·C_D も密度で下がり、同じ動圧をより速いTASで得るため、抗力の軽減が推力減衰を上回るから（対流圏界面まで）。これが海面720 km/h→高度7〜8 kmで755〜775 km/h（`jet-interceptor` §3、橘花の抗力で校正）の機構。**速度は推力でなく次節のマッハで頭打ちになる**。

---

## 5. 最高速＝推力＝抗力、そして本当の壁＝マッハ

最高速は推力＝抗力の点。コーパスは橘花で校正（海面623 km/hから実効C_D0≈0.037を逆算、清浄設計C_D0≈0.028で海面720 km/h、`jet-interceptor` §3）。本稿はこれを**物理的に支持**し、偽の精度で再導出はしない（校正が正直な錨）。要点は**最高速を縛るのは推力でなく機体の臨界マッハ**だということ：

| 高度 | 速度 | マッハ | 含意 |
|---|---|---|---|
| 7 km | 720 km/h | **M0.64** | 圧縮性の入口手前 |
| 7 km | 775 km/h | **M0.69** | 直線翼の臨界マッハに接近 |
| 8 km | 775 km/h | **M0.70** | 〃 |
| 8 km | 900 km/h | M0.81 | 後退翼域 |
| 8 km | 940 km/h | M0.85 | 後退翼の上限（運用帯9〜11 kmでは903〜930） |

- **直線薄翼の臨界マッハ M_crit ≈ 0.72〜0.75**。これを超えると造波抗力が急に立ち上がる。霹靂一一型の高度速度はちょうどM0.64〜0.70＝**755〜775 km/hの頭打ちは推力不足でなく圧縮性の壁**。推力をいくら足しても、直線翼ではこの壁の手前で抗力発散に当たる。
- **後退翼（ブーゼマン1935）で M_crit≈0.82〜0.85** へ後退（臨界マッハを遅らせる）。8 kmで M0.85＝**943 km/h**。ここを抜くための推力を**再燃焼**が供給する（§7）。よって上端の高亜音速要撃＝薄翼＋後退翼＋再燃焼で**約900〜930 km/h**（要撃高度9〜11 kmのM0.85。8 kmなら943だが、B-29要撃の運用帯9〜11 kmに合わせ`jet-hekireki-kai` §4bの930へ統一。`propulsion-roadmap` §2）。**超音速は狙わない**（canon）ので、ここが頭打ち。
- 読み替え：「最高速」は**機体の臨界マッハが決め、エンジンは遷音速の抗力上昇に抗する推力を出す**役。直線翼＝速度の床、後退翼＝床を上げる、再燃焼＝床まで押す推力。

---

## 6. 後置ファン＝推進効率を買う（バイパスの物理導出）

推進効率 **η_p = 2V₀/(V₀+Ve)**【物理】。Veが低いほど高い。バイパスは核の動力を**より多い質量へ低い速度で**配り、実効Veを下げてη_pを上げる。V₀=200 m/s（720 km/h）で：

| 形式 | 実効Ve | η_p |
|---|---|---|
| 純ジェット | 540 m/s | 0.54 |
| 後置ファン（バイパス比約1） | 430 m/s | 0.63 |
| ターボプロップ | 250 m/s | 0.89 |

- 純ジェット0.54→後置ファン0.63＝**推進効率+約17%→比燃費−約15〜20%**（コーパスの−20〜30%帯の内、`aviation-forms` §3）。
- **静止推力は、同じ実jet-powerをより大きい質量流量へ低いΔVで配るほど増やしやすい**。理想 actuator-disk/jet-power比較では F∝√(P_jet·ṁ) だが、ここでP_jetは**実際に噴流へ渡ったkinetic power**であり、gross Brayton `w·ṁ` と同一視しない。v46でE6-Mをinstalled-cycle再検算した結果、835°C・BPR≈1・FPR≈1.30では **+約21%**。理想√ṁの+41%は上限方向の説明であり、free-turbine work splitとcore-nozzle低下を払った製品値ではない。
- **代償は最高速**：実効Veが下がると、より低い速度で推力＝抗力に達する＝**最高速−5〜10%**【物理／設定】。超音速を狙わない以上、捨ててよい余白。
- **弱コアほど値打ちが大きい**理由が式で見える：純ジェットは乏しい比仕事を「速すぎる噴流」に全部注ぎ、低速でη_p=0.54と半分以上を捨てている。冷たいファンを足すと捨てた分を拾える。ファンは冷部で**温度天井（熱部）に触れない**（`aviation-forms` §2）。
- 三形式が一本のη_p曲線上の点＝連続体（プロペラ0.89／ファン0.63／純ジェット0.54）。後端は離散の機種でなく一本の摘み。

---

## 7. 瞬間の上乗せ——再燃焼・水噴射（Veの嵩上げ）

定常効率を捨てて瞬間推力を買う手。離陸・上昇・要撃の数分に効かせる（常用しない）。

- **再燃焼（アフターバーナー）**：噴口手前で排気に燃料を足し、排気温を上げる。Ve∝√T。排気温 900K→1800K で **Ve×1.41＝静止推力 約+41%**【物理】。代償は燃料消費が約2〜3倍（TSFC激増）と、可変面積ノズル＋耐熱噴管【要確認】。上端の高亜音速ダッシュ＝臨界マッハの壁を抜く推力源（§5）。
- **水・水メタノール噴射**：圧縮機/燃焼器へ水を吹き、質量流量増＋冷却で短時間の推力。安価・基盤が軽く、日本はピストンで実用済みのnative技術（`aviation-forms` §5）。
- いずれも**瞬間側の上乗せ**。定常側の底上げ（後置ファン）と重ねられる＝量産主力は「バイパスで足を確保＋噴射/再燃焼で上昇の摘み」。

---

## 8. まとめ——律速はinstalled thrust chainと圧縮性（機体の臨界マッハ）

物理だけで言えば、ジェットの性能は二つの限界に閉じる。

1. **推力**＝inlet、compressor、combustor、turbine work balance/cooling、nozzle、mass flowを解いたinstalled quantity。gross Brayton specific workは世代比較指標であって推力そのものではない。
2. **臨界マッハ**＝機体（翼厚・後退角）が決める速度の壁。エンジンはその壁の手前/抜けで抗力に抗する役。

- **純ジェット**・**後置ファン**・**再燃焼**は、同じcore capabilityを異なるmass-flow/ΔV/温度配分へ割り当てる後端選択である。
- E5/E6/E7の比推力350 N/(kg/s)級は既存製品の保守的empirical anchorとして保持する。E8/E9のinstalled thrustは専用H→Aで閉じ、gross `w` の平方根から自動生成しない。会社側（誰がいつ何機）は本稿の外。

---

## 9. タグ・索引

- 【確認済み】：ISA（対流圏の密度・音速）、同時代機の比推力（Jumo004 415・Whittle 420・Ne-20 536 N/(kg/s)）、後退翼の着想（ブーゼマン1935）、再燃焼の史実実用（1940年代半ば）。
- 【物理】：F=ṁ(Ve−V₀)+(pe−p0)Ae、Ve²/2=cp(Tt5−Te)（ノズルenthalpy drop）、F∝ρ、η_p=2V₀/(V₀+Ve)の単純jet近似、速度↔マッハ、臨界マッハによる最高速の頭打ち。gross Brayton w→Ve の直接変換は禁止。
- 【設定／v46更新】：旧比推力350はE5/E7の履歴的保守anchor。E6-Mはdedicated installed auditを優先し、JF利得は同温度純ジェット比で静止+約21%・TSFC−約17%。機体最高速ペナルティはH→Aで再評価する。
- 【要確認】：E5/E7〜E9各installed coreのcompressor/turbine/nozzle map、入口回復、再燃焼の可変ノズル・耐熱噴管、ラム回復の実効。**E6-M J/JFのengine-side重量・前面積はv46で閉鎖済み**、航空機側drag/CGは別H→A。
- 親：`asai-works-aviation-forms.md`（連続体の定性）／`asai-works-gt-core-generations.md`（比仕事・熱効率の芯）／`asai-works-core-elements.md`（九軸）。
- 機体側（会社・諸元）：`asai-works-jet-catalog.md`（機種カタログ）／`asai-works-jet-interceptor.md`（一一型）／`asai-works-jet-hekireki-21.md`（二一型・後置ファン）／`asai-works-propulsion-roadmap.md`（後端の時間軸・後退翼/再燃焼）。
