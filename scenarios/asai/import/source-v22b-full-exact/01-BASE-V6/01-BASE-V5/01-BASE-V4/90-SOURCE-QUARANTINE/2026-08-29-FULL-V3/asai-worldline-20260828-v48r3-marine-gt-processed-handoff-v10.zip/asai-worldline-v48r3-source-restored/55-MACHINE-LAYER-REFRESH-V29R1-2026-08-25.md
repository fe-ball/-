# v29r1 machine-layer refresh

- Chronology: `CANONICAL-CHRONOLOGY-V29R1.tsv/.jsonl` (**447 records**).
- Schema: `CHRONOLOGY-SCHEMA-V29R1.json`.
- Main index: `CANONICAL-MAIN-INDEX-V29R1.tsv` (**181 main files**).
- Trigger matrix: `CAPABILITY-TRIGGER-MATRIX-V29R1.tsv`; `MARINE-GT-CRAFT` now points first to the v29 design-closure parent.
- Preflight: `CROSS-DOMAIN-PREFLIGHT-V29R1.md`, adding the v29 trial/service, E5 one-GT, shaft/prop, installed-mass, salt/MTBO, pure-GT and E6 procurement gates.

v28r1 records are carried forward. CHR-0426..0428 are demoted to `superseded` because the v27 2GT+350hp central, unresolved pure-GT production framing and old E6 43–45kt / 500–800nm envelope are no longer current.

New CHR-0439..0447 encode the v29 authority, E5 one-GT marine-qualification central, conditional 2GT/CPP branch, trial-vs-service rule, shaft/prop design bands, installed GT-path mass bands, salt/intake qualification, pure-GT normal-production NO and the conditional E6 50–55t technical shadow.
