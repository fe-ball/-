# Taiyo V5 module architecture — notes

At fixed incremental propulsive power, fixed E6 installed specific work and a fixed post-engine path-retention sensitivity, **total core mass flow is nearly independent of module count**. At the V5 central sensitivity of 93%, Taiyo 21→25.5 kt asks for about 122.35 kg/s total core flow whether that flow is split among four, six or ten modules. Module count therefore does not magically remove the intake/exhaust-flow problem.

What module count changes is the trade between:

- new-core scale-development tax;
- number of gas generators, starters, controls, lube systems and hot sections;
- number of unit reducers/clutches/pinions or grouping stages;
- machinery-room subdivision and maintenance access;
- redundancy after a single-module failure;
- symmetry on the ship's two existing propulsion shafts.

The current leading **trade**, not selection, is six modules / three per shaft. At 93% path retention it implies about 3,570 engine hp and 20.4 kg/s per core. That is a real scale crossing beyond E6-M and therefore needs its own compressor/rotor/combustor/hot-section article, but it avoids the 30+ kg/s jump of a four-module plant and the five-input-per-shaft integration of ten canonical E6-M modules.

The ten-module E6-M branch remains the no-new-core fallback. It is important because it prevents the development program from pretending a large core is mandatory. Conversely, four/six-module branches show why the Navy could rationally pay for a larger core if a pre-planned carrier-boost program is real.
