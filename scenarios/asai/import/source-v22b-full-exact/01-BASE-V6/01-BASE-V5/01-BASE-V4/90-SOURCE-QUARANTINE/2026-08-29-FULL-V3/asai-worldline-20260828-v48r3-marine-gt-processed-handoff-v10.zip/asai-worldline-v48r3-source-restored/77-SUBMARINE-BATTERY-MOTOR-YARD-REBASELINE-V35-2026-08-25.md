# 77 — SUBMARINE BATTERY / MOTOR / YARD REBASELINE v35

v35 closes the P1 submarine battery/motor/yard accounting audit without replacing the v23 hull concept.

Central corrections:
- retain ordinary large lead-acid 3-group battery + four ~1,000 hp-class DC motors as the first-generation architecture;
- reduce the central engineering programme from the old 4–6 boats to **1–2 hull-equivalent complete electrical/yard sets**, with the third and later sets conditional on factory and yard repeatability;
- treat 4,400–4,500 hp **one-hour rating as motor thermal rating**, not one-hour submerged high-speed endurance;
- require a separate full-bank high-rate discharge / end-voltage / temperature / H2 / cavitation acceptance test for the 15 kt target;
- use cell count, motor count, high-current copper/switchgear, charging/ventilation and installation/replacement workflow as the industrial ledger instead of invented yard man-hours.

Historical calibration used in the canonical parent:
- I-15/B1: 240 cells, two main motors, 2,000 hp total, 8 kt-class submerged baseline;
- I-400 Mark I Model 13: 360 cells as three 120-cell batteries in parallel; 5,500 Ah at 1 h and 11,200 Ah at 20 h;
- I-200 special D battery: warning case for many-small-cell high-power architecture and its electrolyte/separator/parallel-charge/H2 problems.

Canonical parent:
- `main/asai-works-submarine-battery-motor-yard-rebaseline-1938-44.md`

Post-1941-12-08 actual construction, deployment and combat history remain FROZEN.
