# GFRP小型艇一次艇体の再基底化——1940–46 scale-up / wet / slam / repair gate

> **[v30 current]** 旧v27の「1942–43に20–30t級GFRP高速艇一次構造を中央」は一段強すぎるため撤回する。1942–43の中央は **実寸bottom/forebody区画＋8–12m級低～中速全GFRP実証艇**。20–30t級の全GFRP高速艇は **1943–44以後のconditional prototype**、50–55t E6全面GFRP高速艇は戦中中央に置かない。GFRPは不燃ではない。

目的は「FRPが作れる」から「40kt級の一次艇体として繰返しslamを受け、湿潤後も検査・修理・再使用できる」までの距離を、材料・工法・試験・生産量に分解すること。E5/E6の機関・prop/shaft設計は `asai-works-marine-gt-small-craft-design-closure-1938-43.md` を優先し、本稿は艇体材料だけを閉じる。

---

## 0. 裁定

1. **1938–41 E5 marine-qualification艇は木造中央を維持**する。GT試験とGFRP艇体試験を同じ艇に束ねない。
2. **1940–41**：coupon、接着継手、曲面panel、through-hull/insert、海水・南方曝露を開始。
3. **1941–42**：実寸bottom/forebody bay、chine/keel/engine-bed局部、反復pressure/slam rigを中央。ここで厚肉積層の発熱・ボイド・二次接着を閉じる。
4. **1942–43**：**8–12m級の低～中速全GFRP実証艇**を中央。高速20–30t艇については完成艇ではなく **大区画/実寸bottom section** を中央実証に置く。
5. **1943–44以後**：前段gateを通った場合のみ、20–30t級全GFRP高速艇をconditional prototypeへ進める。初期は速度/sea-state制限付きで、段階的にfull-powerへ上げる。
6. **1944–45**：20–30t prototypeがwet/slam/repair gateを満たせば限定運用試験は可能。ただし量産・制式採用は自動でない。
7. **50–55t E6**：戦中の中央艇体は木造double-diagonal/laminated。全面GFRP高速艇は20–30t実証の実時間を食うため **1946+相当のtechnical gate** とする。1945級に先行させ得るのは低速の非磁性実験艇/大区画であって、40kt級E6ではない。

---

## 1. 史実較正——材料出現と艇体scale-upを分ける

史実では連続ガラス繊維と低圧硬化樹脂が揃うのは1930年代末～1940年代前半で、Ray GreeneのFRP艇は1942年の約8ft級dinghyが錨になる。Owens-Corningの社史ではFRP boat hullを1944年のmilestoneに置く。米海軍BuShipsがplastic constructionを本格試験するのは1946年の28ft personnel boatからで、1949年に36ft LCVP experimentalへ拡大する。

したがって浅井側の **epoxy 1931–33、低圧硬化、1939少量silane、40–41 wet coupon、管理図/NDT** は確実な前倒し札だが、1942–43にいきなり19–20m・20–30t・40kt級の完成一次艇体を中央へ置くには、寸法・厚肉硬化・slam疲労・現場修理のscale-upを一段飛ばしていた。

浅井世界線の利得は「史実1946級の小型海軍FRP艇試験を1942–43級へ寄せる」程度には使える。**史実8ft級→浅井20m高速艇を同年帯で直結する札ではない。**

---

## 2. 材料/界面——使えるが、量とwet dataがgate

### 2.1 matrix / glass

- matrix：浅井epoxy。低圧・常圧硬化が大物成形の入口を早める。
- reinforcement：continuous glass cloth / woven rovingを主荷重方向へ、staple glass clothを面の補助へ。
- coupling：高価silaneは1939頃から高価値部位へ。1942–44に直接法系の内製化/安価化を追う。
- **GFRPの目標glass含有率は重量で概ね50–60%級をworking band** とする。これは手積み＋真空補助で無理に高Vfへ寄せない値。CFRP用の `Vf≈50%` をGFRP艇体へ機械的に流用しない。

### 2.2 量

旧 `materials-fleet-application` の **「魚雷艇一隻あたり連続glass fiber 6–8t」** は20–30t級艇の一般値として過大なので撤回する。

19–20m級艇について、外殻/甲板/隔壁の面積と8–11mm級solid-laminate-equivalentを重量帳簿だけに使うと、**一次GFRP構造全体 4.5–6.5t級、うちglass 2.5–3.8t級、resin 1.8–2.7t級** が初期planning band。これはscantling承認値ではなく「桁が合うか」の質量監査である。

50–55t級は同じ作法で **一次複合構造 8–11t級、glass 4.5–6.5t級** が先行planning band。旧6–8t glassはむしろこの上位艇の上端へ近い。

1945年米国FRP全生産約3.5 million lb（約1,590t、軍用）という史実錨に対し、浅井日本はその一部しか持たない。ゆえに20–30t prototypeを数隻作る量は届いても、FRPだから魚雷艇を大量量産できるとはしない。

---

## 3. 構造方式——最初からsandwich全面化しない

40kt級planing hullはbottom slamが支配する。初期prototypeで「新材料＋新core＋新接着＋新修理」を同時に束ねない。

### 3.1 初期20–30t prototypeの中央構成

- **bottom / keel / chine：solid GFRP laminate中央**。局部厚肉、woven cloth/rovingの0/90とbias-cut ±45を積層する。
- topside：solid laminateまたは局部的な軽芯sandwich。
- deck / house：密封した桐等の軽木芯sandwichを許す。紙honeycombをwaterline以下へ置かない。
- transverse frames / bulkheads：GFRP shellへ二次接着。最初は木/軽金属の実績部材を一部残して荷重経路を切り分けてもよい。
- engine bed / shaft strut / rudder / weapon / lifting point：**metal insert＋広いGFRP doubler**。樹脂局部圧壊へ直接預けない。
- hull-deck joint：初期は**接着＋mechanical fastening併用**。接着単独に最終破壊を預けない。

### 3.2 「一体艇体」の語を制限

大物open-mold shellを一体で成形できても、bulkhead・deck・engine bed・insert・二次接着が残る。したがって初期資料の「GFRP一体艇体」は、**継手を減らしたmolded shell** と読み替え、完全monocoqueを意味させない。

---

## 4. 製造gate——大きさより厚肉硬化が怖い

- wet lay-up＋vacuum blanket/bagを基本とする。
- 20m級を一回でbaggingすること自体を成功条件にしない。zoneごとに積層し、overlap/secondary bondを規格化する。
- **thick-section exotherm**：bottom/keel/chineの厚肉部は一度に積まず、複数stage cure＋post-cure。樹脂発熱、温度勾配、残留応力、局部boil/voidを記録する。
- witness couponを各cure batchへ置き、硬化履歴・barcol相当の硬さ/曲げ/層間試験をlotに紐付ける。
- mold精度はline/trimへ直結する。左右重量差・shell thickness map・CGを完成後に実測する。

**失格**：局部void/未含浸を補修すれば済むという扱いを、keel/chine/engine-bed primary zoneへ広げない。primary zoneの広範不良は廃棄/大規模再製作。

---

## 5. wet / salt / fuel / temperature gate

### 5.1 couponから艇体へ

- fresh-water / seawater immersion、湿熱cycle、fuel/oil/cleaner曝露を分ける。
- 1940–41開始の実時間南方曝露を継承し、accelerated testだけで年数を置換しない。
- 既存の「hot/wet後に層間強度が設計値の60%を切れば失格」はhard floorとして維持する。一次艇体の採用目標は **dry baseline比70%級以上を狙い、wet allowableで再設計**する。
- weight gain/吸水が平衡せず増え続ける材・端面・coreは失格。

### 5.2 sealing

- exposed edge、penetration、fastener/insert周りをepoxy sealする。
- deck/topside sandwich coreはdrain/inspection pathを持たせる。完全密閉の宣言だけで済ませない。
- bottomは初期solid laminateにしてcore water-ingressの新故障様式を避ける。

---

## 6. slam / fatigue gate——静強度だけでは通さない

高速艇で最も危険なのは、静水圧ではなく短時間のwave impactとその反復である。40kt級で艇首bottomが水面を叩くため、coupon tensileだけで艇体を承認しない。

### 6.1 rig

- full-scale bottom panel / chine panelを実物frame spacingで作る。
- hydraulic/pneumatic pulseでdesign slam pressureの反復を与える。
- **working qualification：10^5 pulse級**を第一段の比較基準に置き、剛性低下・delamination area・leak・insert loosenessを記録する。数値はhistorical factでなくprogramme gate。
- dry新品だけでなく、wet-conditioned specimenを同じrigへ入れる。

### 6.2 sea trial

20–30t prototypeは次の段階解除とする。

1. displacement/low-speed leak & trim
2. 15–20kt、calm sea
3. 25–30kt、moderate sea
4. 35kt級、inspection intervalを短く
5. full-power trialは最後

初期採用gateのworking値：**累積300h級、うち高出力/高速100h級、rough-water 30–50h級**。各段で打音＋透過ultrasound/切出しcouponを行い、progressive delaminationが無いこと。最高速一回を合格にしない。

---

## 7. inspection / damage / repair gate

### 7.1 inspection

- 工場：透過ultrasound、透過光/目視（可能な薄部）、witness coupon、thickness map。
- 現場：打音、外観、leak、局部剛性/音の比較。
- tool drop / grounding / gun blast / docking damageの後は「凹みが無いから無傷」を禁止する。

### 7.2 repair

- 非一次部：glass cloth＋epoxy patchを現場で可。
- primary bottom/chine：損傷部を健全部まで除去し、広いstep/scarf＋真空補助で再積層。温度・乾燥・cleanlinessを管理できるdepot作業を中央。
- emergency patchは**水密復旧**と**構造復旧**を分ける。応急patch後のfull-speed運転を認めない。
- repaired coupon/panelを再びwet/slam rigへ入れ、virginの許容値をそのまま使わない。

このrepair doctrineが無い限り、高速艇の「一体成形で継手が減る」は運用上の利得にならない。

---

## 8. fire / machinery boundary

GFRPは**腐らず、フナクイムシに食われず、電気絶縁性を持つ**が、不燃材ではない。旧 `frp-manufacturing` の「GFRP一体艇体＋灯油GTで素材と燃料の火災リスクを同時に潰す」は撤回する。

- fuelをgasolineからkerosene/dieselへ寄せることは火災hazardを下げる。
- GFRP resinは熱分解・燃焼・煙を出すので、engine room/firewall/exhaust周りは**metal liner/firebreak＋air gap＋glass wool lagging**。
- fuel tank/engine bedの局部は耐火時間を別試験する。
- 被弾後火災で「FRPだから安全」としない。

---

## 9. 20–30t prototypeの意味

20–30t級を通す価値は軽量化だけではない。

- wood grain/接着/fastenerのばらつきをmold＋lot QCへ置換できる。
- rot/borer/caulkingを減らせる。
- shell joint/fastenerを減らせる。
- electrical insulation/nonmagnetic性を得る。

一方、初期GFRPは厚く、metal insert・firebreak・repair marginを積むため、**木造艇に対して必ず大幅軽量になるとはしない**。prototypeの成功指標はまず「同等重量で再現性・耐湿・保守性を改善」でよい。

---

## 10. 50–55t E6 full-GFRP gate

E6全面GFRP高速艇は以下を全部満たした後だけ開く。

1. 20–30t prototypeの300h級sea trialとrough-water inspectionを完了。
2. wet-conditioned full-scale bottom panelのslam fatigue pass。
3. primary repair specimenが再試験pass。
4. 20m級mold/cureで厚み・void・左右重量差の管理能力が実証。
5. glass/resin allocationが航空radome、防護、電装、他艇と競合しても確保可能。
6. 50t hullのbottom pressure/scantlingを、実際のdeadrise/CG/frame spacing/sea-stateで再計算。
7. firebreak・machinery insert・shaft strut load pathがclose。

**中央裁定**：1942–45のE6 technical shadowは木造double-diagonal/laminated hull。50–55t full-GFRP high-speed hullは **CONDITIONAL、1946+相当**。低速非磁性艇はslamが軽いため別枝として1945級から実験可能だが、mine threat/production/adoptionは別gate。

---

## 11. 旧記述の置換規則

以下はv30でcurrentから外す。

- 「1942–43に20–30t級GFRP高速艇一次構造を中央」
- 「第二世代魚雷艇1942–43以後がGFRP一体艇体」
- 「1945級に非磁性GFRP掃海艇がそのまま技術成立」
- 「GFRP＋灯油GTで素材と燃料の火災リスクを同時に潰す」
- 「20–30t級魚雷艇でglass fiber 6–8t/隻」

置換後：

- 1942–43 central = full-scale hull section + 8–12m demonstrator。
- 20–30t full high-speed GFRP = conditional 1943–44+ prototype。
- 50–55t full high-speed GFRP = conditional 1946+ technical gate。
- low-speed nonmagnetic demonstrator = 1945+ branch、adoption別判定。
- GFRP fire safety = no; fuel/firebreakで受ける。

---

## 12. closure

### CLOSED / REBASED
- GFRP材料出現と高速艇一次構造scale-upを分離。
- 1942–43中央を20–30t完成高速艇からsection/8–12m demonstratorへ後退。
- solid-bottom / limited-sandwich初期構成を設定。
- glass/resin mass orderを再計上し、旧6–8t glass/E5値を撤回。
- wet、slam/fatigue、NDT、repair、fireのgateを設定。
- 50–55t E6 full-GFRPを戦中中央から外した。

### CONDITIONAL
- 1943–44+ 20–30t full-GFRP high-speed prototype。
- 1944–45限定運用試験への進行。
- 1945+ low-speed nonmagnetic demonstrator。
- 1946+ 50–55t full-GFRP high-speed E6。

### HISTORY/FROZEN
- 1941-12-08以後のactual procurement、series production、deployment、combat outcome。

### NEXT
- 史実基準戦闘機H→A / 1942+ rotorcraft / radio-radar reliability / mine-sweeping / survey-artillery meteorology。
