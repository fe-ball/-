# E6 torpedo-boat decision V1 — 2026-08-27

Status: requirement/procurement crosswalk pass. Technical design-space calculations remain inherited from v29/v44; this file decides what may and may not be used as a chronology gate.

## Historical requirement timing

The large Japanese T-51 / 甲型魚雷艇 line is not a 1940 universal gate. The 1941 wartime urgent construction program lists **one PT-10 / No.600 prototype and seventeen PT-11 / No.601–617 boats**. Secondary design histories place the No.600 prototype's laying down in **July 1942** and completion in 1943. The historical design was an approximately 75–85 t, four-engine large MTB family and became a failure-side calibration for weight, machinery/shaft integration and achieved speed rather than evidence of a mature 1940 requirement.

External verification:
- https://www.generalstaff.org/WW2/PEDIA/Prod/WW2_IJN_Prod_Plans.htm
- https://old-wiki.warthunder.com/Type_T-51b
- Japanese Society of Naval Architects and Ocean Engineers archive, wartime motor-boat table: https://zousen-shiryoukan.jasnaoe.or.jp/wp/wp-content/uploads/item/senpaku/senpaku-vol38-07.pdf

## Worldline consequence

1. **Retire `1940 torpedo-boat success` as a marine-GT adoption gate.** E5 marine qualification can proceed in 1940–41 without asserting a fleet procurement decision.
2. The v29 **E6 50–55 t / ~5,200 hp / four-torpedo technical shadow remains physically useful**, but its procurement trigger should be tied to the 1941 large-MTB requirement window, not pushed backward merely because E6 exists.
3. At ~5,200 hp the current technical central is **42–44 kt trial**, not guaranteed 40 kt operating speed. A hard 40 kt operating requirement still drives roughly 6,000–7,100 hp or a lighter boat.
4. Pure-GT mass production remains non-central. The hybrid architecture retains piston/diesel cruise/astern capability and uses E6 for high-power operation.

## Decision

- **Technical feasibility/design-space:** CLOSED enough to retain as a candidate.
- **1940 procurement/adoption:** RETIRED.
- **1941 requirement-driven prototype competition:** OPEN-HIGH.
- **Series procurement and exact numbers:** OPEN; the historical 1+17 program is a requirement calibration, not an automatic worldline order.
- **Role as a prerequisite for large-ship GT:** RETIRED. Large-ship qualification proceeds on its own land-rig/sea-trial/gear/salt gates.

The next platform decision can therefore choose Momi/廃駆二号 for early marine qualification without waiting for the later large-MTB program.
