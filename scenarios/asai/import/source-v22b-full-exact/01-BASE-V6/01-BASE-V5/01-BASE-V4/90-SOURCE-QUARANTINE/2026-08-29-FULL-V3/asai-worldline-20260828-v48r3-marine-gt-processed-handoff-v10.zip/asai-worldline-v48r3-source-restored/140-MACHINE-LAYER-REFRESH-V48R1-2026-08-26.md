# v48r1 machine-layer refresh

- `CANONICAL-CHRONOLOGY-V48R1.tsv/.jsonl`: 687 records.
- 169 carried records whose source moved to `archive/aviation-pre-v48/v46-main/` were converted to `superseded` provenance.
- v46 Hekireki/Sakufu downstream H→A target rows were also retired.
- 20 v48 records were added for business origin/diversification, E1–E9 core authority, archive fence, aviation three-layer method, E4/E5 jet/fan conditional gates, transonic pressure, retained FRP/CFRP clocks and TP re-audit.
- `CANONICAL-MAIN-INDEX-V48R1.tsv` indexes current `main/` only; archive files are intentionally excluded.
- Trigger matrix redirects old aviation/TP/rotorcraft triggers to the v48 reconstruction/core parents and adds `BIZ-ORIGIN`, `CORE-V48`, `AIR-RESET`.
- `CROSS-DOMAIN-PREFLIGHT-V48R1.md` makes business origin, archive fence, mission competition, TP re-audit, transonic and CFRP gates mandatory.
