# 無線・電探の実用品質再基底化 1935–45 —— tube / contact / insulation / power / EMI / training H→A

> 2026-08-25 v33。浅井側の樹脂、線材、電源、フェライト、計測、統計/QCを、機上・艦上radio/radarの**実用品質**へ接続する正準親。装置の存在、研究開始、波長/周波数、送信出力、探知原理を浅井差から自動前倒ししない。改善対象は availability、始動再現性、湿塩/振動耐性、整備時間、受領歩留り、故障フィードバックであり、運用教義・配備数・戦果は別gate。

## 0. 結論

1. 日本の戦時無線を一括して「低品質・使えない」と扱うのは誤り。1940年以後の機上radioには良好な工作・材料・水晶制御が存在する一方、**防食・防黴、標準化、整備性、機体側EMI、量産再現性**が別問題として残る。
2. 浅井が1935–41に最も強く効くのは、**巻線含浸、端子/コイル局部封止、接地/ボンディング、点火雑音抑制、コネクタ/配線工程、電源regulation/filter、burn-in、受領試験、故障票**。送信出力や探知距離へ一律係数を掛けない。
3. 真空管ではタングステン/線材・ガラス/封止・工程QCを支援できるが、陰極chemistry、真空技術、高周波管/マグネトロンそのものを浅井が一社で代替しない。**tube life / microphonics / seal yieldを改善する枝**と、RF性能を発明する枝を分ける。
4. 電源は大きな実用gate。史実調査では日本電子装備のpower-supply設計は戦中ほぼ停滞し、陸海軍の機密分業で装置全体との統合が弱く、受領仕様とfield-fault feedbackも弱かった。浅井は共通電源tray、regulator/filter、試験端子、acceptance sheetを提案できるが、**軍種横断標準化は顧客側承認なしに成立しない**。
5. **1941–42のradar暦は維持**。H-6機上捜索電探は研究開始1941-11、完成1942-08の史実Hを下限較正とし、浅井品質技術から1939–40実用機上電探を発生させない。艦上Type 22等も「部品が良いから要求・方式・運用が数年前倒し」とはしない。
6. radar実用性は hardware availability だけでなく、operator/maintainer training、spares、test gear、plot/communication、艦内EMI、CIC/戦闘指揮手順を払う。1945調査でも電子教育は戦争後半に量優先で質が低下した。**良いset ≠ 良いcombat system**。
7. したがって1941末までに正準化できるのは、fighter/observation/shipboard radio向けの**reliability package ready**と、radar/sonarへ流用可能な電源・封止・試験技術。1942+ radar実装では同packageが成熟を助けるが、実配備/OOB/戦果はHISTORY/FROZEN。

## 1. H —— 史実電子装備の「強い所」と「弱い所」

### 1.1 radio construction

米軍1944年の日本信号装備調査では、航空無線は頑丈・小型で工作と材料が良く、1940年以後の新型は電気・機械面で連合軍水準に近いと評価された。水晶も良質。一方、腐食・fungus対策は認められず、機種ごとの空間へ合わせた設計と手作り色が強く、保守標準化には不利だった。

NavTechJap E-18も、戦前型radio/electronicsはよく作られていたが、構造法は基本的に戦前商用品の延長で、temperature/humidity/fungus proofingの専門化が量産段階へ届いていなかったとする。

よってHは「回路が全部悪い」ではなく、**環境・統合・標準化が弱い**。

### 1.2 power supply / feedback

NavTechJap E-15では、戦中の日本power-supply component designは大きく進まず、末期は材料不足と生産拡大で品質が低下。さらに海軍/陸軍の強い機密分業により、power unitと最終装置のproduction design統合が弱く、受領規格が緩い場合があり、field faultを設計へ戻すcoordinationも不十分だった。

航空電子機器のregulationは多くがmanualで、戦争末期になってvibrating-reed regulatorが使われた例がある。したがって**発電機がある＝安定電源がある**ではない。

### 1.3 training / operation

NavTechJap E-29では海軍electronics教育は体系自体はよく計画されていたが、equipment inferiority、訓練器材の少なさ、防御任務への高級司令部の弱い支持、戦争後半の大量養成要求による課程短縮・入学基準低下・教官分散で質が落ちた。

戦闘事例でも、1943年Empress Augusta Bayでは一部日本艦がradarを搭載していてもoperator trainingが弱く、視認へ依存した。**setの搭載と戦闘利用を同じ変数にしない**。

### 1.4 radar timing

NavTechJap E-02のH-6（Type 3 Air Mark 6 Model 4）は、研究開始1941-11、完成1942-08、2m/150MHz、peak約3kWのairborne patrol/search set。大型艦、航空機、浮上潜水艦を探す用途へ進んだ。

ここは浅井差で「1937年に同等電探」としない。浅井は**既に成立した方式をfieldableにする側**へ効く。

## 2. C/M/E/P —— 浅井側で実際に前払いできるもの

### C —— measurement / acceptance / fault loop

- receiver sensitivity、selectivity、oscillator drift、transmitter output、modulation、insulation resistance、contact resistanceを受領カード化。
- 発動機回転数を掃引してignition noiseを測り、radio-on / magneto / generator / landing-light等の組合せで機体側EMIを再現。
- 艦上はgenerator切替、砲/電動機/探照灯/他radio同時運転、接地電位差、salt/humidity後を試験。
- 故障を「真空管交換」で閉じず、tube / socket / contact / power / antenna / cable / operator / installationへcause code分解。
- 同一型setをbench→vibration→hot/humid→再benchで比較し、性能低下を量産受領へ戻す。

Cの配当は**故障原因の可視化と修理の短縮**。dBやkmを直接足さない。

### M —— insulation / sealing / contacts / wiring

1935–38：
- 点火coil、小型transformer、巻線、端子箱、meter/radio小物へ樹脂含浸・局部potting。
- cotton/rubber/varnish系を全置換せず、湿気が入りやすい端子、coil end、transformer、接続部を優先。

1938–41：
- 高価値aircraft/ship equipmentへ封止範囲を拡大。
- cable gland、terminal board、connector strain relief、防錆、drain/vent、service loopを図面標準へ。
- shock/vibrationで緩むねじ・socket・relayをlocking、spring contact、support spacingで処理。

**完全密封はしない**。熱を閉じ込める、修理不能になる、樹脂がRF部品の容量/損失を変える箇所はpotting対象外。封止は設計判断であり「樹脂を塗れば全部強い」ではない。

### E —— electrical power / EMI

浅井が標準提案できるのは、装置本体と分離した**power-conditioning package**。

- generator/dynamotor入力のfilter、surge suppression、voltage/current monitor。
- regulator、transformer/choke、rectifier周りの熱/振動支持。
- chassis bonding、single-point/defined return、shield termination、antenna/feedline routing。
- ignition harness shielding、feed-through capacitor / choke / resistor等による雑音経路の抑制。
- maintenance test socket / labelled test points。

ただし軍種・工廠ごとに別設計される装備へ「共通tray」を強制できない。**Asai-ready / customer-adoption conditional**とする。

### P —— parts / tube / standardization

- タングステン線、heater/filament線材の径・表面・lot管理は浅井の既存材料技術と整合。
- tube seal/glass-to-metal joint、base pin、socket、microphonics、burn-inを受領試験へ繋ぐ。
- ferrite/iron-powder coreはTDK等の既存メーカーを置換せず、測定スポンサー/大口顧客として品質mapを作る。
- 同じ機能のsetでtube type、connector、fuse、meterを無制限に増やさない。**spares complexityを設計値として監査**。

RF発振管、magnetron、特殊cathode等の能力は別のH/メーカー能力を必要とする。浅井材料だけからcm-wave radarを生成しない。

## 3. A-RADIO —— 1938–41の実用無線中央

### 3.1 fighter / observation aircraft

A0は「長距離高性能radio」ではなく、**既存帯域・出力のsetを飛行中に使い続けられる割合を上げるpackage**。

中央仕様：
- crystal control等、史実setが持つfrequency-control方式を尊重。
- ignition-noise acceptanceを機体受領へ追加。
- antenna/feedline、bonding、ground returnを機体図面の一部にする。
- coil/transformer/terminal局部防湿、connector strain relief。
- quick fault isolation card、spare tube/fuse/connector kit。

効果として許す：編隊内command、位置/観測報告、基地/艦との連絡の**service availability改善**。

禁止：
- 「全戦闘機が常時完璧に通話」
- fit rate 100%の自動正準化
- rangeを一律+X%
- doctrine/CAP control/CICをradio品質だけから発生

### 3.2 Zero / Ki-43 / Ki-44への波及

初期零戦について旧正本が持つ「九六式空一号無線は史実で一律実用性が低い」という表現は弱める。史実日本radioの品質評価はset/時期/installationで混在する。

v33中央は、**機体側点火雑音・配線・接地・antenna・環境・整備を別原因として管理する**こと。1941末に「技術的に常用しやすいinstallation package」は成立し得るが、実際の搭載率、撤去率、部隊運用はHISTORY/FROZEN。

Ki-43/Ki-44 A0の「無線へ再投資」は、このpackageを採る意味。重量余裕を高出力radioへ使うのではなく、installation、電源、spares、保守性へ使う。

## 4. A-RADAR —— 1941–45は方式暦を維持し実用品質を上げる

### 4.1 1941–42 gate

- H-6 airborne search radarのresearch 1941-11 / completion 1942-08をHとする。
- shipborne / land radarも各史実方式のrequirement・研究開始を別Hとして扱う。
- 1935–41浅井packageは、radar研究に入った時点で**power supply, transformer, insulation, connector, chassis/bonding, test instrumentation**を即利用できる背景。

したがって短縮対象はprototype debug、受領不良、field repairであって、**研究要求そのものを数年前倒ししない**。

### 4.2 airborne radar

1942+の機上電探は、重量・antenna drag・power・operator spaceを払う。

v33で許す改善：
- power supplyの始動/電圧変動margin。
- humidity/salt/condensation後のinsulation fault低減。
- vibration支持、socket/connector緩み低減。
- receiver/transmitter moduleのbench交換とfault isolation。
- production acceptanceの再現性。

探知距離はantenna、frequency、peak power、receiver NF、target/sea clutterのH/Iで決め、reliability packageから一律増距離しない。

### 4.3 shipboard radar

hardware以外に必須：
- antenna installation / blind sector。
- power/grounding / same-ship interference。
- operator + maintainer training。
- spare tubes/modules/test gear。
- plotting table / voice circuit / fighter/weapon direction手順。

ここを払わない艦は、radarを載せてもvisual lookoutより戦術的に優位とは限らない。

## 5. Training / maintenance gate

浅井が直接できる：
- training bench、故障挿入用trainer、cutaway/module board。
- fault chart、test-point voltage table、交換手順、修理時間記録。
- operatorとmaintainerを分け、operatorに「故障か干渉かtargetか」を識別させる訓練素材。
- 予備tube/relay/fuse/connectorをset単位でpack。

浅井だけではできない：
- 海軍/陸軍の教育定員、課程長、配属優先。
- defensive electronicsを重視するcommand culture。
- Army/Navy/common frequency doctrine。
- CIC/air-defense organizationの採用。

よって**training kit ready ≠ trained fleet**。

## 6. Reliability ledger —— 数値を捏造しない

v33ではfield MTBFや稼働率の史実seriesが不足しているため、「浅井で故障率半減」「可動率95%」のような一律値を置かない。

代わりに各setで次を記録する：
1. cold-start pass。
2. hot/humid exposure後pass。
3. vibration/shock後pass。
4. generator/voltage sweep。
5. ignition/ship EMI環境でのS/Nまたは通信可否。
6. fault-isolation time。
7. replaceable module / tube / fuse countとspares burden。
8. field return原因分布。

**A判定は「規格化された受領試験と故障loopがある」こと**。性能値を別の装置から借りない。

## 7. 年次中央

### 1935–38
- 電機小物の含浸/封止、coil/transformer/terminalの環境試験を商品化。
- radio makerへ材料供給＋受領試験支援。完成radioメーカーにはならない。

### 1938–40
- aircraft/ship high-value radioへinstallation-QC package。
- ignition/grounding/shielding試験、connector/terminal標準、burn-in/fault cardを開始。
- Army/Navy共通化は未成立。顧客別variantを許す。

### 1940–41
- fighter/observation radio用reliability package **TECHNICALLY READY**。
- actual fit rate / unit removal / combat useはhistory gate。
- radar用power/sealing/test building blocks ready。ただしradar system availabilityとは別。

### 1941–42
- H-6等のradar programが史実相当のrequirement/timingで開いた後、浅井packageをdebug/production/field supportへ投入可能。
- airborne/shipboard radarのresearch startを1930年代へ遡及しない。

### 1942–45
- radar set availability、maintainability、operator fault isolationを改善可能。
- training pipeline、spares、plot/CIC/voice integrationが別律速。
- actual production/deployment/combat effectsはHISTORY/FROZEN。

## 8. 波及裁定

- `asai-works-materials-resin.md`：1935–41電装封止を維持。ただし**封止だけでradio/radar可靠性が閉じる**とは書かない。
- `archive/aviation-pre-v48/v46-main/asai-works-army-fighter-rebaseline-1937-42.md`：Ki-43/Ki-44のradio再投資をv33 packageへ接続。
- `archive/aviation-pre-v48/v46-main/asai-works-zero-operational-1941-42.md`：旧「史実radio一律不良→世界線常用」の断定を弱め、set/installation/fit/historyを分離。
- `archive/aviation-pre-v48/v46-main/asai-works-maritime-patrol.md`：radar方式成熟は前倒ししないが、既存setのavailability改善は許す。1942–43 Q1Yへの実搭載はhistory/requirement gate。
- `archive/aviation-pre-v48/v46-main/asai-works-rotorcraft-1942-plus-rebaseline-1942-55.md`：「radar-assisted」はradarが実際にavailableな母艦/基地/機体に限る。レ号自身への標準機上電探を意味しない。
- radarからCIC、fighter direction、ASW kill chain、fleet outcomeを自動生成しない。

## 9. 外部Hアンカー

- U.S. Naval Technical Mission to Japan, E-18, *Japanese Radio Apparatus Construction Methods*：戦前品の工作は良好、基本構造は商用品延長、temperature/humidity/fungus proofingは量産専門化不足。
- U.S. Naval Technical Mission to Japan, E-15, *Power Supplies for Japanese Electronics*：power-supply designの停滞、機密分業によるsystem integration/acceptance/field-feedback弱さ。
- U.S. Naval Technical Mission to Japan, E-29, *Japanese Electronics Training and Operating Techniques*：教育体系は計画されていたが、戦争後半の量優先で質低下。
- U.S. Naval Technical Mission to Japan, E-02, *Japanese Airborne Radar*：H-6 research 1941-11 / completed 1942-08の較正。
- U.S. War Department, *Tactical and Technical Trends No.46* (1944)：1940年以後の日本airborne radioの工作/材料/水晶制御は良好、一方corrosion/fungus対策・標準化/量産性に弱点。
- NHHC, Battle of Empress Augusta Bay：radar搭載だけでなくoperator trainingが戦闘利用を左右した較正。

## 10. authority / history boundary

本稿が1935–45のradio/radar **reliability/integration**について上位。回路方式、個別setのhistorical performance、sensor research timingは各H資料/既存正本を保持する。

1941-12-08以後のradio/radar実生産、機数/艦数、搭載率、部隊教育、CAP/CIC、探知、撃墜、ASW戦果はFROZEN。v33はtechnical readinessとintegration gateを修正するだけで、戦史を再計算しない。
