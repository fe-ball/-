# CROSS-DOMAIN PREFLIGHT — v27r1

Purpose: prevent semantic omission and accidental promotion of conditional branches. Before dated design/history analysis, scan `CANONICAL-CHRONOLOGY-V27R1.*` and `CAPABILITY-TRIGGER-MATRIX-V27R1.tsv`.

## Mandatory order

1. **Chronology/status** — ordinary current analysis uses `current`/`scope`; `conditional` requires an explicit gate; `superseded` is provenance only; `mixed` requires source inspection.
2. **Requirement owner / historical counterpart** — ask who actually generates the requirement. Do not convert Asai's technology supply into platform omniscience.
3. **Availability R/P/X/N** — distinguish research, productization, external absorption and military/program availability.
4. **Propulsion/energy** — piston boost, diesel turbo, GT, TP/turboshaft, turbojet are separate technologies. Check part-load, installed mass and environment.
5. **Materials/environment** — separate steel/heat-treatment, resin/process, GFRP and CFRP maturity; do not backdate structural composites or treat GFRP as nonflammable.
6. **Mechanisms/controls** — gears, clutches, transmission, shaft/prop/cavitation, cooling, steering/traverse, electrics.
7. **Computation/QC/test** — computation shortens iteration and improves margins/repeatability; it does not create missing requirements or raw-physics bonuses.
8. **Production/maintenance/logistics** — tooling, spares, inspection, field/base/yard infrastructure and actual procurement remain separate gates.
9. **Integration tax / negative gate** — record attractive technology that was checked and rejected.

## v27 TANK-EARLY gate

Current authority is `main/asai-works-tank-early-computation-materials-rebaseline-1928-41.md`.

Do not revive as current:
- Type 89 as a 120hp diesel throughout 1929–34;
- production turbo Type 89;
- Ha-Go 130–145hp as the production central or automatic 20–25mm armor growth;
- Chi-Ha as a later turbo retrofit rather than the worldline 1938 200/220hp production central;
- Shinhoto Chi-Ha 5-crew/3-man-turret worldline specification;
- Chi-He 260hp operational boost, 400mm initial track, powered coarse traverse or standard full-crew voice intercom.

For each early tank, first state the Army/manufacturer requirement independently of Asai. Then ask what turbo/materials/computation/QC actually buy in transmission, cooling, reliability, high-altitude performance, crew workload and production repeatability.

## v27 MARINE-GT-CRAFT gate

Current authority is `main/asai-works-marine-gt-small-craft-rebaseline-1934-43.md`.

Fixed calibration:
- ~20.5t Japanese No.1-class: ~1,800hp / 38–38.5kt / two 45cm torpedoes.
- large T-51 branch is the heavy-boat failure calibration, not the No.1 class.

Conditional only unless its explicit gate is opened:
- ~27t E5 hybrid GT test/high-end boat;
- pure-GT short-range boat;
- ~50t E6 large four-torpedo/long-range boat;
- 1942–43 20–30t GFRP primary-hull demonstrator and any later 50t full-GFRP hull.

Always check: water-tank/hull/trim/sea state, reduction ratio/shaft rpm, prop diameter/blade loading/cavitation/ventilation, salt filtration/MTBO, cruise part-load fuel, reverse/harbor handling, weapons/crew/fuel weight and yard repair. Small-craft success is **not** the sole prerequisite for all naval GT applications.

## v26 aircraft gates retained

Aircraft role/rebaseline authority remains `main/asai-works-aircraft-computation-closure-1937-46.md`. AT-3/Ki-92 and Fugaku development milestones remain conditional. Do not revive B6A Tenzan, Tenzan-bomber→Ryusei, Ki-48TP production, old Ginga seven-seat total-replacement or old carrier-jet density-only speed rows.

## v25 TANK-NEXT gate retained

`main/asai-works-tank-next-generation-conditional-1939-45.md` remains a conditional technical shadow. Actual research authorization, threat-intelligence timing, prototypes, production and deployment are not current history.

## Minimum record

| Family | Result | Reason/source |
|---|---|---|
| chronology / semantic status | CHECKED / GATED-OUT / N/A | source |
| requirement owner / historical counterpart | CHECKED / GATED-OUT / N/A | source |
| propulsion / part-load / fuel / environment | CHECKED / GATED-OUT / N/A | source |
| materials / structure / corrosion | CHECKED / GATED-OUT / N/A | source |
| mechanisms / controls / shaft/prop/transmission | CHECKED / GATED-OUT / N/A | source |
| computation / optics / QC / test | CHECKED / GATED-OUT / N/A | source |
| production / maintenance / logistics | CHECKED / GATED-OUT / N/A | source |
| integration tax / negative gate | CHECKED / GATED-OUT / N/A | source |
