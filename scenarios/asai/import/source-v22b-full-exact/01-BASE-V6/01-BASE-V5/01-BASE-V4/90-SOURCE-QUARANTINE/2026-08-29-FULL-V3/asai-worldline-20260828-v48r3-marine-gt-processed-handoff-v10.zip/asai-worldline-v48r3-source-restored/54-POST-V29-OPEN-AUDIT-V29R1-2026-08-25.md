# v29r1 post-audit OPEN queue

## CLOSED / REBASED
- v29 marine-GT small-craft design closure completed.
- E5 one-GT boost marine-qualification architecture is current; old 2GT+350hp independent-three-shaft central is superseded.
- trial/operating speed, shaft/prop bands, complete installed mass and salt/intake qualification gates are explicit.
- pure-GT normal production central is closed as NO for E5/E6; sprint/test shadow remains conditional.
- E6 50–55t technical shadow is closed as a design envelope but actual procurement/series production remains conditional.
- v28 large-marine, v27 early-tank, v26 aircraft and v25 conditional tank gates remain.

## P1 — next
1. **GFRP small-craft hull structure**: 20–30t laminate/core/adhesive/process, wet/salt exposure, fatigue/slam, damage/repair, mold/cure repeatability; then judge the 50t full-GFRP gate.
2. Historical-fighter H→A / rotorcraft 1942+ / radio-radar reliability / mine-sweeping / survey-artillery meteorology.
3. Submarine battery/motor/yard accounting and optional next-generation 2-cycle integrated propulsion.
4. E8/E9+ later-war propulsion when specifically required.

## CONDITIONAL / HISTORY
- High-speed marine CPP/feathering domestic implementation for 2GT small craft.
- E6 50–55t actual requirement, procurement, series production and any post-1941 operational history.
- Large-ship GT class installations and A-140F5 remain conditional.
- 1941-12-08+ actual OOB/production/deployment/losses/combat/enemy reaction remain FROZEN.
