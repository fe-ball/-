# MACHINE LAYER REFRESH — v34r1

- v33r1 chronology 495 records carried forward.
- v34 adds 14 records: current +10, scope +2, conditional +2.
- Final chronology: **509** records = current 402 / scope 22 / conditional 47 / superseded 34 / mixed 4.
- Main index: **187** canonical files.
- Added separate `MCM` and `ARTY-MET` capability triggers.
- `TIME` / `AVAIL` point to V34R1 chronology/schema.
- GFRP minesweeper adoption remains conditional; post-1941 mine/artillery operational history remains gated.
- source-line/source-hash, TSV/JSONL parity, schema, main-index and trigger-source checks pass.
