#!/usr/bin/env python3
"""E4 recuperated installed-cycle audit for semantic v42.

Uses the v40 E4 cooled installed-cycle accounting and v41 standard mass flow.
Adds recuperator air-side pressure loss upstream of combustor and exhaust-side
backpressure downstream of turbine. Cooling bleed bypasses the recuperator.
Recuperator effectiveness applies to the combustor-bound main air only.

The heat-exchanger mass/volume estimates are design-coordinate scalings, not
historical hardware constants. They are deliberately exposed in the output.
"""
from __future__ import annotations
import csv, math
from pathlib import Path

CP=1.005              # kJ/(kg K)
GAMMA=1.4
R_AIR=287.0           # J/(kg K)
T1=288.0              # K
A=(GAMMA-1.0)/GAMMA
LHV=43000.0           # kJ/kg
MDOT=6.7              # kg/s, v41 E4 standard
PR=4.5
TIT=710.0+273.15
ETA_C_T=.82
DP_COMB=.040
EXHAUST_RATIO=1.015
ETA_MECH=.990
ACC_KJKG=1.0
ETA_COMB=.980
BLEEDS=[
    {'b':.0075,'tap_frac':1.00,'recovery':.85},
    {'b':.0125,'tap_frac':1.00,'recovery':.55},
    {'b':.0060,'tap_frac':.75,'recovery':.15},
    {'b':.0040,'tap_frac':.55,'recovery':.00},
]


def t_comp(pr):
    return T1*(1+(pr**A-1)/ETA_C_T)

def comp_work(pr):
    return CP*(t_comp(pr)-T1)

BTOT=sum(x['b'] for x in BLEEDS)
T2=t_comp(PR)
WC=(1-BTOT)*comp_work(PR)+sum(x['b']*comp_work(PR**x['tap_frac']) for x in BLEEDS)
ENTHALPY_WEIGHT=(1-BTOT)*TIT+sum(x['b']*x['recovery']*t_comp(PR**x['tap_frac']) for x in BLEEDS)


def point(epsilon, dp_air, dp_exhaust, mdot=MDOT):
    # Pressure ratio available to turbine after recuperator cold-side loss,
    # combustor loss and hot-side backpressure.
    rt=PR*(1-dp_air)*(1-DP_COMB)/(EXHAUST_RATIO*(1+dp_exhaust))
    expansion=CP*ETA_C_T*(1-rt**(-A))
    wt=expansion*ENTHALPY_WEIGHT
    wshaft=ETA_MECH*wt-WC-ACC_KJKG

    # Hot-stream temperature coordinate for recuperator sizing uses the main
    # combustion-gas expansion, not the coolant recovery surrogate.
    t_exh=TIT*(1-ETA_C_T*(1-rt**(-A)))
    t2_recup=T2+epsilon*max(0.0,t_exh-T2)
    qfuel=(1-BTOT)*CP*(TIT-t2_recup)/ETA_COMB
    eta=wshaft/qfuel
    sfc=3600/(eta*LHV)
    power=mdot*wshaft
    fuel=power*sfc
    qrec=(1-BTOT)*mdot*CP*(t2_recup-T2)

    # Equal-capacity-rate counterflow approximation for first-order UA.
    cmin=(1-BTOT)*mdot*CP
    ntu=epsilon/(1-epsilon) if epsilon < 1 else float('inf')
    ua=cmin*ntu
    return dict(epsilon=epsilon,dp_air_pct=100*dp_air,dp_exhaust_pct=100*dp_exhaust,
                turbine_effective_PR=rt,T2_K=T2,T_exhaust_in_K=t_exh,T2_after_recup_K=t2_recup,
                wshaft_kJkg=wshaft,shaft_power_kW=power,shaft_eff_pct=100*eta,
                sfc_kg_kWh=sfc,fuel_kg_h=fuel,recovered_heat_kW=qrec,UA_kW_K=ua)

CENTRAL=point(.60,.015,.025)

# Qualification/audit corner envelope, intentionally wider than central design.
CORNERS=[]
for eps in (.50,.70):
  for da in (.010,.025):
    for de in (.015,.040):
      CORNERS.append(point(eps,da,de))

# Heat-exchanger hardware sizing coordinate from central UA.
# Gas-gas overall U range and surface are explicit assumptions for an early,
# robust low-velocity metallic finned/studded tubular recuperator.
UA_W_K=CENTRAL['UA_kW_K']*1000
U_LO,U_C,U_HI=45.0,55.0,70.0
AREA_HI=UA_W_K/U_LO
AREA_C=UA_W_K/U_C
AREA_LO=UA_W_K/U_HI
# Effective metal kg per heat-transfer-area m2, then pressure shell/headers and bypass/duct.
MASS_LO=AREA_LO*2.2 + 280
MASS_C=AREA_C*2.6 + 320
MASS_HI=AREA_HI*3.0 + 400

# Exhaust face-volume coordinate.
p_exhaust=101325*EXHAUST_RATIO*(1+.025)
rho_exhaust=p_exhaust/(R_AIR*CENTRAL['T_exhaust_in_K'])
vdot=MDOT/rho_exhaust
free_area=vdot/22.0
frontal=free_area/.50
core_vol=frontal*.80
installed_vol=core_vol*1.80

# Solve effectiveness needed for 25% shaft efficiency at central losses.
def eff_at_eps(eps): return point(eps,.015,.025)['shaft_eff_pct']/100
lo,hi=0.0,.999
for _ in range(80):
    mid=(lo+hi)/2
    if eff_at_eps(mid)<.25: lo=mid
    else: hi=mid
eps_for_25=hi

# Flow required for 475 kWe at 95% generator efficiency using central recuperated specific work.
required_shaft=475/.95
mdot_475=required_shaft/CENTRAL['wshaft_kJkg']

rows=[]
rows.append({'case':'central','value':CENTRAL})
rows.append({'case':'audit_envelope','value':{
    'shaft_power_kW_low':min(x['shaft_power_kW'] for x in CORNERS),
    'shaft_power_kW_high':max(x['shaft_power_kW'] for x in CORNERS),
    'shaft_eff_pct_low':min(x['shaft_eff_pct'] for x in CORNERS),
    'shaft_eff_pct_high':max(x['shaft_eff_pct'] for x in CORNERS),
    'sfc_kg_kWh_low':min(x['sfc_kg_kWh'] for x in CORNERS),
    'sfc_kg_kWh_high':max(x['sfc_kg_kWh'] for x in CORNERS)}})
rows.append({'case':'hardware_coordinate','value':{
    'heat_transfer_area_m2_low':AREA_LO,'heat_transfer_area_m2_central':AREA_C,'heat_transfer_area_m2_high':AREA_HI,
    'recuperator_system_mass_kg_low':MASS_LO,'recuperator_system_mass_kg_central':MASS_C,'recuperator_system_mass_kg_high':MASS_HI,
    'exhaust_density_kg_m3':rho_exhaust,'exhaust_volume_flow_m3_s':vdot,
    'central_core_volume_m3':core_vol,'central_installed_hotpath_volume_m3':installed_vol,
    'canonical_installed_volume_band_m3_low':1.4,'canonical_installed_volume_band_m3_high':2.5}})
rows.append({'case':'derived_gates','value':{
    'epsilon_required_for_25pct_shaft_eff':eps_for_25,
    'mdot_required_for_475kWe_at_95pct_generator_kg_s':mdot_475,
    'central_generator_output_kWe_at_95pct':CENTRAL['shaft_power_kW']*.95,
    'central_electrical_sfc_kg_kWh':CENTRAL['fuel_kg_h']/(CENTRAL['shaft_power_kW']*.95)}})

# Flat TSV with useful columns.
out=Path(__file__).with_name('E4-REGENERATION-INSTALLED-V42.tsv')
fields=['case','epsilon','dp_air_pct','dp_exhaust_pct','shaft_power_kW','shaft_eff_pct','sfc_kg_kWh','fuel_kg_h','recovered_heat_kW','UA_kW_K','notes']
with out.open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter='\t'); w.writeheader()
    w.writerow({**{k:CENTRAL.get(k,'') for k in fields},'case':'central',
                'notes':'E4 6.7 kg/s; epsilon .60; air dp 1.5%; exhaust dp 2.5%'})
    w.writerow({'case':'audit-low','shaft_power_kW':min(x['shaft_power_kW'] for x in CORNERS),
                'shaft_eff_pct':min(x['shaft_eff_pct'] for x in CORNERS),'sfc_kg_kWh':max(x['sfc_kg_kWh'] for x in CORNERS),
                'notes':'corner envelope epsilon=.50-.70, air dp=1.0-2.5%, exhaust dp=1.5-4.0%'})
    w.writerow({'case':'audit-high','shaft_power_kW':max(x['shaft_power_kW'] for x in CORNERS),
                'shaft_eff_pct':max(x['shaft_eff_pct'] for x in CORNERS),'sfc_kg_kWh':min(x['sfc_kg_kWh'] for x in CORNERS),
                'notes':'corner envelope epsilon=.50-.70, air dp=1.0-2.5%, exhaust dp=1.5-4.0%'})
    w.writerow({'case':'hardware','notes':f'area {AREA_LO:.0f}-{AREA_HI:.0f} m2 central {AREA_C:.0f}; recuperator+headers+bypass/duct {MASS_LO:.0f}-{MASS_HI:.0f} kg central {MASS_C:.0f}; installed hotpath 1.4-2.5 m3'})
    w.writerow({'case':'gates','notes':f'epsilon for 25%={eps_for_25:.3f}; 475 kWe@95% requires mdot={mdot_475:.2f} kg/s; central generator={CENTRAL["shaft_power_kW"]*.95:.1f} kWe'})

if __name__=='__main__':
    for r in rows: print(r)
