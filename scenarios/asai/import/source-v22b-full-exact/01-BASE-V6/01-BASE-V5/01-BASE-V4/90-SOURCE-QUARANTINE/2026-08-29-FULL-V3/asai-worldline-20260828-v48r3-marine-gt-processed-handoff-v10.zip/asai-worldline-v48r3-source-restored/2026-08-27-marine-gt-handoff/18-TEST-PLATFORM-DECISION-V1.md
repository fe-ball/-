# Marine GT test-platform decision V1 — 2026-08-27

Status: working adoption decision derived from the historical/technical crosswalk. This is the first pass that chooses a central test architecture; it does not name a canonical engine model beyond existing E-generation/product authorities.

## 1. Early old-hull program: choose Momi / 廃駆二号

Historical availability is now closed: Momi left the active Navy List on 1932-04-01 and remained a disposal/test destroyer through 1936. That window overlaps E4 product maturity, the 1934 Navy/Asai marine-GT joint trial start, E5 research/completion, and the 1935–36 salt/filter/reduction/clutch land program.

Central working decision:

- **1934:** instrument the hull/shafting and use her as a marine environment / intake / exhaust / control / clutch test platform, initially at modest E4-class power rather than pretending E4 is a destroyer main plant.
- **1935–36:** use the same hull as the sea-side integration platform for an E5-derived enlarged demonstrator if the relevant land-rig gate passes. The purpose is not fleet speed; it is salt ingestion, filter pressure loss, hot restart, free-power/reduction behavior, clutch transient, lubrication, vibration, exhaust routing and inspection repeatability.
- Existing steam machinery can remain the safe-return/astern path where practicable. The experimental GT path need not replace the entire propulsion plant.

This choice has low opportunity cost because the historical hull was already a trial hulk, and it avoids inventing a new warship solely to generate early sea hours.

## 2. Dedicated new-build propulsion test ship: do not make it the prewar central path

A purpose-built 700–1,000 t propulsion test ship is technically useful but not necessary to open E4/E5 marine qualification. Before 1937 it duplicates a historical trial hull plus land-rig capability; after 1938 the rapidly changing E6 scale bands risk freezing an expensive hull around the wrong reducer/shaft geometry.

Central working decision:

- **1934–36 dedicated new-build:** NO / RETIRED AS CENTRAL.
- **1937–41 new-build laboratory ship:** CONDITIONAL only if a later E6-large-B/C program demonstrates that no available auxiliary/obsolete hull can accept the required intake, exhaust, reduction and shaft loads.
- Prefer modular shore rigs and opportunistic auxiliary/obsolete-hull sea trials before consuming a scarce new-build slip.

## 3. What Momi does not prove

Momi sea hours do not automatically qualify:

- E6 hot-section life;
- 50+ kg/s large cores;
- carrier-scale multiple-unit reduction trains;
- class-wide destroyer/cruiser adoption;
- a 1941 large-MTB procurement decision.

Each of those remains a later scale/application gate. The value of Momi is that it closes the otherwise-missing **1934–36 real seawater/ship-integration loop** at the least historical cost.

## 4. Current status changes

- `Momi/樅 old-hull test bed`: **OPEN -> WORKING-CENTRAL / ADOPT FOR PROCESSING**.
- `Dedicated new-build propulsion test ship`: **OPEN -> CONDITIONAL / NOT CENTRAL BEFORE 1941**.
- `Earlier E4/E5 test craft history`: partially closed by splitting it into (a) Momi old-hull marine integration and (b) later small high-speed E5 qualification craft; these are different experiments and can coexist.
