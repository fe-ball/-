# 計算追加層 2026-08-22

> **computation-integrated-v4で正本へ昇格済み**：01–04の採用内容は `main/asai-works-computation-*.md` へ統合された。本ディレクトリは入力スナップショットとして保持する。以後、競合時は `main/` を優先。

このディレクトリは2026-08-20の `provisional-2026-08-20/` と、その後の会話で固まった計算史を統合する作業層。`main/` を自動上書きしない。

- `prior-v2/` — 以前の計算追加v2の計算ファイルをそのまま保存
- `01-origin-business-and-product-lines.md` — 企業起源・Tiger・カード・商売
- `02-ferrite-cipher-magnetic-memory.md` — フェライト、TDK、暗号、磁気記憶
- `03-machines-1923-1945-and-center-ecology.md` — 最大機と実際の計算センター
- `04-aircraft-computation-bridge.md` — 航空設計への接続

