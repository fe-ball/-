# MACHINE LAYER REFRESH — v33r1

- Carry forward v32r1 chronology and all inherited semantic gates.
- Add v33 radio/radar reliability authority, environmental/process readiness, power/EMI, radar timing, training and history-boundary records.
- Add `ELEC-RR` trigger.
- Current machine pointers move to V33R1.
- No post-1941 history is promoted.

Final machine counts: chronology 495; main index 185; semantic-status counts current=392 / scope=20 / conditional=45 / superseded=34 / mixed=4.
