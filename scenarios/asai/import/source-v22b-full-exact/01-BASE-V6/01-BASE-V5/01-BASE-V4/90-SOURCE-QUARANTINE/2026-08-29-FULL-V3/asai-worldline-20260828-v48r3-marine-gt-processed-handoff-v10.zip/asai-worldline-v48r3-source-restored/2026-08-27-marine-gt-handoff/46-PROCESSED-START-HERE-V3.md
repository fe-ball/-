# Marine GT processed handoff V3 — START HERE — 2026-08-28

## State

Base semantic authority remains **v48 / machine v48r3**. V3 is a processing overlay. It preserves V2's separation of TECHNICAL / DEMONSTRATED / OPPORTUNITY / SELECTED and adds an upstream research-to-product and naval-design baseline.

## Read order

1. package-root `CURRENT-CANONICAL-STATE.md`.
2. `33-DECISION-FRAMEWORK-REFRAME-V2.md` — downstream decision layers remain authoritative.
3. `45-UPSTREAM-REFRAME-NOTES-V3.md` — V3 method correction.
4. `40-RESEARCH-TO-PRODUCT-STAGE-LEDGER-V3.tsv` — current upstream development-stage authority for this handoff.
5. `41-E4-E6-INHERITANCE-LEDGER-V3.tsv` — what E4/E5/diesel-turbo/industrial experience actually prepays for E6/marine.
6. `42-NAVAL-DESIGN-PROCUREMENT-BASELINE-V3.tsv` — computation culture, design dividend, rework, freeze/preplanning rules.
7. `44-UNIT-POWER-DEMAND-SEED-V3.tsv` — current demand evidence used to regenerate large-core choices.
8. `43-MARINE-GT-REWORK-QUEUE-V3.tsv` — ordered closure queue.
9. `34-MARINE-GT-LAYERED-DECISION-MATRIX-V2.tsv` — downstream adoption status remains current unless a later V3 file explicitly changes an upstream premise.
10. `47-MARINE-GT-PRECEDENCE-OVERLAY-V3.tsv` — precedence map.
11. `48-PROCESS-STATE-V3.json` and `49-PROCESS-VALIDATION-REPORT-V3.txt`.

## Important corrections now in force

- Future knowledge may start research clocks early; it does not automatically create products or unrun qualification hours.
- Legacy `E5-S marine 1,300 hp` is not a valid current S-core rating. Rebuild the qualification craft around ~1,000 hp standard E5-S or ~1,130 hp E5-S-HF sensitivity unless a separate M-scale core is explicitly justified.
- A 9–12 kg/s E5 M-scale research program is plausible and useful as E6-M prepayment, but an `E5-M product` is not assumed.
- V1 E5/E6 large-A/B/C rows are arithmetic analysis classes. Their old derived availability dates are not current product dates.
- Exact >13.2 kg/s full-core choices must be regenerated from named demand, duty, quantity, timing, reducer, and installation requirements.
- Naval computation effects are split into planned design dividend (often reinvested in quality) and unplanned rework reduction (cleaner schedule/cost saving). No blanket shipbuilding speed multiplier is permitted.
- A conversion opportunity may be pre-planned before dock entry if the technology was already a credible candidate; hindsight reservations are prohibited.

## Next action

Start with P0 rows in `43-MARINE-GT-REWORK-QUEUE-V3.tsv`: repair the E5 marine qualification craft, determine the E5 M-scale R2 history, regenerate unit-power demand, and replace the binary large-gear gate with a reducer/torque ladder. Only then rebuild the yearly marine demonstration ladder and revisit platforms.
