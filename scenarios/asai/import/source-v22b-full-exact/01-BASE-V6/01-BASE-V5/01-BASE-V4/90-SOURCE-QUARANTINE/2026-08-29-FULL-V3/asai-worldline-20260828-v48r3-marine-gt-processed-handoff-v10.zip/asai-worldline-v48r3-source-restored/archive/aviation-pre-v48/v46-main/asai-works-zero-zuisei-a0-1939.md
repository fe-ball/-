# superseded redirect

本稿はv11で `asai-works-a6m1-12shi-1939.md` へ名称規則込みで移行した。技術内容は新稿を正準とする。旧 `A0-Z/Z900/Z940` は内部監査ラベルとしてのみ残す。
