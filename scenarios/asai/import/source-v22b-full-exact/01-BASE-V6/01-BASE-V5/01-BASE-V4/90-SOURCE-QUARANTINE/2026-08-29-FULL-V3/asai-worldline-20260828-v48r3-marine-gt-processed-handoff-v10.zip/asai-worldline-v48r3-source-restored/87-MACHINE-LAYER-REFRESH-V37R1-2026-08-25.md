# MACHINE LAYER REFRESH — v37r1

Status: **COMPLETE**.

v37r1 carries v34r1 forward, reconstructs the cumulative v35/v36 semantic deltas, and adds the v37 E8/E9+ propulsion rebaseline.

Final machine state:
- chronology: **545 records** = 509 v34r1 + 13 v35 + 9 v36 + 14 v37;
- semantic statuses: **current 424 / conditional 53 / superseded 39 / scope 25 / mixed 4**;
- canonical `main/`: **190 files**;
- manifest: **502 files** excluding `SHA256SUMS.txt` itself.

v35 machine gates separately encode ordinary-large-lead-battery architecture, 1–2 hull-equivalent engineering-set scale, motor one-hour thermal rating versus battery high-rate endurance, full-bank acceptance, yard critical path and HISTORY/FROZEN procurement.

v36 machine gates separately encode 31号6型 and 22号10型 historical anchors, the absence of an engine-output requirement gap, integrated 2-cycle central production GATED-OUT, conditional design/land-test work and requirement-based reopening.

v37 machine gates separately encode paid E7 foundation, E8 high-end practical rating, gross versus cooled installed-core comparison, compressor architecture, hot-section/material/endurance gates, E9 current component/rig technical front, conditional flight/series rating, generation/core-scale separation, installed-turbojet accounting, conditional single-engine convergence and HISTORY/FROZEN procurement.

Inherited chronology rows `CHR-0286`, `CHR-0292`, `CHR-0293`, `CHR-0294`, `CHR-0295` are explicitly **superseded** so old Ni/calendar/dry-thrust/E9-generation shortcuts cannot remain current by retrieval accident.

`tools/validate_machine_layer.py` now validates v37r1 filenames and counts, chronology source hashes and JSONL parity, main-index coverage/hashes, capability-trigger sources, current human pointers, cumulative v35/v36/v37 semantic gates, old-E8/E9 demotion, manifest coverage and file hashes.
