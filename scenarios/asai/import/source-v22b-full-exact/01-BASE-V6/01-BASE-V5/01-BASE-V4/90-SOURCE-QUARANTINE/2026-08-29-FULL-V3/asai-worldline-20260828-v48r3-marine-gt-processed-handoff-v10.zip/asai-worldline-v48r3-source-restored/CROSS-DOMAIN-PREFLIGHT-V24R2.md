# CROSS-DOMAIN PREFLIGHT — v24r2

Purpose: prevent semantic omission during design/history review. This is a recall gate, not a new worldline conclusion. Before evaluating a platform, retrofit, production choice, or historical consequence, scan the chronology and trigger matrix and mark each relevant family `CHECKED`, `GATED-OUT`, or `N/A`.

## Mandatory order

1. **Chronology first** — query `CANONICAL-CHRONOLOGY-V24R2.tsv` / `.jsonl` for the date and domain.
2. **Availability semantics** — use `main/asai-works-product-availability-ledger-1903-41.md` where R/P/X/N stages matter.
3. **Propulsion/energy** — distinguish piston boost, diesel turbo, submarine 2-stroke scavenging, independent GT, TP/turboshaft, turbojet; check fuel/storage.
4. **Materials/wet environment** — steel/heat treatment, epoxy sealing, plant FRP, GFRP, CFRP; for wet use check drainage, corrosion, repair, exposure and inspection, not weight alone.
5. **Mechanisms/controls** — gears, bearings, propeller, cooling, steering, turret/servo, electrics/EMI, battery/motor.
6. **Computation/QC/test** — central computation versus limited-purpose onboard devices; check transducers, display/servo, power, ruggedness, maintenance and test attribution.
7. **Production/maintenance/logistics** — tooling, inspection, spares, crew training, transport, mother-platform handling.
8. **Integration tax and negative gate** — explicitly record attractive technologies that are too early, unsuitable, unnecessary, or superseded.

## v24 omission traps

### “Turbo” is not one technology

Aircraft piston exhaust supercharging, 1930s diesel turbo, submarine two-stroke scavenging, independent GT, turboprop/turboshaft and turbojet remain separate branches. For long-range TP aircraft, **also trigger `TP-PARTLOAD`**: design-point BSFC must not be extended unchanged to low load.

### “FRP” is not one material

Separate epoxy/process, plant-fiber FRP/sandwich, GFRP, CFRP and propeller branches. Availability year and wet/heat/inspection gates matter.

### “計算機” is not only the central machine

Fire-control, bombing/torpedo aiming, navigation, trim, battery/motor management may use mechanical/electromechanical/relay/vacuum-tube dedicated devices before general computers. Do not assume a miniature stored-program machine.

### Water aircraft / amphibious systems are integration problems

For seaplanes/flying boats, use `main/asai-works-seaplane-flyingboat-rebaseline-1940-44.md`. For Seiran/I-400 use its dedicated integration file. For landing craft use `main/asai-works-amphibious-landing-system-1938-44.md`. Sealing, drainage, hydrodynamics, propulsor, handling and mother-platform constraints must be checked together.

### Tanks are a powertrain + human-processing system

For Chi-Ha/Chi-He and descendants, trigger `TANK-COMP`: do not convert extra horsepower directly to top speed or armor. Check engine map, gear ladder, cooling, transmission/final drive, track slip, observation, radio/intercom, turret traverse and first-shot cycle.

### Torpedo headline performance is not the primary dividend

For Type 93/95/91, trigger `TORPEDO-AIR`: prefer dispersion, depth/heading settling, water-entry envelope, production tolerance and aiming workload. Actual hit rates remain history-side.

## Minimum record

| Family | Result | Reason/source |
|---|---|---|
| chronology / availability | CHECKED / GATED-OUT / N/A | source |
| propulsion / part-load / fuel | CHECKED / GATED-OUT / N/A | source |
| materials / wet environment | CHECKED / GATED-OUT / N/A | source |
| mechanisms / controls / propeller | CHECKED / GATED-OUT / N/A | source |
| electrical / battery / EMI | CHECKED / GATED-OUT / N/A | source |
| computation / optics / QC / test | CHECKED / GATED-OUT / N/A | source |
| production / maintenance / logistics | CHECKED / GATED-OUT / N/A | source |
| integration tax / negative gate | CHECKED / GATED-OUT / N/A | source |

Machine-readable companion: `CAPABILITY-TRIGGER-MATRIX-V24R2.tsv`.


## v24r2 chronology status gate

Before using a chronology hit, filter `semantic_status`. Ordinary current analysis uses `current` and `scope`. `superseded` is provenance/A_old only. `mixed` means the source row contains both a still-usable fact and a superseded fragment; inspect the cited source line before using the affected claim. Rotorcraft queries trigger `ROTOR`; aircraft comparison and Kaifu/old retrofit tables trigger `AIR-REBASE`.
