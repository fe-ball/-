# v28 水上艦船型・大型舶用 再基底化

## 判定

**TECHNICAL BASELINE REBASED / CAPITAL-SHIP DIESEL DECISION CLOSED / LARGE-SHIP GT PROCUREMENT CONDITIONAL。**

### 主な訂正
- 13号6型を「大型ディーゼル失敗」と一括しない。史実は480×600 mm、350 rpm、4,800 PS級、144時間耐久完走、95点以上。
- 13号の残余問題を、排煙・リング折損・ライナ/ピストン摩耗という**技術3点**と、13号就航実績欠如・11号系列故障歴という**採用リスク2点**へ分離。
- 浅井計算/QCは技術3点を早く潰せるが、1937年春までの実艦就航履歴は生成できない。大和A-140F6全タービンを中央維持し、F5混載はconditional branch。
- 大鯨11号改善→大和ディーゼル採用、という自動因果を閉鎖。
- 大型舶用GTでは**自由動力タービン≠逆転装置**を明文化。後進はCPP/逆転歯車/電気伝達/基礎主機側が必要。
- 駆逐・巡洋・空母のGT増速／予備動力は技術候補として残すが、個別搭載・改装・量産は吸排気、減速/軸、塩MTBO、installed mass、艦政要求を通るまでconditional。

current親=`main/asai-works-surface-ship-large-marine-rebaseline-1934-41.md`。

次のP1は **GT小型艇 design gates**。
