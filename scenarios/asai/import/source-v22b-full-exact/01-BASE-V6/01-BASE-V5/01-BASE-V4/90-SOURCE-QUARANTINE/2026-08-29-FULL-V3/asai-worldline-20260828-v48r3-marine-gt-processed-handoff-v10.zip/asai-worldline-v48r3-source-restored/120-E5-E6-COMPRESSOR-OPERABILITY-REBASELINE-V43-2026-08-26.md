# 120 — E5/E6 compressor operability rebaseline — v43

v43 closes the main P1-3 compressor-operability gate without yet propagating aircraft/ship adoption effects.

Central decisions:

- E5-S PR6: **5 axial + 1 centrifugal**, 7.6 kg/s standard, axial PR≈2.19 / centrifugal PR≈2.74, 17.5 krpm / ~455 m/s.
- E5 start/control: fixed IGV + stage-3 bleed; steady surge-flow margin >=13%, transient >=10%.
- E6-S PR7: **7 axial + 1 centrifugal**, design 7.8 kg/s, 18 krpm / ~471 m/s; VIGV + stage-4 bleed.
- E6-M PR7: **14 axial**, average stage PR≈1.149, design 13.2 kg/s / full-speed trim 12.5–14.0 kg/s, 13.5 krpm.
- E6-M old **10 kg/s TP exact core coordinate is superseded**; jet 14 kg/s is retained as a high-flow trim. E6 shaft-power products require a later installed-cycle audit.
- E4-R 7.16 kg/s is compressor-side **ACCEPT** as a distinct ~7.2 kg/s S-HF trim; standard 6.7 product is unchanged.
- E5-S-N ~1,130 hp / ~8.08 kg/s is compressor-side **ACCEPT** as E5-S-HF; standard headline remains 1,000 hp.
- E5 marine 1,300 hp / ~9.29 kg/s remains **REJECT as S-core / CONDITIONAL downstream**.
- E4-R exact part-load bypass crossover is retained as a 30–45% load calibration band, not a single canonical SFC point.

Canonical parent: `main/asai-works-e5-e6-compressor-operability-rebaseline-1934-41.md`.
Reproducible computation: `computation-2026-08-22/e5_e6_compressor_operability_v43.py` / `E5-E6-COMPRESSOR-OPERABILITY-V43.tsv`.
