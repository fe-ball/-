# Marine GT V4 — numeric derivation discipline

## Purpose

This overlay tightens how future knowledge, computation culture, historical anchors, and numerical derivations are allowed to enter the marine-GT reconstruction. It does not weaken the protagonist's advantages; it prevents both accidental historical-copying and unexplained "cheat multipliers".

## Source classes

- **W-CLOSED** — a value already closed by the current worldline semantic authority (v48) or a current accepted rebaseline. It may be used as an input.
- **W-DERIVED** — deterministic arithmetic from W-CLOSED inputs. The formula and inputs must be recorded.
- **W-CHOICE** — a design/program choice made by Asai/Navy/yard for an explicit reason. It can choose a branch, rating, test order, redundancy, or allocation of margin; it is not itself a physics gain.
- **W-TEST** — a capability that requires an actual rig, sea run, endurance clock, material clock, or qualification result. Future knowledge may start the clock early and choose the right test, but may not mark the result passed before the test exists.
- **H-BASE** — historical Japanese/industrial hardware or process that is part of the worldline's inherited starting state. It may define the baseline from which Asai changes things.
- **H-SANITY** — a foreign, later, or merely similar machine used only to check order of magnitude. It may not set the central worldline value or calendar date by itself.
- **SENS** — a sensitivity point. It is not a selected design.
- **OPEN** — insufficient worldline evidence. Do not fill the gap with a generic percentage or an analogue.

## Rules for the protagonist's future knowledge

1. Future knowledge can identify the useful direction, skip known dead ends, start long clocks early, order experiments by information value, and preserve options before a customer formally asks.
2. It cannot create future materials, future factories, unrun creep/endurance hours, or an unexplained efficiency/power/life multiplier.
3. A claimed improvement by direct Asai tuning must be decomposed into named losses or margins (matching, inlet, combustor, control, gear, packaging, process yield, etc.). If the component ledger does not support the gain, leave it unclaimed.
4. Internal strategic demand may justify R0/R1 and, when information value is high, a small number of R2 demonstrators. It does not automatically justify a product line, production tooling, inventory, or Navy selection.
5. Computation reduces the number of bad physical experiments and improves experiment design. It does not remove unknown coefficients or replace all full-scale validation.
6. Historical foreign/later machines may remain as H-SANITY checks. They must not be used as a shortcut to choose worldline installed mass, propeller rpm, gearbox date, or product rating when worldline-specific inputs exist or are still OPEN.

## Consequence for current marine work

- E5 1,000 hp, E5-S-HF ~1,130 hp compressor feasibility, E6-M 13.2 kg/s / 2,100 hp flat rating, and ~2,300 hp marine short are W-CLOSED upstream values.
- The old E5 marine 1,300 hp is not W-CLOSED and remains superseded.
- The v29 small-craft `E5 2.8–3.4 kg/kW / E6 2.2–2.8 kg/kW` complete-installation bands were set mainly from a later Gatric comparison. They are therefore **H-SANITY**, not V4 central worldline mass coordinates. Marine-specific mass must be rebuilt from the current Asai engine/package ledger plus explicitly itemized marine additions.
- Likewise, exact propeller diameter/rpm bands imported from later US PT comparisons are H-SANITY until the worldline hull/shaft/prop calculation closes them. Crouch values remain first-order SENS only.
- The inherited Japanese First Type itself closes a local Crouch baseline: 20.5 t / 1,800 hp / 38–38.5 kt gives **C=4.055–4.109** (midpoint 4.082). Values such as 4.2–4.5 that were broadened with foreign boats are not a worldline central baseline; they are SENS until tank/sea testing earns them.
- The current E5 1,000 hp assembly mass **390–460 kg** (core + power turbine + reducer + accessories) is a W-CLOSED base. Marine separator/intake, exhaust, one-way clutch placement, marine accessory delta, mount/structure and test instrumentation must be itemized; the old complete-installation kg/kW bands cannot fill those rows.

Authority inputs: `main/asai-works-capability-convergence-framework-1903-45.md`; `main/tensei-engineer-kufu-shu.md`; `main/asai-works-product-availability-ledger-1903-41.md`; `main/asai-works-engine-capability-core-e1-e9.md`; V3 upstream ledgers.
