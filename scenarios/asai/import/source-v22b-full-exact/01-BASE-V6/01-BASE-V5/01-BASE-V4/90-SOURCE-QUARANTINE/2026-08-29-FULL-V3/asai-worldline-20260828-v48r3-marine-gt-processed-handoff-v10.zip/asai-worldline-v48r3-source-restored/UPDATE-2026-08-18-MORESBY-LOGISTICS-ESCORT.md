# UPDATE 2026-08-18 — Port Moresby personnel / logistics / escort

この更新は、5/10 Port Moresby連合側在地人員の再集計と、5/12占領後の日本側補給・護衛・監視baselineを反映する。

## 主変更

1. `26-MO-PORT-MORESBY-LANDING-CANON-1942-05-09-12.md`
   - 旧「約5,000守備隊」をAustralian-command ground component約5,300として再定義。
   - U.S. Army / USAAF / RAAF等を加え、5/10 military/armed presenceを7,115 ≒ 7,100へ更新。
   - KIA/dead約390、POW約3,590、war-duration hard loss約4,000、30-day hard unavailable約5,100の非重複status ledgerを追加。
   - 人物単位の死亡・未脱出者を残差法で作らないルールを追加。

2. `27-PORT-MORESBY-BASING-ATTRITION-CANON-1942-05-12-06-30.md`
   - 通常航空作戦月のdestination inflowを6〜9kt/month、中央7.5ktへ整理。
   - 重量比sea 94 / air 5 / mountain 1を追加。
   - 5/12〜6/30 Japanese occupation attrition、aircraft / shipping loss baselineを追加。
   - Allied loss ledgerを7,100母数へ更新。

3. `28-MORESBY-LOGISTICS-ESCORT-INTERDICTION-BASELINE-1942-05-12-08.md` 新規
   - Rabaul / Lae / Moresby / Buna-Kokoda / Deboyneの役割分担。
   - 海運、航空輸送、Owen Stanley山岳連絡の能力・用途。
   - 2 convoys/month、old DD1 + small escort2のroutine escort。
   - South Seas Area escort pool DD2 + small4〜6。
   - Deboyne water recon、Moresby Ka-go/local ASW、convoy CAP、Louisiades lookout posts。
   - protection overhead 0.5〜0.8kt/month equivalent。
   - 7〜8月阻止戦を detection → attack opportunity → success → cargo loss で判定する枠組み。

4. `00-README-CURRENT.md` / `01-CURRENT-CANON-AND-STATUS.md`
   - 現在地点と次判定を更新。

## 次の判定

`28` の日本側baselineに対し、1942年7〜8月のAllied submarine / bomber / reconnaissance / radio-intelligence pressureを週または船団単位で適用し、cargo loss、escort loss、airfield damage、stockpile trendを算出する。

- Current package checksums: `SHA256SUMS.txt` and `SHA256SUMS-CONTINUATION-2026-08-18.txt`.
