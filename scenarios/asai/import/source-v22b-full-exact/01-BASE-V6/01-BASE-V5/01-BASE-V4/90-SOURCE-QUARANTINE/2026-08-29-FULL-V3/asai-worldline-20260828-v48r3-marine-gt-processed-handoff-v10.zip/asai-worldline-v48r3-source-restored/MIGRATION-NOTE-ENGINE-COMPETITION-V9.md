# Migration note — engine-competition-v9 (2026-08-23)

v8を完全保持し、1937–41の瑞星/栄競争を発動機EH→EAで正本化した。

## New canonical files
- `10-ENGINE-COMPETITION-ZUISEI-SAKAE-P0-2026-08-23.md`
- `main/asai-works-engine-competition-zuisei-sakae-1937-41.md`

## Canonical changes
- 史実A6M1用瑞星、Ha-26-I級900 hp枝、Ha-26-II級940 hp枝、初期二速瑞星試作、Ha-102/瑞星21を分離。
- 1939世界線零戦の瑞星開発母機はZ-900Nを中央、Z-940Nを後続候補。
- 初期二速瑞星は耐久未合格を維持し、EC/EMQで自動救済しない。
- 1940零戦主力EAは栄12を中央採用。A0-S 543–550 km/h級を維持。
- 瑞星はA0-Z試験/予備枝として継続し、零戦顧客を失わない。
- 1941はZ21N vs S21を再競争。Ha-102/瑞星21と栄21の出力重量比はほぼ同等で、機体Iまで未決。
- 瑞星vs栄のexact BSFC差は未正準。栄の低燃費という定性錨だけ採る。
- `aviation-rework` の「瑞星零戦が空母試験に落ちたため栄換装」という過強な因果を修正。

## Not changed yet
- A0-Z完成機速度/重量/冷却。
- 1941 S21 vs Z21Nの最終勝敗。
- 初期二速瑞星の具体故障部位。
- 工場月産能力/補給分割。
