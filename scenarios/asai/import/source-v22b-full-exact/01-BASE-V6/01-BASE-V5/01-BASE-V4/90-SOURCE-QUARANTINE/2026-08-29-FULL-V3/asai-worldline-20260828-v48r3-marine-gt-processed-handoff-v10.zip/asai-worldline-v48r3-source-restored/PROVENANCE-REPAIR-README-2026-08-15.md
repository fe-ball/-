# 2026-08-15 provenance修復パッケージ

## 内容

- `main/`：2026-08-14 mainを基準に、旧supplemental 21〜45へ残った途中式のうち現行mainが実質依存するものだけを再認証・統合した修正版。
- `main/asai-works-validated-derivations-2026-08-15.md`：再現可能な途中式、包含関係、VALIDATED/UPDATED/SUPERSEDED判定。
- `MERGE-RECOMMENDATIONS-2026-08-15.md`：main側へ何をどうマージしたか／戻さなかったか。
- `asai-supplemental-reverse-index-20260815-v2.md`：main→旧supplementalの逆引き索引。

## 運用原則

旧supplemental 21〜45は履歴資料。今後の正準値・途中式の生参照先にはしない。

歴史WIP・戦争結果・旧名称案は復活させていない。科学・算数で再現できる導出と、世界線モデルとして現在も必要な入力だけを救出した。

## 主な実質修正

- レシプロ改修の包含関係を復元。零戦21型548〜552 km/hは、表面仕上げ＋純排気推力＋給排気/冷却/カウル整理を含む標準改修最終帯であり、排気やパテを再加算しない。
- 後期レシプロは1941級改善札を単純加算しない。
- 銀河航続をBreguet式で再認証。
- E系燃料需要・航空生産能力の算数を再認証。
- 特殊潤滑油は旧43の機種別率から再計算し、サービス消費14〜17 t/月、物流計画18〜22 t/月へ更新。
- 旧supplementalの生きた参照を `asai-works-validated-derivations-2026-08-15.md` へ置換。
