# MIGRATION NOTE — SUBMARINE SERIES V19

- Base: v18 submarine-aircraft.
- Added `main/asai-works-submarine-series-1938-41.md` and summary `18-SUBMARINE-SERIES-P0-1938-41-2026-08-23.md`.
- Closed 1938–41 KD7 / Type A1 / B1 / C1 design-role audit.
- No battle-history/OOB changes.
- Initial A/B/C retain Kampon Type 2 Model 10; Type 1A Model 10 becomes an earlier follow-on comparison, not a retroactive replacement.
- Aviation equipment retained on A/B, not added to C; E14Y envelope remains v18.
- Exact dive seconds intentionally not canonized without common-definition primary/trial data.
