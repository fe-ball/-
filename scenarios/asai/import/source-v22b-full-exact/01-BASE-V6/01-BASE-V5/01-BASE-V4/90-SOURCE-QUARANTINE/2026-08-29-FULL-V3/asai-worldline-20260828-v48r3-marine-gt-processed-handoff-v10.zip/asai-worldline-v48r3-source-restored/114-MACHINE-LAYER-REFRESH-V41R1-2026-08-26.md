# 114 — Machine-layer refresh v41r1 — 2026-08-26

v41r1 refreshes the machine layer after the E4/E5 product mass-flow / size rebaseline.

- chronology: **608 records** (`CANONICAL-CHRONOLOGY-V41R1.tsv` / `.jsonl`)
- main canonical files: **196**
- status partition: **current 464 / conditional 63 / superseded 43 / scope 29 / mixed 9**
- new v41 chronology delta: CHR-0595..0608
- v40 E4/E5 resize gates CHR-0591/0592: superseded by v41 product closure.
- v29 E5 one-GT marine architecture row CHR-0440: conditional because its 1,300 hp rating exceeds standard 7.6 kg/s E5-S capability; architecture/method remains a downstream rebaseline input.
- legacy E5 ~1,000 hp aircraft rows remain conditional only at the **platform installation/performance** layer; the engine product itself is now size-closed.

Current recall layer:
`CURRENT-CANONICAL-STATE.md` → `CANONICAL-MAIN-INDEX-V41R1.tsv` → `CANONICAL-CHRONOLOGY-V41R1.tsv` → `CROSS-DOMAIN-PREFLIGHT-V41R1.md` → `CAPABILITY-TRIGGER-MATRIX-V41R1.tsv`.
