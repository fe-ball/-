# 96 — Early Hot-Section Materials Test Program / v38 DRAFT

> Status: DRAFT / not yet canonical. v37r1 remains the checkpoint.
> Purpose: pay for the metallurgy Time Head-start identified in 95 with local apparatus, people, rig-hours and records rather than a narrative bonus.

## 0. Central design decision

Asai does **not** import a future creep laboratory. He imports the priority:

> Hot machinery is a time-dependent materials problem. Start the clock before the product needs the answer.

The initial apparatus can therefore be deliberately crude but numerous:

- dead-weight / lever constant-load stations;
- electric or fuel-fired resistance/furnace zones with calibrated thermocouples;
- simple extensometers/comparators and periodic manual readings;
- duplicate coupons from the same heat and heat-treatment batch;
- failure-time, elongation, section reduction, oxidation scale and fracture-section records;
- serial-number linkage from heat → process → coupon → engine component → service return.

The protagonist's cheat is **test selection, program architecture and record discipline**. The fixtures, furnaces, operators, metallurgy and years remain local.

## 1. Why this program is affordable in-world

Canonical prepayments already exist:

- 1914–19 special-steel business and heat-treatment capability;
- several hundred employees by 1918;
- E1 hot rotating machinery by 1921;
- turbocharger prototype 1923–24 and practical product by 1925;
- statistical process control from 1924;
- 1928 reorganization with steel, engine, research and independent inspection functions.

A creep station is not a gas turbine. A bank of simple constant-load furnaces is capital- and labor-light compared with the E-engine program. The bottleneck is disciplined long occupancy and temperature/load calibration, not exotic machinery.

## 2. Program stages — proposed v38 engineering envelope

These are **planning envelopes**, not claims of exact historical counts until canonicalized.

### M0 — 1919–21: short-time hot-material laboratory

People: ~4–8 dedicated metallurgical/test staff plus shared machinists.

Fixtures:

- 1–2 heated tensile/elastic fixtures;
- 1 oxidation furnace bank;
- metallography/polishing/microscopy bench;
- hardness/room-temperature tensile from existing special-steel work.

Output:

- high-temperature short-time strength ranking;
- oxidation/scale qualitative ranking;
- heat-treatment and microstructure archive.

This stage **does not provide creep life**.

### M1 — 1921–24: first long-clock bank

People: ~8–15 dedicated staff/operators, with night checks shared with the engine test organization.

Representative capacity:

- **4–8 constant-load long-duration stations** initially;
- 2–4 thermal-cycle / burner/furnace cycling positions;
- 1 overspeed/spin test position or shared rotating rig;
- M0 short-time/oxidation/metallography retained.

Test philosophy:

- 50–300 h comparative tests first;
- selected 500–1000 h runs where temperature stability is adequate;
- duplicate tests prioritized over a huge alloy matrix;
- failure-to-failure / time-to-defined-strain is acceptable when precise continuous creep strain is not.

The important output is not a universal creep law. It is a ranked ledger: **this heat/process survives longer at this T/stress than that one, with this scatter**.

### M2 — 1924–27: statistical long-duration laboratory

Representative capacity:

- **12–20 long-duration stations**;
- 4–8 thermal-cycle/oxidation positions;
- 2 rotating fatigue/spin/component positions;
- early component-section furnace rigs.

Key change: 1924 control-chart culture is applied to materials tests.

Records now include:

- heat / chemistry;
- melt/refining route;
- forging/casting route;
- heat-treatment lot;
- specimen orientation/location;
- load, temperature and calibration drift;
- failure mode;
- metallographic section;
- engine/service return if the same process enters hardware.

This converts long tests from anecdotes into a reusable process-selection system.

### M3 — 1927–30: turbine-materials process laboratory

Representative capacity:

- **24–36 long-duration stations**;
- 8–12 thermal/oxidation stations;
- 3–5 rotating fatigue/spin rigs;
- first contracted/shared radiography for high-value parts;
- lost-wax small-part process experiments;
- stationary cooled-vane / passage heat-transfer rigs.

New focus:

- blade/root/disk-specific samples;
- casting/forging defect classes;
- joint/weld/braze trials where used;
- thermal gradients rather than uniform furnace temperature only;
- service turbocharger parts fed back as destructive samples.

### M4 — 1930–34: qualification-oriented hot-section laboratory

Representative capacity:

- **40–60 long-duration stations**;
- 12–20 oxidation/thermal-cycle positions;
- multiple rotor/component rigs;
- high-value radiography and magnetic inspection institutionalized;
- rotating cooled-component development begins where fabrication permits.

The lab can now run parallel matrices by:

- temperature;
- stress;
- heat treatment;
- alloy family;
- process route.

The key gain is no longer “know creep exists”. It is **choose a lower-bound allowable and reject bad process lots before an engine program absorbs them**.

### M5 — 1934–38: E5/U4 materials system

Representative capacity:

- **60–100 long-duration stations** across the central lab + production/engine test network;
- dedicated hot-section component endurance rigs;
- formal Ni/non-Ni experimental ladder transitioning into two production policies;
- cooled-vane/blade process development separated from bulk-alloy creep;
- NDT reject type linked statistically to subsequent endurance results.

This is the point at which materials development becomes an organizational system rather than the protagonist personally recognizing the right alloy.

## 3. Rig-hours — order-of-magnitude accounting

A station occupied continuously provides at most 8,760 station-hours/year. Real utilization is lower because of specimen changes, furnace maintenance, calibration and failed runs.

Use a conservative planning utilization of **55–70%** for long-duration stations.

| Stage | stations | useful station-hours/year (rough) | Interpretation |
|---|---:|---:|---|
| M1 | 4–8 | ~19k–49k | enough for dozens of 100–300h comparisons and a few long runs |
| M2 | 12–20 | ~58k–123k | replicated matrices become possible |
| M3 | 24–36 | ~116k–221k | heat/process/alloy comparisons can run in parallel |
| M4 | 40–60 | ~193k–368k | qualification lower-bound work becomes practical |
| M5 | 60–100 | ~289k–613k | large continuous materials program; still finite and prioritization-heavy |

These are **capacity ceilings**, not guaranteed valid data. Bad thermometry, drift, specimen preparation, operator error and furnace atmosphere can waste the hours.

## 4. What the protagonist explicitly does

He does **not** need to teach a future creep constitutive model in 1921.

He can say, in contemporary engineering language:

1. short-time tensile is insufficient for a hot rotating blade;
2. hold identical specimens under constant load at several temperatures for hundreds/thousands of hours;
3. record extension and rupture time;
4. always retain heat/process identity;
5. duplicate critical points to measure scatter;
6. section failed pieces and compare fracture/microstructure;
7. correlate engine-return parts with the same heat/process coupons;
8. never change alloy, heat treatment and geometry simultaneously if the failure must be understood.

This is exactly the “future CAD office without future tools” logic: the correct experimental architecture is supplied early; all data still have to be physically generated.

## 5. What computation later adds — and does not add

Computation is auxiliary.

1920s machine calculation/card systems can help:

- normalize stress/temperature/time tables;
- interpolate test matrices;
- group heats/processes;
- calculate simple thermal stress or centrifugal stress families;
- schedule the finite rig bank efficiently;
- retrieve comparable prior failures.

1930s sequential/relay calculation can add:

- larger multi-variable regressions/correlations;
- more candidate heat-treatment/alloy combinations before committing long rig time;
- coupled temperature/stress design cases.

But computation cannot manufacture 1,000 h of creep data in 100 h. It makes the physical test program **more information-efficient**, not time-free.

## 6. E4/E5 head-start actually paid under this program

If M1 begins in 1921–24:

### E4 qualification window, 1931–33

Available history:

- ~7–12 years since first long-clock start;
- ~6–8 years of practical turbo service by 1931–33;
- ~7–9 years of control-chart/process records;
- M3/M4 scale parallel test capacity.

Therefore E4 should plausibly have:

- much better alloy/process ranking than a fresh GT program;
- known scatter for established material/process families;
- meaningful derating-life curves;
- better root/disk/defect rejection;
- fewer late hot-section redesign loops.

Still not fully mature:

- E4 operates hotter and in different geometry/stress fields than the 1925 turbo;
- full component thermal gradients and start/stop cycles add new clocks;
- high-temperature casting/joining defects remain real.

### E5 qualification window, 1934–37

Available history:

- ~10–16 years of long-duration material testing;
- ~9–12 years of turbo service;
- decade-plus statistical process culture;
- M4/M5 qualification-oriented lab;
- explicit component and process matrices.

This should significantly improve the **lower tail** of life and qualification confidence. It is reasonable to expect E5's advantage over historical early aerojets to be especially large in life/yield even before invoking exotic alloys.

## 7. Preliminary life re-rating envelope — DRAFT ONLY

Do not yet write these into canon. They are the next hypothesis to test against hot-section temperature, stress, cooling and product duty.

Current v37:

- E4: “百数十〜数百時間”
- E5: “数百時間”

With the M1–M5 program, a plausible *engineering interpretation* is:

### E4

- development engines: failures may still occur below 100 h during new-part debugging;
- qualification lower bound for established hot-section process: **~150–250 h**;
- typical conservative rated band after maturation: **~250–450 h**;
- derated stationary/intermittent products: can exceed this substantially, but product duty must be separate.

This largely **narrows and clarifies**, rather than radically increases, the current “hundred-plus to several hundred” canon.

### E5

- early development lower tail: still ~100–200 h for new geometry/material/process;
- established full-rating hot-section lower bound: **~250–400 h**;
- mature typical full-rating engineering band: **~400–700 h**;
- deliberate derating may buy four-figure hours, but only with product-specific thermal duty and maintenance accounting.

This would make “数百時間” remain true while giving it a much stronger lower/median/upper meaning.

**Important:** these bands are not accepted yet. They are deliberately conservative because early test head-start mainly removes ignorance and scatter; it does not repeal temperature/stress physics.

## 8. Why E6/E7/E8 do not inherit E5 maturity for free

Every major new hot-section change carries a **clock-reset fraction**.

Suggested audit reset factors (fraction of old Gq maturity retained):

- same alloy/process, +moderate stress/T: 0.75–0.90 retained;
- new heat treatment / coating: 0.60–0.80;
- new alloy family: 0.40–0.65;
- new hollow/cooling-passage manufacture: 0.35–0.60;
- substantially new disk/root temperature field: 0.50–0.70;
- new joining/casting route: 0.35–0.60.

Thus E8 can be close to future-CAD in design O while still only ~63–78% in Gq, as the 91 matrix estimated.

## 9. Recommended next audit

Before canonical v38 patching:

1. decompose E4 and E5 into **hot-section metal temperature / stress / duty cycle / process route** rather than TIT alone;
2. identify which parts are forged, cast, fabricated or welded;
3. assign the M-program data inheritance/reset factor to each;
4. derive product-specific TBO: stationary, marine sprint, turboprop, turbojet;
5. only then modify `gt-core-generations` life labels.

## 10. v38 decision status

- Early long-duration materials testing: **strong candidate for canonicalization**.
- Exact rig counts above: **planning envelope**, not yet canonical.
- E4/E5 preliminary life bands: **audit hypothesis only**.
- v37r1 life numbers: **remain canonical until subsystem/duty decomposition is complete**.

