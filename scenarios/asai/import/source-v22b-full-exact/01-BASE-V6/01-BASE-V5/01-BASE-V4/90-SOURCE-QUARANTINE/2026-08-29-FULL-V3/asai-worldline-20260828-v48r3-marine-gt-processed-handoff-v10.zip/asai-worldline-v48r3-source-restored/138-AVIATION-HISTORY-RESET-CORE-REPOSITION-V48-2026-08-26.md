# v48 航空史リセット／コア再配置

## semantic change

- 旧航空採用・機体系列をcurrentから外しarchiveへ移した。
- 発動機上流は `main/asai-works-engine-capability-core-e1-e9.md` をcurrent numeric parentとした。
- `main/asai-works-core-rebaseline-history-v38-v48.md` にv38以後の変更理由を記録した。
- `main/asai-works-business-origin-diversification-1903-30.md` を追加し、織機→内製化→特殊鋼/計算→タービン研究→過給機→独立GTという会社史と、転生者の多角化操舵を上流正本へ戻した。
- `main/asai-works-aviation-reconstruction-framework-v48.md` で技術史/実証史/採用史を分離した。

## deliberate non-closure

- 新しい航空採用史は確定していない。
- E4/E5 pure jet backward values remain pre-audit.
- E5 aft-fan timing is reopened.
- turboprop aircraft/product comparison must be rebuilt with current shaft/product accounting.
- discussed E5 fighter/heavy-fighter/carrier concepts remain candidates only.
