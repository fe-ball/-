> **v45 current authority:** E6-S-T standard is **1,300hp**. Dedicated H→A is now closed here: clean max **455–485km/h**, practical loaded range **1,200–1,500km**. ~1,400hp high-flow short trim gives a conditional **470–495km/h** clean shadow.

# 艦上攻撃機 B6N「天山」——E6-S-T統合のv26再基底化

> **[v26・2026-08-25]** 旧B6A愛知案は廃棄。世界線の天山は史実と同じ**中島B6N**を本流とし、浅井は発動機・計算・材料側から参加する。B7A流星は愛知の独立新設計であり、天山爆撃型からの派生ではない。上位正本=`asai-works-aircraft-computation-closure-1937-46.md` / `asai-works-attack-bomber-rebaseline-1937-46.md`。

## 1. 要求と主体

- 主務：中島。海軍のB5N後継艦攻要求。
- 任務：雷撃・水平爆撃。急降下爆撃の次世代統合はB7A流星へ。
- 浅井：E6-S-T供給、吸排気/減速機/prop matching、振動・脚・折畳剛性の計算協力。
- E6採用は「浅井が機体を支配する」のでなく、Mamoru/Kasei等との通常競争で、灯油・低振動・艦上防火・加速余裕が高く評価されるため。

## 2. 発動機

E6-S-T installed **600–770kg**を使用する。旧稿のengine+gear+prop約530kgは軽すぎるので廃棄。

初期試作段階は1,300hp未満の減格を許容し、量産標準は**1,300hp**。離艦/go-around/緊急用のhigh-flow short trimは約**1,400hp**を条件付きで使える。高高度機ではないのでNi高温型を常用しない。

## 3. 重量と性能shadow

| 項目 | v26 current band |
|---|---:|
| 通常全備 | **4.55–4.75t** |
| clean max | **455–485km/h級**（standard）／470–495km/h short shadow |
| 標準兵装 | 魚雷1本 / 800kg級爆弾 |
| 実用積載航続 | **1,200–1,500km級** |
| 乗員 | 3 |

旧「速度の跳躍」や長すぎる航続を置かない。利得は、雷装時の発進加速、go-around、低振動による照準/投下安定、灯油による火災抗堪、折畳翼剛性、脚/ブレーキ寿命、燃料/防御余裕。

## 4. 艦上運用

Fowler系高揚力を使うが、極端STOL機にはしない。大型空母では通常運用、条件の悪い短甲板では艦速・風・必要なら発艦補助を使う。逆ピッチは不採用。

## 5. B7Aとの関係

B6Nが成功しても、雷撃専用寄りB6Nと高速軽快D4Yの二機種運用は残る。海軍が次に求めるのは「天山を急降下できるよう改造する」ことではなく、**雷撃＋急降下を最初から統合したB7A**。したがって旧「天山爆撃型（後の流星系）」はDROP。

## 6. closure

- B6N本流：**CLOSED**。
- E6-S-T本線候補：**CLOSED**。
- v45 E6-S-T power-performance H→A：**CLOSED**。
- exact prop径/gear ratio/実TBO・艦上発艦距離：P2。
- 実採用時期・生産数・空母配備：HISTORY/OOB FROZEN。
