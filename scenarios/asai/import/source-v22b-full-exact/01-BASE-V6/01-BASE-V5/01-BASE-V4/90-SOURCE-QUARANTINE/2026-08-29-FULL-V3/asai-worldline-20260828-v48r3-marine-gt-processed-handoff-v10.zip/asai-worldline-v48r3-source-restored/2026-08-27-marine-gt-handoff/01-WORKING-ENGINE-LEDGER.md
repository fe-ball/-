# Working engine ledger — marine GT discussion through 2026-08-27

> **Status:** mixed. Canonical upstream values are identified explicitly; large-diameter extrapolations are OPEN working calculations.

## A. E4 / 一号 analytical generation — retained technical baseline

### Simple shaft machine

- accepted shaft output: ~500 kW
- mass flow: ~6.7 kg/s
- PR: ~4.5
- TIT: ~710C
- dry product mass: ~0.80–0.90 t
- diameter: ~0.66–0.74 m
- length: ~2.0–2.4 m
- installed shaft efficiency: ~15%
- installed specific work: ~76 kJ/kg
- aviation-equivalent shaft output: ~680–690 hp

### Recuperated E4-R working baseline

- shaft: ~467.7 kW
- recuperator effectiveness working point: ~0.60
- shaft efficiency: ~19.34%
- SFC: ~0.433 kg/kWh
- recuperator/duct/header/bypass add ~0.6–1.1 t and ~1.4–2.5 m3
- high-flow ~7.16 kg/s can restore ~500 kW with a slightly larger recuperator
- earlier 25% E4 recuperated claim is retired; plausible effectiveness band 0.50–0.70 gives ~17.3–21.3%

### Marine interpretation

- simple E4: short sprint/emergency/black-start/pump/fire-fighting
- E4-R: long continuous applications where added heat exchanger pays back
- compact core does **not** imply compact intake/exhaust

## B. E5 / 二号 standard — retained technical baseline

- PR6
- compressor: 5 axial + 1 centrifugal in the standard family
- standard mass flow: 7.6 kg/s
- ~17.5 krpm
- standard non-Ni quantity rating around 950 hp at ~765C
- common Ni ~1,000 hp; selected test ~1,050–1,060 hp
- Ni@800C ~1,063 hp
- non-Ni@800C ~1,014 hp
- non-Ni@765C ~952 hp
- installed efficiency roughly 18.4–19.3% depending rating/material
- high-flow standard derivative ~1,130 hp / ~8.08 kg/s compressor-side accepted

## C. E5 large-diameter marine classes — OPEN analysis labels

These arose from the marine scaling discussion. They are **not** yet canonical products.

### Design principle

At roughly similar blade speed:

- N scales ~1/D
- flow and power scale roughly ~D^2
- torque scales ~D^3

Scale-up reduces extreme rotational speed/reduction ratio but increases torque, casing, shaft, bearing and gear demands. Total airflow for the same cycle/power does not magically disappear.

### E5 large-A / `大径甲` working band

- representative diameter: ~1.0–1.15 m
- mass flow: ~17.1 kg/s
- gas-generator speed: ~11.5–12 krpm
- likely move toward more/all-axial compressor rather than scaling the centrifugal rear stage literally
- non-Ni normal: ~2,000–2,150 hp
- high/Ni: ~2,300–2,400 hp
- long-life ~700C working point: ~1,850–1,900 hp
- engine module rough band used in discussion: ~1.7–2.2 t before large marine train items

### E5 large-B / `大径乙` working band

- representative diameter: ~1.35–1.5 m
- mass flow: ~30.4 kg/s
- gas-generator speed: ~8.5–9 krpm
- normal ~3,700–3,800 hp
- high ~4,100–4,300 hp depending material/rating
- long-life ~690–710C: ~3,300–3,400 hp
- working full-fuel around ~1.15–1.30 t/h depending rating
- engine module rough band used in discussion: ~4–5+ t before gear/duct/support

### Intended marine rating philosophy — OPEN

Instead of one headline rating:

- long-life continuous: ~690–710C, ~3.3–3.4 khp
- military normal: ~750–765C, ~3.7–3.8 khp
- short maximum: ~790–800C, ~4.0–4.2 khp

Purpose of derating is primarily **life**, not lower BSFC. Lower TIT slightly worsens simple-cycle specific fuel consumption while buying potentially much larger creep margin.

## D. E6 / 三号 canonical M-family anchor

Source authority: `124-E6-INSTALLED-CYCLE-PRODUCT-POWER-REBASELINE-V44-2026-08-26.md`.

Canonical/accepted values:

- PR7
- E6-M flow: 13.2 kg/s central / 12.5–14.0 trim
- non-Ni 870C installed shaft specific work: ~130.5 kJ/kg
- 870C fuel-based shaft efficiency: ~22.5%
- 870C central BSFC: ~0.372 kg/kWh
- non-Ni 820C derate: ~116.2 kJ/kg
- 820C fuel-based shaft efficiency: ~21.6%
- 820C central BSFC: ~0.387 kg/kWh
- E6-M aircraft product: 2,100 hp flat-rated below ~2,250 hp central capability
- marine: ~2,300 hp short / ~2,000–2,100 hp continuous cycle-consistent
- long-life product point ~1,870 hp retained

Do not overwrite these with the later scaling-study shorthand.

## E. E6 large-diameter marine classes — OPEN working study

The discussion extrapolated the E6/M-family all-axial architecture into larger marine cores. These are **paper/rig targets**, not closed product ratings.

Working assumptions used for comparison:

- 780C long-life point extrapolated from the 820/870C canonical cycle
- marine transmission/reducer debit paid
- modest scale gains assumed for clearance/Reynolds/leakage (not magic cycle-efficiency jumps)
- exact gains must be recomputed when formalized

| analysis class | linear scale | mass flow | GG rpm | 780C long-life | 800C continuous | 820C normal | 870C max |
|---|---:|---:|---:|---:|---:|---:|---:|
| base M-like | 1.0 | 13.2 kg/s | 13.5k | ~1,790 hp working | ~1,890 | ~1,990 | ~2,240 |
| 甲 | 1.5 | 29.7 | 9.0k | ~4,110 hp | ~4,340 | ~4,570 | ~5,140 |
| 乙 | 2.0 | 52.8 | 6.75k | ~7,390 hp | ~7,800 | ~8,210 | ~9,230 |
| 丙 | 2.5 | 82.5 | 5.4k | ~11,650 hp | ~12,300 | ~12,950 | ~14,560 |

### Important interpretation

- The `base M-like` row is a **marine scaling worksheet row**, not a replacement for v44 product ratings.
- 甲 is roughly the same airflow scale as E5 large-B but materially higher power/efficiency.
- 乙 brings ~8 khp class into a manageable engine count for destroyers and larger ships.
- 丙 is attractive because ~12 khp per block makes four-engine ~50 khp destroyer studies possible.
- `丙` should emerge from ship requirement/unit-power optimization, not from a desire to create every geometric scale.

## F. Physical working dimensions for E6 marine scale classes — OPEN

| class | core dia | GT module length | gas generator | free power turbine | bare GT module mass working band |
|---|---|---|---|---|---|
| M-like | ~0.9–1.0 m | ~2.8–3.2 m | ~13.5 krpm | ~8.5–9.5 krpm | ~0.8–1.0 t |
| 甲 | ~1.35–1.5 | ~3.8–4.5 | ~9.0k | ~6–6.5k | ~2.8–3.8 t |
| 乙 | ~1.8–2.0 | ~5.0–6.0 | ~6.75k | ~4.5–5.0k | ~6.5–8.5 t |
| 丙 | ~2.2–2.5 | ~6.2–7.5 | ~5.4k (possibly ~4.8–5.2k long-life marine redesign) | ~3.5–4.0k | ~12–16 t |

Large marine installed train mass must include reduction gear, clutch, thrust bearing, lube, foundation, intake/exhaust, separators, fire protection, etc. Earlier simplistic very-low kg/kW values are retired for full-plant comparisons.

## G. Lifetime / maintenance — OPEN target model

Do **not** interpret early 350–700 h figures as whole-engine scrap life. They were discussed as high-temperature aviation-style hot-section intervention scales.

Large marine philosophy should instead be:

- avoid frequent casing splits;
- removable combustor/nozzles where possible;
- segmented first-stage nozzles;
- compressor wash provisions;
- multi-point exhaust-temperature monitoring;
- bearings/housings made serviceable without full rotor removal where practical.

Working target bands discussed:

### E5 large marine

- long-life hot-section: qualify 500 -> 1,000 -> 2,000 -> 3,000 h
- mature target ~2,500–3,500 h hot section
- full rotor target ~5,000–8,000 h or more

### E6 large marine

- ~780C long-life: begin 3,000 h guarantee target, aim ~5,000 h
- ~800C continuous: ~2,000–3,000 h
- ~820C military normal: ~1,000–2,000 h
- ~870C maximum: cumulative few-hundred-hour damage budget
- full rotor development target ~8,000–12,000 h

The discussion used a **heuristic** `~25C hotter = ~2x high-temperature damage rate` to illustrate the value of derating. This is NOT canon and must be replaced by actual material/rig correlations when formalized.

