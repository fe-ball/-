# v29 — Marine GT small-craft design closure / 2026-08-25

## Closed
- v27の `2×1,300hp GT + 350hp diesel / 3 independent shafts` をcentralから撤回。独立軸はCODAG gearboxを消すが、停止GT prop dragとcruise/full-speed prop matchingを解決しない。
- E5 first marine-qualificationは、既存piston二軸をcruise/asternに残し、中央一軸E5 GT boostを足すone-GT architectureを低リスクcentralに変更。
- 2GT high-power branchはCPP/feathering等のlow-speed prop-drag対策をmandatoryにした。
- trial speedとoperating/service speedを分離。43–45ktを実戦常用値として扱わない。
- prop初期帯：E5 0.74–0.80m / 2050–2300rpm、E6 0.86–0.94m / 1750–1950rpm。
- small-craft complete installed GT pathは旧1.5–2.5kg/kWを撤回。E5 2.8–3.4（中央3.1）、E6 2.2–2.8（中央2.5）kg/kW。
- E5 marine gate=150h cumulative / 50h hot-section inspection、E6=300h cumulative / 100h inspection / 500h design-TBO target。fleet実績へ自動昇格しない。
- pure-GT 27tはtest/sprint conditionalのみ。E5/E6通常魚雷艇の量産中央はNO。
- E6 large-MTB technical shadowは50–55t、4×45cm、5,200hp branch、full-load trial 42–44kt、planning range 450–600nm級へ再基底化。40kt service硬要求なら6,000–7,100hp級が必要。

## Still conditional
- 高速艇用CPP/featheringの国内実装とmarine endurance。
- E6 50–55t actual requirement / procurement / series production。
- post-1941-12-08 OOB / production / deployment / combat。

## Next
GFRP艇体：20–30t一次構造のlaminate/芯材/曝露/疲労/slam/repairを閉じ、50t全面GFRP gateを判定する。
