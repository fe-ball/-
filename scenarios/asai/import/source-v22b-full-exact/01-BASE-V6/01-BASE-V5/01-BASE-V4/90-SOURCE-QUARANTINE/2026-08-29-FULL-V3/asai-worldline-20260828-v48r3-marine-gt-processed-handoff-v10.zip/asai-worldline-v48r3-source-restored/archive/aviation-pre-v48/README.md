# aviation-pre-v48 archive — source-restored v48r3

- `v46-main/` contains **71** old aviation platform/adoption documents recovered verbatim from the supplied v46r1 checkpoint. Membership is reconstructed from v48 semantic scope and independently checked against the documented 71-file / 169-row invariants; the missing original v48 archive manifest prevents a bit-for-bit manifest claim.
- Those files account for exactly **169** carried v46 chronology records, matching `140-MACHINE-LAYER-REFRESH-V48R1-2026-08-26.md`.
- They are provenance only under semantic v48. Do not treat old Hekireki/Kaifu/Sakufu/old TP/old Zero/CFRP-aircraft adoption or performance as current canon.
- `LEGACY-PATH-REMAP.tsv` maps former `main/` paths to the archive.
- The v47 Hekireki transition-working set referenced by v48 was not present in either supplied v46r1 or v48r1 ZIP, so it is not reconstructed from invented content.
