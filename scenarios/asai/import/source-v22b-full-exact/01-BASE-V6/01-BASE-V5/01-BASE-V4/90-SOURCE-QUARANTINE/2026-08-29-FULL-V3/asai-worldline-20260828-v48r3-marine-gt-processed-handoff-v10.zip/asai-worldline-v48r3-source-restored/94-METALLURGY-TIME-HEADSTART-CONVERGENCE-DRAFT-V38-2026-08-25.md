# 冶金・高温材料の能力収斂——Time Head-start を独立会計する

> **v38再監査用作業稿。v37r1正本は未変更。**
> GTの `91` / `93` を受け、E4/E5寿命帯を再OPENする前に、材料側の「未来知識による試験開始年の前倒し」を分離する。

## 0. なぜ冶金はO-scoreだけでは足りないか

冶金では、未来設計室へ近い合金系・熱処理・検査法を選べても：

- creep
- stress rupture
- oxidation
- hot corrosion
- thermal fatigue
- cyclic fatigue
- grain growth
- coating/interface degradation
- casting defect distribution

は**時間と実物**を要求する。

しかし主人公は将来どのfailure modeが重要になるかを知っている。

したがって最大のチートは「試験時間を消す」ことではなく、**必要になる10–20年前から時計を回し始めること**。

これを通常のO/Gとは別に `TH = Time Head-start` として持つ。

---

# 1. THの定義

## 1.1 Head-start years H

`H = T_need - T_start`

- `T_start`：そのfailure modeを目的にした継続試験を開始する年。
- `T_need`：そのデータが製品設計のcritical pathになる年。

例：E5 hot sectionで1935年に500–800℃級長時間データが必要になり、1922年から定荷重高温試験を回していれば、H≈13年。

## 1.2 TH-score

長く試せば無限に価値が増えるわけではない。現象別に `H_sat`（先行の有効飽和年数）を置く。

`TH = min(100, 100 × H / H_sat)`

暫定H_sat：

| 試験群 | H_sat | 理由 |
|---|---:|---|
| 熱処理・硬度・短時間高温引張 | 2–3年 | 多数runで比較しやすい |
| 高温酸化・coating | 4–6年 | 長期曝露＋季節/炉条件が欲しい |
| fatigue / thermal cycling | 5–8年 | cycle数とfailure statisticsが必要 |
| creep / stress rupture | 8–12年 | 1000h級を多数条件で重ね、長時間外挿を較正する |
| corrosion / marine hot-corrosion | 4–8年 | environment差と実曝露が必要 |
| casting/yield statistics | 3–5年 | ロット数・工員・炉・中子工程の蓄積が必要 |

TH=100でも未来材料になるわけではない。「その現地材料について、未来部下が欲しがる長期データをかなり前から持っている」という意味。

---

# 2. 史実アンカー——1920年代開始は可能か

可能側。

- creepの科学的観測は20世紀初頭から存在し、Andradeは1910/1914に複数金属のcreepを研究。
- 高温化する蒸気設備により、1920年代には鋼の時間依存強度が工業問題になっている。
- 日本でも1922年に高温弾性率試験、1928年には1000℃までの高温衝撃・疲労試験装置の報告がある。
- 米Bureau of Standardsは1928年に複数鋼種の定荷重creep testを報告。

したがって浅井が1920年代初頭に：

「短時間引張強さだけで高温翼材を選ぶな」

「温度×応力×時間で伸びを記録しろ」

「炉温、試験片、heat lot、破断時間を同じカードで残せ」

と要求すること自体は、未来の試験機を召喚する行為ではない。

---

# 3. 浅井材料線の候補TH

> **ここはv38候補。開始年はまだ正本化しない。** 現行v37では1919特殊鋼、1921 E1、1924管理図、1925過給機実用が固定されている。その間に置ける自然な試験開始帯を示す。

| track | candidate T_start | T_needの主帯 | Hの目安 | TH中央 | 主な配当 |
|---|---|---|---:|---:|---|
| 高温引張・弾性率 | 1919–22 | E1/E2 1921–25 | 2–6年 | 70–100 | 温度で許容応力が落ちることを設計値へ早期反映 |
| creep / stress rupture | 1921–24 | E4/E5 1931–37 | 7–15年 | 80–100 | 短時間強度から長時間寿命を切り離す |
| oxidation / scale | 1920–23 | E3–E5 1928–37 | 5–14年 | 90–100 | 合金系・皮膜・表面処理の順位付け |
| thermal cycling / thermal fatigue | 1922–25 | E4–E6 1931–41 | 6–16年 | 80–100 | start/stop機・航空GTの寿命設計 |
| high-speed rotor fatigue | 1921–24 | E3–E6 1928–41 | 4–17年 | 70–100 | disk/shaft/fastenerの安全率・検査重点 |
| investment casting coupon/yield | 1924–28 | hollow-cooled part 1930s | 5–12年 | 70–100 | 中子、肉厚、欠陥位置、歩留まりを工程知識化 |
| NDT radiography/magnetic | 1923–30 | E4以後 | 3–10年 | 60–100 | 欠陥前提設計＋出荷前除去 |
| cooling passage/process coupons | 1925–30 | E5–E8 | 4–20年 | 60–100 | 冷却流量と製造再現性を分離して蓄積 |
| Ni / non-Ni dual alloy ladder | 1920s | E5–E8 | 8–20年 | 80–100 | 戦略材料と性能・寿命を別枝で最適化 |

ここで重要なのは「1921からE8用合金完成」ではない。

初期は低温・低応力の鋼でよい。試験機、記録方式、炉温均一性、試験片形状、破断判定、ロット追跡を先に育てる。温度・材料が上がるたび同じ試験文化へ新材を投入する。

---

# 4. 冶金のO/G/TH三層

## 4.1 O：未来設計へ近い選択

冶金のOは早期から高くなりやすい。

強いL0：

- 高速度鋼・超硬を正しい用途へ。
- grain size / cleanliness / inclusion controlを重視。
- heat treatmentを「秘伝」ではなく温度・時間・冷却速度で記録。
- Ni系と非Ni系を二本立て。
- 中空冷却、皮膜、NDTを将来の必要技術として早く育てる。

弱いL4：

- 実creep life。
- thermal-fatigue interaction。
- casting defect distribution。
- coating/interface life。

したがって「合金の方向はほぼ当たっているが、許容寿命はまだ幅が広い」が自然。

## 4.2 Gp：性能利得

材料のGpは比較的早く回収できる。

- 適切な合金系。
- 不純物低減。
- 熱処理。
- grain control。
- 表面処理。

はlow-hanging gainが大きい。

ただしTITを上げた利得はhot-section全体のcooling / disk / seal / bearingへcoupleするので、材料GpをGT Gpへ二重加算しない。

## 4.3 Gq：寿命・歩留まり

ここでTHが効く。

同じOでも：

- 試験開始1年前
- 試験開始10年前

では、1935年に持っているfailure statisticsが全く違う。

冶金Gqの簡易モデルを：

`Gq_material ≈ base_Gq(O, manufacturing) × (0.65 + 0.35×TH)`

と置く。

TH=0でも短時間試験・未来知識は効くが、TH=100なら長期データ由来の最大35ポイント相当の欠損をかなり埋める、という監査用モデル。これは正本性能式ではない。

---

# 5. E世代への影響

## E1/E2

- 合金系・冷却方向を正しく選ぶOは高い。
- 長期データはまだ蓄積中。
- したがってTITを上げても寿命は短い。

現行E1/E2の「実証・改良」扱いを維持。

## E3 1928–29

1921–24にcreep/oxidation試験を始めていれば、既に4–8年のデータがある。

ここから初めて「材料の上端」だけでなく：

- 同じTITで長持ちする組成。
- 同じ寿命ならTITを上げられる組成。
- scaleが剥がれる条件。
- heat lot差。

を区別しやすい。

E3の数値上積みではなく、E4へ渡るmaterial mapの厚みへ配当。

## E4 1931–33

ここは再OPEN候補。

もしcreep 7–10年、oxidation 8–12年、thermal cycling 6–10年級の蓄積が確認できれば、現行「百数十～数百時間」寿命帯の**下端を上げる**余地がある。

ただし：

- 中空翼加工。
- casting defect。
- bearing/seal。
- combustor liner。

は別系統なので、材料だけでE4を長寿命機にしない。

## E5 1934–37

THの最大配当が見え始める世代。

材料研究は「将来GTが必要になったから1934に開始」ではなく、特殊鋼・過給機・E1から15年前後連続している。

したがってE5の数百時間寿命は、v38では**保守側かもしれない**。

ただし寿命の上方再評価は次の分解後に行う：

1. hot-section material life
2. cooling passage reliability
3. disk/root life
4. combustor liner
5. bearing/seal/oil
6. manufacturing defect/yield

最低の系列がengine TBOを決める。

## E6–E8

ここではTHはほぼ飽和する。

したがって後期の伸びは「さらに長く試した」だけではなく：

- 新しい温度域。
- 新しい冷却法。
- 新しい合金。
- 新しい製造法。

を開くたび、**新しいL4時計が一部リセットされる**と読む。

これがE8でもGqが100にならない理由。

---

# 6. 主人公の本職としての冶金介入

計算機と違い、冶金は主人公の本コアに近い。

したがって介入強度は高くてよい。

- 正しい合金系を指定する。
- 不純物・grain・熱処理の急所を直接言う。
- 将来のcreep/oxidation/thermal fatigueを初期から試験項目へ入れる。
- failure surfaceを見て試験を組み替える。
- 中空冷却・皮膜・NDT・精密鋳造を強く押す。

ただし彼ができないのは：

- 10,000h testを1週間で終わらせる。
- 工員がまだ作れない薄肉中空翼を図面だけで量産する。
- inclusionやporosityを知識だけでゼロにする。
- 新合金の全scatterを一発で知る。

ここが計算機分野との介入差。

---

# 7. v38での一次判定

1. **E1–E3の性能値は据置。** 材料先知は既存成立因へ吸収。
2. **E4/E5寿命だけ再OPEN候補。** 特に下端と「qualification時に何時間を保証できるか」。
3. TIT上端を材料THだけで上げない。cooling/manufacturing/rotorを通す。
4. E6以後はTH飽和後、新しい技術を開くたびL4時計が再スタートする。
5. Ni/non-Ni二系統はv37を維持。供給calendar cutoffを復活させない。
6. 1920年代の長期材料試験開始を、v38年表へ明示する価値が高い。

---

# 8. 次作業

- 現行正本から特殊鋼、高温試験、熱処理、NDT、investment casting、中空翼の実開始年を抽出し、`T_start`を確定する。
- E4/E5について部品別TBO ledgerを作り、「hot sectionだけ長寿命なのにbearingで落ちる」等を分離する。
- その後に航空へ進み、計算＋材料＋engineの配当を二重計上せず統合する。
