# 128 — E6-S aircraft H→A rebaseline — v45

> Status: **ACCEPTED v45 semantic rebaseline**. Base checkpoint = v44r1.
> Scope: first downstream aircraft propagation of v44 E6-S shaft-product ratings: B6N Tenzan and the single-engine Ni Ki-40 development. S-core fighter, twin-engine E6-S reconnaissance, adoption/OOB and post-1941 history remain separate gates.

## 0. Authority chain

Upstream fixed inputs:

- v43 compressor: E6-S **7.8 kg/s / PR7 / 7 axial + 1 centrifugal / 18 krpm**, full-speed trim 7.6–8.2 kg/s.
- v44 E6-S-T: **1,300 hp standard**, ~1,400 hp high-flow short trim.
- v44 E6-S-N-T: **1,500 hp standard**, ~1,600 hp high-flow short trim conditional.
- v44 BSFC: non-Ni **0.372 kg/kWh**, Ni **0.356 kg/kWh** at the installed shaft coordinate.
- inherited non-flat-rated altitude audit ratios: 4 km 0.70–0.82, 6 km 0.55–0.70, 8 km 0.43–0.58, 10 km 0.32–0.48. These remain shadow/qualification bands rather than measured maps.

Reproducible files:

- `computation-2026-08-22/e6_s_aircraft_ha_v45.py`
- `computation-2026-08-22/E6-S-AIRCRAFT-SPEED-SCALING-V45.tsv`
- `computation-2026-08-22/E6-S-ALTITUDE-POWER-SHADOW-V45.tsv`
- `computation-2026-08-22/E6-S-AIRCRAFT-RANGE-SHADOW-V45.tsv`

## 1. Method

No new aerodynamic miracle is inserted. Where the previous v26 airframe closure already supplied a clean-speed band, v45 treats it as an airframe/drag anchor and propagates the power correction with the high-speed approximation

`V_new = V_anchor × (P_new/P_anchor)^(1/3)`.

This is a local H→A correction, not a substitute for a full drag polar. Weight, planform and installation family are held unless v44 changed them. The E6-S gas path did not shrink when its standard rating fell, so the installed powerplant mass bands remain the existing conservative 1937–41 bands.

Range is independently checked with the propeller Breguet relation using v44 installed BSFC, plausible propeller efficiency, existing fuel loads and the L/D values already implied by the range audit. Range is therefore not scaled directly from maximum horsepower.

## 2. B6N Tenzan verdict

Current installation envelope remains:

- normal loaded mass **4.55–4.75 t**;
- E6-S-T installed powerplant **0.60–0.77 t**;
- internal fuel calibration ~**0.9 t**;
- loaded-aircraft implied L/D ~**8.6**.

### 2.1 Maximum speed

The v26 clean-speed anchor was **480–510 km/h** on the old 1,520 hp standard assumption.

At the v44 1,300 hp standard rating the cube-root factor is **0.9492**, giving **455.6–484.1 km/h**. Canonical product band:

- **standard E6-S-T: 455–485 km/h clean max**;
- **~1,400 hp high-flow short trim: 470–495 km/h clean short-rating shadow**.

The short-rating row is not the continuous fleet headline and requires local gearbox/prop/life qualification.

### 2.2 Range

Using BSFC 0.372 kg/kWh, 4.55–4.75 t initial mass, ~0.9 t internal fuel, L/D 8.6 and propeller efficiency 0.78–0.82 gives a broad ideal/reserve-sensitive shadow of roughly **1,160–1,530 km**.

**Verdict: retain the existing practical loaded range headline of 1,200–1,500 km.** The power downgrade mainly reduces speed and excess-power margins; it does not erase the Tenzan range case because cruise power is a requirement, not a fixed fraction of maximum rating.

### 2.3 Operational consequence

- The main E6-S-T benefit remains **torpedo-load acceleration, go-around margin, low vibration, kerosene fire safety and installation smoothness**, not a 500+ km/h speed claim.
- Standard-rating acceleration/climb reserve is weaker than in the old 1,520 hp shadow; ~1,400 hp short trim can be reserved for takeoff/go-around or emergency rather than used as a continuous cruise assumption.
- B6N remains a plausible E6-S-T application; the v44 correction does **not** force a return to a piston engine on thermodynamic grounds.

## 3. Ki-40 E6-S-N-T single-engine high-altitude development

Current airframe anchor from v26:

- clean recon mass **3.9–4.1 t**;
- installed E6-S-N-T powerplant **0.64–0.83 t**;
- high-altitude single-engine reconnaissance mission;
- internal fuel working band **1.3–1.4 t**;
- high-altitude L/D working band **11.5–12.5**.

### 3.1 Altitude shaft power

With the v44 1,500 hp standard rating, inherited shadow ratios give:

| altitude | v45 E6-S-N-T shaft-power shadow |
|---|---:|
| sea level | **1,500 hp** |
| 4 km | **1,050–1,230 hp** |
| 6 km | **825–1,050 hp** |
| 8 km | **645–870 hp** |
| 10 km | **480–720 hp** |

Thus the old v26 8 km band 730–990 hp is superseded.

### 3.2 Maximum speed at 8 km

The v26 airframe anchor was **650–675 km/h @8 km** under the old 1,700 hp product point and its corresponding altitude band.

The standard-rating cube-root factor is **0.9591**, yielding **623.4–647.4 km/h**.

Canonical bands:

- **standard E6-S-N-T: 625–650 km/h @8 km**;
- **~1,600 hp high-flow short trim: 640–660 km/h @8 km shadow**, conditional on the v44/v43 high-flow, gearbox, propeller and hot-section gates.

The old routine **650–675 km/h @8 km** is superseded as a standard-fleet point.

### 3.3 Range

A Breguet cross-check using v44 BSFC 0.356 kg/kWh, 3.9–4.1 t initial mass, 1.3–1.4 t internal fuel, 80–85% mission-usable fuel, L/D 11.5–12.5 and propeller efficiency 0.80–0.82 gives a broad mission shadow of about **2,780–3,850 km**, with the central 10–90% region around **3,000–3,580 km**.

Canonical practical range:

- **3,000–3,600 km internal-fuel practical reconnaissance range**;
- old 5,000–6,000 km routine mission figures remain superseded;
- ferry/drop-tank extensions require a separate payload/reserve calculation and are not folded into the standard headline.

### 3.4 Ceiling and mission reading

v45 does not lock a new one-number service ceiling because the 10–12 km compressor/propeller/pressurization map remains a shadow rather than measured data. The old 11.5–12 km statement is therefore **not promoted as a v45 exact value**. A working **~11 km-class** ceiling remains plausible, but exact ceiling/climb is a later qualification output.

The Ki-40 value proposition survives but changes emphasis: **625–650 km/h at ~8 km, long kerosene range and low-vibration photography**, rather than an automatic 650–675+ km/h high-altitude overmatch.

## 4. Downstream status

### Closed by v45

- B6N Tenzan standard E6-S-T clean speed: **455–485 km/h**.
- B6N Tenzan loaded practical range: **1,200–1,500 km retained**.
- Ki-40 E6-S-N-T standard 8 km speed: **625–650 km/h**.
- Ki-40 practical internal-fuel range: **3,000–3,600 km**.
- E6-S-N-T 8 km shaft shadow: **645–870 hp**.

### Still gated

- E6-S-T **S-core fighter** rows (e.g. Kaifu 21) still using old 1,520 hp.
- twin-engine E6-S reconnaissance/light-medium-bomber rows whose speed/weight/range use old per-engine 1,520 hp.
- exact Tenzan propeller diameter/reduction ratio, carrier wind-over-deck and takeoff distance.
- exact Ki-40 pressure-cabin mass, propeller compressibility, climb schedule and service ceiling.
- adoption dates, production numbers, OOB and post-1941 combat/history remain HISTORY/FROZEN.

## 5. Next local P1

Proceed to **remaining E6-S aircraft H→A**, beginning with the S-core fighter/Kaifu 21 and twin-engine E6-S reconnaissance rows. After those close, move to E6-M 13.2 kg/s aircraft intake/installation while retaining the 2,100 hp product headline.
