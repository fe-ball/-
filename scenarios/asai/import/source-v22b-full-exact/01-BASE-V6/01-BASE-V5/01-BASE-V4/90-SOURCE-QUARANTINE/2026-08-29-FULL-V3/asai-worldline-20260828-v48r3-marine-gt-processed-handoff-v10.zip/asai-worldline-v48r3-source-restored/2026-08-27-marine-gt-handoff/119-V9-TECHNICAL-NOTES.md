# Marine GT V9 — technical continuation inside the V8 history stop line

## 1. Purpose

V9 continues only the P0 engineering work that V8 declared safe: LL20 R2 definition, E6-M marine boost-role requirements, and the Taiyo dual-path common interface. It does not select or date any alternate-history program.

## 2. Important accounting correction

V44 reports the canonical E6-M-T 2,100 hp headline after a 0.975 T-product output-transmission debit. V7 then compared a Taiyo path defined from raw free-power-turbine shaft to propeller shaft against that post-debit headline as though both were the same station. V9 separates the stations.

At the 95% Taiyo all-in marine-path target, ten E6-M modules require about 2,159.6 raw hp each. The canonical 2,100 hp T-product headline corresponds to about 2,153.8 raw hp before the v44 0.975 product transmission. The difference at the same station is only about 0.27%. Therefore the central new problem is **marine role qualification and transmission/environment integration**, not creation of a materially new 2,160 hp thermodynamic product rating.

At a 93% ship path, the equivalent requirement is about 2,206.1 raw hp / 2,150.9 hp on the v44 T-output basis, still below the E6-M raw central installed capability. This remains a contingency test point, not an automatic rating.

The LL20 V7 sizing remains valid because LL20 was sized from the v44 pre-product-output-transmission installed shaft work and the 95% figure already represents its entire new marine PT-shaft-to-prop-shaft path. Adding a separate 0.975 debit would double-count a product-specific transmission that LL20 does not inherit as hardware.

## 3. LL20 R2 engineering package

The V7 selected R2 duty recalculates to about 20.561 kg/s and 2.684 MW / 3,599.5 raw hp per article at the named 3% Taiyo reserve and 95% all-in ship path. First-order similarity to E6-M yields an inlet tip near 0.486 m, hub near 0.267 m, blade height about 109 mm, sea-level inlet axial velocity about 130 m/s, and a same-tip-speed starting GG speed about 10.82 krpm. All are drawing starts, not acceptance values.

An additional useful facility consequence appears: a PR7 compressor at the E6 eta=0.84 release target and 20.56 kg/s represents roughly 5.27 MW of compressor aerodynamic power. V9 therefore does **not** require a newly invented >5 MW motor-driven full-compressor rig as the central R1 path. The information-efficient route is stage/cascade/partial-annulus work followed by a self-powered R2 full-core map, while full-scale spin/casing/combustor evidence is gathered where it matters. This is exactly where protagonist knowledge should act: choosing the high-information experiment, not granting efficiency.

At the v44 central BSFC planning coordinate, one LL20 R2 article at full duty consumes roughly 1.0 t/h fuel and represents about 11.9 MW LHV thermal input. The absorption stand must continuously take at least 2.684 MW shaft power; 3.0-3.2 MW nameplate bands correspond to explicit 10-20% headroom sensitivities, while a 4 MW class stand remains an optional program-created facility rather than an inherited historical fact.

## 4. E6-M marine boost role

The role evidence now focuses on:

- raw PT duty at the nominal 95% and contingency 93% ship paths;
- repeated 30- and 60-minute boost/rest cycles;
- salt ingestion, intake pressure loss, washing and compressor-map recovery;
- free-power-turbine map/vibration/bearing evidence;
- separately measured clutch, meshes, bearings and final-coupling losses;
- teardown/inspection evidence appropriate to the repeated intermittent duty.

The canonical ~2,300 hp short point remains a cycle-consistent ceiling/reference. V9 does not make repeated 2,300 hp operation a Taiyo requirement merely because it exists.

## 5. Taiyo common interface

A drawing-independent dual-path envelope can be defined without asserting that any shipyard reserved it. At a 15 m/s intake-face sensitivity the larger total clear-area case is the ten-E6-M branch at about 7.18 m2/ship or 3.59 m2/shaft bank. At 475 C / 35 m/s exhaust sensitivity the larger case is about 7.99 m2/ship, and at 550 C about 8.79 m2/ship. Exact trunks remain gated by measured pressure loss, temperature/back-pressure and actual yard routing.

The same half-ship raw boost work produces about 64.1 kN m at the 1,200 rpm comparison station. Six LL20 modules therefore buy fewer interfaces (three pinions per shaft bank instead of five), not a reduction in transmitted power. Absolute module-removal openings and foundation loads remain OPEN until complete shop-envelope and mass/CG drawings exist.

## 6. History boundary

Nothing in V9 states that LL20 was authorized, that a 3-4 MW stand was built, that E6-M passed the marine role tests, or that Taiyo drawings reserved the dual-path envelope. Those remain WORLDLINE-PROBABLE/SCENARIO as defined by V8. V9 only makes the engineering comparison cleaner and more reproducible.
