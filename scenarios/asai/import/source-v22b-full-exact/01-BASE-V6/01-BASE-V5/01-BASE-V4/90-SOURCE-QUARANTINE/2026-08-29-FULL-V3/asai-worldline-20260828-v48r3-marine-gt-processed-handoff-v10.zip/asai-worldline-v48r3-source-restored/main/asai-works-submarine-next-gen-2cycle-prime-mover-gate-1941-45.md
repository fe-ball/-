# 潜水艦 次世代2-cycle統合主機 gate 1941–45 — capability supply と requirement の分離

> **v36 current canonical parent.** 2-cycleを設計できることと、1942–44中央潜水艦が新機関系列を必要とすることを分離する。現行~19 kt / ~4,700 hp surface-power nicheには既存22号10型級pairが出力帯を閉じるため、新2-cycle量産系列を自動的に開かない。

## 0. 中央裁定

1. **31号6型**は1937時点の単動2-cycle設計/実機能力のH anchor。約1,900 BHP/400 rpm級のblower-drive engineで、艦隊潜水艦main-engine量産成熟の証明ではない。
2. **22号10型**は10-cylinder、4-cycle single-acting、約2,350 hp/基。2基で約4,700 hpとなり、v23/v35第二世代のsurface-power requirement bandを既存familyで覆える。
3. 1941年のB&W-linked大型2-cycle研究は6,000 PS級設計/単筒試験までをresearch capability anchorとする。series maturityへ飛ばさない。
4. よって現行第二世代には**engine-output requirement gapがない**。1942–44中央で新2-cycle production familyはGATED-OUT。
5. design/land-test shadowはCONDITIONALで保持する。higher power、installed volume/mass、mission fuel、signature、industrial commonalityなど具体要求が22号familyで閉じない時だけ再OPENする。
6. 約4,700 hpはmachinery bandであって19 ktの保証値ではない。hull resistance、displacement、propeller、shaft efficiencyは別受領。
7. 1941-12-08以後の実発注、建造、配備、損失、戦果はHISTORY/FROZEN。

## 1. temporal / requirement ledger

| 時期 | 項目 | v36 current判定 |
|---|---|---|
| 1937 | 31号6型 H anchor | single-acting 2-cycle ~1,900 BHP / 400 rpm級。2-cycle hardware/design capabilityを示すがfleet-series authorityではない |
| 1940–43 | 22号10型 H/available-family anchor | 10-cylinder 4-cycle single-acting ~2,350 hp/engine。pair≈4,700 hpでcurrent second-generation surface-power bandを覆う |
| 1941 | large 2-cycle research H anchor | B&W-linked ~6,000 PS-class design + single-cylinder test。research plausibilityはcurrent、series maturityは非自動 |
| 1941–44 | requirement-gap decision | ~19 kt second-generation nicheには新2-cycleを必要とするengine-output gapなし |
| 1942–44 | central production decision | **integrated 2-cycle production family = GATED-OUT**。v35 electrical/yard critical path中に不要な新toolingを開かない |
| 1942–45 | design / land-test shadow | CONDITIONAL。scavenging、boost、thermal/load、maintenanceを試験する設計枝は保持 |
| 1941–45 | reopen ledger | higher-power / installed-volume-mass / mission-fuel / signature / industrial requirementの少なくとも一つが22号familyで閉じない場合のみ再OPEN |
| 1941-12-08+ | actual procurement / construction / operations | HISTORY/FROZEN。engine orders、hull totals、deployment、loss、combatを再計算しない |

## 2. requirement-first rule

浅井の計算・掃気・過給・QC能力は「供給できる技術」の集合である。顧客/艦が要求していない新系列を、能力があるという理由だけで量産中央へ昇格させない。既存familyで要求を満たせる場合は、そのfamilyの成熟・共通化・spares/yard simplificationを優先する。

## 3. reopen acceptance ledger

再OPEN時には、単純なBHPだけでなく、specific mass/volume、fuel rate/mission range、scavenging blower/turbo complexity、thermal load、torsional vibration、maintenance points、yard tools/spares、factory tooling commonalityを既存22号familyと比較する。新2-cycleが少なくとも一つのhard requirementを明確に閉じる場合にのみseries候補へ上げる。
