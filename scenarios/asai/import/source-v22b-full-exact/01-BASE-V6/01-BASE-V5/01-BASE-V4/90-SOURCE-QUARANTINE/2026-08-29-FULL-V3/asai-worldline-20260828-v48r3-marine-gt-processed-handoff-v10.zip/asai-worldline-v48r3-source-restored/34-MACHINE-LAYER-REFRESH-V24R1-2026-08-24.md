# v24r1 machine-layer refresh

Semantic worldline: **v24**. Machine release: **v24r1**.

Changes:

- Generated `CANONICAL-MAIN-INDEX-V24R1.tsv` including all v24 canonical files.
- Carried the source-preserving v23r1 temporal chronology forward as `CANONICAL-CHRONOLOGY-V24R1.tsv/.jsonl`; changed legacy source line/hash references were remapped. v24 additions intentionally avoid new temporal Markdown tables, so chronology record count is unchanged.
- Updated schema to `CHRONOLOGY-SCHEMA-V24R1.json`.
- Updated recall gate to `CROSS-DOMAIN-PREFLIGHT-V24R1.md` and trigger list to `CAPABILITY-TRIGGER-MATRIX-V24R1.tsv`, adding TP part-load, torpedo-air, tank computation and Seiran/I-400 families.
- Updated `tools/validate_machine_layer.py` to v24r1 current pointers.
- Rebuilt `SHA256SUMS.txt` after validation inputs were finalized.

No war-history/OOB conclusion is advanced by the machine layer.
