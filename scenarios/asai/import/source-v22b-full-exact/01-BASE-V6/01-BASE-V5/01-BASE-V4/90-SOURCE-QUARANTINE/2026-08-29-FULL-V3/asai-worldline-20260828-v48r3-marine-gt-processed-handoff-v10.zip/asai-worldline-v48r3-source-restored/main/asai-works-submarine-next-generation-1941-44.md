# 潜水艦次世代再生成 1941–44 — 12kt第一世代から15kt級第二世代へ

> **v35/v36 authority update.** 電池・主電動機・工廠会計は `asai-works-submarine-battery-motor-yard-rebaseline-1938-44.md`、次世代2-cycle主機の要否は `asai-works-submarine-next-gen-2cycle-prime-mover-gate-1941-45.md` が上位。以下v23本文は船体/要求再生成の親として残す。

本稿はv16–v22で閉じた1927–43年の潜水艦再基底化を親にし、1941年時点の要求から次世代の非航空攻撃潜水艦を再生成したv23正本である。戦争結果・敵ASW・実戦損失を要求形成へ逆輸入しない。1941-12-08以後の暦を使う場合も、ここで扱うのは模型、水槽、陸上rig、公試、量産技術、材料・電機・機械の成熟だけである。

## 結論

- 1930年代の差は「超潜水艦の早出し」ではない。故障診断、品質管理、battery構造、主電動機rating、潜航trajectory、own-noise mapが早く成熟し、1941年に設計要求そのものを問い直せるようになる。
- 航空偵察巡潜はE14Y実用性改善のため直ちには消えない。一方、非航空攻撃型については「水上23–23.5kt、長大航続、航空設備、多数魚雷を全部同時に持つ」要求を外してよい。
- 第一世代の中央は基準約1,800t級、水上約21kt、水中12kt級、艦首6門・魚雷12本、航空設備なし、甲板砲なし、通常大型鉛battery 120cell群×3、約1,000hp級主電動機×4。特殊高出力batteryや未知の巨大motorを前提にしない。
- 4motor・3battery群・大電流配電・motor-generator運転を実用化することで、1941型は水中高速化の産業実証艦にもなる。
- 第71号艦系の低抵抗船型研究は独立した特殊兵器枝として隔離せず、1941型で成熟した電気系と合流させる。
- 第二世代の中央は基準約1,700t級、水上約19kt、水中15kt級、6門・魚雷10–12本、通常大型鉛battery 3群、4,400–4,500hp級の**motor 1-hour thermal rating**、円筒主体で量産性を残した低抵抗耐圧殻。**1-hourは15kt持続時間を意味しない**。史実伊201の19kt特殊艇を1941へコピーしない。
- 1941型の中央技術プログラムは**1–2 hull-equivalent complete electrical/yard sets**で工程・電機・充電・潜航・騒音データを閉じる。**3rd+はfactory/yard repeatability gate後のCONDITIONAL**。1943年後半に船型・motor thermal rating・full-bank duration・航洋性の門を通れば、第二世代設計を技術候補へ進める。実起工/配備はHISTORY/FROZEN。

## 設計思想の変化

従来大型巡潜は水上航洋性能を大きく重視していた。v16–v22で、主機を単純に増力するより、故障tail短縮、1号甲10型級への合理化、batteryのseparator/glass mat/槽・支持・換気・cycle/shock Q、主電動機の温度/rating、潜航trajectory、own-noise vs rpmを改善する方が実効性の高いことが分かった。

この蓄積により、1941年には「次の純攻撃潜水艦にも23kt級水上最高速が必要か」を設計問題として比較できる。水上最高速を少し落として余った馬力を電動機へ直接移す、という換算はしない。主機室、吸排気、燃料、耐圧殻配置、battery volume、外部タンク、ケーシング、propeller、潜航trajectoryまでを再統合する。

## 第一世代 1941型の中央像

基準1,800–1,850t級、全長100m弱、耐圧殻最大径約6.3mを中央とする。水上主機は海大七型系8,000hp級を使い、水上21kt級を確保する。水中は約1,000hp級主電動発電機4基を各軸2基タンデムで使い、実用3,600hp級、短時間4,000hp級を狙う。通常大型鉛batteryを120cell群×3とし、高出力時の一群当たり放電率を過度に上げず、水中12kt級を数十分まとまって使える構成とする。

12ktは静粛速度ではない。低速quiet band、通常水中戦術域、高速移動域を別々に受領し、cavitation onsetをspeed/rpm/depthで地図化する。価値は最高速の記録ではなく、攻撃位置変更、発射後離脱、接触切断などで従来8kt級艇にはない戦術速度を使えることにある。

三群batteryは航続だけでなく高出力時の電流分担を買う。充電は主電動機をgeneratorとして使う主軸系を本線とし、補助発電機は冗長電源として扱う。充電能力の上限はgenerator馬力よりbattery温度、電圧、水素、SOC差で決まる。

## 1943年までの純技術成熟

初号艇では、4motorの負荷分担・整流・温度、軸系ねじり振動、クラッチ過渡、propeller/cavitation、潜航中のpitch/overshoot、三battery群のSOC/温度偏差が主な調整点になる。量産改一では4,000hpを常用値にせず、実用ratingと短時間ratingを分ける。propellerは水上最高速を少し捨てて水中6–12kt域とcavitation marginを改善する可能性が高い。

この成熟は戦訓を必要としない。陸上耐久、模型、水槽、公試、battery cycle、騒音測定、建造工数だけで進める。

## 第二世代 15kt級への合流

第71号艦は低抵抗船型で水中高速を実証した史実Hとして残す。1941型が3battery群、4motor、大電流配電、充放電管理を産業化すると、高速枝は新battery・新motor・新船型を同時に開発する必要がなくなる。研究の焦点を低抵抗船型、外部付加物、艦橋、舵、propeller/cavitation、航洋性へ絞れる。

1,550 / 1,700 / 1,850t級の比較では、1,550tは高速には有利だが航洋余裕を削りやすく、1,850tは航続・兵装に余裕がある一方15ktを同じ通常battery/4motorで保証しにくい。中央は約1,700t級とする。水上主機は23kt級の大出力を要求せず、**22号10型級pairを含む約4,700hp machinery band**で19kt前後を狙うが、速度は船体/propulsive acceptanceで別に閉じる。水中は通常大型鉛battery三群と約1,100–1,125hp級×4の**motor 1-hour thermal rating**で4,400–4,500hp級を狙う。15ktはfull-bank high-rate dischargeで持続時間・end voltage・温度・H2・cavitationを別受領する。

これは史実潜高型を前倒ししたものではない。19kt級特殊高速ではなく、6門、10–12魚雷、8,000–10,000nmi級航続を持つ主力航洋攻撃潜水艦へ、水中優先思想を一段早く降ろすものとする。

## 量産・産業ゲート

1941型は従来非航空大型艇よりdiesel製造負荷を軽くする一方、batteryは約1.5倍/艇、1,000hp級主電動機は約2倍/艇を要求する。律速は造機から電機へ移る可能性がある。これは無料の量産改善として扱わない。

ただし第二世代も3battery群・4motor・6門・100m級という第一世代の産業基盤を共有するため、船型、水上主機、motor thermal ratingが主な差分になる。**工程安定化の中央は1–2 hull-equivalent setまで**で、3rd+はcell/motor factoryとyard installation/replacementの反復性を確認した後にだけ開く。

## v23で閉じるもの

- 1941–44次世代非航空攻撃潜水艦ニッチの再生成。
- 71号艦/水中高速枝を1941型電気系と合流させる方向。
- 22号10型級低出力主機の第二世代水上19kt級ニッチ。
- 通常鉛battery三群＋4motorを使う第一世代12kt級と第二世代15kt級の基本構成。
- 戦史を使わず、試験・設計・産業だけでここまで進める境界。

## v24で回収済みの横断残件

v23で横断OPENへ送った以下は、v24で `archive/aviation-pre-v48/v46-main/asai-works-seiran-i400-tp-integration-1942-44.md` を中心に技術側を閉鎖した。

1. 綿麻布フェノール積層材の静音歯車・水潤滑軸受：補機等へ選択適用し、own-noise実測で対象を絞る。主減速歯車へ一律適用しない。
2. 艦上専用計算：trim、battery/motor state、rating margin。quiet/avoid rpmは計算機でなく受領tachometer band/lightでよい。
3. 電子化・非ラッチ化：stored-program万能機でなく、限定目的連続演算器。
4. 聴音/探信儀：Asai-linked ferrite、封止、power-noise、bandpass/notch、blanking、simple AGCまで。sensor本体の非連鎖部分は背景技術力。

敵ASW、損失、作戦配置、戦訓による変更は引き続きhistory-side。
## 境界

敵ASW、実戦損失、作戦配置、建造優先順位、戦訓からの防音/深度/電子装備変更は本稿へ入れない。戦史を再開するときに別Aとして接続する。
