# Marine GT V5 — recalculation notes

## 1. E5 qualification craft: what is and is not closed

V5 does **not** force the qualification craft back into the inherited 25–27 t box. The closed arithmetic only reaches 20.998–21.122 t when the 20.5 t First Type baseline is given the E5 assembly and 20–30 minutes of GT sprint fuel. The remaining center shaft/prop/supports, intake separator and duct, exhaust, disconnect device, local structure, marine service delta, instrumentation and any deliberate hull enlargement must be designed explicitly.

The current E5 compressor flow itself gives a useful geometric anchor: 7.6 kg/s at sea-level density is about 6.20 m3/s. A 20–30 m/s separator-face velocity therefore asks for roughly 0.31–0.21 m2 of clear area. V5 records this geometry and even the sheet-skin arithmetic, but refuses to invent separator internals or pressure-loss mass.

The center shaft is treated the same way. At 1,000 hp and roughly 2,050–2,300 rpm, preliminary torque is about 3.1–3.5 kN m. A solid-shaft sensitivity with 40–60 MPa design shear gives roughly 65–75 mm diameter; actual fatigue/keyway/coupling/strut/prop design remains open. This is enough to size the arrangement without pretending a later PT shaft is the answer.

Because the old displacement target is removed, a 21.5–25 t speed table is kept only as a consequence map. If the finished takeoff lands nearer 22–24 t and the enlarged hull merely retains the inherited First-Type Crouch band, the first-order trial result is materially higher than the old 25–27 t table. That gain is not accepted until the actual enlarged hull earns its coefficient in tank/sea tests.

## 2. First demand above E6-M

The demand audit separates `large machinery competence` from `large hot-core product pull`.

- Industrial turbomachinery creates real large-flow rotor, casing, bearing, seal, balancing, metrology and continuous-operation experience. It does **not** automatically create a PR7 combustion core.
- Stationary GT strategy explicitly avoids large baseload products, so it is a negative pull for an invented 1930s large hot core.
- Aviation has a real E6-M pull, but the 13.2 kg/s medium core already closes the named pre-1941 shaft requirement. Later E7 large cores may not be back-projected to set an E6 calendar.
- Momi, the E5 qualification craft and No.600 all create strong marine learning/application demand but remain within E4/E5/E6-M scale.
- Kagero/Agano tactical-boost studies can create paper trades, but the military payoff per additional machinery burden is weaker.
- The **pre-planned Taiyo/Kasuga Maru attack-speed branch** is the first current ledger item with both a large incremental-power requirement and a qualitatively important role payoff. Therefore it is the strongest pre-1941 justification for >13.2 kg/s `R0/R1` work.

This does not select a core. For Taiyo 21→25.5 kt, the incremental propulsive requirement is about 19.9 kshp by the current cube-law sensitivity. At the current E6 installed specific work, with no scale bonus and an explicit 90–95% post-engine path sensitivity, the implied flow is roughly:

- 6 modules: ~20–21 kg/s each;
- 5 modules: ~24–25 kg/s each;
- 4 modules: ~30–32 kg/s each.

Those are **demand-derived design spaces**, not product names. A 10-module canonical E6-M path avoids a new core but pays many intake, accessory, clutch/pinion and maintenance interfaces; fewer modules pay a new-core development tax. The next gate is to compare those integration taxes before authorizing an R2 hot large-core article.

## 3. Terminology

V5 removes scalar `maturity` language from the overlay. The correct statement is always what has been proven: physics, rig, environment, accumulated hours, production repeatability, role qualification, application readiness or selection. A raised Asai acceptance bar is not a technology downgrade.
