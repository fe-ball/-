# E6/E7ターボプロップ部分負荷・長距離運用再監査（v24正本）

## 0. 修正の核心

旧稿の「軸熱効率26%からBSFC≈0.32kg/kWhを求め、E6-Mを約30%出力へ絞っても同値で経済巡航できる」という扱いを撤回する。

単純サイクル初期ターボプロップは設計点付近では良くても、部分負荷ではcompressor/turbine efficiencyと固定geometryのためBSFCが悪化する。E6/E7は**高負荷で強く、低負荷では弱い**。長距離多発機はmap・可変機構・engine shutdownでこれを回避する。

## 1. E6-M 暫定受領map

設計点：PR≈7、**airflow≈13.2kg/s central（12.5–14.0 trim）**、TIT/材料はv44 E6正本。旧10kg/s exact identityはv43でsuperseded。2,100hp headlineはv44でflat-ratedとして維持。

shadow BSFC：

- 90–100%負荷：0.32–0.35 kg/kWh。
- 75%：0.34–0.38。
- 60%：0.37–0.42。
- 50%：0.40–0.46。
- 40%：0.45–0.54。
- 30%：0.55–0.70。
- 20%：0.75以上もありうる。

これはcompressor map実測前の設計bandで、個別値は試験で更新する。

## 2. 1941–43の改善

未来的FADECや多段連続variable statorは使わない。

- 二位置程度のinlet guide vane。
- 始動/低出力用compressor bleed。
- free power turbine。
- full-feathering variable-pitch propeller。
- gas-generator rpm、P2/P3、aneroid、acceleration limiterを使う機械式fuel scheduling。
- TITはthermocouple表示で監視するが、電子閉loop必須にはしない。

E6改でも30%負荷をfull-power並みには戻せない。40–60%域を改善して使う。

## 3. 多発機の本命——engine shutdown cruise

必要shaft powerが小さいとき、全発を低負荷で回すより、一部を停止・featherして残りを高負荷で使う。

- 1941–42：まず一発停止巡航を試験。feather、長時間停止、冷間油系、air restart、unfeatherを受領。
- 1942–43：軽重量/好天/十分高度で左右対称二発停止を試験。
- 1943–44：長距離大型機では一発停止を通常候補、二発停止を航続/滞空modeとして受領可能。

engine restart不能時の二発/三発性能、左右非対称停止、油温・減速機温度は別試験。

## 4. E7-M 長距離flat-rated型

E7は既存正本の1942–44世代、PR≈8、熱効率≈28%、比仕事≈173kJ/kgを使う。

10kg/s級M coreの理論能力を最大出力商品にせず、**1,900–2,000shp定格**へflat-rate/down-rateして、寿命、hot-day、altitude、salt、surge marginへ余裕を返す。

shadow BSFC：

- 80–100%：0.30–0.33kg/kWh。
- 65–75%：0.31–0.35。
- 50–60%：0.34–0.39。
- 40%：0.39–0.46。
- 30%：0.47–0.55。

## 5. 深山→連山への修正

`asai-works-turboprop-shinzan-renzan.md` の「各600hp・BSFC0.32固定」は本稿が上位。

1941深山一一型は、6kmでE6-M usable powerが1,160–1,470shp/基なので600hpは約41–52%負荷。壊滅的ではないが0.32固定は楽観。

新中央：

- 静止大気最大航続：**3,700–4,100km級**。
- 実用航続：**3,200–3,600km級**。
- 通常爆装戦闘行動半径：**1,300–1,600km級**。
- 高重量時は四発、燃料消費後は左右外側2基をfeatherし内側2基を高負荷で使う候補。

1943二一型以後はE7-M-Lを入れ、3発/2発巡航と空力改善を含めて実用3,800–4,300km級、1944連山で4,500–5,000km級を設計帯とする。空中給油は別の作戦能力で、内部航続の誤差を隠す札にしない。

## 6. 大型飛行艇への接続

E6-M×4の1942型は離水/振動/始動/灯油/塩で優位でも、H8K2の7,000km級を直ちに置換しない。E7-M-L＋feather/restart成熟が長距離TP大艇の成立点。

## 7. CLOSED / OPEN

**CLOSED**：部分負荷一定BSFCの撤回、高負荷優位、engine shutdown cruiseの設計思想、E7長距離flat-rated型、深山/連山・大型飛行艇への再伝播。

**OPEN（P2）**：実compressor map曲線、個別rpm/PR/bleed点、restart MTBF、propeller径/gear ratio。
