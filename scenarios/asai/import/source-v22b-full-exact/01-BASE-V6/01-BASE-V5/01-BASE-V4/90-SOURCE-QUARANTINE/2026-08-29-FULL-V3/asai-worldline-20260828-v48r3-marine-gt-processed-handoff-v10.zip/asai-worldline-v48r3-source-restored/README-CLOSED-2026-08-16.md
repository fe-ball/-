# 浅井世界 2026-08-16 閉鎖パッケージ

## 状態

このZIPは、2026-08-15cのmainを**本文無変更のまま**保持し、技術監査の最終注記と歴史考察再開用メモを追加して閉じたもの。

### 今回追加したもの

1. `TECHNICAL-ADDENDUM-2026-08-16.md`
   - ラム全開高度＝100%全圧回収時の上限側評価
   - 最高速高度による資料帰属＝証明ではなく整合性チェック
   - G3M2金星四五型帰属＝LIKELY
   - 「排気札は速度に比例」を一般則として撤回
   - 未確認5項目は歴史考察のブロッカーにしない
   - 1941史実系レシプロ浅層監査をCLOSED FOR HISTORY USEと判定

2. `HISTORY-RESTART-1941-12-08-2026-08-16.md`
   - 技術監査前の歴史考察到達点を復元
   - 前史、ノモンハン残効、12月8日固定、初期集中原則、史実比較OOB、以前の仮置きの扱いを整理
   - 次回は1941年12月8日の機種別実在OOBから再開

## 読み順

歴史を再開する場合：

1. `HISTORY-RESTART-1941-12-08-2026-08-16.md`
2. `HISTORY-CARRY-FORWARD-1941-20260815.md`（短縮版）
3. `main/asai-works-china-war-1937-1941.md`
4. `main/asai-works-orbat-1941.md`

1941史実系レシプロの数値を使う場合：

1. `TECHNICAL-ADDENDUM-2026-08-16.md`
2. `main/asai-works-validated-derivations-2026-08-15.md`
3. `main/asai-works-piston-package-1941-application.md`

## 優先規則

- 数値の正本はmain。
- ただし、上記3点の**解釈・確度表現**については `TECHNICAL-ADDENDUM-2026-08-16.md` を優先する。
- 旧supplemental 21〜45は復活させない。
- 今回はmain本文を修正していない。
