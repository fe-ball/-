# 掃海・機雷対処再基線化 1939–45 — 木造低磁気艇、signature、機械・磁気・音響掃海の分離

> **v34 current canonical parent.** GFRP availability does not define WWII mine-countermeasure readiness. Mine mechanism, ship signature, sweep source, power, handling and maintenance are separate gates.

## 0. 中央裁定

1. 係維機雷はwire/cutter/depressor/otter等の**機械掃海**で扱う。非磁性船体は万能解ではない。
2. 磁気機雷は、(a)自艦磁気signature低減/degaussing と、(b)人工磁界を作るelectric sweepを分離する。
3. 音響機雷は、(a)自艦の不要騒音低減と、(b)掃海用の意図的なacoustic sourceを分離する。
4. 戦時中央艇体は**木造低磁気艇**。wood hullはmagnetically invisibleではなく、機関・軸・歯車・発電機・錨・兵装・電纜・搭載品をsignature ledgerに含める。
5. GFRPはv30材料枝のまま。1945級低速非磁性実験艇はconditionalであり、WWII掃海能力の前提にしない。
6. 1941-12-08以後の実配備、掃海具支給、機雷原、掃海成功率、損失はHISTORY/FROZEN。

## 1. H — 史実技術の分解

第二次大戦期の掃海は、木造船体、機械式掃海具、磁気掃海用高電流設備、音響掃海具を組み合わせる工学である。したがって世界線差は「新素材を一つ発明して解決」ではなく、signature measurement、degaussing、generator/cable acceptance、gear handling、予備品、訓練、整備手順へ出す。

## 2. MCM temporal ledger

| 時期 | 項目 | v34 current判定 |
|---|---|---|
| 1939–40 | 木造低磁気沿岸掃海艇package | hull材だけでなく機関・軸・発電機・錨・配線まで磁気signature ledger化する研究/試作を開始。TECHNICALLY READYへの入口 |
| 1939–41 | 係維機雷機械掃海 | wire/cutter/depressor/otter、曳航点、winch、recovery、emergency releaseを中央。既存原理の標準化・受領試験を改善 |
| 1940–41 | degaussing / signature station | heading/load状態を変えて測定し、coil currentと残留磁気を記録。木造艇にも残存磁気源がある前提 |
| 1940–41 | electric magnetic sweep power | high-current generator、switchgear、cable resistance/insulation/heating、current control、EMI、jettison/recoveryを別acceptance gate化 |
| 1940–41 | acoustic countermeasure preparation | own-ship quietingとacoustic sweep sourceを混同しない。source mounting、frequency/amplitude、tow/handling、crew exposureを試験項目化 |
| 1941 | wartime technical package | wood low-magnetic craft + mechanical sweepは技術中央。磁気/音響influence sweepの実装は敵機雷情報・海軍要求・支給体系を別gateにする |
| 1945+ | low-speed GFRP nonmagnetic demonstrator | CONDITIONAL。材料/構造実証としては可能性があるが、掃海艇採用・量産を自動的に意味しない |
| 1941-12-08+ | operational mine warfare | CONDITIONAL/HISTORY。実建造数、配備、gear issue、minefield、clearance、loss/effectは再計算しない |

## 3. 工学会計

### 3.1 magnetic signature

- hull材質だけでなく、主機、補機、shaft/gear、generator、anchor/chain、armament、cable route、予備品、搭載貨物を測定対象にする。
- acceptanceは「一度消磁した」ではなく、heading、load、yard work後の再測定を含む。
- degaussing coilは重量、銅量、発熱、絶縁、電源、EMIを消費する。

### 3.2 electric sweep

- high-current cableの抵抗・温度上昇・被覆損傷・海水浸入。
- generatorの連続/短時間rating、engine governor、switchgear arc、緊急切離し。
- tow geometryと艇の操縦性、他艦・自艦電装へのEMI。

### 3.3 acoustic sweep

- 掃海sourceは「静かな船」の逆で、意図的に大きな水中音を作る装置。
- source寿命、mount/tow荷重、周波数再現性、電源または機械駆動、crew exposureを別に受領する。
- own-noise reductionは安全余裕/trigger avoidanceに効くが、掃海sourceそのものではない。

## 4. A — 採用形

1939–41の技術中央は、木造低磁気沿岸艇に機械掃海gearを載せ、magnetic signature/degaussing stationを整備し、敵influence mineが要求を作った時点でelectric/acoustic sweep kitを追加できる体系である。GFRPは待たない。

実際の海軍発注・配備・機雷原対処成果はhistory gateを通す。
