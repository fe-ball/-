# 69 — RADIO / RADAR RELIABILITY REBASELINE v33

v33 closes the P1 radio-radar reliability audit.

Central decision: do not treat Japanese wartime electronics as uniformly poor, and do not turn Asai materials into earlier radar invention. Asai's realistic advantage is environmental sealing, wiring/bonding/EMI, power conditioning, acceptance testing, fault feedback, maintainability and production repeatability.

Historical radar timing remains a separate gate. H-6 airborne search radar research starts 1941-11 and completes 1942-08 in the historical calibration. Reliability improvements apply once a radar programme exists; they do not create 1939–40 operational airborne radar.

Power-supply/system integration and training are independent gates. A reliable set is not automatically a reliable combat information system.

Canonical parent: `main/asai-works-radio-radar-reliability-rebaseline-1935-45.md`.
