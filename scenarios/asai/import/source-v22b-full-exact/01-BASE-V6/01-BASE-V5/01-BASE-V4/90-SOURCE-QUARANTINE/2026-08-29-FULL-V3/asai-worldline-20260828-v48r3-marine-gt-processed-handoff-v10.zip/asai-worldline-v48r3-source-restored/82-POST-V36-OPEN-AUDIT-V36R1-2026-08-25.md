# POST-v36 OPEN AUDIT — v36r1

## CLOSED / REBASED
- optional next-generation integrated 2-cycle submarine prime mover: **not required** for the current ~19 kt / ~4,700 hp second-generation niche.
- 22号10型-class pair retained as central existing-family candidate; exact 19 kt remains a hull/propulsive acceptance question.
- 31号6型 and the 1941 single-cylinder large-2-cycle work retained as technology anchors, not automatic production authority.
- capability-supply is explicitly separated from customer/ship requirement.

## NEXT P1
1. E8/E9+ later-war propulsion only when a specific aircraft/ship requirement is introduced.

## P2 RETAINED
- exact second-generation submarine hull/propeller/resistance/cavitation and 15 kt duration after final electrical ratings.
- integrated 2-cycle design/land-test shadow only if a concrete reopen requirement is specified.
- battery/motor factory throughput and yard installation hours still require a dedicated industrial source set.

## HISTORY BOUNDARY
Post-1941-12-08 actual submarine engine orders, hull construction totals, deployments, losses, combat outcomes and enemy-ASW response remain FROZEN.
