# Migration Note — v11 → v12 Zero fuel/thermal + early-history uncertainty

- Ha-26-II/Z940 low-altitude-only assumption retracted; source conflict is explicit.
- New canonical fuel/thermal comparison file added.
- Sakae 12 remains 1940 production winner; Zuisei 940 remains accepted development competitor.
- Early Zero exact serial/date claims converted to confidence bands and functional gates.
- Model 21 folding-tip start canonicalized as 65–67-airframe-class uncertainty band, not a single exact serial.
- Internal aircraft/engine audit codes remain allowed, but historical designation/name remains primary when a historical equivalent exists.
