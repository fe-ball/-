#!/usr/bin/env python3
"""Marine large-core scale audit, pass 1.

Purpose:
- remove undocumented scale-gain shorthand from E5/E6 large marine working classes;
- keep the accepted v40/v44 thermodynamic accounting;
- distinguish engine/free-power output from propeller-shaft power after a marine reduction path;
- expose low-TIT bleed assumptions instead of hiding them in a rating.

This is a handoff computation, not a canonical rebaseline.
"""
from __future__ import annotations
import csv, math
from pathlib import Path

CP=1.005; GAMMA=1.4; T1=288.0; A=(GAMMA-1)/GAMMA; HP_KW=0.745699872; LHV=43.0
MARINE_REDUCTION_EFF=0.975


def t_comp(pr,eta): return T1*(1+(pr**A-1)/eta)
def comp_work(pr,eta): return CP*(t_comp(pr,eta)-T1)

def bleeds_e5(total):
    # distribute a chosen total bleed in the same rough proportions as v40 non-Ni 765C.
    shares=(.25,.425,.20,.125) # vane, rotor, root, seal sums 1.0
    taps=(1.0,1.0,.75,.55); rec=(.85,.55,.15,0.0)
    return [{'b':total*s,'tap_frac':t,'recovery':r} for s,t,r in zip(shares,taps,rec)]

def installed_e5(tit_c, bleed_total):
    pr=6.0; eta=.83; dp=.035; ex=1.015; mech=.992; acc=1.0; comb=.985
    t3=tit_c+273.15; b=bleeds_e5(bleed_total); bt=sum(x['b'] for x in b)
    wc=(1-bt)*comp_work(pr,eta)
    for x in b: wc += x['b']*comp_work(pr**x['tap_frac'],eta)
    rt=pr*(1-dp)/ex; expansion=CP*eta*(1-rt**(-A))
    hw=(1-bt)*t3
    for x in b: hw += x['b']*x['recovery']*t_comp(pr**x['tap_frac'],eta)
    wt=expansion*hw
    w=mech*wt-wc-acc
    q=((1-bt)*CP*(t3-t_comp(pr,eta)))/comb
    eta_s=w/q; bsfc=3.6/(LHV*eta_s)
    return w,eta_s,bsfc

def bleed_e6(total):
    base=[(.012,1.0,.85),(.022,1.0,.55),(.012,.75,.15),(.009,.55,0.0)]
    s=total/sum(x[0] for x in base)
    return [{'b':b*s,'tap_frac':t,'recovery':r} for b,t,r in base]

def installed_e6(tit_c, bleed_total):
    pr=7.0; eta=.84; dp=.030; ex=1.012; mech=.993; acc=1.2; comb=.987
    t3=tit_c+273.15; b=bleed_e6(bleed_total); bt=sum(x['b'] for x in b)
    wc=(1-bt)*comp_work(pr,eta)
    for x in b: wc += x['b']*comp_work(pr**x['tap_frac'],eta)
    rt=pr*(1-dp)/ex; expansion=CP*eta*(1-rt**(-A))
    hw=(1-bt)*t3
    for x in b: hw += x['b']*x['recovery']*t_comp(pr**x['tap_frac'],eta)
    wt=expansion*hw
    w=mech*wt-wc-acc
    q=((1-bt)*CP*(t3-t_comp(pr,eta)))/comb
    eta_s=w/q; bsfc=3.6/(LHV*eta_s)
    return w,eta_s,bsfc

E5_CLASSES=[('E5-large-A',17.1,11750),('E5-large-B',30.4,8750)]
E6_CLASSES=[('E6-large-A/甲',29.7,9000),('E6-large-B/乙',52.8,6750),('E6-large-C/丙',82.5,5400)]

rows=[]
def emit(family, cls, flow, rpm, tit, bleed, basis, model):
    w,eta,bsfc=model(tit,bleed)
    engine_kw=w*flow; engine_hp=engine_kw/HP_KW
    prop_kw=engine_kw*MARINE_REDUCTION_EFF; prop_hp=prop_kw/HP_KW
    rows.append(dict(family=family,analysis_class=cls,status='OPEN-SCALE-AUDIT',massflow_kg_s=flow,gg_rpm=rpm,
                     TIT_C=tit,bleed_total_pct=100*bleed,bleed_basis=basis,
                     installed_specific_work_kJ_kg=round(w,4),shaft_efficiency_pct=round(100*eta,3),
                     engine_output_hp=round(engine_hp,1),marine_reduction_eff=MARINE_REDUCTION_EFF,
                     propeller_shaft_hp=round(prop_hp,1),engine_shaft_bsfc_kg_kWh=round(bsfc,4),
                     prop_shaft_effective_bsfc_kg_kWh=round(bsfc/MARINE_REDUCTION_EFF,4)))

# E5: 765/800 are v40 anchor accounting. 700/735 are sensitivity cases.
# 700C is shown twice: zero-bleed is a thermodynamic upper ceiling; 2.5% is a conservative low-TIT working floor.
for cls,flow,rpm in E5_CLASSES:
    emit('E5',cls,flow,rpm,700,.000,'SENSITIVITY CEILING: zero cooling/seal bleed; not a rating',installed_e5)
    emit('E5',cls,flow,rpm,700,.025,'SENSITIVITY WORKING: 2.5% minimum cooling/seal bleed',installed_e5)
    emit('E5',cls,flow,rpm,735,.030,'SENSITIVITY WORKING: 3.0% total bleed',installed_e5)
    emit('E5',cls,flow,rpm,765,.040,'v40 non-Ni 765C central bleed total',installed_e5)
    emit('E5',cls,flow,rpm,800,.060,'v40 non-Ni 800C central bleed total',installed_e5)

# E6: 820/870 are v44 anchors. 780/800 interpolate/extrapolate the accepted 820->870 bleed slope.
for cls,flow,rpm in E6_CLASSES:
    for tit in (780,800,820,870):
        if tit==820: B=.041; basis='v44 non-Ni 820C central bleed total'
        elif tit==870: B=.050; basis='v44 non-Ni 870C central bleed total'
        else:
            B=.041+(tit-820)*(.050-.041)/50.0
            basis='OPEN interpolation/extrapolation of v44 820->870 bleed slope'
        emit('E6',cls,flow,rpm,tit,B,basis,installed_e6)

out=Path(__file__).with_name('13-MARINE-LARGE-SCALE-AUDIT-V1.tsv')
with out.open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t',lineterminator='\n'); w.writeheader(); w.writerows(rows)
print(out)
