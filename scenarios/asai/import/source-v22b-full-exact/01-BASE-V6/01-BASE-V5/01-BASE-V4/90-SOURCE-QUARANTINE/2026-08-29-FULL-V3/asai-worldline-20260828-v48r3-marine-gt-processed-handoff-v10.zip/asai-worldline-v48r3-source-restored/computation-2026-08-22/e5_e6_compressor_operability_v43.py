#!/usr/bin/env python3
import csv, math
from pathlib import Path

OUT=Path(__file__).with_name('E5-E6-COMPRESSOR-OPERABILITY-V43.tsv')
GAMMA=1.4
T1=288.15
RHO=1.225

cases=[
 dict(case='E5-S-standard',generation='E5',scale='S',architecture='5 axial + 1 centrifugal',PR=6.0,eta_c=0.83,flow=7.6,flow_band='7.4-7.9',axial_n=5,axial_sr=1.17,rpm=17500,impeller_d=0.4966,Vx=110,hub_tip=0.50,surge_ss=13.0,surge_trans=10.0,choke=8.0,igv='fixed standard; variable optional on HF/J trim',bleed='after axial stage 3; 10-12% below 60% Nc, closed by 80-82% Nc',idle='55-60% Nc',critical='1st 32-38% Nc; 2nd >125% Nc',clearance='axial hot 0.45-0.65 mm; centrifugal 0.55-0.80 mm'),
 dict(case='E6-S-standard',generation='E6',scale='S',architecture='7 axial + 1 centrifugal',PR=7.0,eta_c=0.84,flow=7.8,flow_band='7.6-8.2',axial_n=7,axial_sr=1.16,rpm=18000,impeller_d=0.5000,Vx=115,hub_tip=0.50,surge_ss=12.0,surge_trans=9.0,choke=8.0,igv='mechanically scheduled VIGV -15deg to 0deg by ~85% Nc',bleed='after axial stage 4; 10-14% below 60% Nc, closed by 80-83% Nc',idle='58-62% Nc',critical='1st 35-42% Nc; 2nd >122% Nc',clearance='axial hot 0.40-0.60 mm; centrifugal 0.50-0.75 mm'),
 dict(case='E6-M-standard',generation='E6',scale='M',architecture='14 axial',PR=7.0,eta_c=0.84,flow=13.2,flow_band='12.5-14.0',axial_n=14,axial_sr=7.0**(1/14),rpm=13500,impeller_d=0.0,Vx=130,hub_tip=0.55,surge_ss=10.0,surge_trans=8.0,choke=7.0,igv='mechanically scheduled VIGV -20deg to 0deg by 85-90% Nc; fixed stators thereafter',bleed='two simple dump bands after stages ~5 and ~10; total 10-15% at low Nc, staged closed by ~82-88% Nc',idle='62-65% Nc',critical='1st 45-52% Nc; no dwell; 2nd >118% Nc',clearance='rear axial hot target 0.40-0.55 mm; reject >0.65 mm; front 0.5-0.8 mm'),
]

rows=[]
for c in cases:
    pr_ax=c['axial_sr']**c['axial_n']
    pr_hp=c['PR']/pr_ax if 'centrifugal' in c['architecture'] else 1.0
    area=c['flow']/(RHO*c['Vx'])
    tip=math.sqrt(4*area/(math.pi*(1-c['hub_tip']**2)))
    hub=tip*c['hub_tip']
    bh=(tip-hub)/2
    if c['impeller_d']:
        u=math.pi*c['impeller_d']*c['rpm']/60
    else:
        u=math.pi*tip*c['rpm']/60
    rows.append({
      'case':c['case'],'generation':c['generation'],'scale':c['scale'],'architecture':c['architecture'],
      'design_PR':f"{c['PR']:.3f}",'eta_c_target':f"{c['eta_c']:.3f}",'design_corrected_flow_kg_s':f"{c['flow']:.3f}",'full_speed_trim_band_kg_s':c['flow_band'],
      'axial_stage_count':c['axial_n'],'avg_axial_stage_PR':f"{c['axial_sr']:.4f}",'axial_booster_PR':f"{pr_ax:.3f}",'centrifugal_stage_PR':f"{pr_hp:.3f}",
      'design_rpm':c['rpm'],'tip_speed_coordinate_m_s':f"{u:.1f}",'inlet_tip_d_m':f"{tip:.4f}",'inlet_hub_d_m':f"{hub:.4f}",'inlet_blade_h_m':f"{bh:.4f}",
      'steady_min_flow_margin_to_surge_pct':f"{c['surge_ss']:.1f}",'transient_min_flow_margin_to_surge_pct':f"{c['surge_trans']:.1f}",'design_choke_margin_pct':f"{c['choke']:.1f}",
      'IGV_VSV_policy':c['igv'],'bleed_schedule':c['bleed'],'ground_idle':c['idle'],'rotordynamic_gate':c['critical'],'clearance_gate':c['clearance']
    })

# qualification operating-line coordinates: design/acceptance targets, not measured maps
mapdefs={
'E5-S-standard':[(0.55,2.2,4.4,14),(0.60,2.6,4.8,14),(0.70,3.4,5.5,13),(0.80,4.2,6.2,13),(0.90,5.1,6.9,13),(1.00,6.0,7.6,13)],
'E6-S-standard':[(0.60,2.8,5.0,13),(0.70,3.6,5.7,12),(0.80,4.6,6.4,12),(0.90,5.7,7.1,12),(1.00,7.0,7.8,12)],
'E6-M-standard':[(0.62,2.8,8.4,11),(0.70,3.5,9.5,10),(0.80,4.5,10.7,10),(0.90,5.7,12.0,10),(1.00,7.0,13.2,10)],
}
for name, pts in mapdefs.items():
    for N,pr,w,sm in pts:
        rows.append({'case':name+'-map','generation':'','scale':'','architecture':'qualification operating-line target',
          'design_PR':f"{pr:.3f}",'eta_c_target':'','design_corrected_flow_kg_s':f"{w:.3f}",'full_speed_trim_band_kg_s':'',
          'axial_stage_count':'','avg_axial_stage_PR':'','axial_booster_PR':'','centrifugal_stage_PR':'','design_rpm':f"{N:.2f} Nc",
          'tip_speed_coordinate_m_s':'','inlet_tip_d_m':'','inlet_hub_d_m':'','inlet_blade_h_m':'',
          'steady_min_flow_margin_to_surge_pct':f"{sm:.1f}",'transient_min_flow_margin_to_surge_pct':'','design_choke_margin_pct':'',
          'IGV_VSV_policy':'acceptance coordinate; not a measured compressor map','bleed_schedule':'scheduled per parent architecture','ground_idle':'','rotordynamic_gate':'','clearance_gate':''})

fields=list(rows[0].keys())
with OUT.open('w',newline='',encoding='utf-8') as f:
    w=csv.DictWriter(f,fieldnames=fields,delimiter='\t')
    w.writeheader();w.writerows(rows)
print(OUT)
