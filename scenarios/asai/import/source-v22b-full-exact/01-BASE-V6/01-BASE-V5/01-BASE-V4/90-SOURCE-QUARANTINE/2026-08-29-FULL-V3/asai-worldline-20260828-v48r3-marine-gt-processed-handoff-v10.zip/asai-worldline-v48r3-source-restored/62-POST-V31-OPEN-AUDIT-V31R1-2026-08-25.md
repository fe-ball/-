# v31r1 post-audit OPEN queue

## CLOSED / REBASED
- v31 Army Ki-43/Ki-44 H→A completed from historical requirements and load-state-specific H anchors.
- Ki-43 A0 central: ~503–508 km/h @ ~4km, standard turbo NO; margin reinvested in Ho-103 availability path, radio/electrics, local structure and production repeatability.
- Ki-44 H fixed at 583.5 km/h / 2,550kg / Ha-41 1,260PS / 4,000m 4:38; physical I 596.9–601.5 km/h; A0 ~596–600 km/h, standard turbo NO.
- old 1941 P-47-class Ki-64 production/escort causality is superseded.
- Ki-64 designation restored to the Kawasaki tandem-Ha-40 experimental branch; sustained 7–10km turbo fighter is unnamed and conditional.
- Ki-87/Ki-94 are no longer rejected because Ki-64 allegedly pre-occupies the high-altitude seat; they become conditional candidates if an explicit later high-altitude requirement appears.
- v30/v29/v28/v27/v26/v25 gates remain inherited.

## P1 — next
1. Rotorcraft 1942+ requirement/maturity rebaseline.
2. Radio/radar reliability and aircraft/shipboard environmental integration.
3. Mine-sweeping requirement/material/propulsion integration and survey-artillery meteorology.
4. Submarine battery/motor/yard accounting and optional next-generation 2-cycle integrated propulsion.

## CONDITIONAL / HISTORY
- separate sustained 7–10km exhaust-turbo fighter requirement and prototype.
- historical Ki-64 experimental branch actual worldline schedule beyond the technical shadow.
- Ki-43/Ki-44 post-1941 production, deployment and combat effects.
- Ki-87/Ki-94 actual development/procurement decisions.
- all post-1941-12-08 OOB, production, deployment, losses, combat and enemy reaction remain FROZEN.
