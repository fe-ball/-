# 富嶽 160t級超々重爆 —— 技術成立shadow 1942–46

> **status: CONDITIONAL DEVELOPMENT SHADOW / TECHNICAL DESIGN CLOSED**
>
> 本稿は「中島Z/富嶽の要求が実際に国家計画としてgreen-lightされた場合、浅井技術を深く入れるとどの設計へ収束するか」を閉じる。1942–46の各milestone、初飛行、調達24/36機、北米攻撃等は**current historyではない**。

## 1. 設計思想

史実的な160t・20t・16,000km・680km/hという一点要求を、そのまま同時成立させない。計算体系で**payload-range-speed envelope**へ分解する。

維持するもの：

- 160t級airframe。
- 20t structural bomb capability。
- 成熟型680km/h級を狙う速度野望。
- 12,000km超の大陸間mission。

拒否するもの：

- **20t×16,000km×680km/hを同時にnormal missionとして要求すること**。

## 2. airframe central shadow

- ground MTOW **155–165t、中央160t**。
- maximum airborne structural gross **170–175t候補**（top-up fuel専用の別limit）。
- operating empty **76–78t、中央77t**。
- span **65–68m、中央66m**。
- wing area **385–395m²、中央390m²**。
- AR 約11.2。
- crew **13名標準**、12基幹＋mission specialist 1。
- pressurized forward/aft crew sections＋connection tunnel。全胴体与圧はしない。
- cabin differential **0.37kg/cm²級**。

翼内燃料を発動機間へ分散し、燃料消費順をCGだけでなく**wing-root bending / torsion / flutter margin**で最適化する。170t超top-up時も指定翼tankへ入れることを構造条件とする。

## 3. E7-L/E8-L 航空大型コア

富嶽用は20kg/s小コアで5,000shpを無理に出さない。**Lコア上端36–40kg/s級を大きく作り、海面ではflat-rateして高度出力を買う**。

### E7-L-N-T shadow

- corrected flow **36–40kg/s**。
- sea-level rating **4,400–4,700shp**。
- 8km **4,100–4,400shp級**。
- 9km **3,700–3,900shp級**。

### E8-L-N-T shadow

- corrected flow **38–40kg/s**。
- PR 8–10級候補、TIT約940℃級。
- sea-level flat-rated **5,000–5,200shp**。
- 8km **4,600–4,900shp目標**。
- 9km **4,100–4,400shp級**。

高度出力はmajor gate。sea-level powerをそのまま高度へ持ち上げない。

## 4. 減速機・propeller

5,000shpを650–700rpmへ入れるprop shaft torqueは約51–55kN·m級。E6 reducerの単純拡大ではなく**専用two-stage planetary/compound planetary**を本線とする。

- power turbine 11,000–12,000rpm級候補。
- total ratio **16–18:1級**。
- gear mesh / turbine order / prop blade-passage / shaft torsion / nacelle-wing modesを計算とrigで同時監査。
- ここが推進系最大のreliability gate。

propeller第一候補：

- single rotation。
- diameter **5.0–5.3m**。
- **5–6 blades** broad-chord。
- **650–700rpm級**。
- 680km/h・8–9kmでもtip helical Machを概ね0.85–0.89級へ抑える。
- contra-rotationはblade loading/diameter/vibrationで失敗した場合のbackup。

blade materials：大型中空金属→metal root/beam＋CFRP shell→大型CFRP primary bladeの順。初号から全CFRPを必須にしない。

## 5. installed propulsion mass

1944–45時点で後世T34級の軽さを直接置かない。

- core＋power turbine＋reducer＋accessories：**1.5–1.9t/基**。
- 5m-class prop：**0.6–0.9t/基**。
- mount/inlet/exhaust/oil：**0.25–0.35t/基**。
- installed total：**2.4–3.1t/基**。

6基で14–19t級。77t operating emptyの中で成立する。

## 6. cruise and engine shutdown

長距離では六発を低loadで回し続けない。

- heavy initial phase：6 engines。
- 30–40t fuel burn後、対称な一対をshutdown/full-feather。
- 残り4基を55–70%級の効率域へ上げる。

E8 large-core design-point BSFCは**0.27–0.30kg/kWh級候補**、低loadでは悪化するためshutdown戦略を使う。0.27未満を無条件中央にしない。

## 7. performance envelope

### speed

- E7 prototype：**620–650km/h**。
- mature E8：**660–690km/h @8–9km**。
- 680は成熟型の中央～上側目標。初号保証値ではない。

### payload-range practical shadow

| payload | practical range |
|---:|---:|
| 20t | **8,000–9,500km** |
| 15t | **9,000–10,500km級** |
| 10t | **10,000–12,000km** |
| 5t | **12,000–14,000km** |
| ferry/very light | 14,000km超、条件良好なら16,000km級へ接近 |

空中給油は通常任務成立条件ではない。160t離陸後に10–15t top-upするspecial missionは可能。16,000km級ground distanceは季節風、route、refuel、one-way/別着陸地点等を含む特殊作戦で検討する。

## 8. wing / gear / runway

### wing

390m²なら160tで約410kg/m²。Fowler＋leading-edge devicesで全機CLmax 2.4–2.6級を目標。

- 160t stall **181–188km/h級**。
- takeoff safety speed **200–210km/h級**。
- 110t return approach **185–195km/h級**。

### gear

初号からmulti-wheel。第一候補：

- main **6 wheels per side (3-axle bogie×2)**。
- twin nose wheel。
- 160t時 main wheel average 約12–13t/輪級。

AT-3/Ki-92から脚そのものを拡大コピーせず、load-sharing、tire heat、brake、shimmy、hydraulics、landing impact、pavement dataを移植する。

### runway/base

- standard heavy runway：**2,800–3,000m × 約60m**。
- test base：**3,200m級**。
- overrun/clear areaを両端に確保。
- taxiway/hardstand/fuel/bomb handling/crane/firefightingまで重舗装が必要。

富嶽は全国の普通基地から使う機体ではなく、少数専用基地を要する国家級兵器。

## 9. landing and fuel dump

reverse pitchを使わない。normal return weightを**100–115t**へ落とす。

- emergency landing target **135–140t級**。
- rapid fuel dumpを必須systemとする。
- six→five enginesで高度を維持しつつdumpして帰る手順を設計する。

## 10. defense / electronics / crew

### defense

主防御は高度・速度・route/weather・electronic warning・system redundancy。

標準：**20mm×6、remote twin turret×3**（upper/lower/tail）。最大航続では4門軽装optionを許容。

射撃はoptical sight＋gyro angular rate＋airspeed/altitude input＋electromechanical lead calculator＋electro-hydraulic servo。初号にradar rangingを必須としない。

燃料は全量完全self-sealingにせず、multiple wing cells、shutoff、collector、重点self-seal、fire detection/suppression、dual feedを使う。

### electronics

- three-axis autopilot。
- altitude/heading hold。
- engine sync/monitoring。
- fuel-transfer advisory calculator。
- radio direction finding、celestial navigation、drift meter。
- bombing/fire-control dedicated electromechanical computers。
- navigation/terrain/bombing radarはspace/power/radomeをreserve、availability gate別。

### crew

standard **13**：pilot、copilot、relief pilot、chief/assistant engineer、navigator、bombardier/mission navigator、radio、electronic/nav equipment、fire-control chief、upper gunner、lower/tail gunner、mission specialist。

rear pressure sectionに4-bunk級rest area、water、hot drink/simple food、lavatory、first aid。15h級missionでは休憩能力そのものをcombat equipmentとみなす。

## 11. development shadow

- **1942 H2**：中島自主Z concept。
- **1943 H1**：浅井がperformance/propulsion comparisonへ深く参加。一点要求をenvelope化。
- **1943 H2**：陸海軍joint research green-lightが起きた場合、390m²級wing、E7-L aviation core、5m prop、gear、pressure crew sectionをformal study。
- **1944**：E7-L ground run、gear/prop rig、full-scale wing box、gear、fuel cells destructive test。深山等でderated flight test candidate。
- **1945頃**：gateが通ればE7-L first prototype candidate。
- **1945–46**：E8-L retrofit/mature candidate。

すべて**CONDITIONAL**。戦史へ昇格させない。

## 12. force-size shadow

兵器化するなら第一調達24、完成戦力36機級が合理的な設計対象。

- 12機をbasic unit。
- 8–10機級operational package。
- Ki-92 tanker/transport 12–18機級が支援候補。
- aerial refuelingはspecial mission用。

この数は技術・兵站設計用shadowであり、実調達数ではない。

## 13. closure

**technical design: CLOSED**。

残るgateはE7/E8-L high-altitude map、5,000shp reducer life、5m prop blade/hub life、large pressure section fatigue、radar reliability、そして国家が専用基地・燃料・生産を買うかというhistory/policy側。
