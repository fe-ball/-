#!/usr/bin/env python3
from pathlib import Path
import csv,json,hashlib,re
ROOT=Path(__file__).resolve().parents[1]
MAIN=ROOT/'main'
OLD=ROOT/'CANONICAL-CHRONOLOGY-V45R1.tsv'
NEW=ROOT/'CANONICAL-CHRONOLOGY-V46R1.tsv'
FIELDS=['record_id','start_year','end_year','date_precision','date_text','domain','domain_tags','authority_rank','semantic_status','semantic_note','entity','stage_R','stage_P','stage_X','stage_N','source_file','source_line','source_table','time_column','source_sha256','row_json','search_text']

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def heading(p):
    for ln in p.read_text(encoding='utf-8').splitlines():
        if ln.startswith('# '): return ln[2:].strip()
    return ''

def source_line(rel, needle):
    lines=(ROOT/rel).read_text(encoding='utf-8').splitlines()
    for i,l in enumerate(lines,1):
        if needle in l:return i
    raise RuntimeError(f'needle not found {rel} {needle}')

def rec(rid,start,end,prec,date,domain,tags,rank,status,entity,src,needle,fact,note=''):
    line=source_line(src,needle)
    rowj=json.dumps({'time':date,'entity':entity,'fact':fact},ensure_ascii=False,separators=(',',':'))
    return dict(record_id=rid,start_year=start,end_year=end,date_precision=prec,date_text=date,
                domain=domain,domain_tags=tags,authority_rank=str(rank),semantic_status=status,semantic_note=note,
                entity=entity,stage_R='',stage_P='',stage_X='',stage_N='',source_file=src,source_line=str(line),
                source_table='v46 canonical prose',time_column='explicit temporal scope',source_sha256=sha(ROOT/src),
                row_json=rowj,search_text=f'{date} | {entity} | {fact}')

def main():
    with OLD.open(encoding='utf-8',newline='') as f:rows=list(csv.DictReader(f,delimiter='\t'))
    # v46 closes old jet placeholders/gate.
    status_updates={'CHR-0144':'superseded','CHR-0180':'superseded','CHR-0647':'superseded'}
    for r in rows:
        if r['record_id'] in status_updates:
            r['semantic_status']=status_updates[r['record_id']]
            r['semantic_note']='superseded by v46 E6-M J/JF installed-thrust authority'
        # patched prose changes source hashes; refresh all source-preserving hashes.
        p=ROOT/r['source_file']
        if p.exists():r['source_sha256']=sha(p)
    src='main/asai-works-e6-m-jf-installed-thrust-rebaseline-1938-43.md'
    adds=[
      rec('CHR-0658','1938','1943','year-range','1938–43','aviation','E6-M;jet;JF;installed-thrust;authority',215,'scope','v46 E6-M J/JF installed-thrust authority',src,'v46 current authority.','v46 closes E6-M pure-jet and aft-fan engine-side installed thrust; aircraft propagation remains separate.'),
      rec('CHR-0659','1938','1943','year-range','1938–43','aviation','E6-M-J;non-Ni;installed-thrust',215,'current','E6-M-J non-Ni product thrust',src,'~850 kgf/engine','E6-M-J non-Ni 870C calculates ~854 kgf static and is flat-rated at ~850 kgf/engine.'),
      rec('CHR-0660','1938','1943','year-range','1938–43','aviation','E6-M-N-J;Ni;installed-thrust',215,'current','E6-M-N-J Ni product thrust',src,'~900 kgf/engine','E6-M-N-J Ni 920C calculates ~907 kgf static and is flat-rated at ~900 kgf/engine.'),
      rec('CHR-0661','1941','1943','year-range','1941–43','aviation','E6-M-JF;aft-fan;installed-thrust;TSFC',215,'current','E6-M-JF production installed point',src,'~950–1,000 kgf/engine','E6-M-JF production uses ~835C, BPR~1.0 and FPR~1.30; central ~984 kgf and product band ~950–1,000 kgf/engine; same-TIT effect +20.9% thrust and -17.3% TSFC.'),
      rec('CHR-0662','1941','1943','year-range','1941–43','aviation','E6-M-JF;free-turbine;fan;spool',215,'current','E6-M-JF aft-fan architecture',src,'independent free-LP-turbine/fan spool','Gas-generator compressor remains single-spool, but JF adds an independent one-stage free-LP-turbine/fan spool.'),
      rec('CHR-0663','1941','1943','year-range','1941–43','aviation','E6-M-JF;fan;diameter;rpm;power',215,'current','E6-M-JF fan hardware coordinate',src,'fan tip 0.50–0.55 m','Fan release band is ~0.50–0.55 m tip and 8.5–9.5 krpm; central ~0.52 m/~9,000 rpm with ~0.41 MW free-turbine extraction.'),
      rec('CHR-0664','1941','1943','year-range','1941–43','aviation','E6-M-JF;mass;nacelle;installation',215,'current','E6-M-JF package mass and envelope',src,'E6-M-JF dry mass ~610–690 kg/engine','Aft module adds ~100–150 kg; E6-M-JF dry mass ~610–690 kg/engine central ~650 and nacelle max OD ~0.66–0.72 m.'),
      rec('CHR-0665','1938','1943','year-range','1938–43','audit','E6-M;jet;JF;supersession',215,'superseded','old E6-M jet/JF thrust anchors',src,'E6-M-J / E6-M-N-J = ~500 kgf','Old ~500 kgf J/N-J, 650–700 kgf JF and blanket +30–40% JF gain are superseded by v46.'),
      rec('CHR-0666','1940','1944','year-range','1940–44','audit','E6-M;jet;JF;aircraft;H-A',215,'conditional','E6-M J/JF aircraft H→A propagation',src,'Hekireki 11/21 speed','Hekireki 11/21 and other aircraft values based on old thrust anchors are A_old until intake/nacelle drag, mass/CG, fuel, altitude thrust and compressibility are recomputed.'),
      rec('CHR-0667','1941','1944','year-range','1941–44','audit','E6-M-JF;carrier;Sakufu;H-A',215,'conditional','E6-M-JF carrier aircraft H→A propagation',src,'Sakufu prototype / 11 / 21','Sakufu carrier takeoff/speed and other JF carrier performance remain conditional until the v46 engine geometry and thrust are propagated through deck and airframe H→A.'),
    ]
    rows.extend(adds)
    with NEW.open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=FIELDS,delimiter='\t',extrasaction='ignore');w.writeheader();w.writerows(rows)
    with (ROOT/'CANONICAL-CHRONOLOGY-V46R1.jsonl').open('w',encoding='utf-8') as f:
        for r in rows:f.write(json.dumps({k:r.get(k,'') for k in FIELDS},ensure_ascii=False,separators=(',',':'))+'\n')

    # schema
    from collections import Counter
    c=Counter(r['semantic_status'] for r in rows)
    schema=json.loads((ROOT/'CHRONOLOGY-SCHEMA-V45R1.json').read_text(encoding='utf-8'))
    schema.update(release='v46r1',semantic_worldline='v46',
        source_scope='v45r1 carried forward plus v46 E6-M pure-jet/aft-fan installed-thrust and hardware closure. Aircraft H->A remains gated.',
        build_counts={'records':len(rows),'carried_from_v45r1':657,'added_v46r1':10,
                      'current_records':c['current'],'conditional_records':c['conditional'],'superseded_records':c['superseded'],'scope_records':c['scope'],'mixed_records':c['mixed']},
        query_rule='Default retrieval filters current/scope. v46 supersedes E6-M jet ~500kgf and JF 650–700kgf placeholders: use ~850 non-Ni J, ~900 Ni J, and ~950–1,000 JF with separate free-LP-turbine/fan spool. Aircraft performance derived from old thrust is conditional until H->A.')
    (ROOT/'CHRONOLOGY-SCHEMA-V46R1.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

    # main index, preserving old pre-machine ref counts when possible, recomputing current basename references.
    oldidx={}
    with (ROOT/'CANONICAL-MAIN-INDEX-V45R1.tsv').open(encoding='utf-8',newline='') as f:
        for r in csv.DictReader(f,delimiter='\t'):oldidx[r['path']]=r
    textfiles=[p for p in ROOT.rglob('*') if p.is_file() and p.suffix.lower() in {'.md','.tsv','.json','.jsonl','.py'} and '__pycache__' not in p.parts]
    idx=[]
    for p in sorted(MAIN.iterdir()):
        if not p.is_file():continue
        rel=str(p.relative_to(ROOT)); base=p.name
        count=0
        for q in textfiles:
            if q==p:continue
            try:t=q.read_text(encoding='utf-8',errors='ignore')
            except:continue
            count += t.count(base)
        idx.append({'path':rel,'size_bytes':str(p.stat().st_size),'sha256':sha(p),'first_heading':heading(p),
                    'incoming_text_refs_pre_machine_index':oldidx.get(rel,{}).get('incoming_text_refs_pre_machine_index','0'),
                    'incoming_text_refs_current':str(count)})
    with (ROOT/'CANONICAL-MAIN-INDEX-V46R1.tsv').open('w',encoding='utf-8',newline='') as f:
        fn=['path','size_bytes','sha256','first_heading','incoming_text_refs_pre_machine_index','incoming_text_refs_current']
        w=csv.DictWriter(f,fieldnames=fn,delimiter='\t');w.writeheader();w.writerows(idx)

    # triggers: update live machine pointers and add v46 dedicated row.
    with (ROOT/'CAPABILITY-TRIGGER-MATRIX-V45R1.tsv').open(encoding='utf-8',newline='') as f:tr=list(csv.DictReader(f,delimiter='\t'))
    for r in tr:
        r['canonical_sources']=r['canonical_sources'].replace('CANONICAL-CHRONOLOGY-V45R1.tsv','CANONICAL-CHRONOLOGY-V46R1.tsv').replace('CHRONOLOGY-SCHEMA-V45R1.json','CHRONOLOGY-SCHEMA-V46R1.json')
    tr.append({'capability_id':'GT-E6-JF','family':'E6-M installed jet / aft-fan','trigger_terms_or_context':'E6-M-J; E6-M-N-J; E6-M-JF; aft fan; rear fan; free turbine; 850 kgf; 900 kgf; 1000 kgf; 1,000 kgf; BPR; FPR; fan diameter; jet TSFC','canonical_sources':'main/asai-works-e6-m-jf-installed-thrust-rebaseline-1938-43.md;computation-2026-08-22/E6-M-J-JF-INSTALLED-THRUST-V46.tsv;computation-2026-08-22/E6-M-JF-FAN-SIZE-V46.tsv;main/asai-works-e5-e6-compressor-operability-rebaseline-1934-41.md','mandatory_question':'Use v46 engine-side authority: J non-Ni ~850kgf, Ni ~900kgf, JF ~950–1,000kgf at BPR~1/FPR~1.30 with separate free-LP-turbine/fan spool. Is this an engine claim or downstream aircraft H→A? Do not revive 500/650–700kgf or auto-scale aircraft speed.'})
    with (ROOT/'CAPABILITY-TRIGGER-MATRIX-V46R1.tsv').open('w',encoding='utf-8',newline='') as f:
        fn=['capability_id','family','trigger_terms_or_context','canonical_sources','mandatory_question'];w=csv.DictWriter(f,fieldnames=fn,delimiter='\t');w.writeheader();w.writerows(tr)

if __name__=='__main__':main()
