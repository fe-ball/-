# Marine implementation working state — OPEN unless stated otherwise

## 1. Navy as main actor

Keep the organizational framing:

- Navy defines ship requirement, hull, shafting safety, acceptance, trials and tactics.
- Asai supplies turbine cores/products, controls, fuel/combustion knowledge, instrumentation and calculation support.
- Naval arsenals/shipbuilders provide hull, large gearing, shafting, casings, heavy manufacture.
- Do not write the history as `Asai builds the Navy a boat`.

Natural institutional nodes used in discussion:

- 艦政本部第五部: machinery
- 艦政本部第四部: hull/design
- 海軍軍需局第二課: fuel/lubricants
- 海軍技術研究所 / 造船研究部: tank/model work
- 横須賀海軍工廠造機部/造船部
- 広海軍工廠機関研究部: natural land-rig / reduction-gear site
- 海軍水雷学校: later tactics/training

Exact bureaucratic routing/date should be rechecked before narrative closure.

## 2. E4-era marine adoption logic

Do NOT use a single ladder `emergency generator -> auxiliary -> boost -> main engine`.

Once E4 is seen, multiple Navy branches can examine in parallel:

- base/fortification emergency generation
- shipboard emergency generation
- auxiliary/return propulsion
- boost/sprint propulsion
- pure GT main propulsion
- GT-electric
- recuperated continuous plant
- GT exhaust heat into steam systems

Asai had marine/turbocharger rotating-machinery experience from the 1920s, so Navy purchase of several engines for experiments is plausible.

## 3. Heat recovery / steam coupling

Initial proposal can arise very early:

- GT exhaust is hot and oxygen-rich;
- if back-pressure is controlled, exhaust heat can warm feedwater / generate auxiliary steam / pre-warm the steam plant;
- supplementary firing is physically conceivable;
- damaged boiler path must be bypassable so a heat-recovery failure does not kill the GT.

For mixed GT/steam ships, recuperator versus steam-side heat recovery is a real design competition. The same high-grade exhaust heat cannot be fully used twice.

Large ships make exhaust boilers/heat recovery more attractive because they already carry steam auxiliaries and can amortize exchanger mass over long running periods.

## 4. Small craft state

Existing v27 authority explicitly says DESIGN & PROCUREMENT OPEN.

Old v27 candidate rows in the package include:

- 25–30t E5 test craft candidate: 2×1,300 hp GT + 350 hp diesel, 3 shafts, 43–44 kt central
- pure-GT 27t branch: 3×900 hp, 41–43 kt candidate
- 50t E6 large candidate: 2×2,300 hp GT + 600 hp diesel, 5,200 hp total, 43–45 kt, 4×45cm torpedo candidate

This conversation subsequently re-opened the **earlier E4/E5 test-craft history** and proposed a different research path. Therefore do not silently merge these rows into a single adopted chronology.

### Working E4/E5 research-craft concept discussed here

- ~28.5–29 m length
- ~4.6 m beam
- ~40 t light test, ~43–44 t standard, ~47–49 t full representative
- hull ~70% representative of a desired near-coastal attack craft
- weapons initially ballast/dummies
- design representation: 45cm torpedoes×2, crew ~10–12, 300–400 nmi mission, external-sea use, night attack
- three-shaft research layout favored for flexibility, but 2-vs-3 shaft model-basin comparison remains needed
- E4×3 ~2,040 hp -> ~29–30 kt conservative
- E4×4 ~2,720 hp -> ~32–33 kt conservative
- E5 standard×3 ~2,850 hp -> ~32.5–33.5 kt
- E5×4 ~3,800 hp -> ~35.5–36.5 kt standard; higher only light/good matching

This is a working research-platform history, NOT yet integrated into v27 canon.

## 5. Old-hull sea-trial candidate

`樅 / Momi` was discussed as a very attractive historical test-bed candidate because an old destroyer hull gives:

- real seawater/spray/pitch/roll/ship vibration;
- enough volume for changing large GTs;
- useful ~20–25 kt test envelope with large-A/B class machines;
- room for exhaust-boiler and auxiliary-system experiments.

**Status: OPEN.** Exact historical availability/dates must be re-verified before closure.

## 6. Land endurance facility

Strongly favored regardless of which hull is used:

- large-airflow intake
- salt-spray / contamination test
- water brake or generator load
- marine reduction gear / clutch rigs
- direct exhaust bypass
- experimental exhaust boiler / feedwater / steam system
- fuel-treatment experiments
- hundreds-to-thousands-hour endurance sequences

Practical logic: use endurance output as real naval-yard electric/steam supply rather than wasting all test energy.

This is a likely institutional program, but exact build date/facility naming remains OPEN.

## 7. Dedicated new-build propulsion test ship

Discussed concept:

- ~700–1,000 t
- 2 shafts
- deliberately large, replaceable machinery spaces
- interchangeable foundations / reduction gear inputs
- large intake/exhaust routes
- steam and electrical test capability
- little/no combat armament

Reason: by the time such a vessel is designed for E5 large-B, E6 甲/乙 may become available, so the platform should be technology-neutral.

**Status: OPEN.** User explicitly noted there is not yet a clean axis that makes a new-build test ship feel historically closed.

## 8. Generation churn as a feature, not a contradiction

Expected pattern:

- E5 large-A solves large axial compressor / marine power turbine / gear / salt / access problems.
- E5 large-B solves multi-thousand-horsepower continuous marine operation and heat recovery.
- E6 甲 arrives in roughly the same airflow/installation envelope but with materially better specific work and efficiency.
- E6 乙 makes destroyer-scale main-engine blocks plausible.
- E6 丙 is driven by ship unit-power targets (~12 khp), potentially making four-block ~50 khp arrangements possible.

Therefore E5 large engines may be highly successful **research generations** even if mass procurement is overtaken by E6.

