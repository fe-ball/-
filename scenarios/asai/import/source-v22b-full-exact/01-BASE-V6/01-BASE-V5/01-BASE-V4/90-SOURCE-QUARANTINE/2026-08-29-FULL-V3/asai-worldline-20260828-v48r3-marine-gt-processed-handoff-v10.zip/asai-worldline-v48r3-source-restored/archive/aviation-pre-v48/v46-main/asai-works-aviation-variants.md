# 航空・変種機の短データ集（軽め機＝ロスター行＋要点）

> **v46 engine authority / H→A fence.** E6-M-J is now ~850 kgf/engine non-Ni and ~900 kgf/engine Ni; E6-M-JF is ~950–1,000 kgf/engine (central ~984 at 835°C, BPR~1/FPR~1.30). Older 500 and 650–700 kgf engine values, and aircraft performance derived from them, are A_old/conditional until dedicated aircraft H→A. Authority: `asai-works-e6-m-jf-installed-thrust-rebaseline-1938-43.md`.

> **v40 E5 product-power hold.** E5 `約1,000馬力` はproduct design targetとして保持するが、旧 `126 kJ/kg×6 kg/s` はinstalled proofとしてsuperseded。current Ni@800 installed w≈104 kJ/kgで、1,000hp維持にはṁ≈7.25kg/s（audit約6.9–7.8）を要する。mass-flow/diameter/weight/gear再受領までは本稿の航空性能・採用判断を変更せず、1,000hpを確定物理入力として再利用しない。

ロスター（`asai-works-aviation-lineup.md`）の本命6機（個別ファイル）に対し、**派生・変種の軽め機**を短データでまとめる。各機は本命機または素体の派生で、エンジン機種（`turboprop-catalog`／`jet-catalog`）と同等品で測る。規則は `tensei-engineer-kufu-shu.md`、数値は【確認済み】【物理】【設定】。回転翼（カ号観測機・レ号系中型回転翼機）は専用資料（`rotorcraft`／`autogyro-ka-go`）にあるので §末で参照のみ。

---

## 1. 試製簡易局地戦闘機（単発廉価点防御）

- 分類：派生（霹靂一一型の単発廉価版）／エンジン：**E6-M-J ×1**（v46 engine-side約850 kgf、機体H→A待ち）。
- **A_old**：全備 約2,000〜2,300 kg・海面 約595 km/h・推力重量比 0.22〜0.25。旧500 kgf入力由来なのでcurrent性能には使わない。武装 20mm×2〜4。
- 同等品：He162型。**安く軽い数の点防御**——本命は双発の一一型、これは数で補う廉価案（`jet-interceptor` §4）。灯油で火災に強い（He162の難点を回避）。

## 2. Ki-40 初期型（単発・司令部偵察）

- 分類：置換（Ki-15の役）／エンジン：**E5-S-T ×1**（約1,000馬力）。
- 全備 約2,500〜2,800 kg・約490〜520 km/h（海面、Ki-15同等）・航続 Ki-15以上・無武装【設定】。
- 同等品：Ki-15（九七司偵）。**灯油で焚く滑らかな偵察の最初**（`turboprop-first`）。E-5世代の本命の最初。

## 3. 百式司令部偵察機（Ki-46系TP発展）（高速偵察）

- 分類：派生（**史実Ki-46百式司偵の双発本流を維持したTP発展**。Ki-40とは別系列）／エンジン：**2×E6-S-T**。
- 約540〜630 km/h（Ki-46級）・双発で射程と速度・灯油・高高度【設定】。制式名・Ki-46系列名は史実同様に維持する。
- 同等品：Ki-46。単発Ni型（`turboprop-ki40`）が高度・航続に振るのに対し、**双発は生の速度**に振る変種。

## 4. B7A 流星（艦上統合攻撃）

- 分類：**独立新設計**（愛知）。B6N天山の爆撃派生ではない。
- エンジン：**E6-M-T ×1候補**（約2,100shp級）。
- 第一shadow：全備5.6–6.0t、最高560–585km/h級、魚雷/800kg級爆弾、実用積載航続1,800–2,200km級。
- 役：B6Nの雷撃とD4Yの急降下爆撃を一機に統合。大型空母本命。

## 5. P1Y 銀河（双発・高速陸上攻撃）

- 分類：史実P1Yの要求へ復帰。設計=空技廠、量産=中島。
- エンジン：**E6-M-T ×2候補**。
- 乗員3名標準、通常戦闘重量10.8–11.8t、過荷重13t級、翼55–60m²。
- 最高530–555km/h級、通常爆装0.8–1.0t、魚雷1本。
- 通常実用航続2,600–3,300km級。軽装ferry/偵察は4,000km超候補。
- G4Mを1941から即時全置換する機体ではない。高速戦術攻撃・雷撃・中距離侵攻を順次吸収する。
- 旧12t・7名・内部3,840–4,780km級の通常中央、増槽6,000km級の記述はv26でsuperseded。

## 6. 5t級大型TP輸送機（大型輸送ワークホース）

- 分類：新規/置換（貧弱な輸送機群を置換）／エンジン：**E6-M-T〔減格〕**（約1,870馬力・数千時間級・非Ni）。
- 大型・長距離・大搭載・灯油【設定】。**燃料置換の本丸**——数が出て燃料を食う輸送をタービン化し、合計のガソリン置換が最大（`turboprop-uses` §4）。減格長寿命で量産・酷使に耐える。

## 7. 練習機（高等練習）

- 分類：派生（減格）／エンジン：**E5-S-T〔減格〕** または **E4-S-T**。
- 機数膨大ゆえ**ガソリン節約が大きく、同時に乗員をタービンに慣らす**【設定】。固有名は設定・未定。地味だが燃料戦略と人材育成に効く。

---

## 8. 回転翼（既存資料を参照）

- **カ号観測機**：オートジャイロ系列（観測＝ピストン量産型／艦上＝E4-S-Tタービン上位型・跳躍離陸）。詳細＝`asai-works-autogyro-ka-go.md`。
- **レ号系中型回転翼機**：1942+はv32再基底化。中央は約3.2t・15mローター・E6-S-S減格900/1,000shpのprototype/service-testから。4–5.5t/1,500shpは後続条件付き。詳細＝`asai-works-rotorcraft-1942-plus-rebaseline-1942-55.md`。

---

## 9. タグ・次

- 【確認済み】：同等品（He162・Ki-15・Ki-46・D3A/彗星・G4M）、灯油の火災抗堪。
- 【物理】：各エンジン機種の出力（カタログ）、推力重量比。
- 【設定】：固有名・各機の役割対応・性能の帯。詳細性能は需要が出たら本命同様に個別詰め。
- 次：全体年表へ（`asai-works-timeline-master.md`）。各機の登場時期は年表で因果に位置づける。

---

## 10. 索引

- 親：`asai-works-aviation-lineup.md`（ロスター）／`asai-works-turboprop-catalog.md`・`asai-works-jet-catalog.md`（エンジン機種）。
- 本命：`asai-works-turboprop-ki40.md`／`asai-works-turboprop-tenzan.md`／`asai-works-turboprop-shinzan-renzan.md`／`asai-works-fighter-ki64.md`／`asai-works-jet-interceptor*`／`asai-works-jet-hekireki-21.md`。
