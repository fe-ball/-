# Marine GT processed handoff V10 — start here

Status: technical continuation of V9 under the V8 evidence/history stop rules. Semantic authority remains v48; machine layer remains v48r3. No alternate-history test-platform selection is created here.

## Read order

1. `102-EVIDENCE-AND-HISTORY-CLASS-TAXONOMY-V8.tsv` and `104-HISTORY-PROMOTION-AND-STOP-RULES-V8.tsv` — history boundary.
2. `113-POWER-STATION-ACCOUNTING-CORRECTION-V9.tsv`, `114-LL20-R2-TECHNICAL-PACKAGE-V9.tsv`, `116-E6-M-MARINE-BOOST-ROLE-QUALIFICATION-V9.tsv` — current GT technical basis.
3. `124-E5-QUALIFICATION-CRAFT-TECHNICAL-DOSSIER-V10.tsv` and `125-E5-QUALIFICATION-CRAFT-DELETION-AND-CLOSURE-LEDGER-V10.tsv` — repaired E5 test-craft design basis without false displacement closure.
4. `126-TEST-PLATFORM-INFORMATION-COVERAGE-MATRIX-V10.tsv`, `127-TEST-PLATFORM-MARGINAL-VALUE-AND-ACTIVATION-GATES-V10.tsv`, `128-MARINE-EVIDENCE-PRIMARY-SECONDARY-METHOD-V10.tsv` — what shore rigs, qualification craft, old hull, dedicated lab ship and LL20 each prove.
5. `129-MARINE-GT-REWORK-QUEUE-V10.tsv` — next safe work.

## V10 key findings

- The E5 qualification-craft **technical dossier** can be closed to arrangement, explicit new-hardware mass band, longitudinal centroid, deletion/retention logic and test/load gates, but not to exact dry displacement, whole-craft LCG/KG or final scantlings without a First-Type weight/structure breakdown.
- Shore rigs and sea platforms are complementary. Controlled endurance/fault isolation belongs primarily ashore; real spray/motion and hull/prop interaction require sea evidence.
- The E5 qualification craft is uniquely valuable for high-speed small-craft prop/trim/ventilation and compact E5 integration, but it is not the sole marine-GT gate.
- Momi/another obsolete hull has strong marginal value for cheap real-sea machinery integration if a suitable hull is available, but its geometry does not prove a carrier or modern small craft.
- A dedicated 700–1,000 t lab ship is technically useful but becomes nonduplicative only when repeated large-module sea integration / module swaps / controlled trunks and assured sea time justify it. V10 defines that activation gate and does not select the ship.
- LL20 R2 remains the required scale-specific evidence source if the ~20.56 kg/s large core is pursued; no smaller platform can grant that hot-core evidence by analogy.

## Current stop line

No file in V10 states that the E5 craft was built, that Momi was used, that a dedicated laboratory ship was ordered, or that LL20 was authorized/fired. Those remain worldline decisions or scenarios.
