# 20 — 潜水艦水中系 P0 1938–43（v21）

- 初期巡潜甲/乙/丙の2,000hp/8kt級、鉛蓄電池chemistry、cell数はHを維持。浅井製高性能battery/motorを捏造しない。
- ただし旧「batteryはH据え置き」を撤回。日本電池/湯浅をメーカーHに、浅井C/M/Qでseparator、glass mat、槽/蓋、封止、衝撃支持、換気、raw-material/サイクル試験を改良する。
- 戦後米調査のH錨：microporous separatorなら450cycle期待、wood使用で通常250cycle級、hard-rubber jar/seal/ventilation/Qに弱点。世界線E-B1は350–450cycleを受領目標帯とし、全量450を保証しない。
- エポキシはcell内部の強酸浸漬材にせず、巻線/端子/外部seal/電池室局部防食へ。battery glass matは短繊維で、構造GFRPより早く使える。
- 1939–40から潜航を秒数一個でなくdepth/time・horizontal advance・pitch・overshoot・settlingの受領curveで管理。同一船体の世界線改善は10–20%帯、exact秒は史実公試値不足のため未固定。
- own-ship noiseは旧「日本海軍はほぼ重視しなかった」を撤回。USNTMJ S-43を独立史実錨に置き、E-10の史実1940注意→1942本格研究を時期錨として1–2年前倒し。1941新造艇からnoise-vs-rpm map、quiet/avoid rpm、selected resilient mounting、shaft/prop balanceを標準化。現代anechoic tile等は無し。
- 主電動機は出力加算せず、湿塩/温度/整流/絶縁/衝撃を含む実用rating mapを作る。
- 「公称諸元・内部subsystem・設計自由度・任務/戦術・艦隊/program」の5軸差分帳簿を潜水艦総括の必須形式に追加。
- 次P0は1941–44次世代潜水艦要求の再生成。水上23.5kt維持 vs 20–22kt級＋水中側再投資を同一Iで比較する。

正本：`main/asai-works-submarine-underwater-1938-43.md`
