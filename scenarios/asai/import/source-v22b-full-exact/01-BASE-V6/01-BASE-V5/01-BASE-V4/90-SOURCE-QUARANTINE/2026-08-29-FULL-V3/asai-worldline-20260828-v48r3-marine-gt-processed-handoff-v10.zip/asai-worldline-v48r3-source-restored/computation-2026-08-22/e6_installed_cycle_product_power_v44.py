#!/usr/bin/env python3
"""v44 E6 installed-cycle and shaft-product power rebaseline.

The E6 generation table remains a *gross Brayton comparison* at PR=7 and
component-efficiency coordinate ~0.84. Product shaft power then pays:
  1) staged cooling/seal bleed,
  2) combustor total-pressure loss,
  3) finite exhaust/diffuser pressure margin,
  4) turbine/mechanical + accessory debit,
  5) combustion inefficiency for fuel-based efficiency,
  6) turboprop/free-power output gearing when reporting propeller-shaft power.

Flows are the v43 compressor identities. No jet thrust is derived here.
"""
from __future__ import annotations
import csv, math
from pathlib import Path

CP = 1.005
GAMMA = 1.4
T1 = 288.0
A = (GAMMA - 1.0) / GAMMA
HP_KW = 0.745699872
LHV_MJ_KG = 43.0


def t_comp(pr: float, eta: float) -> float:
    return T1 * (1.0 + (pr**A - 1.0) / eta)


def comp_work(pr: float, eta: float) -> float:
    return CP * (t_comp(pr, eta) - T1)


def gross(pr: float, tit_c: float, eta: float):
    t3 = tit_c + 273.15
    t2 = t_comp(pr, eta)
    tau = pr**A
    t4 = t3 * (1.0 - eta * (1.0 - 1.0 / tau))
    wc = CP * (t2 - T1)
    wt = CP * (t3 - t4)
    w = wt - wc
    q = CP * (t3 - t2)
    return w, w / q


def bleed_pattern(total: float):
    # E6: process maturity improves distribution relative to E5, but 870/920 C
    # still requires meaningful vane/rotor/root/seal flow. Fractions are an audit
    # surrogate and are swept in BANDS below.
    base = [
        ('vane',  .012, 1.00, .85),
        ('rotor', .022, 1.00, .55),
        ('root',  .012, .75, .15),
        ('seal',  .009, .55, .00),
    ]
    scale = total / sum(x[1] for x in base)
    return [{'name':n, 'b':b*scale, 'tap_frac':tap, 'recovery':r}
            for n,b,tap,r in base]


def installed(case):
    pr, tit_c, eta = case['pr'], case['tit_c'], case['eta']
    t3 = tit_c + 273.15
    bleeds = bleed_pattern(case['bleed_total'])
    btot = sum(x['b'] for x in bleeds)

    wc = (1.0 - btot) * comp_work(pr, eta)
    for x in bleeds:
        wc += x['b'] * comp_work(pr ** x['tap_frac'], eta)

    rt = pr * (1.0 - case['dp_comb']) / case['exhaust_ratio']
    expansion = CP * eta * (1.0 - rt ** (-A))
    h_weight = (1.0 - btot) * t3
    for x in bleeds:
        h_weight += x['b'] * x['recovery'] * t_comp(pr ** x['tap_frac'], eta)
    wt = expansion * h_weight

    w_shaft = case['eta_mech'] * wt - wc - case['accessory_kjkg']
    q_fuel = ((1.0 - btot) * CP * (t3 - t_comp(pr, eta))) / case['eta_comb']
    eta_shaft = w_shaft / q_fuel
    bsfc = 3.6 / (LHV_MJ_KG * eta_shaft)
    return dict(w_shaft=w_shaft, eta_shaft=eta_shaft, bsfc=bsfc,
                wc=wc, wt=wt, rt=rt, bleed_total=btot)


CASES = [
    dict(name='E6-nonNi-870-central', pr=7.0, tit_c=870, eta=.84,
         bleed_total=.050, dp_comb=.030, exhaust_ratio=1.012,
         eta_mech=.993, accessory_kjkg=1.2, eta_comb=.987),
    dict(name='E6-Ni-920-central', pr=7.0, tit_c=920, eta=.84,
         bleed_total=.045, dp_comb=.030, exhaust_ratio=1.012,
         eta_mech=.993, accessory_kjkg=1.2, eta_comb=.987),
    dict(name='E6-nonNi-820-derate', pr=7.0, tit_c=820, eta=.84,
         bleed_total=.041, dp_comb=.030, exhaust_ratio=1.012,
         eta_mech=.993, accessory_kjkg=1.2, eta_comb=.987),
]

BANDS = {
 'E6-nonNi-870-central': dict(B=(.042,.060), dp=(.025,.040), ex=(1.008,1.018), mech=(.990,.995), acc=(.8,1.8), comb=(.982,.992)),
 'E6-Ni-920-central':    dict(B=(.038,.055), dp=(.025,.040), ex=(1.008,1.018), mech=(.990,.995), acc=(.8,1.8), comb=(.982,.992)),
 'E6-nonNi-820-derate':  dict(B=(.034,.050), dp=(.025,.040), ex=(1.008,1.018), mech=(.990,.995), acc=(.8,1.8), comb=(.982,.992)),
}


def corners(base):
    b = BANDS[base['name']]
    vals=[]
    for B in b['B']:
      for dp in b['dp']:
       for ex in b['ex']:
        for mech in b['mech']:
         for acc in b['acc']:
          for ce in b['comb']:
           c=dict(base); c.update(bleed_total=B,dp_comb=dp,exhaust_ratio=ex,eta_mech=mech,accessory_kjkg=acc,eta_comb=ce)
           vals.append(installed(c))
    return dict(w_min=min(v['w_shaft'] for v in vals),w_max=max(v['w_shaft'] for v in vals),
                eta_min=min(v['eta_shaft'] for v in vals),eta_max=max(v['eta_shaft'] for v in vals))


def product_rows(results):
    # 97.5% is gearbox/free-power output transmission efficiency for T products.
    gear=.975
    rows=[]
    by={x['case']:x for x in results}
    def add(name,case,flow,role,headline=None,gear_eff=gear):
        r=by[case]
        kw=r['w_installed_shaft_central_kJkg']*flow*gear_eff
        hp=kw/HP_KW
        rows.append(dict(product=name,case=case,flow_kg_s=flow,output_gear_eff=gear_eff,
                         central_flange_kW=kw,central_flange_hp=hp,
                         proposed_headline_hp=headline or '',role=role))
    add('E6-S-T standard','E6-nonNi-870-central',7.8,'standard non-Ni aircraft turboprop',1300)
    add('E6-S-T high-flow trim','E6-nonNi-870-central',8.2,'short/high-flow S trim; not common rating',1400)
    add('E6-S-N-T standard','E6-Ni-920-central',7.8,'Ni high-altitude aircraft turboprop',1500)
    add('E6-S-N-T high-flow trim','E6-Ni-920-central',8.2,'conditional short/high-flow Ni trim',1600)
    add('E6-M-T standard','E6-nonNi-870-central',13.2,'M-family aircraft turboprop; flat-rate for life/gear',2100)
    add('E6-M-T marine short trim','E6-nonNi-870-central',13.5,'marine short/sprint validation point',2300)
    add('E6-M-T long-life','E6-nonNi-820-derate',13.2,'~50 C thermal derate; further flat-rated for life',1870)
    # Turboshaft core ability: no prop reduction; retain a small free-turbine coupling debit only.
    add('E6-S-S shaft derivative','E6-nonNi-870-central',7.8,'engine output shaft before aircraft main gearbox',1350,gear_eff=.990)
    return rows


def main():
    rows=[]
    for c in CASES:
        wg,eg=gross(c['pr'],c['tit_c'],c['eta'])
        r=installed(c); bd=corners(c)
        rows.append(dict(
            case=c['name'],PR=c['pr'],TIT_C=c['tit_c'],eta_component=c['eta'],
            cooling_bleed_central_pct=100*r['bleed_total'],combustor_dp_central_pct=100*c['dp_comb'],
            w_gross_kJkg=wg,eta_gross_pct=100*eg,
            w_installed_shaft_central_kJkg=r['w_shaft'],
            w_installed_shaft_band_low_kJkg=bd['w_min'],w_installed_shaft_band_high_kJkg=bd['w_max'],
            eta_installed_fuel_central_pct=100*r['eta_shaft'],
            eta_installed_fuel_band_low_pct=100*bd['eta_min'],eta_installed_fuel_band_high_pct=100*bd['eta_max'],
            bsfc_central_kg_kWh=r['bsfc'],gross_to_installed_loss_pct=100*(1-r['w_shaft']/wg)
        ))
    out=Path(__file__).with_name('E6-INSTALLED-CYCLE-PRODUCT-POWER-V44.tsv')
    with out.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys(),delimiter='\t'); w.writeheader(); w.writerows(rows)
    prod=product_rows(rows)
    pout=Path(__file__).with_name('E6-PRODUCT-POWER-V44.tsv')
    with pout.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=prod[0].keys(),delimiter='\t'); w.writeheader(); w.writerows(prod)
    for r in rows: print(r)
    for r in prod: print(r)

if __name__=='__main__': main()
