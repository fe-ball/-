# Semantic recall / cross-domain trigger audit — v22r2 (2026-08-23)

Scope: data-operation only. Worldline semantic state remains v22.

## Finding

v22r1 solved file reachability and reference integrity, but it did not guarantee **concept recall during a new analysis**. The main risk is not a missing file; it is a known cross-cutting capability failing to enter the candidate set when the conversation does not explicitly name it.

Two representative cases:

- **Turbo/boost** was especially omission-prone because one colloquial label spans distinct branches: aircraft piston exhaust supercharging, commercial/vehicle diesel turbocharging, submarine 2-stroke compound scavenging, independent GT, turboprop/turboshaft, and turbojet. These branches have different chronology and transfer rules.
- **FRP** already had a strong materials master index, but a thematic index still requires the analyst to remember to consult materials. FRP also spans epoxy/process capability, plant-fiber FRP, GFRP, CFRP and the CFRP-propeller branch, with different maturity gates.

## Repair

Added:

- `CROSS-DOMAIN-PREFLIGHT-V22R2.md` — mandatory human-readable recall gate.
- `CAPABILITY-TRIGGER-MATRIX-V22R2.tsv` — machine-readable list of 21 cross-domain capability families, trigger contexts, canonical sources, and mandatory questions.
- `CANONICAL-MAIN-INDEX-V22R2.tsv` — regenerated after the v22r2 rule pointers changed two `main/` files.

Patched:

- `00-START-HERE-2026-08-22.md`
- `CURRENT-CANONICAL-STATE.md`
- `main/tensei-engineer-kufu-shu.md`
- `main/asai-works-handoff.md`

The rule is now: before a substantive design, retrofit, production, or historical-impact analysis, cross-domain families are explicitly marked `CHECKED`, `GATED-OUT`, or `N/A`. “Not remembered” is no longer equivalent to “not applicable”.

## Validation

- Trigger matrix rows: 21.
- Every canonical-source path named by the trigger matrix exists in the package.
- `main/` inventory rows: 163/163.
- Current manifest is regenerated after all changes and verifies every file except the manifest itself.
- Historical `CANONICAL-MAIN-INDEX-V22R1.tsv` is retained as the v22r1 snapshot; current state points to V22R2.
