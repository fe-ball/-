# MACHINE LAYER REFRESH — v25r1 / 2026-08-24

## Purpose

Semantic v25 changes the tank-history boundary without advancing war history. The machine layer is refreshed so hypothetical next-generation tank branches cannot leak into ordinary current-state retrieval.

## Inputs

- semantic parent: `37-TANK-CONDITIONAL-TECHNICAL-CLOSURE-V25-2026-08-24.md`
- canonical conditional tank parent: `main/asai-works-tank-next-generation-conditional-1939-45.md`
- prior machine base: v24r2 chronology/index/trigger layer

## Machine changes

1. `CANONICAL-CHRONOLOGY-V25R1.tsv` / `.jsonl`
   - 373 records total.
   - 366 records carried from v24r2, with changed tank-source hashes/rows refreshed.
   - 7 v25 conditional tank records present.
   - status counts: current 343 / scope 7 / mixed 8 / superseded 8 / conditional 7.
2. `CHRONOLOGY-SCHEMA-V25R1.json`
   - adds `conditional` to `semantic_status`.
   - ordinary retrieval explicitly filters to `current` + `scope`; conditional rows require an explicit counterfactual/development-branch query.
3. `CANONICAL-MAIN-INDEX-V25R1.tsv`
   - 172 canonical files under `main/`, including the new conditional tank parent.
4. `CAPABILITY-TRIGGER-MATRIX-V25R1.tsv`
   - adds `TANK-NEXT`.
   - mandatory question: current worldline event or conditional shadow, and which threat/intelligence/policy gate is open?
5. `CROSS-DOMAIN-PREFLIGHT-V25R1.md`
   - adds the same status gate before using later-tank chronology hits.

## Regression gates

- `conditional` tank rows must not be accepted by ordinary current retrieval.
- `main/asai-works-tank-next-generation-conditional-1939-45.md` must have conditional chronology coverage.
- no conditional record may be silently promoted to `current` or `scope`.
- current v24 technical parents remain temporally discoverable.
- source hashes, JSONL parity, main-index coverage, trigger sources and manifest hashes remain validator-enforced.

## Result

Machine semantics now preserve three distinct statements:

- **current**: worldline facts usable in ordinary analysis;
- **conditional**: technically examined development shadows whose event/adoption/production/OOB status is unfixed;
- **superseded/mixed**: provenance requiring exclusion or source inspection.

This is a data-layer change, not a declaration that the 1940 research vehicle or 1942+ 75mm tank actually exists.
