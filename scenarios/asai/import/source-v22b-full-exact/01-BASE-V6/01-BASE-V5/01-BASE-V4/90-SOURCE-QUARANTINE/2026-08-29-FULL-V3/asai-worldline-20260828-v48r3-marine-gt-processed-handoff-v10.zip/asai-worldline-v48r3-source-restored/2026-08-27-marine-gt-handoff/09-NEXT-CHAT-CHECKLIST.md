# Next-chat checklist

1. Read `00-NEXT-CHAT-START-HERE.md` first.
2. Treat the original v48r3 files as semantic authority unless this handoff explicitly marks a later accepted number.
3. Build a verified 1931–1941 historical ship/refit timeline from web sources.
4. Build a separate engine/rig/product timeline from package authorities.
5. Only then intersect them.
6. Resolve E6 torpedo-boat branch before propagating to a general `GT fleet` history.
7. Decide whether old-hull trials, dedicated propulsion test ship, both, or neither actually happen.
8. Re-evaluate carrier conversions one hull/refit window at a time.
9. Leave 雲龍系 until the new-build carrier logic is derived from the verified technology calendar.
10. Keep fuel policy as a parallel capacity constraint, not as a retroactive excuse for an already-selected fleet.

## Key warning

Do not convert the analysis labels `E5 large-A/B` and `E6 甲/乙/丙` into canonical in-world model names just because the calculations are convenient. They are cross-generation design-space bins.

