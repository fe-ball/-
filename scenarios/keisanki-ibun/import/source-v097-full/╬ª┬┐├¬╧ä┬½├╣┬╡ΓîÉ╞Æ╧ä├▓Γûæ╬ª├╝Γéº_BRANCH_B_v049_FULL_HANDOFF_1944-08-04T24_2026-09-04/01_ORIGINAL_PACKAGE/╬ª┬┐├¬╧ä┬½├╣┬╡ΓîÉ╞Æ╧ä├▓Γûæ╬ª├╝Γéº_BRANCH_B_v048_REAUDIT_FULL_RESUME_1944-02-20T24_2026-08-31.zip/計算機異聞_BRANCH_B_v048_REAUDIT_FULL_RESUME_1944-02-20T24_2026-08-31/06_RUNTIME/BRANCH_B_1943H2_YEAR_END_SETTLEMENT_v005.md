# Branch B 1943H2 year-end settlement v005

status: AUTHORITATIVE_CURRENT_BRANCH_SETTLEMENT_BENGAL_LAND_VEHICLE_PROPAGATED
period: 1943-08-01T00:00:00 -- 1943-12-31T24:00:00
frontier_after_closeout: 1944-01-01T00:00:00
branch: BRANCH_B_1943SUMMER_EXPLORATION

## 0. Precedence

This file closes the Branch-B 1943H2 exploration that v026 had reopened at 1943-08-01. It supersedes v026's forecast-only treatment for the specific realized outcomes listed below. It does **not** authorize automatic inheritance of retained 1944 descendants in the archive. The 1944 world remains unopened beyond planning/reconnaissance/force-movement facts explicitly dated on or before 1943-12-31.

Mandatory companion files:
- `BENGAL_ARAKAN_CHITTAGONG_1943-10_12_SETTLEMENT_v002.md`
- `BENGAL_ARAKAN_LAND_VEHICLE_EVENT_LEDGER_1943-10_12_v001.json`
- `GALVANIC_BRANCH_B_1943-11_SETTLEMENT_v004.md`
- `DODECANESE_WITHDRAWAL_BRANCH_B_1943-11_SETTLEMENT_v001.md`
- `ROYAL_NAVY_DIVERGENCE_AUDIT_1942-1943_v001.md`
- `EASTERN_FLEET_1944Q1_POTENTIAL_GATE_v001.md` (planning/gate, not realized 1944 combat)

## 1. Central Pacific / GALVANIC — final re-audit

The detailed GALVANIC dependency reopened by v028 and the v047 ground-vehicle rollback remain closed under `GALVANIC_BRANCH_B_1943-11_SETTLEMENT_v004.md`. The v048 Bengal land/vehicle rollback is independently closed under `BENGAL_ARAKAN_CHITTAGONG_1943-10_12_SETTLEMENT_v002.md`; no GALVANIC numeric delta is copied into Bengal.

US GALVANIC-equivalent D-Day is 1943-11-24. Makin organized resistance ends on 11/27; Tarawa coherent resistance persists through 11/28 evening and the secure declaration is centered on 11/29 morning. The United States wins the Gilberts but pays a materially higher fast-carrier price than historical while failing to destroy the surviving Japanese fleet-carrier core.

Settled Japanese facts:
- Shokaku, Zuikaku and Hiryu are operational after the 11/26 carrier battle and withdraw.
- Soryu survives but is mission-killed by two bomb hits and is in Truk/home-yard repair at year-end; not operational on 1944-01-01.
- Junyo/Hiyo/Ryujo/Zuiho are not consumed by Bengal on the centered line and remain an explicit secondary-carrier/rear-deck regeneration pool.
- Event-local Kinsei Zero use on 11/26 is 18-22, center 20; it is a small but material component, not an all-Kinsei force.
- Hatsuzuki/Suzutsuki/Hamakaze/Fujinami conduct one stand-off Makin night torpedo raid 11/26-27; Fujinami is lightly/moderately damaged and returns after repair.
- I-175 torpedoes USS Pierce on 11/27, is depth-charge damaged and withdraws.

Settled Allied facts:
- USS Independence is torpedoed D-1 (11/23) and is a long-term repair casualty.
- USS Lexington is hit by torpedo + bombs on 11/26 and is a major repair casualty into 1944.
- USS Yorktown is temporarily damaged but returns to near-normal deck operations within days.
- USS Cowpens remains operational; the old campaign-out result is superseded.
- USS Liscome Bay survives; the old sinking result is superseded.
- USS Franks is sunk by Type 93 during the 11/26-27 night stand-off raid.
- USS Pierce is torpedoed on 11/27, survives, and enters repair.

Tarawa final US casualty working band is about **2,150-2,550 total** (KIA/MIA 620-770; WIA 1,530-1,780) after the v047 land-vehicle/hardware rollback. The working-center delta against v003 is about +250 total casualties. The old 4,500-4,700 Japanese 'combat' count remains superseded: first-line combat is about 2,600-2,900, with another 700-1,000 limited armed-support personnel and the remainder construction/air-ground/labor/support.

The corrected vehicle state uses 14 physical Type 95-class tanks, 6-9 contact-capable after suppression, 4-5 in the first-night counterattack and 2-4 later short-hop mobile firepoints. It does not create additional tanks or improve armor/gun energy. US M4A2 availability is still materially better than historical Tarawa because the Branch 24-November tide/lane plan lands 8-11 tanks and keeps 6-8 operational for the first night.

The historical mass 1943-12-04 Kwajalein/Roi carrier raid is **not** current realized history. Immediate aftermath centers on a smaller outer-Marshalls raid/reconnaissance under a large US cover reserve, while Japan disperses air units and keeps the surviving three first-line carriers as a fleet-in-being.

Repair/regeneration authority: `GALVANIC_DAMAGE_REPAIR_REGEN_LEDGER_1943-11_1944Q1_v002.json`.
Aircraft lessons authority: `GALVANIC_AIRCRAFT_AFTER_ACTION_LESSONS_1943-12_v002.md`.

## 2. Bengal / Arakan — v048 land/vehicle rollback propagated

The Japanese operation begins 1943-10-28 as an overland northward Arakan advance supported by sea logistics, short coastal transplants and rotating old-battleship bombardment. It is not a one-shot Chittagong amphibious landing. v048 reopened the campaign to the pre-Naf-crossing node because the old settlement had no physical vehicle OOB, serviceability, damage-class or repair/reappearance ledger.

Major settled milestones:
- Teknaf captured late 11/04..11/05.
- Ukhia captured 11/13..14.
- Cox's Bazar captured late 11/20..11/21; Gate B GREEN.
- Dohazari captured early 12/05 after British planned withdrawal and a short coastal insertion.
- Chittagong captured late 12/14..early 12/15, centered late 12/14; Gate C GREEN.

The British field army is **not** annihilated. 5th and 26th Indian Divisions withdraw north; 7th Indian Division escapes east/northeast with about 7,700-9,100 personnel but more stragglers and heavy equipment lost than v001. 81st West African Division main body is not retroactively trapped in the Kaladan and remains a relatively fresh Feni/Comilla/Hill Tracts reserve.

Japanese 55th Division ends the campaign exhausted. Relative to the old settlement it retains about 300-600 more effective personnel and 20-45 more dispatchable vehicles because repairable transport/prime-mover/engineer-plant faults are no longer misclassified as permanent loss. 54th Division advance/rear/logistics elements increasingly relieve security functions but the full division is not conjured into early-November combat.

The authoritative event result is `BENGAL_ARAKAN_LAND_VEHICLE_EVENT_LEDGER_1943-10_12_v001.json`. No independent Japanese tank regiment is present. Physical motor/prime-mover/engineer-plant OOB is 430-560, start-serviceable/crewed/fueled 355-465. Old vehicle working loss 80-150 is replaced by 55-95 permanent writeoffs plus 45-80 temporary mission-kills, of which 25-50 return inside 24-72 hours.

Campaign casualty bands are now Japan 5,300-7,600 total centered about 6,300, and British/Commonwealth 7,700-11,100 centered about 9,300. The exchange shifts toward Japan without importing Tarawa's ratio; prepared fire, communications, engineering and vehicle recovery apply only at traced phases.

## 3. Bengal naval method

Fuso/Yamashiro and Ise/Hyuga remain conventional battleships in this Branch and are used as rotating heavy shore-artillery/convoy-cover groups. First-line carriers and Kongo-class fast battleships remain Pacific assets.

Royal Navy interference in Nov-Dec 1943 is interpreted as **existing Eastern Fleet forces plus locally retasked and limited late-arriving reinforcements from a Royal Navy still recovering from 1942-43 carrier losses**. It does not imply a full fleet battle or an ahistorical instant European reinforcement.

Effects are principally submarine, mine, reconnaissance, night-light-force and convoy friction. These effects are already absorbed into the Bengal working loss/tempo bands; do not spawn additional major British units retroactively without a dated movement chain.

## 4. Chittagong condition at year-end

British demolition is substantial:
- Kalurghat bridge central spans down; repair is weeks, not days.
- Patenga and Double Moorings damaged.
- fuel/rail/warehouses/cranes/wrecks/mines impose major denial.
- northern rail damaged.

Japanese recovery ladder remains conditional on repair and air defense. By year-end Patenga can support a regular 15-25 fighter/recon presence, with short surges above that possible. Port throughput grows from roughly 100-200 t/day small-craft scale in the first week toward roughly 320-520 t/day late December if repair/air conditions cooperate.

Main Japanese priority after 12/15 is consolidation, minesweeping, wreck clearance, Patenga repair, Cox-Chittagong sea LOC, AA/CAP and 55th Division reconstitution. There is no realized immediate Feni charge before the year-end frontier.

## 5. Burma / Chindwin

15th Army remains intact and studies/pressures the Chindwin-Imphal axis, thereby pinning British IV Corps. No U-Go GO has been issued. Division-scale deep attack toward Imphal remains logistically AMBER/RED; a three-division Kohima/Dimapur offensive is RED.

British IV Corps (17th/20th/23rd Indian Divisions plus 254 Tank Brigade/support) remains a healthy force because the historical Imphal catastrophe has not yet occurred. Japan likewise avoids the historical self-destruction. This is a future 1944 two-sided constraint, not a free Japanese bonus.

## 6. Royal Navy / Mediterranean correction

The Royal Navy divergence audit is now retroactively integrated:
- Operation C: Indomitable and Formidable sunk 1942-04-05; Warspite damaged survives. Hermes, Vampire, Hollyhock, Athelstane and British Sergeant survive because the 4/09 raid is absent.
- Ironclad still succeeds with Illustrious + Hermes direct support; no additional capital loss.
- Pedestal remains GO; Illustrious replaces Indomitable and is heavily damaged but survives. Eagle historical loss remains.
- TORCH remains GO; Victorious is the sole fast fleet-cover carrier and survives.
- Victorious US loan is delayed until Illustrious is back to limited readiness.
- Sicily 1943 uses Illustrious as the single principal fleet carrier in a more conservative posture; no Branch-specific carrier loss.
- Salerno succeeds; Warspite's historical guided-bomb damage remains.
- After Kos falls, the Dodecanese position is reassessed; planned withdrawal from Leros/Samos begins early Nov rather than accepting the full historical late-November disaster.

## 7. Dodecanese Branch outcome

The British do not instantly abandon Leros on 10/04. They pay the historical early/mid-October damage first. Around 11/01..03, the combination of lost fighter-base geometry, declining operational value, accumulated naval losses and general Royal Navy reserve weakness pushes London toward planned evacuation.

Working realized center:
- Leros British strength at evacuation start roughly 3,000-3,300 rather than the later historical ~4,000 because 10/31-11/07 reinforcement flow is mostly cancelled.
- roughly 2,700-3,000 British personnel are evacuated; British death/missing/capture total roughly 200-350.
- roughly 3,200-3,800 Italian troops are organized out from Leros, with additional later small-craft escape; roughly 1,800-2,500 remain/captured center.
- Samos British/Greek combat elements evacuate substantially intact.
- 6-10 small craft lost, several more heavily damaged; no new destroyer loss is forced in the centered evacuation adjudication.
- the historical later damage to Rockwood and sinking of Dulverton in the Leros endgame are avoided as **those events**; the hulls are not thereby guaranteed future survival.
- German ground/landing forces avoid most of the historical Leros battle casualties and occupy the islands earlier; this is a German retained-force benefit, not automatically a mobile reserve.

## 8. Royal Navy year-end resource meaning

The Royal Navy is not best described as numerically collapsed. It is better described as having **less reserve elasticity**:
- permanent loss of two modern fleet carriers;
- Illustrious modernization debt after emergency repair;
- Victorious deployment/refit clock displaced;
- additional Indian Ocean escort/ASW burden;
- extra repair/maintenance debt from higher operating tempo;
- some historical small-ship losses avoided (Hermes group, later Dodecanese events), partially offsetting raw hull-count damage.

Working estimate at 1943-11/12: destroyer/escort total hull count can be near historical or slightly better, yet freely assignable escort reserve is roughly 2-4 hulls worse than history after theater commitment and maintenance debt. Treat this as an analytic band, not a named-ship inventory until exact OOB is rebuilt.

## 9. 1944 boundary

No 1944 combat is realized here. Settled on/before 1943-12-31 is the **British decision/movement potential** to reinforce Eastern Fleet once the Mediterranean/Italian fleet problem has largely closed. A historical-scale eastbound group (Queen Elizabeth, Valiant, Renown, Illustrious, Unicorn) is a plausible Branch baseline; movement beginning at the very end of December is accepted as the working departure state, but January arrival/contact/operations remain to be simulated.

Japan is expected to recognize that the old-battleship freedom window is closing and can likely detect the eastward movement before arrival through Axis reporting, traffic/port observations and later Indian Ocean reconnaissance. This is a planning/intelligence fact, not yet a 1944 battle result.

## 10. Next mandatory gate

Before any 1944 Eastern Fleet/Japanese fleet action, rebuild Japan's **actual movable** naval wallet as of 1944-01-01:
- fleet destroyers: total, ready, mandatory Pacific commitments, Indian Ocean transferable band;
- submarines: conventional ocean boats, high-speed-submerged six-boat core, patrol-day commitments, Indian Ocean transferable band;
- heavy/light cruisers: actual readiness and whether low-speed British battleship arrival justifies westward reinforcement;
- old battleships: Fuso/Yamashiro/Ise/Hyuga rotation and safe withdrawal/forward-basing options;
- German Monsun/U-boat coordination: useful patrol-sector complement, constrained by German 1944 submarine situation; no magical joint command.

Do not use total hull inventory as available combat power. Trace origin -> readiness -> escort/fuel -> route -> arrival -> local base support.

## 11. GALVANIC negative-delta note

The final fighter microcombat and no-change audit does not alter the 1944-01-01 strategic state. It refines the GALVANIC aircraft-loss working centers and after-action fighter doctrine. See `GALVANIC_FIGHTER_MICROCOMBAT_REAUDIT_1943-11_v001.md` and `95_AUDIT/GALVANIC_NEGATIVE_DELTA_REVALIDATION_2026-08-29.md`.
