#!/usr/bin/env python3
from __future__ import annotations
import json, math
from dataclasses import dataclass
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PROFILES=json.load(open(ROOT/'carrier_damage_profiles_v117.json',encoding='utf-8'))

TIMES=(0.0,2.0,6.0,24.0)

def _clip01(x): return np.clip(x,0.0,1.0)

def simulate_conditional(profile_id:str,bomb_hits:int=0,torpedo_hits:int=0,n:int=50000,seed:int=11701,dc_scale:float=1.0,readiness_risk:float=.60):
    """Conditional carrier mission-continuation model.

    Inputs are already geometric weapon hits. This layer deliberately does NOT infer hit probability.
    Numerical effect distributions are B-priors constrained by r30 mission-kill/DC architecture.
    """
    p=PROFILES[profile_id]; rng=np.random.default_rng(seed)
    deck_res=float(p['deck_resistance']); uw=float(p['underwater_resistance']); subdiv=float(p['subdivision'])
    dc=float(p['dc_quality'])*dc_scale; fuel_iso=float(p['fuel_isolation'])*dc_scale; fire_sup=float(p['fire_suppression'])*dc_scale
    elev_red=float(p['elevator_redundancy']); aa_red=float(p['aa_redundancy'])
    base_speed=float(p['base_speed_kn'])

    # latent damage state
    deck_repair_h=np.zeros(n); shock_deck_h=np.zeros(n); elevator_out=np.zeros(n,int)
    hangar=np.zeros(n); fire0=np.zeros(n); flood0=np.zeros(n); aa_loss=np.zeros(n)
    speed_perm=np.zeros(n); speed_temp=np.zeros(n); steering_loss=np.zeros(n)
    avgas=np.zeros(n); ordnance=np.zeros(n); catastrophic=np.zeros(n,bool)
    bomb_long=[]; torp_long=[]

    for _ in range(int(bomb_hits)):
        x=rng.uniform(-1,1,n); bomb_long.append(x)
        # A direct flight-deck hit almost always damages deck surface; armor changes extent/repair time.
        block_prob=np.clip(.78/deck_res,.42,.92)
        blocked=rng.random(n)<block_prob
        median=6.0/(deck_res**0.85 * dc**0.22)  # hours, B-prior patch/clear working time
        rt=rng.lognormal(mean=math.log(max(.6,median)),sigma=.48,size=n)
        deck_repair_h=np.maximum(deck_repair_h,np.where(blocked,rt,0.0))
        # elevator-area direct damage is an area event, distinct from deck crater
        pe=np.clip(.13/elev_red,.07,.18); elevator_out += (rng.random(n)<pe)
        # penetration/hangar event; armor suppresses but does not eliminate blast/spall/fire
        ppen=np.clip(.82/deck_res,.28,.92); pen=rng.random(n)<ppen
        hsev=np.where(pen,rng.gamma(1.6,.16,n),rng.gamma(1.2,.035,n)); hangar += hsev
        # fuel/ordnance secondary risk depends on readiness and r30 isolation discipline
        pav=np.clip(.13*readiness_risk/fuel_iso,0,.16); por=np.clip(.10*readiness_risk/fire_sup,0,.14)
        av=(rng.random(n)<pav)&pen; od=(rng.random(n)<por)&pen
        avgas += av*rng.uniform(.35,.75,n); ordnance += od*rng.uniform(.35,.85,n)
        ignition=np.clip((.34*pen + .10*blocked + .45*av + .50*od)/fire_sup,0,.90)
        ign=rng.random(n)<ignition
        fire0 += ign*rng.gamma(1.5,.20,n) + avgas*.10 + ordnance*.12
        # machinery/steering are low-probability for a nominal 1000-lb dive-bomb hit, but possible on penetration
        pmach=.07*pen*(np.abs(x)<.42); m=rng.random(n)<pmach
        speed_perm += m*rng.uniform(1.0,3.5,n)
        psteer=.05*pen*(x>.65); st=rng.random(n)<psteer
        steering_loss=np.maximum(steering_loss,st*rng.uniform(.25,.70,n))
        aa_loss += (rng.random(n)<(.15/aa_red))*rng.uniform(.05,.18,n)

    for _ in range(int(torpedo_hits)):
        x=rng.uniform(-1,1,n); torp_long.append(x)
        # Side underwater hit: broad shock/flooding speed penalty even outside machinery, class resistance scales it.
        base_loss=rng.lognormal(mean=math.log(8.2/uw),sigma=.20,size=n)
        speed_temp += base_loss
        # central machinery / shaft region adds semi-permanent loss
        mach_zone=np.abs(x)<.48; mach=mach_zone&(rng.random(n)<.58)
        speed_perm += mach*rng.uniform(1.5,4.0,n)/max(.75,uw)
        # aft steering vulnerability
        steer=(x>.68)&(rng.random(n)<.62)
        steering_loss=np.maximum(steering_loss,steer*rng.uniform(.35,.90,n))
        # flooding severity and list/free-surface burden
        fsev=rng.gamma(2.0,.18,n)/(subdiv*uw)
        flood0 += fsev
        # shock / aviation-fuel safety stand-down; not structural deck crater
        sh=(rng.random(n)<.86)
        shock_deck_h=np.maximum(shock_deck_h,np.where(sh,rng.lognormal(math.log(3.2/max(.65,dc)),.38,n),0.0))
        # fuel-system local damage / vapor event is possible, but r30 isolation sharply limits global escalation
        av=(rng.random(n)<np.clip(.12/fuel_iso,0,.14))
        avgas += av*rng.uniform(.25,.65,n)
        fire0 += av*rng.gamma(1.3,.16,n)/fire_sup
        aa_loss += (rng.random(n)<(.10/aa_red))*rng.uniform(.04,.15,n)

    # Catastrophic cascade is emergent from combined fire/fuel/ordnance/flooding rather than per-hit kill probability.
    cascade=(fire0 + .75*avgas + .90*ordnance + .55*np.maximum(0,flood0-.55))/max(.75,dc)
    pcat=_clip01((cascade-.95)*.16)
    catastrophic = rng.random(n)<pcat

    rows=[]
    trial={}
    for t in TIMES:
        # temporary shock speed loss recovers as damage control isolates flooding and machinery stabilizes
        temp=speed_temp*(.42 + .58*np.exp(-t*dc/5.0))
        flood=flood0*(.58 + .42*np.exp(-t*dc/10.0))
        fire=fire0*np.exp(-t*fire_sup/2.8)
        speed=np.maximum(0.0,base_speed-speed_perm-temp-2.2*np.maximum(0,flood-.45))
        steer_cap=_clip01(1.0-steering_loss*(.72+.28*np.exp(-t*dc/8.0)))
        # structural/elevator/hangar effect; elevators are assumed isolated, not instant global deck loss.
        elev_pen=np.minimum(.55,elevator_out*(.19/max(.75,elev_red)))
        hangar_pen=np.minimum(.65,hangar*(.42+.18*np.exp(-t*dc/8.0)))
        deck_struct=_clip01(1.0-elev_pen-hangar_pen)
        deck_closed=(t<deck_repair_h)|(fire>.48)
        shock_active=(t<shock_deck_h)
        # wind-over-deck / speed support: not a literal launch curve, just mission capacity carrier
        speed_fac=_clip01((speed-13.0)/15.0)
        fire_fac=_clip01(1.0-.85*fire); flood_fac=_clip01(1.0-.55*np.maximum(0,flood-.25))
        launch=deck_struct*speed_fac*fire_fac*flood_fac
        recovery=deck_struct*np.sqrt(speed_fac)*fire_fac*flood_fac
        # torpedo shock/fuel-system checks restrict, but do not equal a physical flight-deck crater
        shock_fac=np.where(shock_active,.38,1.0)
        launch*=shock_fac; recovery*=np.where(shock_active,.48,1.0)
        launch=np.where(deck_closed,0,launch); recovery=np.where(deck_closed,0,recovery)
        aa=_clip01((1-aa_loss)*(1-.20*fire)*(1-.18*np.maximum(0,flood-.35)))
        lost=catastrophic | (flood>1.65) | (speed<5)
        closed=(~lost)&((launch<.12)|(recovery<.12))
        limited=(~lost)&(~closed)&((launch<.55)|(recovery<.55)|(speed<24)|(steer_cap<.55))
        restricted=(~lost)&(~closed)&(~limited)&((launch<.88)|(recovery<.88)|(speed<29)|(aa<.82))
        full=(~lost)&(~closed)&(~limited)&(~restricted)
        mission_kill=lost|closed|limited
        state=np.full(n,'FULL',object);state[restricted]='RESTRICTED';state[limited]='LIMITED';state[closed]='FLIGHT_DECK_CLOSED';state[lost]='LOST'
        rows.append({
            'profile':profile_id,'bomb_hits':bomb_hits,'torpedo_hits':torpedo_hits,'dc_scale':dc_scale,'time_h':t,'n':n,
            'p_full':float(full.mean()),'p_restricted':float(restricted.mean()),'p_limited':float(limited.mean()),
            'p_flight_deck_closed':float(closed.mean()),'p_lost':float(lost.mean()),'p_mission_kill':float(mission_kill.mean()),
            'mean_launch_capacity':float(launch.mean()),'mean_recovery_capacity':float(recovery.mean()),
            'median_speed_kn':float(np.median(speed)),'p_speed_below_26':float((speed<26).mean()),'p_speed_below_24':float((speed<24).mean()),
            'mean_steering_capacity':float(steer_cap.mean()),'mean_AA_capacity':float(aa.mean()),
            'mean_fire_severity':float(fire.mean()),'mean_flood_severity':float(flood.mean())
        })
        trial[t]={'speed':speed,'launch':launch,'recovery':recovery,'aa':aa,'steer':steer_cap,'lost':lost,'closed':closed,'limited':limited,'restricted':restricted}
    return rows,trial

if __name__=='__main__':
    import argparse,csv
    ap=argparse.ArgumentParser();ap.add_argument('--profile',default='TAIHO_R30_WORK');ap.add_argument('--bombs',type=int,default=0);ap.add_argument('--torps',type=int,default=1);ap.add_argument('--n',type=int,default=50000);ap.add_argument('--seed',type=int,default=11701);ap.add_argument('--dc-scale',type=float,default=1.0);ap.add_argument('--out')
    a=ap.parse_args();rows,_=simulate_conditional(a.profile,a.bombs,a.torps,a.n,a.seed,a.dc_scale)
    if a.out:
        with open(a.out,'w',newline='',encoding='utf-8') as f:w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    else:
        for r in rows:print(json.dumps(r,ensure_ascii=False))
