from pathlib import Path
import sys,json
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v114 as a, air_microcombat_v115 as b
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP

def run(vmod):
 p,w,e,d=vmod.load_all(R);at=load_attack_types(R)['TBF1C'];pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
 kw=dict(N=16,active_A=16,active_B=8,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(vmod._default_centered_y(8))+list(vmod._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500)
 if vmod is b: kw['package_weapon_release_range_m']=None
 return vmod.simulate_escort_cap(pa,p['US02'],da,d['US02'],w,e,ntr=3,seed=115002,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=False,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP['TBF1C'],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=True,global_aa_fire_discipline='center',global_screen_aa=True,global_screen_profile='akizuki2_yugumo2',global_screen_fire_discipline='center',global_screen_ship_motion=True,**kw)
A=run(a);B=run(b)
keys=['package_attack_passes','package_online_clean_bursts','package_online_mission_losses','A_mean_losses','B_mean_losses','global_mean_AA_heavy_rounds','global_mean_AA_25mm_rounds','global_mean_AA_jink_events','global_mean_release_opportunity_equivalent','global_mean_delivery_quality_at_release','global_mean_ship_solution_quality_equivalent','screen_mean_heavy_rounds','screen_mean_25mm_rounds','screen_mean_jink_events','screen_mean_station_error_m']
out={k:{'v114':A[k],'v115_no_gate':B[k],'equal':bool(A[k]==B[k])} for k in keys}
out['all_equal']=all(x['equal'] for x in out.values() if isinstance(x,dict) and 'equal' in x)
path=R.parent/'results_current'/'weapon_release_gate_disabled_equivalence_v115.json';path.write_text(json.dumps(out,indent=2),encoding='utf-8')
print(json.dumps(out,indent=2));assert out['all_equal']
