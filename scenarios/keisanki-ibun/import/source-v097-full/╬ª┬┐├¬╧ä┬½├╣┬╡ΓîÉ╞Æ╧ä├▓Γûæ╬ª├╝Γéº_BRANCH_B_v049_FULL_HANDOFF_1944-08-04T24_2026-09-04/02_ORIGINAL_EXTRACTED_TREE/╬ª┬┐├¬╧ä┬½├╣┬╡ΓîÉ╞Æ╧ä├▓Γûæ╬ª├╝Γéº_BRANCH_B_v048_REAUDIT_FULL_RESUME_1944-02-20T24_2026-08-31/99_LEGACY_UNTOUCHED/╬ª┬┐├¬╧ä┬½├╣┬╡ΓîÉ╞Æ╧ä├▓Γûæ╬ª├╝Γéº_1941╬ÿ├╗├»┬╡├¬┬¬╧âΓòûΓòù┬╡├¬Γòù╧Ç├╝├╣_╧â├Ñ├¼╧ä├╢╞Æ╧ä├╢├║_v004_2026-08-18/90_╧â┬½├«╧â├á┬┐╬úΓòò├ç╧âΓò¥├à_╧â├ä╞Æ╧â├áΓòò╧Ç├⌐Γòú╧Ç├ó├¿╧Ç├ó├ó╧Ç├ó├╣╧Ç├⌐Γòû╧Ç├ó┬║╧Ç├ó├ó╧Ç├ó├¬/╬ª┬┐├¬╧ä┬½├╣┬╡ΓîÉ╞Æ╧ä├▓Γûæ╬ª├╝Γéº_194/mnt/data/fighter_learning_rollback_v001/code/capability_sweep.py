import sys, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import air_microcombat_v04 as m
p,w,e,d=m.load_all(Path(__file__).parent)
rows=[]
for k in ['JP01','JP02','JP03','JP04','JP05','JP06','JP07']:
 r=m.simulate_dynamic(p[k],p['US02'],d[k],d['US02'],w,e,3000,3000,400,400,ntr=6000,seed=1200+int(k[-2:]),policyA='auto',policyB='auto')
 rows.append({'jp':k,'name':p[k].name,'JP_kill':r['A_kill'],'US_kill':r['B_kill'],'JP_first':r['A_firstshot'],'US_first':r['B_firstshot'],'JP_damaged':r['A_damaged_returnable'],'US_damaged':r['B_damaged_returnable'],'JP_diseng':r['A_diseng'],'US_diseng':r['B_diseng'],'timeout':r['timeout']})
print(json.dumps(rows,ensure_ascii=False,indent=2))
