# RECOVERY — v0.11.8 WIP Sortie Regeneration

## Status

**WIP only. v0.11.7 remains the fixed carrier mission-damage layer.**

The sortie-regeneration layer is now functional enough for structural diagnostics, but its absolute throughput priors are not fixed and it is not yet connected to a historical FORAGER clock.

## What was added in this session

Current model chain now extends through:

`v0.11.7 carrier latent damage -> time-varying recovery -> service/repair -> pilot/fuel/ammo gates -> respot -> time-varying launch -> next-wave package`

New/updated code:
- `code/carrier_damage_continuous_v118.py`
- `code/check_carrier_continuous_v118.py`
- `code/sortie_regeneration_v118.py`
- `code/run_sortie_regeneration_v118.py`
- `code/check_sortie_regeneration_v118.py`

### Important corrections

1. Removed the active 0/2/6/24 h interpolation shortcut. The v0.11.7 latent damage state is now evaluated at arbitrary time.
2. Regression test confirms continuous evaluator reproduces v0.11.7 arrays exactly at 0/2/6/24 h for tested bomb, torpedo and combined-hit cases.
3. Fixed recovery ordering: global ETA FCFS across aircraft types rather than F -> DB -> TB iteration.
4. Flight-deck capacity is non-bankable and time-varying for both recovery and launch/spotting.
5. Added threshold probabilities because bomb damage produces bimodal next-wave outcomes.

## Current B-priors — candidate only

| profile | launch ac/min | recovery ac/min | service slots | respot work |
|---|---:|---:|---:|---:|
| UNRYU | 1.35 | 0.72 | 10 | 11 min |
| SHOKAKU | 1.55 | 0.82 | 12 | 10 min |
| TAIHO | 1.45 | 0.78 | 12 | 10.5 min |

Routine turnaround median: F 28 / DB 43 / TB 49 min.
Repairable damaged-aircraft median: F 125 / DB 150 / TB 165 min.

These are **not historical measurements**.

## Diagnostic state

Generic 72-aircraft post-return state:
- ready F14 / DB8 / TB7
- routine service F6 / DB3 / TB4
- returning F8 / DB8 / TB8, ETA 8–24.5 min
- damaged repairable F2 / DB2 / TB2
- pilot/fatigue/fuel/ammunition gates separate.

The benchmark is for model behavior only.

## Current benchmark

### Undamaged Shokaku working profile

Next wave actually launchable by horizon, p10 / p50 / p90:
- +30 min: 0 / 0 / 0
- +60 min: 17 / 17 / 17
- +120 min: 48 / 50 / 52

At +120 min, P(next wave >= 48) = 0.980 in the current diagnostic Monte Carlo.

This is a recovery-first post-return cycle, not maximum emergency launch capacity.

### Taiho working profile — one torpedo, immediate start

- +30 min: 0 / 0 / 0
- +60 min: 0 / 0 / 1
- +120 min: 0 / 8 / 49

At +120 min:
- P(any next wave) = 0.823
- P(>=24) = 0.244
- P(>=48) = 0.132

The wide distribution is the intended consequence of a shock/restriction timer rather than a permanent deck crater.

### Taiho working profile — one torpedo, start at +6 h damage time

- +30 min: 0 / 0 / 0
- +60 min: 5 / 13 / 13
- +120 min: 48 / 50 / 52

At +120 min, P(>=48) = 0.980.

### One bomb, starting at +6 h damage time

UNRYU:
- +120 min p10 / p50 / p90 = 0 / 20.5 / 48
- P(any) = 0.546
- P(>=24) = 0.490
- P(>=48) = 0.123

SHOKAKU:
- +120 min p10 / p50 / p90 = 0 / 43 / 51
- P(any) = 0.578
- P(>=24) = 0.549
- P(>=48) = 0.478

The median is not a smooth half-capacity state. Trials divide into still-closed/late-opening decks and substantially recovered decks.

### Taiho one bomb + one torpedo, start at +6 h

+120 min p10 / p50 / p90 = 0 / 50 / 52, with P(any) = 0.878 and P(>=48) = 0.779.

This result is **not ready for interpretation as history**. v0.11.7 itself gives the armored Taiho working profile much lower six-hour deck-closure/mission-kill probability than the unarmored one-bomb cases, but the sortie layer does not yet carry persistent fuel-vapor/fire/ordnance servicing restrictions. Treat the strong recovery tail as a calibration flag.

## Automated checks

Passing:
- continuous carrier evaluator exactly matches tested v0.11.7 0/2/6/24 h trial arrays;
- undamaged +30/+60/+120 median output is nondecreasing;
- lower deck capacity does not improve output;
- slower servicing does not improve output;
- Taiho 1T +6 h start regenerates no worse than immediate post-hit start.

Current smoke values:
- undamaged p50 = 0 / 17 / 50
- capacity 1.0 vs 0.55 at +120 = 50 vs 34
- service scale 0.8 vs 1.2 at +120 = 54 vs 47
- Taiho 1T immediate vs +6 h start at +120 = 8 vs 50

## Next correct work

Do **not** resume FORAGER historical reconstruction yet.

Next:
1. transfer actual surviving/returning/damaged aircraft from the upstream air-combat trial into `AirGroupState`;
2. preserve pilot identity/qualification/fatigue across that transfer;
3. split the lumped service queue into elevator/deck handling, fuel, ordnance and maintenance resources;
4. carry carrier fire/fuel-vapor/ordnance safety restrictions into servicing, not only launch/recovery capacity;
5. add recovery-vs-emergency-CAP deck preemption policy;
6. rerun priors/sensitivity and only then consider v0.11.8 fixation.
