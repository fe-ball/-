#!/usr/bin/env python3
from __future__ import annotations
import json, math
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PROFILES=json.load(open(ROOT/'carrier_damage_profiles_v117.json',encoding='utf-8'))

def _clip01(x): return np.clip(x,0.0,1.0)

@dataclass
class CarrierLatentState:
    profile_id: str
    n: int
    dc: float
    fire_sup: float
    base_speed: float
    elev_red: float
    deck_repair_h: np.ndarray
    shock_deck_h: np.ndarray
    elevator_out: np.ndarray
    hangar: np.ndarray
    fire0: np.ndarray
    flood0: np.ndarray
    aa_loss: np.ndarray
    speed_perm: np.ndarray
    speed_temp: np.ndarray
    steering_loss: np.ndarray
    avgas: np.ndarray
    ordnance: np.ndarray
    catastrophic: np.ndarray


def sample_damage_state(profile_id:str,bomb_hits:int=0,torpedo_hits:int=0,n:int=50000,
                        seed:int=11701,dc_scale:float=1.0,readiness_risk:float=.60) -> CarrierLatentState:
    """Sample the v0.11.7 carrier-damage latent state without collapsing it to fixed output times.

    Equations and RNG call order intentionally mirror carrier_damage_v117.py so the evaluator can be
    regression-checked against the v0.11.7 0/2/6/24 h outputs.
    """
    p=PROFILES[profile_id]; rng=np.random.default_rng(seed)
    deck_res=float(p['deck_resistance']); uw=float(p['underwater_resistance']); subdiv=float(p['subdivision'])
    dc=float(p['dc_quality'])*dc_scale; fuel_iso=float(p['fuel_isolation'])*dc_scale; fire_sup=float(p['fire_suppression'])*dc_scale
    elev_red=float(p['elevator_redundancy']); aa_red=float(p['aa_redundancy'])
    base_speed=float(p['base_speed_kn'])

    deck_repair_h=np.zeros(n); shock_deck_h=np.zeros(n); elevator_out=np.zeros(n,int)
    hangar=np.zeros(n); fire0=np.zeros(n); flood0=np.zeros(n); aa_loss=np.zeros(n)
    speed_perm=np.zeros(n); speed_temp=np.zeros(n); steering_loss=np.zeros(n)
    avgas=np.zeros(n); ordnance=np.zeros(n); catastrophic=np.zeros(n,bool)

    for _ in range(int(bomb_hits)):
        x=rng.uniform(-1,1,n)
        block_prob=np.clip(.78/deck_res,.42,.92)
        blocked=rng.random(n)<block_prob
        median=6.0/(deck_res**0.85 * dc**0.22)
        rt=rng.lognormal(mean=math.log(max(.6,median)),sigma=.48,size=n)
        deck_repair_h=np.maximum(deck_repair_h,np.where(blocked,rt,0.0))
        pe=np.clip(.13/elev_red,.07,.18); elevator_out += (rng.random(n)<pe)
        ppen=np.clip(.82/deck_res,.28,.92); pen=rng.random(n)<ppen
        hsev=np.where(pen,rng.gamma(1.6,.16,n),rng.gamma(1.2,.035,n)); hangar += hsev
        pav=np.clip(.13*readiness_risk/fuel_iso,0,.16); por=np.clip(.10*readiness_risk/fire_sup,0,.14)
        av=(rng.random(n)<pav)&pen; od=(rng.random(n)<por)&pen
        avgas += av*rng.uniform(.35,.75,n); ordnance += od*rng.uniform(.35,.85,n)
        ignition=np.clip((.34*pen + .10*blocked + .45*av + .50*od)/fire_sup,0,.90)
        ign=rng.random(n)<ignition
        fire0 += ign*rng.gamma(1.5,.20,n) + avgas*.10 + ordnance*.12
        pmach=.07*pen*(np.abs(x)<.42); m=rng.random(n)<pmach
        speed_perm += m*rng.uniform(1.0,3.5,n)
        psteer=.05*pen*(x>.65); st=rng.random(n)<psteer
        steering_loss=np.maximum(steering_loss,st*rng.uniform(.25,.70,n))
        aa_loss += (rng.random(n)<(.15/aa_red))*rng.uniform(.05,.18,n)

    for _ in range(int(torpedo_hits)):
        x=rng.uniform(-1,1,n)
        base_loss=rng.lognormal(mean=math.log(8.2/uw),sigma=.20,size=n)
        speed_temp += base_loss
        mach_zone=np.abs(x)<.48; mach=mach_zone&(rng.random(n)<.58)
        speed_perm += mach*rng.uniform(1.5,4.0,n)/max(.75,uw)
        steer=(x>.68)&(rng.random(n)<.62)
        steering_loss=np.maximum(steering_loss,steer*rng.uniform(.35,.90,n))
        fsev=rng.gamma(2.0,.18,n)/(subdiv*uw)
        flood0 += fsev
        sh=(rng.random(n)<.86)
        shock_deck_h=np.maximum(shock_deck_h,np.where(sh,rng.lognormal(math.log(3.2/max(.65,dc)),.38,n),0.0))
        av=(rng.random(n)<np.clip(.12/fuel_iso,0,.14))
        avgas += av*rng.uniform(.25,.65,n)
        fire0 += av*rng.gamma(1.3,.16,n)/fire_sup
        aa_loss += (rng.random(n)<(.10/aa_red))*rng.uniform(.04,.15,n)

    cascade=(fire0 + .75*avgas + .90*ordnance + .55*np.maximum(0,flood0-.55))/max(.75,dc)
    pcat=_clip01((cascade-.95)*.16)
    catastrophic = rng.random(n)<pcat

    return CarrierLatentState(
        profile_id=profile_id,n=n,dc=dc,fire_sup=fire_sup,base_speed=base_speed,elev_red=elev_red,
        deck_repair_h=deck_repair_h,shock_deck_h=shock_deck_h,elevator_out=elevator_out,
        hangar=hangar,fire0=fire0,flood0=flood0,aa_loss=aa_loss,speed_perm=speed_perm,
        speed_temp=speed_temp,steering_loss=steering_loss,avgas=avgas,ordnance=ordnance,
        catastrophic=catastrophic,
    )


def evaluate_state(s: CarrierLatentState, t_h: float):
    """Evaluate a sampled latent carrier state at arbitrary hours after damage."""
    t=float(t_h); dc=s.dc; fire_sup=s.fire_sup
    temp=s.speed_temp*(.42 + .58*np.exp(-t*dc/5.0))
    flood=s.flood0*(.58 + .42*np.exp(-t*dc/10.0))
    fire=s.fire0*np.exp(-t*fire_sup/2.8)
    speed=np.maximum(0.0,s.base_speed-s.speed_perm-temp-2.2*np.maximum(0,flood-.45))
    steer_cap=_clip01(1.0-s.steering_loss*(.72+.28*np.exp(-t*dc/8.0)))
    elev_pen=np.minimum(.55,s.elevator_out*(.19/max(.75,s.elev_red)))
    hangar_pen=np.minimum(.65,s.hangar*(.42+.18*np.exp(-t*dc/8.0)))
    deck_struct=_clip01(1.0-elev_pen-hangar_pen)
    deck_closed=(t<s.deck_repair_h)|(fire>.48)
    shock_active=(t<s.shock_deck_h)
    speed_fac=_clip01((speed-13.0)/15.0)
    fire_fac=_clip01(1.0-.85*fire); flood_fac=_clip01(1.0-.55*np.maximum(0,flood-.25))
    launch=deck_struct*speed_fac*fire_fac*flood_fac
    recovery=deck_struct*np.sqrt(speed_fac)*fire_fac*flood_fac
    launch*=np.where(shock_active,.38,1.0)
    recovery*=np.where(shock_active,.48,1.0)
    launch=np.where(deck_closed,0,launch); recovery=np.where(deck_closed,0,recovery)
    aa=_clip01((1-s.aa_loss)*(1-.20*fire)*(1-.18*np.maximum(0,flood-.35)))
    lost=s.catastrophic | (flood>1.65) | (speed<5)
    closed=(~lost)&((launch<.12)|(recovery<.12))
    limited=(~lost)&(~closed)&((launch<.55)|(recovery<.55)|(speed<24)|(steer_cap<.55))
    restricted=(~lost)&(~closed)&(~limited)&((launch<.88)|(recovery<.88)|(speed<29)|(aa<.82))
    full=(~lost)&(~closed)&(~limited)&(~restricted)
    mission_kill=lost|closed|limited
    state=np.full(s.n,'FULL',object);state[restricted]='RESTRICTED';state[limited]='LIMITED';state[closed]='FLIGHT_DECK_CLOSED';state[lost]='LOST'
    return {
        'time_h':t,'speed':speed,'launch':launch,'recovery':recovery,'aa':aa,'steer':steer_cap,
        'lost':lost,'closed':closed,'limited':limited,'restricted':restricted,'full':full,
        'mission_kill':mission_kill,'state':state,'fire':fire,'flood':flood,
        # expose active timers/events so sortie layer can distinguish a zero-capacity interval from low throughput
        'deck_repair_active':t<s.deck_repair_h,'shock_active':shock_active,
    }


def evaluate_capacities(s: CarrierLatentState, t_h: float):
    """Lightweight arbitrary-time launch/recovery evaluator for queue integration."""
    t=float(t_h); dc=s.dc; fire_sup=s.fire_sup
    temp=s.speed_temp*(.42 + .58*np.exp(-t*dc/5.0))
    flood=s.flood0*(.58 + .42*np.exp(-t*dc/10.0))
    fire=s.fire0*np.exp(-t*fire_sup/2.8)
    speed=np.maximum(0.0,s.base_speed-s.speed_perm-temp-2.2*np.maximum(0,flood-.45))
    elev_pen=np.minimum(.55,s.elevator_out*(.19/max(.75,s.elev_red)))
    hangar_pen=np.minimum(.65,s.hangar*(.42+.18*np.exp(-t*dc/8.0)))
    deck_struct=_clip01(1.0-elev_pen-hangar_pen)
    deck_closed=(t<s.deck_repair_h)|(fire>.48)
    shock_active=(t<s.shock_deck_h)
    speed_fac=_clip01((speed-13.0)/15.0)
    fire_fac=_clip01(1.0-.85*fire); flood_fac=_clip01(1.0-.55*np.maximum(0,flood-.25))
    launch=deck_struct*speed_fac*fire_fac*flood_fac*np.where(shock_active,.38,1.0)
    recovery=deck_struct*np.sqrt(speed_fac)*fire_fac*flood_fac*np.where(shock_active,.48,1.0)
    launch=np.where(deck_closed,0,launch); recovery=np.where(deck_closed,0,recovery)
    return np.clip(launch,0,1),np.clip(recovery,0,1)


def evaluate_service_capacities(s: CarrierLatentState, t_h: float):
    """B-prior internal servicing capacities separate from launch/recovery.

    The v0.11.7 latent state already contains hangar damage, elevator outages, fire, flooding,
    avgas involvement and ordnance involvement.  This evaluator exposes those hazards to the
    v0.11.8 split turnaround queues without changing any v0.11.7 mission-damage output.

    Capacities are normalized work rates.  Fuel and ordnance handling can be suspended by
    persistent hazard even after the flight deck itself has reopened.  Hazard-decay constants
    remain sensitivity priors until stronger calibration is fixed.
    """
    t=float(t_h); dc=s.dc; fs=s.fire_sup
    flood=s.flood0*(.58+.42*np.exp(-t*dc/10.0))
    fire=s.fire0*np.exp(-t*fs/2.8)
    avhaz=s.avgas*np.exp(-t*max(.55,dc)/4.5)
    ordhaz=s.ordnance*np.exp(-t*max(.55,fs)/5.5)
    elev_pen=np.minimum(.55,s.elevator_out*(.19/max(.75,s.elev_red)))
    hangar_pen=np.minimum(.65,s.hangar*(.42+.18*np.exp(-t*dc/8.0)))
    flood_pen=np.clip(np.maximum(0.0,flood-.20),0,1)

    handling=_clip01(1.0-elev_pen-.75*hangar_pen-.30*fire-.22*flood_pen)
    maintenance=_clip01(1.0-.75*hangar_pen-.48*fire-.28*flood_pen)
    fuel=_clip01(1.0-.45*hangar_pen-1.15*fire-1.05*avhaz-.18*flood_pen)
    ordnance=_clip01(1.0-.55*hangar_pen-1.05*fire-1.10*ordhaz-.15*flood_pen)
    # Safety stand-downs are intentionally distinct from flight-deck closure.
    fuel=np.where((fire>.34)|(avhaz>.42),0.0,fuel)
    ordnance=np.where((fire>.40)|(ordhaz>.46),0.0,ordnance)
    lost=s.catastrophic | (flood>1.65)
    for a in (handling,maintenance,fuel,ordnance): a[lost]=0.0
    return {
        'handling':np.clip(handling,0,1),'maintenance':np.clip(maintenance,0,1),
        'fuel':np.clip(fuel,0,1),'ordnance':np.clip(ordnance,0,1),
        'fire':fire,'flood':flood,'avgas_hazard':avhaz,'ordnance_hazard':ordhaz,
    }

def summarize_state(s: CarrierLatentState, ev: dict, bomb_hits:int, torpedo_hits:int, dc_scale:float=1.0):
    return {
        'profile':s.profile_id,'bomb_hits':bomb_hits,'torpedo_hits':torpedo_hits,'dc_scale':dc_scale,
        'time_h':float(ev['time_h']),'n':s.n,
        'p_full':float(ev['full'].mean()),'p_restricted':float(ev['restricted'].mean()),
        'p_limited':float(ev['limited'].mean()),'p_flight_deck_closed':float(ev['closed'].mean()),
        'p_lost':float(ev['lost'].mean()),'p_mission_kill':float(ev['mission_kill'].mean()),
        'mean_launch_capacity':float(ev['launch'].mean()),'mean_recovery_capacity':float(ev['recovery'].mean()),
        'median_speed_kn':float(np.median(ev['speed'])),'p_speed_below_26':float((ev['speed']<26).mean()),
        'p_speed_below_24':float((ev['speed']<24).mean()),'mean_steering_capacity':float(ev['steer'].mean()),
        'mean_AA_capacity':float(ev['aa'].mean()),'mean_fire_severity':float(ev['fire'].mean()),
        'mean_flood_severity':float(ev['flood'].mean()),
    }


def simulate_conditional_continuous(profile_id:str,bomb_hits:int=0,torpedo_hits:int=0,n:int=50000,
                                    seed:int=11701,dc_scale:float=1.0,readiness_risk:float=.60,
                                    times_h:Iterable[float]=(0.0,2.0,6.0,24.0)):
    s=sample_damage_state(profile_id,bomb_hits,torpedo_hits,n,seed,dc_scale,readiness_risk)
    rows=[]; trial={}
    for t in times_h:
        ev=evaluate_state(s,float(t)); rows.append(summarize_state(s,ev,bomb_hits,torpedo_hits,dc_scale)); trial[float(t)]=ev
    return rows,trial,s
