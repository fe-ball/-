#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import csv,json,sys
import numpy as np
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
from carrier_damage_continuous_v118 import sample_damage_state,evaluate_capacities,evaluate_service_capacities
from sortie_regeneration_v118 import simulate_sortie_regeneration_dynamic,summarize,benchmark_airgroup

CASES=[
 ('SHO_1B_2h','SHOKAKU_R30_WORK',1,0,2.0),
 ('SHO_1B_6h','SHOKAKU_R30_WORK',1,0,6.0),
 ('TAI_1T_0h','TAIHO_R30_WORK',0,1,0.0),
 ('TAI_1T_6h','TAIHO_R30_WORK',0,1,6.0),
 ('TAI_1B1T_2h','TAIHO_R30_WORK',1,1,2.0),
 ('TAI_1B1T_6h','TAIHO_R30_WORK',1,1,6.0),
]

def curves(profile,b,t,start_h,n_damage,seed):
    s=sample_damage_state(profile,bomb_hits=b,torpedo_hits=t,n=n_damage,seed=seed)
    tm=np.arange(0,121,2,dtype=float)
    L=[];Rc=[];H=[];F=[];O=[];M=[]
    for minute in tm:
        th=start_h+minute/60.0
        l,r=evaluate_capacities(s,th); sv=evaluate_service_capacities(s,th)
        L.append(l);Rc.append(r);H.append(sv['handling']);F.append(sv['fuel']);O.append(sv['ordnance']);M.append(sv['maintenance'])
    return tm,np.stack(L,1),np.stack(Rc,1),np.stack(H,1),np.stack(F,1),np.stack(O,1),np.stack(M,1)

def run_case(name,profile,b,t,start_h,n_damage=3000,n_sortie=1400,seed=118700):
    tm,L,Rc,H,F,O,M=curves(profile,b,t,start_h,n_damage,seed)
    common=dict(profile_id=profile,timeline_min=tm,launch_capacity_curve=L,recovery_capacity_curve=Rc,
                state=benchmark_airgroup(),n=n_sortie,seed=seed+31,horizon_min=120,service_model='split')
    base=simulate_sortie_regeneration_dynamic(**common)
    safe=simulate_sortie_regeneration_dynamic(**common,handling_capacity_curve=H,fuel_capacity_curve=F,
        ordnance_capacity_curve=O,maintenance_capacity_curve=M)
    rows=[]
    for mode,rr in [('deck_only',base),('internal_safety',safe)]:
        s=summarize(rr)[0]
        rows.append({
            'case':name,'profile':profile,'bomb_hits':b,'torpedo_hits':t,'start_h':start_h,'mode':mode,
            'n_damage':n_damage,'n_sortie':n_sortie,
            'wave_p10':s['next_wave_total_p10'],'wave_p50':s['next_wave_total_p50'],'wave_p90':s['next_wave_total_p90'],
            'p_any':s['p_any_next_wave'],'p_ge12':s['p_next_wave_ge_12'],'p_ge24':s['p_next_wave_ge_24'],
            'p_ge36':s['p_next_wave_ge_36'],'p_ge48':s['p_next_wave_ge_48'],
            'ready_F_p50':s['ready_F_p50'],'ready_DB_p50':s['ready_DB_p50'],'ready_TB_p50':s['ready_TB_p50'],
            'handling_end_mean':float(np.mean(H[:,-1])),'fuel_end_mean':float(np.mean(F[:,-1])),
            'ordnance_end_mean':float(np.mean(O[:,-1])),'maintenance_end_mean':float(np.mean(M[:,-1])),
        })
    return rows

def main():
    rows=[]
    for i,c in enumerate(CASES): rows.extend(run_case(*c,seed=118700+i*1000))
    out=R.parent/'results_current';out.mkdir(exist_ok=True)
    jp=out/'sortie_service_hazard_benchmark_v118.json';jp.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    cp=out/'sortie_service_hazard_benchmark_v118.csv'
    with cp.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    print(json.dumps(rows,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
