# Recovery — v0.11.8-WIP3 FORAGER re-entry

Date: 2026-08-16
Current historical clock: 1944-07-07 night, with Jul8–10 transition and Jul11 assembly now reopened.
Status: WIP; do not freeze as canonical battle result.

## What is now operational

- Per-aircraft upstream terminal state → lost / clean return / damaged return → carrier turnaround.
- Damaged airborne aircraft retain the damage flag through recovery and enter long repair after landing.
- Returning crew identity/qualification/fatigue can gate later sorties after actual landing + rest.
- Turnaround may run as legacy lumped service or split handling / fuel / ordnance / maintenance resources.
- Carrier internal fire/avgas/ordnance hazards can inhibit servicing separately from deck launch/recovery capacity.
- B6N2 and D4Y2 Japanese attack packages are online with JP01 escorts.
- US carrier-local 5in/38 + 40-mm AA exists as a separate damage set.
- Four Fletcher-like escort nodes can be enabled as a lower-bound US screen.
- CAP active count is variable.
- D4Y2 weapon release is now recorded at the dive-release gate.
- Screen target scoring recognizes B6N2 as torpedo attack by registered terminal mission, not aircraft-ID string.

## Regression status

Existing v0.11.7/early-v0.11.8 checks remain passing. Undamaged Shokaku diagnostic center remains +30/+60/+120 min = 0/17/50 under the legacy center comparison. Split-service resource checks and air-trial bridge checks also pass.

## FORAGER Jul7 air ledger

20,000-trial working ledger, constrained by r30 canonical aggregate bands:

- all carrier combat-usable p10/p50/p90: 474 / 482 / 490;
- first-line-qualified p10/p50/p90: 434 / 442 / 450;
- first group total: 290 / 295 / 301;
- first group F/DB/TB medians: 127 / 85 / 82;
- second group total: 165 / 170 / 176;
- second group F/DB/TB medians: 89 / 42 / 39.

Role shares and sub-qualification distributions are B-priors, not historical measured counts.

## Carrier attack-cell assembly

Working cell = 12 attack aircraft + 6 escort fighters.

Physical/qualification-supported carrier cells:
- p10/p50/p90 = 17 / 19 / 20 cells;
- equivalent aircraft = 306 / 342 / 360.

The main first-group limiter is usually attack-aircraft inventory; second-group limiters are split among attack-aircraft inventory, fighter escort availability and the role-attack-qualified pool.

Operational commitment matters more than raw support:
- reserve-conscious carrier commitment p50: 288 aircraft;
- massed carrier commitment p50: 306 aircraft;
- maximum supported p50: 342 aircraft.

## Base aviation Jul8–10 transition WIP

This is not yet a microcombat rerun. It reopens doc43 comparison-branch losses by separating combat/irrecoverable loss from base-bound/stranded loss, then applies doc45 air-ground-separation preservation only to the latter component.

50,000-trial outputs:
- Jul8 major loss p50: 62;
- Jul9 major loss p50: 53;
- Jul9-night network survivors p50: 315;
- moved away from immediate Marianas fields p50: 60;
- relocated and ready by Jul11 p50: 46;
- one-day-reach ready Jul11 p50: 301;
- Jul11 base main-strike commitment p10/p50/p90: 125 / 136 / 149.

## Jul11 force assembly

Combining carrier policy scenarios with the base-transition WIP:

- reserve-conscious total p10/p50/p90: 385 / 416 / 444;
- massed total: 406 / 437 / 464;
- maximum-supported total: 442 / 473 / 500.

The old doc43 comparison branch 455–505 is therefore not a neutral center under the new planning model. It is reached mainly when carrier-cell commitment approaches the physical/qualification maximum. This should be treated as a substantive recalculation finding, not silently calibrated away.

## Taiho Jul10 1T timing sensitivity

With a 45-min first-group launch window and near-maximum first-group cell demand:
- +2 h after torpedo: P(lose >=1 cell-equivalent from launch window) ~0.50; >=2 ~0.24;
- +6 h: ~0.05 / ~0.004;
- +12 h: ~0.032 / ~0.0004.

Thus a large Jul11 first-wave penalty requires the torpedo hit to be relatively close to the launch clock or to cause a tail-state not represented by the current center. If enough hours have elapsed, the more natural effect is on second-wave regeneration, servicing safety and damaged-aircraft recovery rather than wholesale first-wave suppression.

## Representative terminal-defense diagnostics

The cell model now supports:
- JP escort 0–12;
- US CAP count 6–24;
- US carrier-local AA;
- optional four-Fletcher screen.

Paired current-code 12-trial diagnostic, CAP12 + escort6:
- B6N2: local-AA only lost 0.083/12, damaged return 0.583; +Fletcher4 screen lost 0.583, damaged return 1.000.
- D4Y2: local-AA only lost 0.333/12, damaged return 0.833; +Fletcher4 screen lost 0.917, damaged return 0.917.

These are **terminal-cell diagnostics**, not full-route historical strike loss rates. They omit cruiser/battleship screen AA, a separate 20-mm layer, repeated route CAP contacts and other task groups. Small n also makes direct-loss counts noisy; use them to validate structure and set future Monte Carlo priorities, not to quote a final loss percentage.

CAP-density 8-trial smoke confirms attack pressure increases with more CAP, especially in pass count/damage and B6N release quality. The sample is too small to require monotonic realized losses at every step.

## Current hard boundary / next work

The model can now assemble a semantically correct Jul11 Japanese carrier/base force, but it cannot yet produce a defensible final FORAGER battle result. The remaining high-value tasks are:

1. microcombat rerun of Jul8–9 fighter sweep + airfield attack instead of comparison-loss transition priors;
2. US screen expansion from Fletcher4 lower bound to task-group cruiser/destroyer/battleship layers, with an independent 20-mm channel;
3. repeated route-CAP / radar-fighter-direction contacts before the terminal cell encounter;
4. attack-weapon hit/damage conversion for B6N torpedo and D4Y bomb release states against maneuvering US ships;
5. only then scale representative cells into Jul11 per-wave fleet outcomes and feed survivors back into sortie regeneration.

## Key outputs

- `results_current/forager_air_ledger_v118.json/.csv`
- `results_current/forager_base_preservation_v118.json/.csv`
- `results_current/forager_cell_assembly_v118.json/.csv`
- `results_current/forager_jul11_force_assembly_v118.json/.csv`
- `results_current/forager_CAP_density_sensitivity_v118.json/.csv`
- `results_current/forager_B6N2_CAP12_escort6_localAA_paired12_v118.json`
- `results_current/forager_B6N2_CAP12_escort6_localAA_screen_paired12_v118.json`
- `results_current/forager_D4Y2_CAP12_escort6_localAA_paired12_v118.json`
- `results_current/forager_D4Y2_CAP12_escort6_localAA_screen_paired12_v118.json`
