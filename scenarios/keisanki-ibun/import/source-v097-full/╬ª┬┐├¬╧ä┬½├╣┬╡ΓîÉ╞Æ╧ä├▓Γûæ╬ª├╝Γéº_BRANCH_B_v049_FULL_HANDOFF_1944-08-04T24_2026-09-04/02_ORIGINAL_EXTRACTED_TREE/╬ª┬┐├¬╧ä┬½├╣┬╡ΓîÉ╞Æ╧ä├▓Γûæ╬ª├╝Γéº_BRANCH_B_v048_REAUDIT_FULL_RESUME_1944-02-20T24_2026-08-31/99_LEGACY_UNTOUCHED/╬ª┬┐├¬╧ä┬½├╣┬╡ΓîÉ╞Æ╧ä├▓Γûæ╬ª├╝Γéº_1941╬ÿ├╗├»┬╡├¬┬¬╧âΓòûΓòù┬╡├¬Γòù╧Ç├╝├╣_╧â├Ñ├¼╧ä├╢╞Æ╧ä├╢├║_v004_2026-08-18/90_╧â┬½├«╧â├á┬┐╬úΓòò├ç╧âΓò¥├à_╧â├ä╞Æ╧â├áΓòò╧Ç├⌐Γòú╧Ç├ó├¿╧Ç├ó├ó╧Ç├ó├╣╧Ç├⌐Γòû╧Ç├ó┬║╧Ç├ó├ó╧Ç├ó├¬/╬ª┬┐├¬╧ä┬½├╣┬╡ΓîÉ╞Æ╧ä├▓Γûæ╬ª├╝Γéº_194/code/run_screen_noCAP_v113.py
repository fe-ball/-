#!/usr/bin/env python3
from pathlib import Path
import sys,csv,concurrent.futures as cf
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v113 as v
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP
SC=['none','sparse','center','dense']
def worker(sc_n):
 sc,ntr=sc_n;p,w,e,d=v.load_all(R);at=load_attack_types(R)['TBF1C'];pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
 kw=dict(N=16,active_A=0,active_B=0,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(v._default_centered_y(8))+list(v._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500)
 m=v.simulate_escort_cap(pa,p['US02'],da,d['US02'],w,e,ntr=ntr,seed=113450,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=False,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP['TBF1C'],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=True,global_aa_fire_discipline='center',global_screen_aa=(sc!='none'),global_screen_profile=('center' if sc=='none' else sc),global_screen_fire_discipline='center',**kw)
 keys=['global_mean_release_opportunity_equivalent','global_mean_delivery_quality_at_release','global_mean_AA_jink_events','global_mean_AA_heavy_rounds','global_mean_AA_25mm_rounds','screen_mean_heavy_rounds','screen_mean_25mm_rounds','screen_mean_jink_events','screen_mean_new_mission_losses']
 return {'screen':sc,'ntr':ntr,**{k:m.get(k,0.0) for k in keys}}
def main():
 import argparse;ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=40);a=ap.parse_args()
 with cf.ProcessPoolExecutor(max_workers=4) as ex:rows=list(ex.map(worker,[(s,a.ntr) for s in SC]))
 out=R.parent/'results_current'/'screen_aa_TBF1C_noCAP_precision_v113.csv'
 with open(out,'w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 for r in rows:print(r)
if __name__=='__main__':main()
