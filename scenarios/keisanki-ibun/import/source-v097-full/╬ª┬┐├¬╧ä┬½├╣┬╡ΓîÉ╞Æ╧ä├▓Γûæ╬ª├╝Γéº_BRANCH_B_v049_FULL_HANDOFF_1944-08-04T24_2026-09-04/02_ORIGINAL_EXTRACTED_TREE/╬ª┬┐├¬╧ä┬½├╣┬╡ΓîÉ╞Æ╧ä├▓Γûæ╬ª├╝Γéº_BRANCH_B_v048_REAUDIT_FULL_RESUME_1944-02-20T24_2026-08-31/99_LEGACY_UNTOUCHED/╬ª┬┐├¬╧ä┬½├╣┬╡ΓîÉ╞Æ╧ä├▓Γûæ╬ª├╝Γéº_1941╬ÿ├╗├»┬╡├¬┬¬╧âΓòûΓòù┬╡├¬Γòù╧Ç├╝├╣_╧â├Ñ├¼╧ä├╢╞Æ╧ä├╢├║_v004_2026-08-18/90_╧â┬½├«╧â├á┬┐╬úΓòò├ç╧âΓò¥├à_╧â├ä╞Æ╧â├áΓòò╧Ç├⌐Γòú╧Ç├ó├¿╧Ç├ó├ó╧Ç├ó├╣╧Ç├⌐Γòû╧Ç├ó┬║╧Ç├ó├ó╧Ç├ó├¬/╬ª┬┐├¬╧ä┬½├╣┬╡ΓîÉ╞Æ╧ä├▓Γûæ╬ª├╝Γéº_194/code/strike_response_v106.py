#!/usr/bin/env python3
from __future__ import annotations
import math, numpy as np
import air_microcombat_v106 as geom
from strike_damage_v102 import load_attack_types,_burst,_rear
from strike_response_v103 import RESP,wrap,_aspect
base=geom.base

# Delivery-quality weights are B-priors.  They rank the ability to complete the
# weapon-release setup; they are not hit-probability multipliers.
DELIVERY_WEIGHTS={
 'SBD5':   dict(controls=.48,structure=.34,engine=.10,cooling=.08),
 'SB2C1C': dict(controls=.46,structure=.34,engine=.12,cooling=.08),
 'TBF1C':  dict(controls=.44,structure=.14,engine=.30,cooling=.12),
}
SETUP_SECONDS={'SBD5':7.5,'SB2C1C':8.0,'TBF1C':15.0}
# Clean/degraded classification thresholds are bookkeeping thresholds, not hit-rate claims.
CLEAN_Q=.78
DEGRADED_Q=.45

def _rear_threat_strength(at,weapons,rr,asp):
    """0..1-ish relative threat from flexible rear guns at current geometry."""
    if asp==2: return 0.0
    arc=1.0 if asp==0 else .48
    score=0.0
    for wid,count,apg in at.rear_armament:
        w=weapons[wid]
        score += count*(w.caliber_mm/12.7)**1.10
    # TBF .50+.30 is about the top of this three-aircraft set.
    norm=min(1.0,score/1.58)
    rfac=float(np.clip(math.exp(-(rr-250.0)/700.0),.25,1.15))
    return arc*norm*rfac

def _delivery_quality(at,states,mission,y,z,hd,last_ev,delcy,dt,setup_seconds=None):
    n=mission.shape[0];K=mission.shape[1];rpar=RESP[at.id]
    hddeg=np.abs(np.rad2deg(hd));yy=np.abs(y);zz=np.abs(z)
    since=np.maximum(0,(delcy[:,None]-last_ev)*dt)
    setup_s=float(SETUP_SECONDS[at.id] if setup_seconds is None else setup_seconds)
    # Setup recovery: partial credit is allowed, but full score requires the full clean-run interval.
    setup=np.clip(since/max(setup_s,1e-6),0,1)
    # Smooth geometry/set-up score, avoiding a binary threshold as the primary metric.
    track=np.exp(-.40*(hddeg/rpar['ready_hdg'])**2-.27*(yy/rpar['ready_y'])**2-.20*(zz/rpar['ready_z'])**2)
    # Component damage factor, aircraft-role specific. Values are state fractions 0..1.
    ww=DELIVERY_WEIGHTS[at.id]
    comp=np.ones((n,K),float)
    for k,st in enumerate(states):
        # Weighted geometric mean keeps one badly damaged critical system meaningful.
        vals={name:np.clip(st[name],.03,1.0) for name in ('controls','structure','engine','cooling')}
        logq=np.zeros(n,float)
        for name,w in ww.items():logq += w*np.log(vals[name])
        comp[:,k]=np.exp(logq)
    q=np.clip(track*setup*comp,0,1)
    q[mission]=0.0
    clean=(q>=CLEAN_Q)&(~mission)
    degraded=(q>=DEGRADED_Q)&(q<CLEAN_Q)&(~mission)
    lost_setup=(q<DEGRADED_Q)&(~mission)
    return q,clean,degraded,lost_setup,track,setup,comp

def simulate_strike_response(m,jp,at,weapons,effects,seed=1,rear_gunner_disruption=.08,rear_gunner_enabled=True,setup_seconds_override=None,recovery_tau_scale=1.0,evasion_impulse_scale=1.0):
    rng=np.random.default_rng(seed);n=len(m['trial_package_passes']);N=m['N'];K=int(m.get('package_aircraft_count',12));dt=2.5
    jpA=geom._expand_objects(jp,N); layerLabels=np.asarray(m.get('A_layer_labels',['A']*N),dtype=object)
    cy=np.asarray(m['trial_package_pass_cycle']);tg=np.asarray(m['trial_package_pass_target_index']);rr0=np.asarray(m['trial_package_pass_range_m']);hr0=np.asarray(m['trial_package_pass_horizontal_range_m']);bear0=np.asarray(m['trial_package_pass_bearing_rad']);cap_hdg=np.asarray(m['trial_package_pass_heading_rad']);cap_alt=np.asarray(m['trial_package_pass_alt_m']);cap_gamma=np.asarray(m['trial_package_pass_gamma_rad']);qstored=np.asarray(m['trial_package_pass_quality']);target_alt=np.asarray(m.get('trial_package_pass_target_alt_m',np.full_like(rr0,m.get('package_alt_m',2800),dtype=float)))
    states=[base._state(n) for _ in range(K)];caps=[base._state(n) for _ in range(N)];y=np.zeros((n,K));z=np.zeros((n,K));vy=np.zeros((n,K));vz=np.zeros((n,K));hd=np.zeros((n,K));ev=np.zeros((n,K),np.int16);last_ev=np.full((n,K),-999,np.int16);rpar=RESP[at.id]
    events=[]
    for tr in range(n):
      for fi in range(N):
       for kk in range(cy.shape[2]):
        if cy[tr,fi,kk]>=0:events.append((int(cy[tr,fi,kk]),tr,fi,kk))
    events.sort();ep=0;clean=np.zeros(n,int);spoiled=np.zeros(n,int);warned=np.zeros(n,int);rdtotal=np.zeros(n,int);hits=np.zeros(n,int);gb=np.zeros(n,int);gh=np.zeros(n,int);targeted=np.zeros((n,K),int);rear_disrupt_events=np.zeros(n,int);rear_disrupt_sum=np.zeros(n,float)
    clean_by_layer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())};rounds_by_layer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())};hits_by_layer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())}
    delcy=np.asarray(m.get('trial_package_delivery_cycle',np.full(n,int(math.ceil((m.get('package_start_x',4800)-m.get('package_target_x',-4500))/(m.get('package_speed_kmh',300)/3.6)/dt)))))
    last=max(int(np.max(delcy[delcy>=0],initial=0)),max([x[0] for x in events],default=-1)+3)
    for c in range(last+1):
      for st in states:
       ix=np.where(~st['mission'])[0]
       if len(ix):base.evolve_damage(st,at.defense,ix,rng)
      for fi,st in enumerate(caps):
       ix=np.where(~st['mission'])[0]
       if len(ix):base.evolve_damage(st,jpA[fi],ix,rng)
      for k,st in enumerate(states):
       alive=~st['mission'];dmg=base.damage_summary(st);active=(ev[:,k]>0)&alive;tau=np.maximum(7.0,rpar['tau']*float(recovery_tau_scale)*(1+.9*dmg));rec=np.exp(-dt/tau);vy[:,k]*=np.where(active,.92,rec);vz[:,k]*=np.where(active,.90,rec);hd[:,k]*=np.where(active,.94,rec);vy[:,k]+=np.where(alive,rng.normal(0,0.50+1.7*dmg,n)*dt,0);y[:,k]+=vy[:,k]*dt;z[:,k]+=vz[:,k]*dt;restore=(~active)&alive;vy[:,k]+=np.where(restore,-y[:,k]/np.maximum(18.0,tau*2.1)*dt,0);vz[:,k]+=np.where(restore,-z[:,k]/np.maximum(14.0,tau*1.8)*dt,0);ev[:,k]=np.maximum(0,ev[:,k]-1)
      while ep<len(events) and events[ep][0]==c:
       _,tr,fi,kk=events[ep];ep+=1;t=int(tg[tr,fi,kk]);
       if t<0 or t>=K:continue
       targeted[tr,t]+=1;hr=float(hr0[tr,fi,kk]);b=float(bear0[tr,fi,kk]);sh=float(cap_hdg[tr,fi,kk]);dx=hr*math.cos(b);dy=hr*math.sin(b)+float(y[tr,t]);hrn=max(1,math.hypot(dx,dy));bn=math.atan2(dy,dx);ta=float(target_alt[tr,fi,kk])+float(z[tr,t]);dz=ta-float(cap_alt[tr,fi,kk]);rr=math.hypot(hrn,dz);rel=float(wrap(bn-sh));vang=math.atan2(dz,hrn);verr=abs(float(wrap(vang-float(cap_gamma[tr,fi,kk]))));asp=_aspect(math.pi+float(hd[tr,t]),bn);normal=(asp!=2 and rr<520 and abs(rel)<math.radians(11.5));front=(asp==2 and rr<300 and abs(rel)<math.radians(6));valid=(normal or front) and verr<math.radians(13)
       oldr=max(1,float(rr0[tr,fi,kk]));oldalign=float(np.asarray(m['trial_package_pass_align'])[tr][fi][kk]);oldq=max(.02,min(1.5,(520-oldr)/320+.55*(oldalign-.96)/.04));sup=float(np.clip(float(qstored[tr,fi,kk])/oldq,.15,1.05));q=max(0,min(1.5,(520-rr)/320+.55*(math.cos(rel)-.96)/.04))*sup
       # Rear-gun threat can disturb the attacker's sight picture before bullets physically hit.
       if rear_gunner_enabled and valid and (not states[t]['mission'][tr]):
        th=_rear_threat_strength(at,weapons,rr,asp)
        if th>0:
         frac=float(np.clip(rear_gunner_disruption*th,0,.35));q*=1-frac;rear_disrupt_events[tr]+=1;rear_disrupt_sum[tr]+=frac
       pw=rpar['warn'][asp]
       if ev[tr,t]>0:pw=max(pw,.94)
       if targeted[tr].sum()>1:pw=min(.98,pw+.06)
       saw=rng.random()<pw
       if saw:
        warned[tr]+=1;side=-1 if rng.random()<.5 else 1;scale=float(rng.uniform(.78,1.22));vy[tr,t]+=side*rpar['lat_imp']*float(evasion_impulse_scale)*scale;vz[tr,t]+=rng.normal(0,rpar['vert_imp']*float(evasion_impulse_scale));hd[tr,t]+=math.radians(side*rpar['hdg_imp_deg']*float(evasion_impulse_scale)*scale);ev[tr,t]=max(ev[tr,t],int(rng.integers(3,6)));last_ev[tr,t]=c;q*=rpar['immediate']
       if (not valid) or q<=.08 or states[t]['mission'][tr]:spoiled[tr]+=1
       else:
        firep=float(np.clip(.52+.42*(q/1.25),.42,.95))
        if rng.random()<firep:
         rd,hh=_burst(jpA[fi],at.defense,weapons,effects,states[t],tr,q,rr,asp,rng,at.size_factor);clean[tr]+=1;rdtotal[tr]+=rd;hits[tr]+=hh;lab=str(layerLabels[fi]);clean_by_layer[lab][tr]+=1;rounds_by_layer[lab][tr]+=rd;hits_by_layer[lab][tr]+=hh
       rd,hh,fired=_rear(at,jpA[fi],weapons,effects,caps[fi],tr,rr,asp,rng)
       if fired:gb[tr]+=1
       gh[tr]+=hh
    mission=np.stack([st['mission'] for st in states],1);dam=np.stack([base.damage_summary(st) for st in states],1);alive=~mission;hddeg=np.abs(np.rad2deg(hd));yy=np.abs(y);zz=np.abs(z)
    qrel,release_clean,release_degraded,release_setup_lost,trackq,setupq,compq=_delivery_quality(at,states,mission,y,z,hd,last_ev,delcy,dt,setup_seconds_override)
    # Legacy setup-state buckets retained for continuity with v0.10.4.
    setup_s=float(SETUP_SECONDS[at.id] if setup_seconds_override is None else setup_seconds_override);since=np.maximum(0,(delcy[:,None]-last_ev)*dt);settled=since>=setup_s
    ready=alive&(hddeg<rpar['ready_hdg'])&(yy<rpar['ready_y'])&(zz<rpar['ready_z'])&settled&(dam<.48)
    degraded=alive&(~ready)&(hddeg<1.8*rpar['ready_hdg'])&(yy<1.8*rpar['ready_y'])&(zz<1.8*rpar['ready_z'])&(dam<.65)
    notready=alive&(~ready)&(~degraded)
    coh=[]
    for tr in range(n):
     aa=alive[tr]
     if aa.sum()<2:coh.append(0.0);continue
     ry=float(np.sqrt(np.mean(y[tr,aa]**2)));rz=float(np.sqrt(np.mean(z[tr,aa]**2)));rh=float(np.sqrt(np.mean(hddeg[tr,aa]**2)));coh.append(float(np.exp(-.45*ry/220-.35*rz/100-.40*rh/9)))
    return {'model':'strike-response-v0.10.5','target_type':at.id,'ntr':n,'package_count':K,'terminal_profile':m.get('package_terminal_profile','level'),'mean_physical_passes':float(np.mean(m['trial_package_passes'])),'mean_clean_bursts':float(clean.mean()),'mean_spoiled_passes_by_evasion':float(spoiled.mean()),'mean_warning_reactions':float(warned.mean()),'mean_attackers_mission_lost':float(mission.sum(1).mean()),'mean_delivery_ready':float(ready.sum(1).mean()),'mean_delivery_degraded':float(degraded.sum(1).mean()),'mean_alive_not_ready':float(notready.sum(1).mean()),'mean_damaged_delivery_ready':float((ready&(dam>.08)).sum(1).mean()),'mean_formation_cohesion':float(np.mean(coh)),'mean_rms_lateral_m':float(np.mean(np.sqrt(np.mean(y*y,axis=1)))),'mean_rms_vertical_m':float(np.mean(np.sqrt(np.mean(z*z,axis=1)))),'mean_rms_heading_deg':float(np.mean(np.sqrt(np.mean(hddeg*hddeg,axis=1)))),'mean_japanese_rounds':float(rdtotal.mean()),'mean_japanese_hits':float(hits.mean()),'mean_gunner_bursts':float(gb.mean()),'mean_gunner_hits':float(gh.mean()),'mean_CAP_mission_losses_from_gunners':float(np.stack([st['mission'] for st in caps],1).sum(1).mean()),'setup_clean_seconds':setup_s,
      'mean_release_clean':float(release_clean.sum(1).mean()),'mean_release_degraded':float(release_degraded.sum(1).mean()),'mean_release_setup_lost':float(release_setup_lost.sum(1).mean()),'mean_delivery_quality_equivalent':float(qrel.sum(1).mean()),'mean_release_quality_per_survivor':float(qrel.sum()/max(1,alive.sum())),'mean_track_quality':float(trackq[alive].mean() if alive.any() else 0),'mean_setup_quality':float(setupq[alive].mean() if alive.any() else 0),'mean_component_quality':float(compq[alive].mean() if alive.any() else 0),
      'setup_seconds_override':None if setup_seconds_override is None else float(setup_seconds_override),'recovery_tau_scale':float(recovery_tau_scale),'evasion_impulse_scale':float(evasion_impulse_scale),'rear_gunner_enabled':bool(rear_gunner_enabled),'rear_gunner_disruption':float(rear_gunner_disruption),'mean_rear_disruption_events':float(rear_disrupt_events.mean()),'mean_rear_disruption_fraction_sum':float(rear_disrupt_sum.mean()),'mean_clean_bursts_by_layer':{k:float(v.mean()) for k,v in clean_by_layer.items()},'mean_rounds_by_layer':{k:float(v.mean()) for k,v in rounds_by_layer.items()},'mean_hits_by_layer':{k:float(v.mean()) for k,v in hits_by_layer.items()},'CAP_mission_losses_from_gunners_by_layer':{str(l):float(np.stack([caps[i]['mission'] for i in np.where(layerLabels==l)[0]],1).sum(1).mean()) for l in dict.fromkeys(layerLabels.tolist())},'delivery_quality_note':'0-1 setup quality only; NOT bomb/torpedo hit probability'}
