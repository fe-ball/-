#!/usr/bin/env python3
import csv, os, sys
sys.path.insert(0,os.path.dirname(__file__))
from carrier_damage_v117 import simulate_conditional,PROFILES

scens=[(1,0),(2,0),(3,0),(0,1),(0,2),(0,3),(1,1),(2,1),(1,2)]
rows=[]
for pi,pid in enumerate(PROFILES):
  for si,(b,t) in enumerate(scens):
    rr,_=simulate_conditional(pid,b,t,n=50000,seed=117100+pi*100+si)
    rows.extend(rr)
with open(os.path.join(os.path.dirname(__file__),'..','results_current','carrier_damage_conditional_curves_v117.csv'),'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
# DC sensitivity, representative mixed hit and one torpedo anchor
rows2=[]
for pid in PROFILES:
  for dc in (.82,1.0,1.18):
    for b,t in [(0,1),(1,1),(2,1)]:
      rr,_=simulate_conditional(pid,b,t,n=40000,seed=117500+int(dc*100)+(b*10+t),dc_scale=dc)
      rows2.extend(rr)
with open(os.path.join(os.path.dirname(__file__),'..','results_current','carrier_damage_dc_sensitivity_v117.csv'),'w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=rows2[0].keys());w.writeheader();w.writerows(rows2)
print('rows',len(rows),'dcrows',len(rows2))
