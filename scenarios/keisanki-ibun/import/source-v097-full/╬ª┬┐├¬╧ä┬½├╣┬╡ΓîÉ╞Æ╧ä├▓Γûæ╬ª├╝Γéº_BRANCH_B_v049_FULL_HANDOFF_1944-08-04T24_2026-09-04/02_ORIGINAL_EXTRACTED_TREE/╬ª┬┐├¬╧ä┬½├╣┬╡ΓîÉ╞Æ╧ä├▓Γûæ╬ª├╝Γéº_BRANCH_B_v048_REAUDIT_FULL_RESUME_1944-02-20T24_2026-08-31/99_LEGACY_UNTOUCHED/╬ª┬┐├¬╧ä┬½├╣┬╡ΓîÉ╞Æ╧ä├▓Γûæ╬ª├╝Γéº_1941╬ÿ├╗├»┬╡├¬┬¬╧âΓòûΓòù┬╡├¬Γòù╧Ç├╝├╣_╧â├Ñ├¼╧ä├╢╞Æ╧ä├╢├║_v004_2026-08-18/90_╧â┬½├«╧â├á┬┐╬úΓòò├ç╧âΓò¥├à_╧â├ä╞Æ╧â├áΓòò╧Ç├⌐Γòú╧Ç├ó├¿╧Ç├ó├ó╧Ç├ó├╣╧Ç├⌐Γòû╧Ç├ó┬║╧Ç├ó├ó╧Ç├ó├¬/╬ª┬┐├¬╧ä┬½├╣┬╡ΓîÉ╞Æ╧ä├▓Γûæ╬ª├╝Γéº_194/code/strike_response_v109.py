#!/usr/bin/env python3
from __future__ import annotations
import numpy as np
import air_microcombat_v109 as geom
from strike_damage_v102 import _rear
from strike_response_v103 import RESP
from strike_response_v106 import DELIVERY_WEIGHTS,SETUP_SECONDS,CLEAN_Q,DEGRADED_Q
base=geom.base

def _delivery_quality_dynamic(at,states,mission,x,y,z,hd,last_ev,delcy,dt,setup_seconds=None):
    n,K=mission.shape;rpar=RESP[at.id]
    hddeg=np.abs(np.rad2deg(hd));xx=np.abs(x);yy=np.abs(y);zz=np.abs(z)
    since=np.maximum(0,(delcy[:,None]-last_ev)*dt)
    setup_s=float(SETUP_SECONDS[at.id] if setup_seconds is None else setup_seconds)
    setup=np.clip(since/max(setup_s,1e-6),0,1)
    track=np.exp(-.10*(xx/420.0)**2-.40*(hddeg/rpar['ready_hdg'])**2-.27*(yy/rpar['ready_y'])**2-.20*(zz/rpar['ready_z'])**2)
    ww=DELIVERY_WEIGHTS[at.id];comp=np.ones((n,K),float)
    for k,st in enumerate(states):
        vals={name:np.clip(st[name],.03,1.0) for name in ('controls','structure','engine','cooling')}
        logq=np.zeros(n,float)
        for name,w in ww.items():logq+=w*np.log(vals[name])
        comp[:,k]=np.exp(logq)
    q=np.clip(track*setup*comp,0,1);q[mission]=0.0
    clean=(q>=CLEAN_Q)&(~mission);degraded=(q>=DEGRADED_Q)&(q<CLEAN_Q)&(~mission);lost=(q<DEGRADED_Q)&(~mission)
    return q,clean,degraded,lost,track,setup,comp

def _states_from_online(m,n,K):
    states=[]
    mission=np.asarray(m['trial_package_online_mission'],bool)
    immediate=np.asarray(m['trial_package_online_immediate'],bool)
    fire=np.asarray(m.get('trial_package_online_fire',np.zeros((n,K))),float)
    for k in range(K):
        st=base._state(n)
        for fld in ('pilot','engine','cooling','fuel','controls','structure'):
            st[fld]=np.asarray(m[f'trial_package_online_{fld}'],float)[:,k]
        st['fire']=fire[:,k];st['mission']=mission[:,k];st['immediate']=immediate[:,k]
        st['ever_hit']=(st['pilot']<1)|(st['engine']<1)|(st['cooling']<1)|(st['fuel']<1)|(st['controls']<1)|(st['structure']<1)|(st['fire']>0)
        states.append(st)
    return states,mission

def simulate_strike_response(m,jp,at,weapons,effects,seed=1,rear_gunner_disruption=.08,rear_gunner_enabled=True,setup_seconds_override=None):
    """v0.10.9 response for fully online strike/CAP damage exchange.

    Japanese CAP fire is not replayed because strike damage and CAP ammunition expenditure already occurred
    in the main loop.  When package rear guns are enabled there, their CAP damage is also read from the
    geometry result rather than fired a second time here.
    """
    if not m.get('package_online_damage',False):
        from strike_response_v107 import simulate_strike_response as legacy
        return legacy(m,jp,at,weapons,effects,seed,rear_gunner_disruption,rear_gunner_enabled,setup_seconds_override)
    rng=np.random.default_rng(seed);n=len(m['trial_package_passes']);N=m['N'];K=int(m.get('package_aircraft_count',12));dt=2.5
    jpA=geom._expand_objects(jp,N);layerLabels=np.asarray(m.get('A_layer_labels',['A']*N),dtype=object)
    cy=np.asarray(m['trial_package_pass_cycle']);tg=np.asarray(m['trial_package_pass_target_index']);rr=np.asarray(m['trial_package_pass_range_m']);asp=np.asarray(m['trial_package_pass_aspect'])
    states,mission=_states_from_online(m,n,K);dam=np.stack([base.damage_summary(st) for st in states],1);alive=~mission
    targeted=np.zeros((n,K),int)
    for tr in range(n):
        for fi in range(N):
            for kk in range(cy.shape[2]):
                if cy[tr,fi,kk]>=0:
                    t=int(tg[tr,fi,kk])
                    if 0<=t<K:targeted[tr,t]+=1
    # v0.10.9: rear-gunner damage can already be online in main geometry.  Do not replay it a second time.
    rear_online=bool(m.get('package_rear_gunner_enabled',False))
    if rear_online:
        gb=np.asarray(m.get('trial_package_rear_gunner_bursts',np.zeros(n)),float)
        gh=np.asarray(m.get('trial_package_rear_gunner_hits',np.zeros(n)),float)
        capmission=np.asarray(m.get('trial_package_rear_gunner_mission',np.zeros((n,N),bool)),bool)
    else:
        # Backward-compatible diagnostic for v0.10.8/legacy geometry.
        caps=[base._state(n) for _ in range(N)];gb=np.zeros(n,int);gh=np.zeros(n,int)
        if rear_gunner_enabled:
            events=[]
            for tr in range(n):
                for fi in range(N):
                    for kk in range(cy.shape[2]):
                        if cy[tr,fi,kk]>=0:events.append((int(cy[tr,fi,kk]),tr,fi,kk))
            events.sort();ep=0;last=max([x[0] for x in events],default=-1)+3
            for c in range(max(0,last+1)):
                for fi,st in enumerate(caps):
                    ix=np.where(~st['mission'])[0]
                    if len(ix):base.evolve_damage(st,jpA[fi],ix,rng)
                while ep<len(events) and events[ep][0]==c:
                    _,tr,fi,kk=events[ep];ep+=1
                    if caps[fi]['mission'][tr]:continue
                    rd,hh,fired=_rear(at,jpA[fi],weapons,effects,caps[fi],tr,float(rr[tr,fi,kk]),int(asp[tr,fi,kk]),rng)
                    if fired:gb[tr]+=1
                    gh[tr]+=hh
        capmission=np.stack([st['mission'] for st in caps],1)
    x=np.asarray(m.get('trial_package_delivery_dx_m',np.zeros((n,K))),float);y=np.asarray(m.get('trial_package_delivery_dy_m',np.zeros((n,K))),float);z=np.asarray(m.get('trial_package_delivery_dz_m',np.zeros((n,K))),float);hd=np.asarray(m.get('trial_package_delivery_dheading_rad',np.zeros((n,K))),float);last_ev=np.asarray(m.get('trial_package_last_evasion_cycle',np.full((n,K),-999)),int);delcy=np.asarray(m.get('trial_package_delivery_cycle',np.zeros(n,int)))
    qrel,rel_clean,rel_deg,rel_lost,trackq,setupq,compq=_delivery_quality_dynamic(at,states,mission,x,y,z,hd,last_ev,delcy,dt,setup_seconds_override)
    rmsx=np.sqrt(np.mean(x*x,axis=1));rmsy=np.sqrt(np.mean(y*y,axis=1));rmsz=np.sqrt(np.mean(z*z,axis=1));rmsh=np.sqrt(np.mean(np.rad2deg(hd)**2,axis=1));coh=np.exp(-.16*rmsx/420-.42*rmsy/220-.30*rmsz/100-.36*rmsh/9)
    clean=np.asarray(m.get('trial_package_online_clean_bursts',np.zeros(n)),float);rounds=np.asarray(m.get('trial_package_online_rounds',np.zeros(n)),float);hits=np.asarray(m.get('trial_package_online_hits',np.zeros(n)),float);aborted=np.asarray(m.get('trial_package_online_aborted',np.zeros(n)),float);wasted=np.asarray(m.get('trial_package_online_wasted',np.zeros(n)),float)
    return {
      'model':'strike-response-v0.10.9-online-rear-feedback','target_type':at.id,'ntr':n,'package_count':K,'terminal_profile':m.get('package_terminal_profile','level'),
      'mean_physical_passes':float(np.mean(m['trial_package_passes'])),'mean_clean_bursts':float(clean.mean()),'mean_aborted_passes_on_newly_lost_target':float(aborted.mean()),'mean_wasted_passes_on_already_lost_target':float(wasted.mean()),
      'mean_distinct_attackers_targeted':float((targeted>0).sum(1).mean()),'mean_max_passes_on_one_attacker':float(targeted.max(1).mean()),
      'mean_attackers_mission_lost':float(mission.sum(1).mean()),'mean_attackers_damaged_survivors':float(((dam>.08)&alive).sum(1).mean()),
      'mean_release_clean':float(rel_clean.sum(1).mean()),'mean_release_degraded':float(rel_deg.sum(1).mean()),'mean_release_setup_lost':float(rel_lost.sum(1).mean()),'mean_delivery_quality_equivalent':float(qrel.sum(1).mean()),'mean_release_quality_per_survivor':float(qrel.sum()/max(1,alive.sum())),
      'mean_track_quality':float(trackq[alive].mean() if alive.any() else 0.0),'mean_setup_quality':float(setupq[alive].mean() if alive.any() else 0.0),'mean_component_quality':float(compq[alive].mean() if alive.any() else 0.0),
      'mean_dynamic_formation_cohesion':float(coh.mean()),'mean_rms_longitudinal_m':float(rmsx.mean()),'mean_rms_lateral_m':float(rmsy.mean()),'mean_rms_vertical_m':float(rmsz.mean()),'mean_rms_heading_deg':float(rmsh.mean()),
      'mean_japanese_rounds':float(rounds.mean()),'mean_japanese_hits':float(hits.mean()),'mean_gunner_bursts':float(np.mean(gb)),'mean_gunner_hits':float(np.mean(gh)),'mean_CAP_mission_losses_from_gunners':float(capmission.sum(1).mean()),'rear_gunner_online_feedback':bool(rear_online and m.get('package_rear_gunner_feedback',False)),'mean_CAP_immediate_geometry_removals_from_gunners':float(m.get('package_rear_gunner_immediate_geometry_removals',0.0)) if rear_online else 0.0,
      'delivery_quality_note':'0-1 setup quality only; NOT bomb/torpedo hit probability','damage_feedback_note':'strike mission-loss, CAP ammunition expenditure, and (when enabled) rear-gunner CAP mission-loss are fed back into main geometry.'
    }
