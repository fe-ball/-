# CHANGELOG v0.11.6 -> v0.11.7

Added:
- heterogeneous carrier damage profiles: Unryu / Shokaku / Taiho working lines
- component damage ledger for bomb and torpedo direct hits
- fire/flooding/DC progression at 0/2/6/24h
- launch/recovery/speed/steering/AA mission outputs
- conditional hit-count damage curves
- weak/center/strong DC sensitivity
- automated monotonicity/canon-anchor invariants
- F6F trial hit-count -> carrier mission-state diagnostic bridge

Fixed during development:
- torpedo shock initially counted as physical flight-deck closure; changed to temporary launch/recovery restriction
- DC recovery exponent sign initially made stronger DC recover more slowly; corrected before fixation
