from pathlib import Path
import sys,pickle,argparse
R=Path(__file__).parent;sys.path.insert(0,str(R))
from run_anvil_torpedo_v116 import run_air
ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=4);ap.add_argument('--us',default='US02');a=ap.parse_args()
m=run_air(a.us,a.ntr)
p=R.parent/'results_current'/f'anvil_aircache_{a.us}_n{a.ntr}_v116.pkl'
p.write_bytes(pickle.dumps(m,protocol=pickle.HIGHEST_PROTOCOL));print(p)
