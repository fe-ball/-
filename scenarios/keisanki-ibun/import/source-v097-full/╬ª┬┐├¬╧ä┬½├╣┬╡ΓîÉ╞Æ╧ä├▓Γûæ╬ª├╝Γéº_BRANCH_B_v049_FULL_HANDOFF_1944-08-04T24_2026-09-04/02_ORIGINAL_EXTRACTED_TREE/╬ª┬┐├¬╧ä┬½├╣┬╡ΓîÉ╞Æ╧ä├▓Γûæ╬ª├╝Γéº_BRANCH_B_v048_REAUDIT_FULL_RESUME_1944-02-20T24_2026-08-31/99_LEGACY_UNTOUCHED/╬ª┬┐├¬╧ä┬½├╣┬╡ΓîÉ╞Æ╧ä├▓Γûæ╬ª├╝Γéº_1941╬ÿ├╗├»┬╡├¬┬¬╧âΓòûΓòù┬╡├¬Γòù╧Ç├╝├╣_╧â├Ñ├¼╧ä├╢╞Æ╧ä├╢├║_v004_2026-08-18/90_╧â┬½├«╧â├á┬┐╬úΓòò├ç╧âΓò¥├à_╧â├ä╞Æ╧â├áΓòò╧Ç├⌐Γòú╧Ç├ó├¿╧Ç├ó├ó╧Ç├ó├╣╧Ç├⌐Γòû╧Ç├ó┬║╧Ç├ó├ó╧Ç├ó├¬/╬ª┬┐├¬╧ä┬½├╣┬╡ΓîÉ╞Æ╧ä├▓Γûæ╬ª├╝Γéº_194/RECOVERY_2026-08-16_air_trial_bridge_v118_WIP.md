# RECOVERY — v0.11.8 WIP Air-Trial Bridge

## Status

**WIP only. v0.11.7 remains the fixed carrier mission-damage layer.**

This session executed the next item from the sortie-regeneration recovery note: transfer individual upstream air-combat outcomes into `AirGroupState` rather than using only the generic 72-aircraft post-return diagnostic state.

## Regression before bridge work

Passing after all changes:
- `check_carrier_continuous_v118.py` — tested v0.11.7 0/2/6/24 h latent-state equivalence;
- `check_sortie_regeneration_v118.py` — undamaged/damage/sensitivity invariants unchanged;
- legacy `air_microcombat_v116` output comparison on identical seed — all pre-existing fields bitwise/numerically unchanged; only new terminal trial fields were added;
- `check_air_trial_bridge_v118.py` — clean/damaged/lost aircraft classification and damaged-return recovery path.

The unchanged sortie smoke center remains:
- undamaged Shokaku p50 +30/+60/+120 = 0 / 17 / 50;
- Taiho 1T immediate +120 p50 = 8;
- Taiho 1T +6 h +120 p50 = 50.

## New upstream export

`air_microcombat_v116.py`, when `return_trials=True` and `package_online_damage=True`, now exports terminal per-aircraft arrays:

- `trial_package_terminal_mission`
- `trial_package_terminal_immediate`
- `trial_package_terminal_fire`
- `trial_package_terminal_pilot`
- `trial_package_terminal_engine`
- `trial_package_terminal_cooling`
- `trial_package_terminal_fuel`
- `trial_package_terminal_controls`
- `trial_package_terminal_structure`

These are observational exports only. A same-seed comparison against the pre-bridge v0.11.8-WIP showed no differences in any legacy air-combat output field.

## New bridge layer

New code:
- `code/air_trial_bridge_v118.py`
- `code/check_air_trial_bridge_v118.py`
- `code/run_air_trial_bridge_smoke_v118.py`

The bridge classifies each upstream package member as:

1. lost/unreturnable;
2. returning clean;
3. returning damaged.

Current damaged-return classification is a **B-prior structural threshold**: component damage score > 0.08 or fire > 0.05, unless already mission-lost/unreturnable. It is not yet a historically calibrated ditch/repairability model.

## Important structural correction — damaged aircraft still airborne

The old `AirGroupState` had:
- `returning` — all airborne returners;
- `damaged` — damaged aircraft already aboard/available for repair.

That could not represent an aircraft that is damaged **and still returning**. Such an aircraft would be recovered and then incorrectly enter routine turnaround.

v0.11.8-WIP now adds:
- `returning_damaged`.

Both static and dynamic recovery queues preserve the damage flag. A damaged returner enters the long repair queue only after recovery.

### Isolation test

With four TB returners as the only useful attack inventory and an undamaged Shokaku ops profile:

- routine returners: +60 p50 = 2, +120 p50 = 4;
- damaged returners: +60 p50 = 0, +120 p50 = 1.

So the new path is functionally active.

In the generic 72-aircraft shell, the same correction often does **not** change total next-wave size because deck throughput and other aircraft inventory bind first. This is a useful bottleneck result, not a failure of the damage flag.

## Crew identity / qualification / fatigue transfer

`AirGroupState` now also has optional `crew_manifest` metadata. The bridge preserves per-package-member:

- stable synthetic crew ID;
- aircraft member index;
- status (lost/unreturnable, returning clean, returning damaged);
- qualification labels;
- fatigue factor;
- pilot component state;
- aircraft damage score;
- return ETA.

**Important:** this data is preserved but not yet the authoritative pilot gate. Current sortie generation still uses the existing aggregate `pilots` and `pilot_fatigue_factor` fields. The next personnel step is to make pilot/crew availability time-dependent and manifest-driven.

## 64-trial structural bridge smoke

To test end-to-end plumbing, four 16-trial batches of the existing **US TBF-1C sync60** upstream package were injected into the Shokaku carrier-ops diagnostic shell.

This is deliberately **not a historical matchup**: the upstream package is US while the carrier-ops shell is Japanese. Use the run only to validate transfer semantics and queue behavior.

Aggregate over 64 upstream trials:

- package size: 12;
- mean lost/unreturnable: 0.171875;
- mean returning clean: 11.21875;
- mean returning damaged: 0.609375.

Next-wave output in that structural shell:

- +60 min p10 / p50 / p90 = 9 / 9 / 11;
- +120 min p10 / p50 / p90 = 51 / 53 / 54.

The bridge carries trial-to-trial aircraft state differences through to sortie generation. The absolute wave figures are not historical evidence.

Files:
- `results_current/air_trial_bridge_smoke_64_v118.json`
- `results_current/air_trial_bridge_smoke_64_v118.csv`

## Next correct work

1. Make `crew_manifest` authoritative for pilot/crew gating with recovery-time availability and qualification checks.
2. Add Japanese carrier-strike package definitions (B6N/D4Y/current r30 types) so the bridge can be exercised with semantically correct Japanese returning groups rather than US structural smoke.
3. Split the lumped service queue into deck/elevator handling, fuel, ordnance and maintenance resources.
4. Carry carrier fire/fuel-vapor/ordnance safety restrictions into those servicing resources.
5. Only after those steps rerun historical FORAGER clocks.
