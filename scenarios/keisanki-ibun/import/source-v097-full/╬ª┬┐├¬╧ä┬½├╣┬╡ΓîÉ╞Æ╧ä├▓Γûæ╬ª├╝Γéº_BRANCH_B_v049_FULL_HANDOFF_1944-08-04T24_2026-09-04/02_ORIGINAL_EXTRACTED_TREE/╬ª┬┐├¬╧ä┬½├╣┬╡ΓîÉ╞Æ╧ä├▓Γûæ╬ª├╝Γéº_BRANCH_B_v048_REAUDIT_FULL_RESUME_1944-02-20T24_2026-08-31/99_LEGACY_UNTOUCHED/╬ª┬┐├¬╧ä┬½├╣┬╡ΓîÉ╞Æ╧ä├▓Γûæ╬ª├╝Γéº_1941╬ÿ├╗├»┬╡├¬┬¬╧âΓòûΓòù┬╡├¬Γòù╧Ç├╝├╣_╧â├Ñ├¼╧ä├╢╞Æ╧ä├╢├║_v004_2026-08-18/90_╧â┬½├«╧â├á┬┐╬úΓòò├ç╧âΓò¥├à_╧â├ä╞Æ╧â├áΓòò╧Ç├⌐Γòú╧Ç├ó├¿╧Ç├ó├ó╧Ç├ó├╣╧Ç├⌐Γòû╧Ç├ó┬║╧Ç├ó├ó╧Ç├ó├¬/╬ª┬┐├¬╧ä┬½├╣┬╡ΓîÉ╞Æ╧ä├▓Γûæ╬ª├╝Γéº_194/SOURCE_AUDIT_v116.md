# SOURCE AUDIT v0.11.6

## Carried forward from v0.11.5

### r30 canon
- `10_水上艦_駆逐艦・戦艦改装・大和型.md`: 夕雲型 = standard carrier escort role; 秋月型 = fleet air-defense role; new 10cm AA/director/electrical chain is a distinct bottleneck.
- `30_センサー射撃指揮_I-O連鎖.md`: AA modeled through finite detection/assignment/tracking/channel/fuze chain, not gun-count multiplier.
- `44_戦術研鑽_1942-44_空母指揮・艦隊回避・教範化.md`: carrier radical turn, close/outer screen response and AA/CAP sector conflict treated as doctrine/geometry problems.

### Public / primary anchors carried forward
- US Naval Technical Mission to Japan O-44: Japanese AA boundary/architecture evidence; not inverted into per-round kill coefficients.
- NHHC H-072-1, VT-8 at Midway: one combat example of release at about 800 yards from Akagi; only order-of-magnitude support for a 750 m working gate, not a 1944 universal doctrine value.
- NHHC H-008-3: historical context for 1944 Mk13 drag/shroud-ring improvements.
- Caltech / NDRC, Joseph Levy, 18 Aug 1944, `Underwater Performance Characteristics of the MK 13-2A Torpedo with Suspension Fittings`: wartime hydrodynamic test evidence; not an operational pilot aim-error distribution.

## v0.11.6 additions

No new historical numerical measurement is introduced for anvil separation, terminal tracking turn rate, pursuit extension or route phasing.

These are explicit B-priors / geometry controls:
- TBF terminal tracking start 4500 m
- route-heading correction 2 deg/s
- pursuit extension 3500 m
- 6+6 axis separations 30/60/90°
- route phasing lead 550–700 m in the F6F final diagnostic
- `continue_turn` as standard post-release response

They exist to remove structural artifacts and expose sensitivity. They must not be rewritten as historical doctrine measurements.

## Interpretation rule

v0.11.6 can support claims about:
- need to measure release to the actual moving target,
- need for terminal tracking,
- need to include simultaneity in anvil attacks,
- inability of one carrier turn to optimize two simultaneous axes.

It does not source-anchor an exact optimum attack angle or historical torpedo hit probability.
