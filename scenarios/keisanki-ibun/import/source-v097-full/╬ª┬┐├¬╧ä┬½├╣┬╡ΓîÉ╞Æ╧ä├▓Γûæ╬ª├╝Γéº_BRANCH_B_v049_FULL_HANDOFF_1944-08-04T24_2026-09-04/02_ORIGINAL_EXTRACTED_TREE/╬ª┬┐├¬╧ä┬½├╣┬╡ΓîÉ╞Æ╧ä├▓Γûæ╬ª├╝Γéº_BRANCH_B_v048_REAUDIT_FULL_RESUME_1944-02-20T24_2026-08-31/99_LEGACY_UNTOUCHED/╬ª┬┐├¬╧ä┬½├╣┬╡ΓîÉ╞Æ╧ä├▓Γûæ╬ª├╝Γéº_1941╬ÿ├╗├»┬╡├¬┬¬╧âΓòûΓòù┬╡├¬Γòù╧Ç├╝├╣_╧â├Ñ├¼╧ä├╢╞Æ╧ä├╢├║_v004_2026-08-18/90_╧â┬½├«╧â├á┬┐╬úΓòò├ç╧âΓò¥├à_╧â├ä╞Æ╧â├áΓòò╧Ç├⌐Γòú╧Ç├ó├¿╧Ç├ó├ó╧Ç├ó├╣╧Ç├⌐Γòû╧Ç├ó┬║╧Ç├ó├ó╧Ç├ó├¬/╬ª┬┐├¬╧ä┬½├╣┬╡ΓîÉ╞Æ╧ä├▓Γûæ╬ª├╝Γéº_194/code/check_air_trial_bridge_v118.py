#!/usr/bin/env python3
from pathlib import Path
import sys, numpy as np
R=Path(__file__).parent;sys.path.insert(0,str(R))
from air_trial_bridge_v118 import trial_shell_airgroup,inject_package_trial,BridgePolicy
from sortie_regeneration_v118 import simulate_sortie_regeneration_dynamic

# Synthetic 1-trial x 4-aircraft package: clean, damaged, lost, clean.
r={
 'trial_package_terminal_mission':[[False,False,True,False]],
 'trial_package_terminal_pilot':[[1,1,0,1]],
 'trial_package_terminal_fire':[[0,.1,0,0]],
 'trial_package_terminal_engine':[[1,.75,0,1]],
 'trial_package_terminal_cooling':[[1,1,1,1]],
 'trial_package_terminal_fuel':[[1,1,1,1]],
 'trial_package_terminal_controls':[[1,1,1,1]],
 'trial_package_terminal_structure':[[1,1,1,1]],
}
st=trial_shell_airgroup('TB')
st,a=inject_package_trial(st,r,0,'TB',BridgePolicy(eta_start_min=10,eta_spacing_min=2))
assert a['lost']==1 and a['returning_clean']==2 and a['returning_damaged']==1, a
assert st.returning['TB']==[10.0,14.0],st.returning['TB']
assert st.returning_damaged['TB']==[12.0],st.returning_damaged['TB']
assert len(st.crew_manifest['TB'])==4
# Smoke: dynamic model accepts damaged returners and remains nonnegative.
t=np.arange(0,120.5,.5); c=np.ones((1,len(t)))
rows=simulate_sortie_regeneration_dynamic('SHOKAKU_R30_WORK',t,c,c,state=st,n=32,seed=818,horizon_min=120)
assert min(x['next_wave_total'] for x in rows)>=0
print('PASS',a,'wave_p50',float(np.median([x['next_wave_total'] for x in rows])))
