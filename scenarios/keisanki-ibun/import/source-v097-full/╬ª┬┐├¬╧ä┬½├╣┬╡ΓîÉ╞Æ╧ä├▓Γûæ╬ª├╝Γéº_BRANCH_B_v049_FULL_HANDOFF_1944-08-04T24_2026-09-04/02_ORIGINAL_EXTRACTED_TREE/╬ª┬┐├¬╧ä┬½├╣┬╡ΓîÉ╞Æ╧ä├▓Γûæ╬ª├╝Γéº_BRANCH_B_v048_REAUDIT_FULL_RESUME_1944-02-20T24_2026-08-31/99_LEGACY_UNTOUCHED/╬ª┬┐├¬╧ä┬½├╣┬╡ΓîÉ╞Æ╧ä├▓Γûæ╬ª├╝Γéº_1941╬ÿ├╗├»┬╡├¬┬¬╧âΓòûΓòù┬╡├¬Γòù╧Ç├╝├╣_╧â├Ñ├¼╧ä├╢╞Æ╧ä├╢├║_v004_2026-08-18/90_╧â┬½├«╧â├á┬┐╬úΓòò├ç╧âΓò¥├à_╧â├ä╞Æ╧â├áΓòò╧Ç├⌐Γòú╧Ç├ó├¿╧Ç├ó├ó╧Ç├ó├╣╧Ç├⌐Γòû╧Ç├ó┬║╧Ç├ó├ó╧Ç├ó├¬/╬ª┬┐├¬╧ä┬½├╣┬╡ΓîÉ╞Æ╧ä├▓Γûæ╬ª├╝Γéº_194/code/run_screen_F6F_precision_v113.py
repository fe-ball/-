#!/usr/bin/env python3
from pathlib import Path
import sys,csv,concurrent.futures as cf
R=Path(__file__).parent;sys.path.insert(0,str(R))
from run_screen_aa_v113 import worker
SC=['none','sparse','center','dense']
def main():
 import argparse;ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=25);a=ap.parse_args()
 jobs=[('TBF1C','US02',s,a.ntr) for s in SC]
 with cf.ProcessPoolExecutor(max_workers=4) as ex:rows=list(ex.map(worker,jobs))
 out=R.parent/'results_current'/'screen_aa_TBF1C_F6F_precision_v113.csv'
 with open(out,'w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 for r in rows:print(r)
if __name__=='__main__':main()
