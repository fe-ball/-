#!/usr/bin/env python3
"""Structural smoke: upstream individual aircraft states -> AirGroupState -> sortie regeneration.

The current upstream strike package is US TBF-1C, while carrier-ops profiles are Japanese.
Therefore this runner validates data plumbing and loss/damage propagation only; its wave sizes
are not a historical US-vs-Japanese carrier result.
"""
from pathlib import Path
import sys,json,argparse
import numpy as np
R=Path(__file__).parent;sys.path.insert(0,str(R))
import run_damage_pipeline_F6F_v117 as dp
from air_trial_bridge_v118 import trial_shell_airgroup,inject_package_trial
from sortie_regeneration_v118 import simulate_sortie_regeneration_dynamic

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=16);ap.add_argument('--seed',type=int,default=11864);ap.add_argument('--out',type=str,default='')
    a=ap.parse_args()
    m,_=dp.tbf_air(60,700,ntr=a.ntr,seed=a.seed)
    t=np.arange(0,120.5,.5);one=np.ones((1,len(t)))
    rows=[]
    for i in range(a.ntr):
        st=trial_shell_airgroup('TB');st,audit=inject_package_trial(st,m,i,'TB',crew_prefix='TBF-smoke')
        rec={'seed':a.seed,'trial_index':i,**audit}
        for H in (60,120):
            q=simulate_sortie_regeneration_dynamic('SHOKAKU_R30_WORK',t[t<=H],one[:,:np.count_nonzero(t<=H)],one[:,:np.count_nonzero(t<=H)],state=st,n=1,seed=a.seed+7000+i+H,horizon_min=H)[0]
            rec[f'wave_{H}']=int(q['next_wave_total']);rec[f'ready_TB_{H}']=int(q['ready_TB'])
        rows.append(rec)
    summary={
      'structural_only':True,'upstream_package':'US TBF-1C sync60','ops_shell':'SHOKAKU_R30_WORK','n':len(rows),
      'mean_lost':float(np.mean([x['lost'] for x in rows])),
      'mean_returning_damaged':float(np.mean([x['returning_damaged'] for x in rows])),
    }
    for H in (60,120):
        v=np.asarray([x[f'wave_{H}'] for x in rows],float)
        summary[f'wave_{H}_p10_p50_p90']=[float(x) for x in np.quantile(v,[.1,.5,.9])]
        summary[f'p_wave_{H}_ge_48']=float((v>=48).mean())
    obj={'summary':summary,'rows':rows}
    out=Path(a.out) if a.out else R.parent/'results_current'/f'air_trial_bridge_smoke_v118_seed{a.seed}.json'
    out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(obj,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2));print(out)
if __name__=='__main__':main()
