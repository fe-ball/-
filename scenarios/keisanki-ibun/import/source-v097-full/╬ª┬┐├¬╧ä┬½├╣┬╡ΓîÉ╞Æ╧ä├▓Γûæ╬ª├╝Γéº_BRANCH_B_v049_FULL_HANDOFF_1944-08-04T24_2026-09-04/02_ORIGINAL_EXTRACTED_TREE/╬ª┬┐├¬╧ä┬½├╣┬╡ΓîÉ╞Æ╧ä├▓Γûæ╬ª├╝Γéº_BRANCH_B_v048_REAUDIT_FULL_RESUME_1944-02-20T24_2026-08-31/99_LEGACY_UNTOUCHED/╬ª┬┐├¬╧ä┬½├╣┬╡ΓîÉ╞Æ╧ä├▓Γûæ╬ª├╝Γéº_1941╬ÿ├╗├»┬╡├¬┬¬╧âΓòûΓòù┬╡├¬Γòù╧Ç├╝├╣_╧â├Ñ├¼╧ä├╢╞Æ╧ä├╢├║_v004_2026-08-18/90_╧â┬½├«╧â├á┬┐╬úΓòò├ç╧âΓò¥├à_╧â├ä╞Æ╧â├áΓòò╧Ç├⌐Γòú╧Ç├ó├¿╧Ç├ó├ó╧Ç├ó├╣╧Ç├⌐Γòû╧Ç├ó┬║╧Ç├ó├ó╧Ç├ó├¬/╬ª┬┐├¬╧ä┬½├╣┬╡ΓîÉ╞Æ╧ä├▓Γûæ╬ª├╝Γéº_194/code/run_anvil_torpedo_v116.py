#!/usr/bin/env python3
from pathlib import Path
import sys,csv,json
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v115 as v
import release_flight_v115 as rf1
import release_flight_v116 as rf
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP

def run_air(us='US02',ntr=8,seed=11677017,gate=750):
 p,w,e,d=v.load_all(R);at=load_attack_types(R)['TBF1C'];pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
 kw=dict(N=16,active_A=16,active_B=8,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(v._default_centered_y(8))+list(v._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500,package_weapon_release_range_m=gate)
 return v.simulate_escort_cap(pa,p[us],da,d[us],w,e,ntr=ntr,seed=seed,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=True,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP['TBF1C'],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=True,global_ship_evasion_policy='auto',global_aa_fire_discipline='center',global_screen_aa=True,global_screen_profile='akizuki2_yugumo2',global_screen_fire_discipline='center',global_screen_ship_motion=True,**kw)

def main():
 import argparse;ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=8);ap.add_argument('--us',default='US02');a=ap.parse_args()
 m=run_air(a.us,a.ntr)
 rows=[]
 b=rf1.simulate_torpedoes(m,seed=11688001,prior='center',torpedo_policy='auto')
 rows.append({'US':a.us,'ntr':a.ntr,'case':'single_axis_current','separation_deg':0,'released':b['released'],'no_solution_rate':b['no_solution_rate'],'aircrew_aim_failure_rate':b['aircrew_aim_failure_rate'],'geometric_hit_rate_per_release':b['geometric_hit_rate_per_release'],'hit_rate_per_release':b['hit_rate_per_release'],'mean_hits_per_wave':b['mean_hits_per_wave'],'axisA_hit_rate':'','axisB_hit_rate':'','axisA_no_solution':'','axisB_no_solution':''})
 for sep in [0,30,60,90,120]:
  r=rf.simulate_torpedoes_anvil(m,separation_deg=sep,seed=11688001,prior='center',ship_policy='bisector_auto');g={x['group']:x for x in r['groups']}
  rows.append({'US':a.us,'ntr':a.ntr,'case':'terminal_anvil','separation_deg':sep,'released':r['released'],'no_solution_rate':r['no_solution_rate'],'aircrew_aim_failure_rate':r['aircrew_aim_failure_rate'],'geometric_hit_rate_per_release':r['geometric_hit_rate_per_release'],'hit_rate_per_release':r['hit_rate_per_release'],'mean_hits_per_wave':r['mean_hits_per_wave'],'axisA_hit_rate':g['axis_A']['hit_rate_per_release'],'axisB_hit_rate':g['axis_B']['hit_rate_per_release'],'axisA_no_solution':g['axis_A']['no_solution_rate'],'axisB_no_solution':g['axis_B']['no_solution_rate']})
 out=R.parent/'results_current'/f'anvil_torpedo_{a.us}_v116.csv'
 with open(out,'w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 print(json.dumps(rows,indent=2))
if __name__=='__main__':main()
