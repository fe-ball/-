# MODEL NOTES v0.11.6

## 1. Scope

v0.11.6 は v0.11.5 の post-release hit/miss を multi-axis TBF attack まで拡張する構造監査版。艦損傷・沈没・飛行甲板復旧時間はまだ扱わない。

## 2. Backward compatibility

新規パラメータは既定で旧挙動を保持する。`check_v115_equivalence_v116.py` で主要指標完全一致。

## 3. Actual-ship release gate

`package_weapon_release_actual_ship_range=True` のとき、名目目標点ではなく global ship state との実距離で release crossing を捕捉する。

- ship: 0.5 s global-AA substep
- aircraft: 2.5 s fighter step 内線形補間
- component damage: fighter-step online state

したがって damage/release の順序には最大2.5 s未満の離散化残差がある。

## 4. Terminal target tracking

working center:
- start range: 4500 m
- max route-heading correction: 2 deg/s

これは B-prior。TBFに完全追尾を与えるものではない。jink offset/heading は dynamic formation 層として別に重なる。

## 5. Pursuit extension

actual-release mode では旧 nominal delivery-line crossing で即終了せず、未投雷生残機に working 3500 m の追尾余白を与える。

B-priorであり、実戦の再攻撃 doctrine の測定値ではない。

## 6. Multi-axis routes

`package_member_axis_offsets_deg` は個体ごとの基準進入軸。full-global mode では CAP/escort/AA/ship evasion が release 前から実軸を見る。

terminal-only rotation はコードに残るが、pre-release ship heading が single-axis で既に決まってしまうため、最終結論には使用しない。

## 7. Route phasing

同じ幾何学的初期航程でも moving carrier + finite terminal tracking により actual release time は揃わない。

`package_member_route_lead_m` は後着群を経路方向へ前出しして release timing を合わせる。これは speed/power bonus ではない。

F6F n=4 final diagnostic:
- 30°: 550 m lead -> 0.94 s mean release gap
- 60°: 700 m -> 1.41 s
- 90°: 700 m -> 1.69 s
- 60° unphased: 10.25 s

この lead 値は geometry dependent な B-prior。別距離・速度・艦回避条件へそのまま移植しない。

## 8. Post-release ship response

`continue_turn` は release 前の established carrier turn をそのまま継続する標準診断。

`bisector_auto` / bow / stern 等は sensitivity / defensive-bound 用。投雷瞬間に敵軸を完全把握して再最適化する policy は標準値にしない。

## 9. Torpedo result interpretation

Final F6F n=4 values are structural diagnostics only.

- no-solution rateが0になったことは、射撃解の二値崩壊が消えたことを示す。
- hit/release や hits/wave は target-motion estimate, gyro/entry error, run-normal, ship turn, small-N に依存する。
- 30/60/90°の順位は固定しない。
- axis-wise hit asymmetry is meaningful qualitatively: a carrier turn can favor one axis and sacrifice the other.

## 10. Known residuals

- sea state, wake, torpedo depth, arming transients beyond working model
- torpedo dud/exploder/warhead consequence
- bomb fuze/dud/penetration/near-miss underwater effect
- exact Shokaku/Zuikaku hull and hydrodynamics
- coordinated pilot doctrine beyond route phasing and axis assignment
- damage to screen ships and carrier before release altering hydrodynamics

These belong to the next ship-damage / mission-continuation layer, not to another aircraft maneuver coefficient.
