#!/usr/bin/env python3
import pandas as pd, json, sys
p='results_current/carrier_damage_conditional_curves_v117.csv';d=pd.read_csv(p)
checks={}
# one-torp Taiho canonical calibration
r=d[(d.profile=='TAIHO_R30_WORK')&(d.bomb_hits==0)&(d.torpedo_hits==1)&(d.time_h==0)].iloc[0]
checks['taiho_1torp_speed_24_26_center']=bool(24<=r.median_speed_kn<=26)
r6=d[(d.profile=='TAIHO_R30_WORK')&(d.bomb_hits==0)&(d.torpedo_hits==1)&(d.time_h==6)].iloc[0]
checks['taiho_1torp_6h_most_not_mission_killed']=bool(r6.p_mission_kill<.25)
# one bomb Unryu: high immediate deck mission kill, very low ship loss
u=d[(d.profile=='UNRYU_R30_WORK')&(d.bomb_hits==1)&(d.torpedo_hits==0)&(d.time_h==0)].iloc[0]
checks['unryu_1bomb_high_deck_stop']=bool(u.p_flight_deck_closed>.6)
checks['unryu_1bomb_low_ship_loss']=bool(u.p_lost<.02)
# monotonic mission-kill with pure hit count at 6h
for pid in d.profile.unique():
 for typ in ['bomb','torp']:
  vals=[]
  for k in [1,2,3]:
   q=(d.profile==pid)&(d.time_h==6)
   q &= ((d.bomb_hits==k)&(d.torpedo_hits==0)) if typ=='bomb' else ((d.torpedo_hits==k)&(d.bomb_hits==0))
   vals.append(float(d[q].iloc[0].p_mission_kill))
  checks[f'{pid}_{typ}_mk_monotonic']=bool(vals[0]<=vals[1]<=vals[2])
# protected Taiho not worse than Unryu for same pure hit counts at 6h
for b,t in [(1,0),(2,0),(0,1),(0,2)]:
 a=float(d[(d.profile=='TAIHO_R30_WORK')&(d.bomb_hits==b)&(d.torpedo_hits==t)&(d.time_h==6)].iloc[0].p_mission_kill)
 bval=float(d[(d.profile=='UNRYU_R30_WORK')&(d.bomb_hits==b)&(d.torpedo_hits==t)&(d.time_h==6)].iloc[0].p_mission_kill)
 checks[f'taiho_not_worse_{b}B_{t}T']=bool(a<=bval)
json.dump({'checks':checks,'all_pass':all(checks.values())},open('results_current/carrier_damage_invariants_v117.json','w'),indent=2)
print(json.dumps({'checks':checks,'all_pass':all(checks.values())},indent=2));sys.exit(0 if all(checks.values()) else 1)
