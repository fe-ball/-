# MODEL NOTES v0.11.8 WIP — Sortie Regeneration

## Scope

Queue-based carrier sortie regeneration after v0.11.7 carrier mission damage.

This layer answers, for a defined post-mission air-group state:
- whether the return cycle can be completed,
- how many aircraft are ready after turnaround/repair,
- how many can actually be launched by +30 / +60 / +120 min,
- what next-wave mix is available,
- what fighter pool can support the next CAP cycle.

It does **not** reconstruct a historical battle yet.

## Current queue structure

1. returning-aircraft ETA
2. time-varying recovery deck throughput
3. service / maintenance queue
4. damaged-aircraft repair queue
5. pilot qualification / fatigue gate
6. fuel / ammunition gate
7. time-varying respot deck work
8. time-varying launch throughput

The carrier deck is treated as non-bankable work capacity. Capacity available while no operation is waiting is not carried forward.

## v0.11.7 damage bridge

`carrier_damage_continuous_v118.py` reproduces the existing v0.11.7 0/2/6/24 h trial arrays exactly for tested cases, while exposing the same latent state continuously at arbitrary time `t`.

Exposed latent state includes:
- flight-deck repair timer,
- shock stand-down timer,
- elevator outage count,
- hangar damage,
- fire/flood progression,
- temporary/permanent speed loss,
- steering and AA degradation,
- catastrophic/lost state.

The earlier 0/2/6/24 h interpolation shortcut has therefore been removed from the active WIP runner.

## FCFS correction

The first WIP implementation described the recovery queue as FCFS but actually iterated aircraft by type. This biased which aircraft type entered the service queue first.

Recovery is now globally sorted by ETA across F / DB / TB.

## B-prior rule

Absolute rates/times remain working priors, not historical measurements.
The architecture is constrained by r30 and historical carrier-operating structure, but numerical throughput values remain sensitivity parameters.

Current candidate priors:

| profile | nominal launch ac/min | nominal recovery ac/min | service slots | respot work |
|---|---:|---:|---:|---:|
| UNRYU | 1.35 | 0.72 | 10 | 11 min |
| SHOKAKU | 1.55 | 0.82 | 12 | 10 min |
| TAIHO | 1.45 | 0.78 | 12 | 10.5 min |

Routine turnaround median: F 28 / DB 43 / TB 49 min.
Repairable-aircraft maintenance median: F 125 / DB 150 / TB 165 min.

## Diagnostic benchmark state

Generic 72-aircraft post-strike/CAP state, used only to exercise the queue:
- ready: F14 / DB8 / TB7
- routine service: F6 / DB3 / TB4
- returning: F8 / DB8 / TB8, ETA 8–24.5 min
- damaged repairable: F2 / DB2 / TB2
- pilot, fatigue, fuel and ammunition gates applied separately.

This is not a claim about a specific historical carrier.

## Output statistics

Because bomb-deck damage is strongly bimodal, p10/p50/p90 alone are insufficient. The active summary now also reports:
- `p_any_next_wave`
- `p_next_wave_ge_12`
- `p_next_wave_ge_24`
- `p_next_wave_ge_36`
- `p_next_wave_ge_48`
- `p_recovery_cycle_cleared`

## Remaining limitations before fixation

1. The air-group state is still generic; it is not yet transferred from the actual upstream air-combat trial.
2. Routine service still uses a lumped parallel-server queue; fuel, ordnance, elevator/hangar handling and maintenance are not separate resources.
3. Persistent carrier fuel-vapor/fire/ordnance safety states do not yet inhibit servicing independently of launch/recovery capacity. This may make some combined bomb+torpedo recovery cases optimistic.
4. Pilot fatigue is a static availability multiplier rather than a persistent sortie-history state.
5. Deck scheduling is recovery-first. Mixed emergency CAP launch / recovery preemption is not yet modeled.
6. Absolute throughput/service priors still require stronger source calibration.

## Next implementation target

Connect the queue to the actual aircraft-level end state from the v0.11.7 upstream combat trial, then split the service queue into elevator/deck handling, fuel, ordnance and maintenance resources. Keep historical FORAGER reconstruction paused until those interfaces pass regression/sensitivity checks.

## Upstream individual-aircraft bridge (2026-08-16 continuation)

The sortie layer can now receive individual upstream package outcomes instead of only a generic count state. The bridge uses terminal mission/component arrays and preserves lost, clean-returning and damaged-returning categories.

`returning_damaged` is structurally distinct from `damaged`: the former still consumes recovery deck work before entering long repair. Do not collapse these categories in future runners.

`crew_manifest` is presently transfer metadata, not yet the authoritative sortie crew gate. Do not interpret preserved crew IDs/qualifications as a completed personnel simulation until the aggregate `pilots` gate is replaced or reconciled.

The current component-damage threshold used by the bridge is a B-prior and requires sensitivity/calibration before fixation.
