import json, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import air_microcombat_v04 as m
p,w,e,d=m.load_all(Path(__file__).parent)
pol=['auto','press','zoom','extend']
rows=[]
for i,a in enumerate(pol):
  for j,b in enumerate(pol):
    r=m.simulate_dynamic(p['JP01'],p['US02'],d['JP01'],d['US02'],w,e,3000,3000,400,400,ntr=5000,seed=900+i*10+j,policyA=a,policyB=b)
    rows.append({'JP_policy':a,'US_policy':b,'JP_kill':r['A_kill'],'US_kill':r['B_kill'],'JP_diseng':r['A_diseng'],'US_diseng':r['B_diseng'],'JP_first':r['A_firstshot'],'US_first':r['B_firstshot'],'JP_damage_ret':r['A_damaged_returnable'],'US_damage_ret':r['B_damaged_returnable'],'timeout':r['timeout']})
print(json.dumps(rows,ensure_ascii=False,indent=2))
