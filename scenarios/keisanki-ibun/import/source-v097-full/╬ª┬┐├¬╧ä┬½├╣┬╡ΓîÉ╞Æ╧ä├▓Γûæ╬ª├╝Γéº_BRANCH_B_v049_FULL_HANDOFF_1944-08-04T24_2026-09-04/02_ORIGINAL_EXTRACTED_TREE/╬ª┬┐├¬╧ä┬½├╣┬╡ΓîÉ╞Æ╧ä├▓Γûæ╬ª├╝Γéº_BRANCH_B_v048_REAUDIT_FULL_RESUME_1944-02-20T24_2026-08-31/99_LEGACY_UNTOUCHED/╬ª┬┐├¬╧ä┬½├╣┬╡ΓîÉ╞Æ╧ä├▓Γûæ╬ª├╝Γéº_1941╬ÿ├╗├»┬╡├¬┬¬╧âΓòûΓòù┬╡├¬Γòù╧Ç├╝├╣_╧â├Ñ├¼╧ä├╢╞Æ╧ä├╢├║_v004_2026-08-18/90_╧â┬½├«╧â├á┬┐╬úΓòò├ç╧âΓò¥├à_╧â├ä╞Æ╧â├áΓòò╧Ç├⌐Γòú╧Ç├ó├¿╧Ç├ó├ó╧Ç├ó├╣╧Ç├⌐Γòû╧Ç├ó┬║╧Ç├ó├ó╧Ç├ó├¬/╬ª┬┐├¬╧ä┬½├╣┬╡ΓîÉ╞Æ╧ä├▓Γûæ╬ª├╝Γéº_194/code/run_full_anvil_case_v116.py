#!/usr/bin/env python3
from pathlib import Path
import sys,json,argparse,math
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v116 as v
import release_flight_v116 as rf
import release_flight_v115 as rf115
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP

def run(sep,us='US02',ntr=2,seed=11699017,lead_b=0.0):
 p,w,e,d=v.load_all(R);at=load_attack_types(R)['TBF1C'];pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
 half=6;axis=[-float(sep)/2]*half+[float(sep)/2]*(12-half);leads=[0.0]*half+[float(lead_b)]*(12-half)
 kw=dict(N=16,active_A=16,active_B=8,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(v._default_centered_y(8))+list(v._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500,package_weapon_release_range_m=750,package_member_axis_offsets_deg=axis,package_weapon_release_actual_ship_range=True,package_terminal_track_ship=True,package_terminal_track_start_m=4500,package_terminal_track_turn_deg_s=2.0,package_member_route_lead_m=leads)
 m=v.simulate_escort_cap(pa,p[us],da,d[us],w,e,ntr=ntr,seed=seed,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=True,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP['TBF1C'],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=True,global_ship_evasion_policy='auto',global_aa_fire_discipline='center',global_screen_aa=True,global_screen_profile='akizuki2_yugumo2',global_screen_fire_discipline='center',global_screen_ship_motion=True,**kw)
 # One common post-release carrier response to the actual multi-axis release state.
 r=rf.simulate_torpedoes_anvil(m,separation_deg=0,seed=seed+191,prior='center',ship_policy='continue_turn')
 import numpy as np
 rc=np.asarray(m['trial_package_weapon_release_cycle'],float);rfra=np.asarray(m['trial_package_weapon_release_frac'],float);rt=(rc+rfra)*2.5;rt[rc<0]=np.nan
 gtime=[]
 for a0,b0,label in [(0,6,'axis_A'),(6,12,'axis_B')]:
  z=rt[:,a0:b0];gtime.append({'group':label,'mean_release_time_s':float(np.nanmean(z)) if np.isfinite(z).any() else None,'std_release_time_s':float(np.nanstd(z)) if np.isfinite(z).any() else None,'released':int(np.isfinite(z).sum())})
 out={'model':'v0.11.6-full-anvil','US':us,'ntr':ntr,'separation_deg':sep,'axisB_route_lead_m':lead_b,
      'package_passes':m['package_attack_passes'],'package_clean_bursts':m['package_online_clean_bursts'],'package_loss':m['package_online_mission_losses'],
      'weapon_release_count':m['package_weapon_release_count'],'weapon_release_qeq':m['package_weapon_release_quality_equivalent'],
      'ship_heading_change_deg':m['global_mean_ship_heading_change_deg'],'screen_station_error_m':m['screen_mean_station_error_m'],
      'release_timing_by_group':gtime,'released':r['released'],'no_solution_rate':r['no_solution_rate'],'aircrew_aim_failure_rate':r['aircrew_aim_failure_rate'],'hit_rate_per_release':r['hit_rate_per_release'],'mean_hits_per_wave':r['mean_hits_per_wave'],'groups':r['groups']}
 return out

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--sep',type=float,required=True);ap.add_argument('--us',default='US02');ap.add_argument('--ntr',type=int,default=2);ap.add_argument('--lead-b',type=float,default=0.0);a=ap.parse_args();o=run(a.sep,a.us,a.ntr,lead_b=a.lead_b)
 path=R.parent/'results_current'/f'full_anvil_{a.us}_sep{int(a.sep)}_lead{int(a.lead_b)}_v116.json';path.write_text(json.dumps(o,indent=2),encoding='utf-8');print(json.dumps(o))
if __name__=='__main__':main()
