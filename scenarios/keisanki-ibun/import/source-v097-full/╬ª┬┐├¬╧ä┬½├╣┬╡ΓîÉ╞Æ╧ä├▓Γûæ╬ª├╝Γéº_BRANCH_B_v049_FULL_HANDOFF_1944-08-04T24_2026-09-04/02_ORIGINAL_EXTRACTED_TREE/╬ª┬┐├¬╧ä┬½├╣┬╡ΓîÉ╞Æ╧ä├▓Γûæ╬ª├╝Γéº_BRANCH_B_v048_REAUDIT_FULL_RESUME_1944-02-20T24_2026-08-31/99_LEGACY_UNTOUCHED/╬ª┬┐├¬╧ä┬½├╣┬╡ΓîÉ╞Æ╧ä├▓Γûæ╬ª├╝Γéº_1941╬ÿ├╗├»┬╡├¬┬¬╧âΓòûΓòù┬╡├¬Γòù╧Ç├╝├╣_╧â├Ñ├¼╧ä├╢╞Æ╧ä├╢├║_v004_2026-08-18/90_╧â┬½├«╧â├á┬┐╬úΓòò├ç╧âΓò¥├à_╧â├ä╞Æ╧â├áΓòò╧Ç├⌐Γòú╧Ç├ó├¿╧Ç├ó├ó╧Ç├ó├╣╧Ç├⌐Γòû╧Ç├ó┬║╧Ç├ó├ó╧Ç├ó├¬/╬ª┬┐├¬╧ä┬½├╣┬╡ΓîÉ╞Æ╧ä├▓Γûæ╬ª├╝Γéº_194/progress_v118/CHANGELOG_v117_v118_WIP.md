# v0.11.7 -> v0.11.8-WIP changelog

Date: 2026-08-16

## Added
- Queue-based sortie regeneration.
- Continuous evaluator for v0.11.7 carrier latent damage at arbitrary time.
- Time-varying, non-bankable recovery and launch/spotting deck work.
- Next-wave threshold probabilities at 12/24/36/48 aircraft.
- Regression and smoke checks.

## Corrected during WIP
- Removed 0/2/6/24 h linear interpolation from the active runner.
- Corrected returning-aircraft queue from type-ordered processing to global ETA FCFS.

## Current diagnostic result
Generic 72-aircraft recovery-first state, undamaged Shokaku working profile:
- +30 min p50: 0
- +60 min p50: 17
- +120 min p50: 50

Damage cases remain strongly distributional/bimodal; threshold probabilities are now preferred alongside medians.

## Status
WIP only. Do not treat the absolute sortie-generation values as canonical or as historical reconstruction outputs.

## 2026-08-16 — upstream air-trial bridge execution

- Added terminal per-aircraft package-state exports to `air_microcombat_v116.py`; same-seed regression confirms all legacy outputs unchanged.
- Added `air_trial_bridge_v118.py` to classify upstream individual aircraft into lost, returning-clean and returning-damaged states.
- Added `AirGroupState.returning_damaged` and preserved that flag through both recovery APIs; damaged airborne aircraft now enter long repair after landing rather than routine turnaround.
- Added optional `AirGroupState.crew_manifest` carrying individual identity/qualification/fatigue metadata. Aggregate pilot gate remains active for now.
- Added bridge checks and a reproducible 64-trial structural smoke runner/output.
- 64-trial smoke is explicitly non-historical (US TBF package into Japanese carrier-ops shell) and is retained only as an end-to-end plumbing diagnostic.

## 2026-08-16 — WIP3: crew gate, split service, JP strike cells, US terminal AA, FORAGER re-entry

- Made `crew_manifest` operational in sortie regeneration: returning crew are unavailable until modeled landing + rest, must satisfy carrier-day/role qualification, and recover fatigue over time. Legacy aggregate onboard crew remains the t=0 pool so old benchmarks stay regression-stable.
- Split the lumped turnaround path into deck/elevator handling, fuel, ordnance, routine maintenance/final inspection; retained `service_model='lumped'` as the legacy comparison path and calibrated undamaged Shokaku split center back to 0/17/50 at +30/+60/+120 min.
- Added time-dependent internal servicing capacities from the v0.11.7 latent carrier state. Fire/avgas/ordnance hazards can stand down fuel or ordnance work even after some flight-deck capacity returns.
- Added B6N2 and D4Y2 attack-aircraft working profiles and response priors. All protection/damage coefficients remain B-priors.
- Added Japanese strike-cell runner with JP01 escort fighters; added CAP-density sensitivity.
- Fixed D4Y2 weapon-release logging by adding an 850-m dive-release gate. The prior `None` release gate recorded valid terminal attacks as zero weapon releases.
- Added US fast-carrier local-AA working profile using 5in/38 + 40-mm effective event carriers; generalized global ship AA away from JP-only damage carriers.
- Added US Fletcher-like four-node screen lower-bound profile. This is not a full TF58 screen; cruiser/battleship and an independent 20-mm layer remain absent.
- Fixed a post-B6N integration bug in screen target scoring: torpedo-vs-dive priority now reads the registered terminal mission instead of `attack_type.id.startswith('TBF')`.
- Added FORAGER 1944-07-07-night qualification ledger constrained by r30 canonical aggregate bands.
- Added Jul8–10 base-air preservation/reallocation transition WIP and Jul11 cell/force-assembly scenario tools.
- Re-opened the old doc43 455–505-aircraft Jul11 comparison band: current reserve-conscious and massed scenarios are generally lower; the old band mainly overlaps near maximum supported carrier-cell commitment.

### Status
Still WIP. Current FORAGER force assembly is a planning/transition layer; Jul8–9 fighter sweeps and the full Jul11 route-to-terminal defense are not yet microcombat-complete.
