# SOURCE AUDIT v0.11.8 WIP

## Internal canonical anchors

- r30 `44_戦術研鑽_1942-44_空母指揮・艦隊回避・教範化.md`
  - CAP launch and attack-wave launch compete for deck cycles.
  - launch/recovery/rearm cycle-time variance reduced 15–25% in the mature alternate-world doctrine.

- r30 `45_航空運用制度_1942-44_空地分離・攻防火器管制破綻研究.md`
  - carrier wind-up periods, CAP turnover/refuel timing, launch/recovery interruption, first/second wave timing.

- r30 `46_航空人事_1942-44_自然還流・空地分離・練度平準化.md`
  - carrier qualification, deck handling, maintenance/ordnance competencies and fatigue/personnel circulation remain separate constraints.

- v0.11.7 carrier mission continuation
  - launch/recovery capacity, speed, steering, AA, fire/flooding and deck closure are consumed directly.

## Public historical architecture anchors

- Jonathan B. Parshall, David D. Dickson, Anthony P. Tully,
  “Doctrine Matters: Why the Japanese Lost at Midway,” Naval War College Review 54(3), 2001.
  Used for the structural distinction between Japanese hangar-centered handling/elevator dependence and US flight-deck-centered servicing.

- Dallas W. Isom,
  “The Battle of Midway: Why the Japanese Lost,” Naval War College Review 53(3), 2000.
  Used as a sanity anchor that rearming/weapon-change was a substantial handling process with ordnance-cart/elevator constraints.

- U.S. Navy / NHHC Midway combat narratives and action reports.
  Used only to check that carrier launch/recovery/refuel/rearm cycles occur on operationally significant tens-of-minutes-to-hours timescales.

No US sortie-generation rate is copied into the Japanese model.

## Explicit B-priors

- base launch/recovery throughput
- number of simultaneous service slots
- deck respot overhead
- per-type routine turnaround time
- repairable-aircraft maintenance time
- pilot-fatigue availability multiplier

All must remain sensitivity-tested until a stronger source basis is assembled.

## 2026-08-16 bridge continuation

No new historical source claim was fixed in this bridge step. New numeric bridge thresholds (component damage >0.08; fire >0.05; synthetic return ETA spacing) are B-priors for structural testing only. The 64-trial TBF/Shokaku-shell run is a software/data-plumbing diagnostic and must not be cited as historical carrier performance.

## WIP3 source audit

### r30 internal canonical inputs
- `38_艦艇台帳_1944年7月_Marianas直前実艦・Availability.md`: 460–500 carrier combat-usable aircraft; 420–460 comparatively high first-line qualification/training.
- `42_艦艇台帳_1944年7月_FORAGER実艦TaskGroup・決戦配置.md`: first carrier strike group 285–305; second group 160–180; Ryujo outside the central nine-carrier battle line; base-air network bands.
- `44_戦術研鑽_1942-44_空母指揮・艦隊回避・教範化.md`: arrival-dispersion and cycle-variance sensitivities; not directly re-added as hit-rate multipliers.
- `45_航空運用制度_1942-44_空地分離・攻防火器管制破綻研究.md`: +10–20 percentage-point receiving-base readiness sensitivity and 20–35% relative reduction in whole-flying-unit tie-down after base damage.
- `46_航空人事_1942-44_自然還流・空地分離・練度平準化.md`: separate carrier/day, night/twilight, navigation/search, formation leadership, attack-role, radio and maintenance qualifications; attack-cell disappearance from formation/navigation/radio shortage reduced 15–30% relative as a sensitivity.
- `113_...FORAGER再計算前.md` and `114_...FORAGER再計算前.md`: authoritative restart order at 1944-07-07 night.
- `43_...FORAGER前哨...md`: **comparison branch only**, not current canonical combat result. Its Jul8/9 losses and Jul11 455–505 total are retained only as comparison priors/bands.

### External weapon/aircraft anchors
- US Navy historical material: 5in/38 sustained rate about 12–15 rpm; VT-fuzed 5in/38 was a major late-war AA component.
- US Navy / wartime ordnance material: 40-mm Bofors mechanical/cyclic maximum around 160 rpm; working effective rate is modeled below mechanical maximum.
- US Navy Fletcher-class examples: five 5in/38 guns and substantial 40-mm/20-mm batteries by late-war fits. Current `FLETCHER_US_WORK` rolls the automatic layer into a 40-mm-dominant abstraction and deliberately omits an independent 20-mm channel.
- NASM B6N technical history used for B6N carrier-torpedo-bomber configuration and B6N2/Kasei context. Numerical protection coefficients remain B-priors.
- Public museum/technical D4Y material used for early D4Y liquid-cooled configuration and weak protection/self-sealing context. Numerical protection coefficients remain B-priors.

### Unresolved source/calibration gaps
1. exact TF58 task-group AA screen composition and effective simultaneous director participation for the Jul11 scenario;
2. 20-mm channel as a separate close-defense layer;
3. exact Jul10 Taiho torpedo-hit time relative to Jul11 launch clock;
4. Jul8–9 Marianas fighter-sweep and ground-attack losses at individual-aircraft level;
5. B6N/D4Y repairability/ditch thresholds after terminal damage.
