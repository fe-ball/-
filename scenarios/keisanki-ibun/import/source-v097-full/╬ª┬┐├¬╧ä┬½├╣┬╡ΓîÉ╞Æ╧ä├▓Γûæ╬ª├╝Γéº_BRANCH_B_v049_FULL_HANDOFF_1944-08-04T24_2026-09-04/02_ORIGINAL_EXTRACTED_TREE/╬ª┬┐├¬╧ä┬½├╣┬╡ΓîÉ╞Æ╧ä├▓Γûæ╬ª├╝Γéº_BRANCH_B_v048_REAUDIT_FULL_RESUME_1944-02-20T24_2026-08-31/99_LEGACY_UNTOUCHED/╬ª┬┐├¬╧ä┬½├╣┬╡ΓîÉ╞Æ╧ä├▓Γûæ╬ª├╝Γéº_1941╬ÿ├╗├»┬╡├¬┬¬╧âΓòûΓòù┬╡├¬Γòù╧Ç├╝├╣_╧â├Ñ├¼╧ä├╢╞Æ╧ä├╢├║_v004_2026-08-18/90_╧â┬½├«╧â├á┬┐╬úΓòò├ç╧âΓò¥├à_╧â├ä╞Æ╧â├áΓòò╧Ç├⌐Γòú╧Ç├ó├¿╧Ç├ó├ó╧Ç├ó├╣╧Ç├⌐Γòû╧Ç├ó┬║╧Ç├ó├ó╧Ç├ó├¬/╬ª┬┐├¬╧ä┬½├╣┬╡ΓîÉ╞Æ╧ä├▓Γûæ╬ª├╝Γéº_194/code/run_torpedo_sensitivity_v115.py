#!/usr/bin/env python3
from pathlib import Path
import sys,csv,json
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v115 as v
import release_flight_v115 as rf
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP

def base_cfg(p,d,gate):
 pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
 kw=dict(N=16,active_A=16,active_B=8,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(v._default_centered_y(8))+list(v._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500,package_weapon_release_range_m=gate)
 return pa,da,kw

def sim(ntr,seed,gate,policy):
 p,w,e,d=v.load_all(R);at=load_attack_types(R)['TBF1C'];pa,da,kw=base_cfg(p,d,gate);ev=policy!='none';gpol='auto' if policy=='auto' else ('torpedo_'+policy if ev else 'none')
 m=v.simulate_escort_cap(pa,p['US02'],da,d['US02'],w,e,ntr=ntr,seed=seed,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=True,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP['TBF1C'],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=ev,global_ship_evasion_policy=gpol,global_aa_fire_discipline='center',global_screen_aa=True,global_screen_profile='akizuki2_yugumo2',global_screen_fire_discipline='center',global_screen_ship_motion=True,**kw)
 post={'auto':'auto','bow':'bow','stern':'stern','none':'none'}[policy];r=rf.simulate_torpedoes(m,seed=seed+191,prior='center',torpedo_policy=post)
 return m,r

def row(kind,value,ntr,m,r):
 return {'kind':kind,'value':value,'ntr':ntr,'weapon_release_count_per_wave':m['package_weapon_release_count'],'weapon_release_qeq':m['package_weapon_release_quality_equivalent'],'ship_heading_change_deg':m['global_mean_ship_heading_change_deg'],'package_loss':m['package_online_mission_losses'],'physical_pass':m['package_attack_passes'],'released_total':r['released'],'no_solution_rate':r['no_solution_rate'],'geometric_hit_rate_per_release':r['geometric_hit_rate_per_release'],'hit_rate_per_release':r['hit_rate_per_release'],'mean_hits_per_wave':r['mean_hits_per_wave'],'mean_miss_m':r['mean_miss_m'],'mean_best_run_m':r['mean_best_run_m']}

def write(path,rows):
 with open(path,'w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
 import argparse;ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=6);ap.add_argument('--mode',choices=['range','policy','all'],default='all');a=ap.parse_args();rows=[];seed=11567017
 if a.mode in ('range','all'):
  for gate in [600,750,900,1000,1200]:
   m,r=sim(a.ntr,seed,gate,'auto');rows.append(row('release_range_m',gate,a.ntr,m,r));print(rows[-1])
 if a.mode in ('policy','all'):
  for pol in ['none','bow','auto','stern']:
   m,r=sim(a.ntr,seed,750,pol);rows.append(row('ship_policy',pol,a.ntr,m,r));print(rows[-1])
 out=R.parent/'results_current';write(out/f'torpedo_{a.mode}_sensitivity_F6F_v115.csv',rows)
if __name__=='__main__':main()
