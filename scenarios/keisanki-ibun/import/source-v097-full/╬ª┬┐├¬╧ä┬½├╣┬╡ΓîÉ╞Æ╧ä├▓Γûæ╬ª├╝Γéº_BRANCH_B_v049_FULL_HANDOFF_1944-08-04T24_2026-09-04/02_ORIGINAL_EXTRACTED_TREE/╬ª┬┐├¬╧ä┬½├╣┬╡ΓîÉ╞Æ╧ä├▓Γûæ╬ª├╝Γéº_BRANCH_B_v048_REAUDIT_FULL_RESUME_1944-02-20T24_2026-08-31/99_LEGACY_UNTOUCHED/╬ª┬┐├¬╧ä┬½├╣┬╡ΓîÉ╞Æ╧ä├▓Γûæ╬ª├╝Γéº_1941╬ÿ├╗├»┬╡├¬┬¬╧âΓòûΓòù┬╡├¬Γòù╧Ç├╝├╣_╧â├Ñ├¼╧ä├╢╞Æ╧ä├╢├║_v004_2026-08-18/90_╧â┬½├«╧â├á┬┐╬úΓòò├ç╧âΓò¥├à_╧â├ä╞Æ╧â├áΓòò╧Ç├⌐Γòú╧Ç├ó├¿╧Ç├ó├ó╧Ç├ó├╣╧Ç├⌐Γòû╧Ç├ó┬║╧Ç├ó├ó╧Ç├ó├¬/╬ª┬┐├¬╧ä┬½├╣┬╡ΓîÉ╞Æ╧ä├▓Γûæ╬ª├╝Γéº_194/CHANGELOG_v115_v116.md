# CHANGELOG v0.11.5 -> v0.11.6

## Added
- actual moving-ship weapon-release gate
- finite terminal target tracking for TBF routes
- pursuit extension for unreleased live aircraft
- persistent per-aircraft multi-axis route geometry in global timeline
- route phasing / per-member lead for synchronized anvil attacks
- `continue_turn` post-release ship policy
- full-global anvil runner and synchronization diagnostics

## Fixed
- nominal-target release surface could report 750 m while actual evasive carrier was >1 km away
- mission trial could terminate at nominal target line before late group reached actual release range
- TBF could continue toward stale nominal target instead of evasive ship
- terminal-only anvil could inherit a single-axis pre-release carrier heading and was not a valid full anvil model
- instant post-release bisector re-optimization was too strong for a standard ship response
- equal nominal path length did not guarantee synchronized actual release; route phasing now makes timing explicit

## Validation
- v115-equivalence with new options OFF: all checked metrics equal
- Python syntax compile: pass
- F6F n=4 synchronized/unsynchronized anvil comparison stored in `results_current/full_anvil_F6F_final_n4_v116.csv`
