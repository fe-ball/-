#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,math,sys,csv
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent; ROOT=R.parent; sys.path.insert(0,str(R))
from forager_air_ledger_v118 import sample as sample_ledger
from carrier_damage_continuous_v118 import sample_damage_state,evaluate_capacities
from sortie_regeneration_v118 import OPS_PROFILES

# A strike cell is a planning unit, not a historical claim that every formation had exactly this size.
ATTACK_PER_CELL=12
ESCORT_PER_CELL=6
# Operational withholding priors: first group is the principal strike arm; second group also retains
# disproportionate CAP/recovery/second-strike capacity per canonical r30 role description.
COMMIT_B={
 'first':(.88,.94,.99),
 'second':(.62,.76,.90),
}
# Historical-Marianas-like formation/nav/radio cell-disappearance baseline is not fixed in r30.
# This is a B-prior used only to instantiate the r30 RELATIVE 15–30% reduction sensitivity.
BASE_CELL_DROPOUT_B=(.10,.15,.20)
REL_REDUCTION=(.15,.225,.30)


def tri(rng,b): return float(rng.triangular(*b))
def q(a):
 a=np.asarray(a,float); return {'p10':float(np.quantile(a,.1)),'p50':float(np.quantile(a,.5)),'p90':float(np.quantile(a,.9)),'mean':float(a.mean())}

def group_supported_cells(r,gn,rng):
    total=int(r[f'{gn}_total']); F=int(r[f'{gn}_F']); atk=int(r[f'{gn}_DB']+r[f'{gn}_TB'])
    # Retain some fighters for CAP/escort reserve; attack aircraft are then the primary physical limiter.
    if gn=='first': cap_hold=float(rng.triangular(.20,.27,.35))
    else: cap_hold=float(rng.triangular(.38,.46,.55))
    escort_pool=max(0,int(math.floor(F*(1-cap_hold))))
    # Qualification constraints are explicitly separate, per doc46.
    form=int(r[f'{gn}_formation_lead'])
    nav=int(r[f'{gn}_nav_radio'])
    day=int(r[f'{gn}_carrier_day'])
    role=int(r[f'{gn}_role_attack'])
    # role-attack-qualified share is applied to the attack-aircraft subset; group ledger stores people, not airframes.
    role_attack_pool=int(round(role*atk/max(total,1)))
    caps={
      'aircraft_attack':atk//ATTACK_PER_CELL,
      'fighter_escort':escort_pool//ESCORT_PER_CELL,
      'formation_lead':form//1,
      'nav_radio':nav//2,
      'carrier_day':day//18,
      'role_attack':role_attack_pool//10,
    }
    raw=max(0,min(caps.values()))
    commit=tri(rng,COMMIT_B[gn])
    planned=int(math.floor(raw*commit+1e-9))
    return raw,planned,caps,cap_hold,escort_pool

def run(n=20000,seed=118720,taiho_hours=(2,6,12,18,24),launch_window_min=45.0):
    rng=np.random.default_rng(seed); led=sample_ledger(n,seed)
    outrows=[]
    # Use a single large latent Taiho state; per-ledger trial indexes select matching latent samples.
    dmg=sample_damage_state('TAIHO_R30_WORK',torpedo_hits=1,n=n,seed=seed+17)
    taiho_cap={h:evaluate_capacities(dmg,float(h))[0] for h in taiho_hours}
    taiho_rate=OPS_PROFILES['TAIHO_R30_WORK'].base_launch_rate_ac_min
    shok_rate=OPS_PROFILES['SHOKAKU_R30_WORK'].base_launch_rate_ac_min
    for i,r in enumerate(led):
      fr,fp,fc,fh,fe=group_supported_cells(r,'first',rng)
      sr,sp,sc,sh,se=group_supported_cells(r,'second',rng)
      baseline=tri(rng,BASE_CELL_DROPOUT_B); reduction=tri(rng,REL_REDUCTION)
      dropout=baseline*(1-reduction)
      planned=fp+sp
      coherent=int(rng.binomial(planned,max(0.0,min(1.0,1-dropout)))) if planned>0 else 0
      row={
        'first_raw_cells':fr,'first_planned_cells':fp,'second_raw_cells':sr,'second_planned_cells':sp,
        'planned_cells':planned,'planned_aircraft':planned*(ATTACK_PER_CELL+ESCORT_PER_CELL),
        'planned_attack_aircraft':planned*ATTACK_PER_CELL,'planned_escort_aircraft':planned*ESCORT_PER_CELL,
        'cell_dropout_p':dropout,'coherent_cells':coherent,'coherent_aircraft':coherent*18,
        'first_attack_limiter':min(fc,key=fc.get),'second_attack_limiter':min(sc,key=sc.get),
      }
      # Launch-window feasibility of the four first-group carriers. Only Taiho has the Jul10 one-torpedo damage.
      # Hiryu uses Shokaku-class throughput as a temporary ops surrogate, explicitly not a ship-design equivalence.
      ccounts={k:int(r[f'carrier_{k}']) for k in ['TAIHO','SHOKAKU','ZUIKAKU','HIRYU']}
      desired_frac=fp/max(fr,1) if fr>0 else 0.0
      desired_first=min(sum(ccounts.values()), int(round((fp*18))))
      # Allocate planned first-group strike aircraft over carriers in proportion to inventory.
      caps_un=[]
      for k in ['SHOKAKU','ZUIKAKU','HIRYU']:
        caps_un.append(min(ccounts[k], int(math.floor(shok_rate*launch_window_min))))
      for h in taiho_hours:
        cap_t=min(ccounts['TAIHO'],int(math.floor(taiho_rate*launch_window_min*float(taiho_cap[h][i]))))
        total_cap=cap_t+sum(caps_un)
        row[f'first_launchable_{h:g}h']=min(desired_first,total_cap)
        row[f'taiho_launch_cap_{h:g}h']=cap_t
      outrows.append(row)
    return outrows

def summarize(rows,taiho_hours):
    numeric=[k for k,v in rows[0].items() if isinstance(v,(int,float,np.integer,np.floating))]
    s={k:q([r[k] for r in rows]) for k in numeric}
    lim={}
    for g in ['first','second']:
      key=f'{g}_attack_limiter'; vals=[r[key] for r in rows]
      lim[g]={x:vals.count(x)/len(vals) for x in sorted(set(vals))}
    return {
      'schema':'FORAGER_CELL_ASSEMBLY_v118_WIP','current_time':'1944-07-07 night planning basis',
      'cell_definition':{'attack_aircraft':12,'escort_fighters':6,'aircraft_total':18},
      'n':len(rows),'summary':s,'limiter_frequencies':lim,
      'B_priors':{
        'first_group_commit_fraction':COMMIT_B['first'],'second_group_commit_fraction':COMMIT_B['second'],
        'historical_like_cell_dropout_baseline':BASE_CELL_DROPOUT_B,
        'r30_relative_dropout_reduction':REL_REDUCTION,
        'launch_window_min':45.0,
      },
      'taiho_damage_sensitivity_hours_after_1T':list(taiho_hours),
      'interpretation_note':'Cell dropout acts before terminal combat and does not modify hit probability. Taiho sensitivity applies only launch throughput; exact Jul10 hit time is unresolved, so hours-after-hit are scenarios.',
    }

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--n',type=int,default=20000);ap.add_argument('--seed',type=int,default=118720);ap.add_argument('--launch-window-min',type=float,default=45.0)
 a=ap.parse_args(); hs=(2,6,12,18,24);rows=run(a.n,a.seed,hs,a.launch_window_min);s=summarize(rows,hs);s['B_priors']['launch_window_min']=a.launch_window_min
 out=ROOT/'results_current';out.mkdir(exist_ok=True)
 (out/'forager_cell_assembly_v118.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
 metrics=['first_raw_cells','first_planned_cells','second_raw_cells','second_planned_cells','planned_cells','planned_aircraft','coherent_cells','coherent_aircraft']+[f'first_launchable_{h:g}h' for h in hs]+[f'taiho_launch_cap_{h:g}h' for h in hs]
 with open(out/'forager_cell_assembly_v118.csv','w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=['metric','p10','p50','p90','mean']);w.writeheader()
  for k in metrics:w.writerow({'metric':k,**s['summary'][k]})
 print(json.dumps({k:s['summary'][k] for k in metrics},ensure_ascii=False,indent=2));print('limiters',s['limiter_frequencies'])

if __name__=='__main__':main()
