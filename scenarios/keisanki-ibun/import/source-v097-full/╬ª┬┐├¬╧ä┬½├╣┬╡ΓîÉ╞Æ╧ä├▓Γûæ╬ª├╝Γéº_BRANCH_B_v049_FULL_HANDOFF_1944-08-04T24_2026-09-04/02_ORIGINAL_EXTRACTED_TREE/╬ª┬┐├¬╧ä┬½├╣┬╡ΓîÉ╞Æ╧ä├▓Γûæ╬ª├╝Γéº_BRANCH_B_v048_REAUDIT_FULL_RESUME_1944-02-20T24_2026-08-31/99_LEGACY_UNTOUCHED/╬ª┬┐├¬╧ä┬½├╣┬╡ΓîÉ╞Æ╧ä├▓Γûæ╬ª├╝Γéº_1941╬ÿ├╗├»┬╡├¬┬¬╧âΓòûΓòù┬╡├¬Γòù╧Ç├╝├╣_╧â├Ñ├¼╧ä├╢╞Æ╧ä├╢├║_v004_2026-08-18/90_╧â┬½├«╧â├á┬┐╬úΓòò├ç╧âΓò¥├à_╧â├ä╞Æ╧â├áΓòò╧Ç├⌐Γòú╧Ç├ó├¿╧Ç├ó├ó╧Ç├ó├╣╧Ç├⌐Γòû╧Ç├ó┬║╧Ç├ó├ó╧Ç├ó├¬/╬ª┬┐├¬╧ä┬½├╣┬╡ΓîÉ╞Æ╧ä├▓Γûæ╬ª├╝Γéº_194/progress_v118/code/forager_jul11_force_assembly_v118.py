#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,csv,sys,math
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent;ROOT=R.parent;sys.path.insert(0,str(R))
import forager_cell_assembly_v118 as ca
import forager_base_preservation_v118 as bp

def q(a):
 a=np.asarray(a,float);return {'p10':float(np.quantile(a,.1)),'p50':float(np.quantile(a,.5)),'p90':float(np.quantile(a,.9)),'mean':float(a.mean())}

def run(n=20000,seed=118760):
 rng=np.random.default_rng(seed)
 c=ca.run(n,seed+1,(2,6,12,18,24),45.0); b=bp.run(n,seed+2)
 rows=[]
 for i,(x,y) in enumerate(zip(c,b)):
  raw1=x['first_raw_cells']; raw2=x['second_raw_cells']
  # More aggressive main-attack scenario, separate from the reserve-conscious policy embedded in ca.
  mf=int(math.floor(raw1*float(rng.triangular(.94,.98,1.0))+1e-9))
  ms=int(math.floor(raw2*float(rng.triangular(.82,.92,1.0))+1e-9))
  mass_cells=mf+ms
  raw_cells=raw1+raw2
  base=y['jul11_base_strike']
  rows.append({
   'carrier_cells_supported':raw_cells,
   'carrier_aircraft_supported':raw_cells*18,
   'carrier_cells_reserve_conscious':x['planned_cells'],
   'carrier_aircraft_reserve_conscious':x['planned_aircraft'],
   'carrier_cells_massed':mass_cells,
   'carrier_aircraft_massed':mass_cells*18,
   'base_strike':base,
   'total_reserve_conscious':x['planned_aircraft']+base,
   'total_massed':mass_cells*18+base,
   'total_max_supported':raw_cells*18+base,
   'p_old_comparison_band_massed':1 if 455 <= mass_cells*18+base <= 505 else 0,
   'p_old_comparison_band_max':1 if 455 <= raw_cells*18+base <= 505 else 0,
  })
 return rows

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,default=20000);ap.add_argument('--seed',type=int,default=118760);a=ap.parse_args()
 rows=run(a.n,a.seed); keys=list(rows[0]);s={k:q([r[k] for r in rows]) for k in keys}
 result={
  'schema':'FORAGER_JUL11_FORCE_ASSEMBLY_v118_WIP','n':len(rows),'summary':s,
  'scenario_definitions':{
   'reserve_conscious':'first-group and second-group strike commitment B-priors from forager_cell_assembly_v118; retains substantial second-wave/recovery/CAP margin',
   'massed':'first raw cell capacity commitment .94/.98/1.00; second .82/.92/1.00 B-prior',
   'max_supported':'all physically/qualification-supported 12 attack + 6 escort cells; not an operational recommendation',
  },
  'comparison_note':'455–505 is retained only as the old doc43 comparison branch band. Probability columns test overlap; they do not calibrate the new model to that band.'
 }
 out=ROOT/'results_current';out.mkdir(exist_ok=True)
 (out/'forager_jul11_force_assembly_v118.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 with open(out/'forager_jul11_force_assembly_v118.csv','w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=['metric','p10','p50','p90','mean']);w.writeheader()
  for k,v in s.items():w.writerow({'metric':k,**v})
 print(json.dumps({k:s[k] for k in ['carrier_aircraft_supported','carrier_aircraft_reserve_conscious','carrier_aircraft_massed','base_strike','total_reserve_conscious','total_massed','total_max_supported','p_old_comparison_band_massed','p_old_comparison_band_max']},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
