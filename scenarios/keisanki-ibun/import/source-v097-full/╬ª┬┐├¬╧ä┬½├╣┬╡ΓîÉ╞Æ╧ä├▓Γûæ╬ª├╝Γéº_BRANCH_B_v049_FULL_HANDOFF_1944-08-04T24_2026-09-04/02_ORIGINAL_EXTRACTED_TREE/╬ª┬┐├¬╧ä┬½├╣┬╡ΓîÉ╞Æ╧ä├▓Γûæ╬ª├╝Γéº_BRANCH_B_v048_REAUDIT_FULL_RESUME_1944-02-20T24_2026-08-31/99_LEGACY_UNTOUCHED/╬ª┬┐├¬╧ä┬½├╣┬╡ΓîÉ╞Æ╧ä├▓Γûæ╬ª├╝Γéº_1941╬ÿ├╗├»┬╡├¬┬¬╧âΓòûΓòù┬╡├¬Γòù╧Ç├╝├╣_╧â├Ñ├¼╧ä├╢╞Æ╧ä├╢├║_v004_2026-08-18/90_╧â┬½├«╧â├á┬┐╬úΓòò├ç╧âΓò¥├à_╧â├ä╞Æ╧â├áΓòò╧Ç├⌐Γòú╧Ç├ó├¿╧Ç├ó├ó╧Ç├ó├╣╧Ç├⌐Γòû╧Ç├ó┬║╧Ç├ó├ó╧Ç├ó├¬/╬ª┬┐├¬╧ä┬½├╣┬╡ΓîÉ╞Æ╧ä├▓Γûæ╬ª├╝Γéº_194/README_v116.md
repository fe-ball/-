# 航空ミクロ戦闘 / 任務戦 v0.11.6

## 現在地

v0.11.6 は、v0.11.5 の実艦 screen + release 後 weapon flight に残っていた **TBF 単一軸雷撃の構造的不連続**を監査し、multi-axis / anvil 雷撃を main global timeline まで統合した固定版。

航空側の計算鎖は現在、

`個機性能 → 編隊戦 → escort/CAP → dynamic strike formation → online damage/loss → 多層CAP → local/screen AA → 実艦screen → 艦回避 → actual weapon release → bomb/torpedo flight → moving target hit/miss`

まで閉じている。

ただし hit/miss の絶対値は B-prior に依存する診断値であり、史実命中率への較正ではない。特に TBF anvil の角度ランキングは n=4 の F6F 構造監査から確定してはいけない。

## 1. v0.11.6 で修正したもの

### 1.1 actual-ship weapon-release gate

v0.11.5 の TBF weapon-release gate は名目目標座標からの距離を見ていた。空母が大回頭して数百 m 移動すると、記録上 750 m release でも実艦から 1.2–1.5 km 離れる場合があった。

v0.11.6 はオプション `package_weapon_release_actual_ship_range=True` を追加し、0.5 s ship/AA substep と 2.5 s fighter-step 内補間を使って、**実際に動いている空母との距離が release range を横切った瞬間**を個体別に保存する。

### 1.2 terminal target tracking

actual-ship gate を入れると、旧 TBF は回避前の名目目標点へ直進したままで、回避して逃げる空母を追わないことが露出した。

`package_terminal_track_ship=True` を追加し、working center では実艦 4.5 km 以内から有限 2 deg/s で target tracking を行う。jink は別状態として残り、無限の追尾性能は与えない。

### 1.3 pursuit extension / trial end

旧 mission end は package center が名目 target line を越えると終了した。多方向攻撃では未投雷群が実艦を追っていても trial が止まるため、actual release gate 使用時は未投雷生残機がいる限り working 3.5 km の pursuit extension を許す。

### 1.4 multi-axis routes

`package_member_axis_offsets_deg` により、12 TBF を 6+6 の別進入軸として main timeline に配置できる。

CAP target selection、護衛、強風低CAP、local AA、実艦screen、艦回避はすべて最初からその実位置を見る。release 後だけ攻撃軸を回転する terminal-only anvil は診断用として残すが、正本結果には用いない。

### 1.5 route phasing

同じ初期航程でも、艦回避と terminal tracking により二群の actual-ship 750 m release が 9–12 s ずれることが分かった。これは anvil ではなく逐次二方向攻撃。

`package_member_route_lead_m` を追加し、後着群の経路位相を事前調整できるようにした。これは戦闘力 bonus ではなく **release timing の作戦調整**。

### 1.6 post-release ship policy

v0.11.5 の一部診断は、魚雷投下の瞬間に艦が攻撃軸へ理想的に再最適化するため上限寄りだった。

v0.11.6 は `continue_turn` を標準診断に追加し、投雷前から成立していた艦の回頭を release 後も継続する。`bisector_auto` 等は防御上限診断として残す。

## 2. 旧版回帰

新機能を既定 OFF にした `check_v115_equivalence_v116.py` は v0.11.5 と主要指標完全一致。

- package physical pass / clean burst
- strike mission loss
- fighter losses
- local 12.7cm / 25mm fire
- release opportunity
- weapon release count / quality
- real screen AA fire / station error

したがって v0.11.6 の追加は、明示的に有効化した multi-axis / actual-release 条件だけに作用する。

## 3. Full-global anvil: F6F 構造監査

US02 F6F-5 護衛、12 TBF、同一 B-prior、各4 trial。30/60/90°は 6+6、route phasing を使って release をほぼ同期させた。

| case | axis B lead | 群間 mean release 差 | no-solution | aim failure | hit/release | mean hits / 12-plane wave |
|---|---:|---:|---:|---:|---:|---:|
| 0° single axis | 0 m | 4.73 s* | 0 | .255 | .255 | 3.00 |
| 30° synchronized | 550 m | **0.94 s** | 0 | 0 | .468 | 5.50 |
| 60° synchronized | 700 m | **1.41 s** | 0 | .021 | .125 | 1.50 |
| 90° synchronized | 700 m | **1.69 s** | 0 | .064 | .404 | 4.75 |
| 60° unsynchronized | 0 m | **10.25 s** | 0 | .468 | 0 | 0 |

* 0°では axis A/B は分析用に半数ずつラベルされているだけで同一攻撃軸。群間時刻差を anvil synchronization 指標として解釈しない。

### 読み方

1. **anvil は「二方向」だけでは成立せず、同時性が必要。**
   - 同じ60°でも unsynchronized では release 差10.25 s、0 hit。
   - route phasing 後は1.41 s、物理射撃解は全投下魚雷に残り、hit も復活した。

2. **wide angle が単調に強いわけではない。**
   30/60/90°の absolute hit は大きく振れる。艦の一回の回頭が一方の軸を有利にし、他方を不利にするためで、n=4 から最適角度を順位化しない。

3. **旧 single-axis の“艦尾を向けると全魚雷の射撃解が消える”二値性は、actual-ship release + finite tracking + continuous turn を入れると main model の標準挙動ではなくなった。**
   synchronized 30/60/90°はいずれも `no_solution_rate=0`。残る失敗は aircrew motion estimate / weapon error / carrier turn geometry へ分散する。

4. **二軸の本質は hit bonus ではなく、一つの艦回避で両方を同時に最適化できないこと。**
   軸別 hit は強く非対称になり、ある試行では一方をほぼ殺す代わりに反対側が残る。この非対称自体が anvil の構造的価値。

## 4. 現時点で閉じた航空側の範囲

### 構造的には閉じた
- actual moving ship に対する weapon-release geometry
- TBF finite terminal tracking
- single / multi-axis route geometry
- route timing / anvil synchronization
- release 後も継続する ship motion
- bomb / torpedo moving-target collision
- CAP / escort / AA / real-screen interactions を同一 global timeline 上で反映

### まだ B-prior
- TBF terminal tracking start 4.5 km / turn 2 deg/s
- pursuit extension 3.5 km
- route lead 550–700 m の具体値
- 30/60/90° attack-axis separation
- Mk13 run-normal / gyro / water-entry / target-motion-estimation error
- bomb release errors
- generic carrier 30 kt / 250 x 26 m hit geometry

## 5. 航空ミクロ戦闘編の判定

**v0.11.6 をもって、航空ミクロ戦闘 / 任務戦は「moving target への geometric hit/miss」まで substantially complete と扱える。**

次に同じモデルを改築する必要はない。次層は別の問いになる。

1. weapon hit → carrier component damage / flight-deck mission continuation
2. sortie regeneration / deck cycle / repair / fuel-ammo / pilot availability
3. その後に historical clock へ戻す

もし「空母を守れたか」までを航空編の完成定義にするなら、次は weapon hit を **飛行甲板・格納庫・機関・操舵・航空燃料・弾薬・火災**へ分配し、mission continuation を出す層へ進む。
