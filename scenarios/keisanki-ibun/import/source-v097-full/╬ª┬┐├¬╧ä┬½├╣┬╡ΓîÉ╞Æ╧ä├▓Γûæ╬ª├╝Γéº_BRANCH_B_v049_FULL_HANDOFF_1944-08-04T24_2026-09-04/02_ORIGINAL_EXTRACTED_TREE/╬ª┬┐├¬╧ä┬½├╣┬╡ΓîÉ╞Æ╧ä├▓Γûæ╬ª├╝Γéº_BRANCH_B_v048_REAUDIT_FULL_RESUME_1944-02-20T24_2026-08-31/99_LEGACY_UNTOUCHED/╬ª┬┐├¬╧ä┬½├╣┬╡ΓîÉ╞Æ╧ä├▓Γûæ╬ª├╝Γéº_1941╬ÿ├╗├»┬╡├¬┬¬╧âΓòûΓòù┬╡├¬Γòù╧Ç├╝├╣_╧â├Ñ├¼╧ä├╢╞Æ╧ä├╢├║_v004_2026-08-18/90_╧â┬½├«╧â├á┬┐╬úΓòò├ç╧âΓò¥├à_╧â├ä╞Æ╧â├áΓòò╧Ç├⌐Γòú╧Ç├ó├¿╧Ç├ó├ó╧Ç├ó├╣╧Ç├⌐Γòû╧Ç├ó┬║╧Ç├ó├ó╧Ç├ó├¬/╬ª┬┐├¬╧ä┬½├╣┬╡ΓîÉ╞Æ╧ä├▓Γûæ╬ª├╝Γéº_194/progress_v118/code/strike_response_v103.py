#!/usr/bin/env python3
from __future__ import annotations
import math
import numpy as np
import air_microcombat_v102 as geom
from strike_damage_v102 import load_attack_types, _burst, _rear
base=geom.base

# B-priors for non-fighter strike-aircraft defensive response. These are not claims of
# measured instantaneous turn performance; they encode short jinks and recovery cost.
RESP={
 'SBD5': dict(warn=(.74,.58,.30), immediate=.82, lat_imp=7.2, vert_imp=2.5, hdg_imp_deg=3.8, tau=15.0, ready_hdg=11.0, ready_y=260.0, ready_z=120.0),
 'TBF1C':dict(warn=(.82,.64,.32), immediate=.78, lat_imp=5.8, vert_imp=1.9, hdg_imp_deg=3.0, tau=19.0, ready_hdg=7.5, ready_y=190.0, ready_z=90.0),
 'SB2C1C':dict(warn=(.77,.60,.31), immediate=.80, lat_imp=6.5, vert_imp=2.2, hdg_imp_deg=3.4, tau=17.0, ready_hdg=9.5, ready_y=230.0, ready_z=105.0),
 'B6N2':dict(warn=(.80,.62,.31), immediate=.79, lat_imp=6.0, vert_imp=2.0, hdg_imp_deg=3.1, tau=18.0, ready_hdg=8.0, ready_y=205.0, ready_z=95.0),
 'D4Y2':dict(warn=(.75,.57,.28), immediate=.82, lat_imp=7.4, vert_imp=2.5, hdg_imp_deg=3.9, tau=15.5, ready_hdg=10.5, ready_y=245.0, ready_z=110.0),
}

def wrap(a): return (a+np.pi)%(2*np.pi)-np.pi

def _aspect(target_hdg,bearing_shooter_to_target):
    d=abs(float(wrap((bearing_shooter_to_target+np.pi)-target_hdg)))
    if d<math.radians(60): return 2
    if d>math.radians(120): return 0
    return 1

def _event_arrays(m):
    return (np.asarray(m['trial_package_pass_cycle']),np.asarray(m['trial_package_pass_target_index']),
            np.asarray(m['trial_package_pass_range_m']),np.asarray(m['trial_package_pass_horizontal_range_m']),
            np.asarray(m['trial_package_pass_bearing_rad']),np.asarray(m['trial_package_pass_heading_rad']),
            np.asarray(m['trial_package_pass_alt_m']),np.asarray(m['trial_package_pass_gamma_rad']),
            np.asarray(m['trial_package_pass_quality']),np.asarray(m['trial_package_pass_threat']))

def simulate_strike_response(m,jp,at,weapons,effects,seed=1,escort_aim_suppression=.55,gunner_feedback=True):
    """Convert physical CAP attack-pass events into target damage + strike-formation response.

    The fighter geometry is kept from v0.10.2. Strike aircraft can now jink away from the
    rigid base position; accumulated lateral/vertical/heading offsets can spoil later passes.
    Delivery-ready is a setup-state metric, not weapon-hit probability.
    """
    rng=np.random.default_rng(seed); n=len(m['trial_package_passes']);N=m['N'];K=int(m.get('package_aircraft_count',12));dt=2.5
    cy,tg,rr0,hr0,bear0,cap_hdg,cap_alt,cap_gamma,qstored,threat=_event_arrays(m)
    states=[base._state(n) for _ in range(K)];caps=[base._state(n) for _ in range(N)]
    # Relative deviations from rigid formation track, world-y/world-z and heading from package heading pi.
    y=np.zeros((n,K)); z=np.zeros((n,K)); vy=np.zeros((n,K)); vz=np.zeros((n,K)); hd=np.zeros((n,K)); ev_timer=np.zeros((n,K),np.int16)
    rpar=RESP[at.id]
    events=[]
    for tr in range(n):
      for fi in range(N):
       for kk in range(cy.shape[2]):
        if cy[tr,fi,kk]>=0: events.append((int(cy[tr,fi,kk]),tr,fi,kk))
    events.sort(); ep=0; clean=np.zeros(n,int); spoiled=np.zeros(n,int); warned=np.zeros(n,int); rdtotal=np.zeros(n,int);hits=np.zeros(n,int);gb=np.zeros(n,int);gh=np.zeros(n,int);targeted=np.zeros((n,K),int)
    # delivery cycle based on package centre transit
    delivery=int(math.ceil((m.get('package_start_x',4800)-m.get('package_target_x',-4500))/(m.get('package_speed_kmh',300)/3.6)/dt))
    last=max(delivery,max([x[0] for x in events],default=-1)+3)
    for c in range(last+1):
      # Damage progression.
      for st in states:
        ix=np.where(~st['mission'])[0]
        if len(ix): base.evolve_damage(st,at.defense,ix,rng)
      for st in caps:
        ix=np.where(~st['mission'])[0]
        if len(ix): base.evolve_damage(st,jp,ix,rng)
      # Kinematic response and recovery toward formation. Damaged aircraft recover more slowly and drift more.
      for k,st in enumerate(states):
        alive=~st['mission']; dmg=base.damage_summary(st)
        active=(ev_timer[:,k]>0)&alive
        # During a jink, retain velocity/heading deviation; otherwise damp back toward formation.
        tau=np.maximum(7.0,rpar['tau']*(1+.9*dmg))
        rec=np.exp(-dt/tau)
        vy[:,k]*=np.where(active,.92,rec); vz[:,k]*=np.where(active,.90,rec); hd[:,k]*=np.where(active,.94,rec)
        # Damage-induced inability to hold station.
        drift=rng.normal(0,0.50+1.7*dmg,n)*dt
        vy[:,k]+=np.where(alive,drift,0)
        y[:,k]+=vy[:,k]*dt; z[:,k]+=vz[:,k]*dt
        # Weak restoring acceleration after the immediate evasion has ended.
        restore=(~active)&alive
        vy[:,k]+=np.where(restore,-y[:,k]/np.maximum(18.0,tau*2.1)*dt,0)
        vz[:,k]+=np.where(restore,-z[:,k]/np.maximum(14.0,tau*1.8)*dt,0)
        ev_timer[:,k]=np.maximum(0,ev_timer[:,k]-1)
      # Resolve events at this cycle using target's displaced position.
      while ep<len(events) and events[ep][0]==c:
        _,tr,fi,kk=events[ep]; ep+=1; t=int(tg[tr,fi,kk]);
        if t<0 or t>=K: continue
        targeted[tr,t]+=1
        # Reconstruct original horizontal LOS and then move the target by current lateral displacement.
        hr=float(hr0[tr,fi,kk]); b=float(bear0[tr,fi,kk]); sh=float(cap_hdg[tr,fi,kk]);
        dx=hr*math.cos(b); dy=hr*math.sin(b)+float(y[tr,t]); hrn=max(1.0,math.hypot(dx,dy)); bn=math.atan2(dy,dx)
        dz0=math.tan(float(np.asarray(m['trial_package_pass_vertical_error_rad'])[tr][fi][kk])+float(cap_gamma[tr,fi,kk]))*hr if False else 0.0
        # Original target altitude is package_alt + fixed formation z offset; infer vertical LOS from shooter/known target.
        # Offsets are deterministic by target index and same helper as fighter geometry.
        off=geom._package_offsets(K)[t]; target_alt=float(m.get('package_alt_m',2800))+float(off[2])+float(z[tr,t]); dz=target_alt-float(cap_alt[tr,fi,kk])
        rr=math.hypot(hrn,dz); rel=float(wrap(bn-sh)); vang=math.atan2(dz,hrn); verr=abs(float(wrap(vang-float(cap_gamma[tr,fi,kk]))))
        target_hdg=math.pi+float(hd[tr,t]); asp=_aspect(target_hdg,bn)
        normal=(asp!=2 and rr<520 and abs(rel)<math.radians(11.5)); front=(asp==2 and rr<300 and abs(rel)<math.radians(6.0)); valid=(normal or front) and verr<math.radians(13.0)
        # Preserve v0.10.2 escort-suppression realization by recovering its multiplicative factor.
        oldr=max(1.0,float(rr0[tr,fi,kk])); oldalign=float(np.asarray(m['trial_package_pass_align'])[tr][fi][kk]); oldq=max(.02,min(1.5,(520-oldr)/320+.55*(oldalign-.96)/.04)); sup=float(np.clip(float(qstored[tr,fi,kk])/oldq,.15,1.05))
        q=max(0.0,min(1.5,(520-rr)/320+.55*(math.cos(rel)-.96)/.04))*sup
        # Warning/reaction. Rear/beam crewed aircraft see more of the attack; front snap attacks give less time.
        p_warn=rpar['warn'][asp]
        if ev_timer[tr,t]>0: p_warn=max(p_warn,.94)
        # Nearby attacks on the same package create formation warning.
        if targeted[tr].sum()>1: p_warn=min(.98,p_warn+.06)
        saw=rng.random()<p_warn
        if saw:
            warned[tr]+=1; side=-1 if rng.random()<.5 else 1
            scale=float(rng.uniform(.78,1.22)); vy[tr,t]+=side*rpar['lat_imp']*scale; vz[tr,t]+=rng.normal(0,rpar['vert_imp']); hd[tr,t]+=math.radians(side*rpar['hdg_imp_deg']*scale); ev_timer[tr,t]=max(ev_timer[tr,t],int(rng.integers(3,6)))
            q*=rpar['immediate']
        if (not valid) or q<=.08 or states[t]['mission'][tr]:
            spoiled[tr]+=1
        else:
            # Current-pass aim can be disrupted even without enough displacement to geometrically spoil it.
            firep=float(np.clip(.52+.42*(q/1.25),.42,.95))
            if rng.random()<firep:
                rd,hh=_burst(jp,at.defense,weapons,effects,states[t],tr,q,rr,asp,rng,at.size_factor);clean[tr]+=1;rdtotal[tr]+=rd;hits[tr]+=hh
        # Rear gunner can fire if geometry permits; this also strengthens warning but does not retroactively spoil the pass.
        rd,hh,fired=_rear(at,jp,weapons,effects,caps[fi],tr,rr,asp,rng)
        if fired: gb[tr]+=1
        gh[tr]+=hh
    mission=np.stack([st['mission'] for st in states],1);dam=np.stack([base.damage_summary(st) for st in states],1)
    alive=~mission
    # Delivery setup state: track/formation tolerances differ by mission type. This is not bomb/torpedo hit chance.
    hddeg=np.abs(np.rad2deg(hd)); yy=np.abs(y); zz=np.abs(z); active_ev=ev_timer>0
    ready=alive&(hddeg<rpar['ready_hdg'])&(yy<rpar['ready_y'])&(zz<rpar['ready_z'])&(~active_ev)&(dam<.48)
    degraded=alive&(~ready)&(hddeg<1.8*rpar['ready_hdg'])&(yy<1.8*rpar['ready_y'])&(zz<1.8*rpar['ready_z'])&(dam<.65)
    notready=alive&(~ready)&(~degraded)
    # Formation cohesion scalar from surviving aircraft deviations.
    coh=[]
    for tr in range(n):
      aa=alive[tr]
      if aa.sum()<2: coh.append(0.0); continue
      ry=float(np.sqrt(np.mean(y[tr,aa]**2))); rz=float(np.sqrt(np.mean(z[tr,aa]**2))); rh=float(np.sqrt(np.mean(hddeg[tr,aa]**2)))
      coh.append(float(np.exp(-.45*ry/220-.35*rz/100-.40*rh/9.0)))
    return {
      'model':'strike-response-v0.10.3','target_type':at.id,'ntr':n,'package_count':K,
      'mean_physical_passes':float(np.mean(m['trial_package_passes'])),'mean_clean_bursts':float(clean.mean()),'mean_spoiled_passes_by_evasion':float(spoiled.mean()),'mean_warning_reactions':float(warned.mean()),
      'mean_attackers_mission_lost':float(mission.sum(1).mean()),'mean_delivery_ready':float(ready.sum(1).mean()),'mean_delivery_degraded':float(degraded.sum(1).mean()),'mean_alive_not_ready':float(notready.sum(1).mean()),
      'mean_damaged_delivery_ready':float((ready&(dam>.08)).sum(1).mean()),'mean_formation_cohesion':float(np.mean(coh)),
      'mean_rms_lateral_m':float(np.mean(np.sqrt(np.mean(y*y,axis=1)))),'mean_rms_vertical_m':float(np.mean(np.sqrt(np.mean(z*z,axis=1)))),'mean_rms_heading_deg':float(np.mean(np.sqrt(np.mean(hddeg*hddeg,axis=1)))),
      'mean_japanese_rounds':float(rdtotal.mean()),'mean_japanese_hits':float(hits.mean()),'mean_gunner_bursts':float(gb.mean()),'mean_gunner_hits':float(gh.mean()),
      'mean_CAP_mission_losses_from_gunners':float(np.stack([st['mission'] for st in caps],1).sum(1).mean()),
      'response_priors':rpar.copy()
    }
