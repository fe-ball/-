#!/usr/bin/env python3
from __future__ import annotations
import math
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple
import numpy as np

# v0.11.8 candidate — sortie regeneration layer.
# All absolute handling/service values below are B-priors. Structural logic is bound by r30:
# damage affects launch/recovery capacity; Japanese carrier operations are modeled as
# recovery -> elevator/deck handling -> fuel/arm/service -> respot -> next launch.

AIRCRAFT_TYPES = ("F", "DB", "TB")
HORIZONS_MIN = (30, 60, 120)

@dataclass(frozen=True)
class CarrierOpsProfile:
    profile_id: str
    base_launch_rate_ac_min: float
    base_recovery_rate_ac_min: float
    service_slots: int
    deck_spot_overhead_min: float
    launch_window_min: float
    overnight_repair_slots: int

OPS_PROFILES: Dict[str, CarrierOpsProfile] = {
    # B-priors: throughput/crew values, not historical measurements.
    "UNRYU_R30_WORK": CarrierOpsProfile("UNRYU_R30_WORK", 1.35, 0.72, 10, 11.0, 16.0, 8),
    "SHOKAKU_R30_WORK": CarrierOpsProfile("SHOKAKU_R30_WORK", 1.55, 0.82, 12, 10.0, 16.0, 10),
    "TAIHO_R30_WORK": CarrierOpsProfile("TAIHO_R30_WORK", 1.45, 0.78, 12, 10.5, 16.0, 10),
}

@dataclass
class AirGroupState:
    # aboard ready at t=0
    ready: Dict[str, int]
    # already in routine turnaround queue at t=0
    service: Dict[str, int]
    # returning from a previous mission, ETA minutes from t=0
    returning: Dict[str, List[float]]
    # damaged but potentially repairable aboard/after recovery
    damaged: Dict[str, int]
    # immediately available qualified pilots/crews by type
    pilots: Dict[str, int]
    # sortie-equivalent fuel and ammunition stocks by type
    fuel_sorties: Dict[str, float]
    ammo_sorties: Dict[str, float]
    # fatigue multiplier on effective pilot pool (1.0 = fresh)
    pilot_fatigue_factor: Dict[str, float]

def benchmark_airgroup() -> AirGroupState:
    """72-aircraft generic fleet-carrier post-strike/CAP benchmark.
    This is a diagnostic state, not a historical air-group claim.
    """
    return AirGroupState(
        ready={"F":14, "DB":8, "TB":7},
        service={"F":6, "DB":3, "TB":4},
        returning={
            "F":[8.0, 10.0, 12.0, 14.0, 16.0, 18.0, 20.0, 22.0],
            "DB":[12.0, 13.5, 15.0, 16.5, 18.0, 19.5, 21.0, 22.5],
            "TB":[14.0, 15.5, 17.0, 18.5, 20.0, 21.5, 23.0, 24.5],
        },
        damaged={"F":2, "DB":2, "TB":2},
        pilots={"F":28, "DB":19, "TB":19},
        fuel_sorties={"F":26.0, "DB":18.0, "TB":18.0},
        ammo_sorties={"F":28.0, "DB":18.0, "TB":18.0},
        pilot_fatigue_factor={"F":0.92, "DB":0.88, "TB":0.88},
    )

CENTER_SERVICE_MIN = {"F":28.0, "DB":43.0, "TB":49.0}
SERVICE_SIGMA = {"F":0.22, "DB":0.25, "TB":0.27}
DAMAGED_REPAIR_MEDIAN_MIN = {"F":125.0, "DB":150.0, "TB":165.0}
DAMAGED_REPAIR_SIGMA = {"F":0.45, "DB":0.48, "TB":0.50}

def _sample_lognormal(rng: np.random.Generator, median: float, sigma: float, n: int) -> np.ndarray:
    if n <= 0:
        return np.empty(0)
    return rng.lognormal(mean=math.log(median), sigma=sigma, size=n)

def _service_queue_completion(
    rng: np.random.Generator,
    arrivals: List[Tuple[float,str,bool]],
    slots: int,
    service_scale: float,
    maintenance_capacity: float,
) -> List[Tuple[float,str]]:
    """FCFS parallel-server queue. Returns ready-time/type for aircraft entering service."""
    eff_slots=max(1, int(round(slots * max(0.15, maintenance_capacity))))
    servers=np.zeros(eff_slots, dtype=float)
    out=[]
    for arrival, typ, damaged in sorted(arrivals, key=lambda x:x[0]):
        j=int(np.argmin(servers))
        start=max(float(arrival), float(servers[j]))
        if damaged:
            dur=float(_sample_lognormal(rng, DAMAGED_REPAIR_MEDIAN_MIN[typ]*service_scale, DAMAGED_REPAIR_SIGMA[typ],1)[0])
        else:
            dur=float(_sample_lognormal(rng, CENTER_SERVICE_MIN[typ]*service_scale, SERVICE_SIGMA[typ],1)[0])
        finish=start+dur
        servers[j]=finish
        out.append((finish,typ))
    return out

def simulate_sortie_regeneration(
    profile_id: str,
    launch_capacity: float,
    recovery_capacity: float,
    state: AirGroupState | None = None,
    n: int = 5000,
    seed: int = 11801,
    service_scale: float = 1.0,
    maintenance_capacity: float = 1.0,
    deck_cycle_scale: float = 1.0,
    horizons_min: tuple[int,...] = HORIZONS_MIN,
):
    """Monte Carlo next-wave availability conditional on carrier capacities.

    launch_capacity/recovery_capacity are normalized [0,1] outputs from v0.11.7.
    Output package sizes are aircraft that can be spotted and launched in the
    profile's launch window beginning at each horizon.
    """
    if state is None:
        state=benchmark_airgroup()
    ops=OPS_PROFILES[profile_id]
    rng=np.random.default_rng(seed)
    Larr=np.asarray(launch_capacity,dtype=float).reshape(-1) if np.ndim(launch_capacity) else np.asarray([launch_capacity],dtype=float)
    Rarr=np.asarray(recovery_capacity,dtype=float).reshape(-1) if np.ndim(recovery_capacity) else np.asarray([recovery_capacity],dtype=float)
    Larr=np.clip(Larr,0,1); Rarr=np.clip(Rarr,0,1)
    if len(Larr) != len(Rarr) and len(Larr) != 1 and len(Rarr) != 1:
        raise ValueError("launch_capacity and recovery_capacity arrays must have equal length or be scalar")

    rows=[]
    # fixed immediately-ready inventory, constrained later by pilots/fuel/ammo
    base_ready={k:int(state.ready.get(k,0)) for k in AIRCRAFT_TYPES}

    for sim in range(n):
        # Sample a conditional v0.11.7 carrier state when capacity arrays are supplied.
        if len(Larr)==1 and len(Rarr)==1:
            L=float(Larr[0]); R=float(Rarr[0])
        else:
            m=max(len(Larr),len(Rarr)); idx=int(rng.integers(0,m))
            L=float(Larr[idx if len(Larr)>1 else 0]); R=float(Rarr[idx if len(Rarr)>1 else 0])

        # Recovery queue: one deck, FCFS after each aircraft ETA. Very low recovery capacity
        # may make returners unable to get aboard within the 120-min horizon.
        rec_events=[]
        next_deck_free=0.0
        if R > 1e-5:
            rec_spacing=1.0/(ops.base_recovery_rate_ac_min*R)
            # Global FCFS by ETA across aircraft types. v0.11.8-WIP initially iterated
            # type-by-type, which biased service-queue entry order.
            return_queue=sorted(
                (float(eta),typ)
                for typ in AIRCRAFT_TYPES
                for eta in state.returning.get(typ,[])
            )
            for eta,typ in return_queue:
                land=max(eta, next_deck_free)
                next_deck_free=land+rec_spacing
                rec_events.append((land,typ,False))
        # pre-existing routine service aircraft enter at t=0
        service_arrivals=[]
        for typ in AIRCRAFT_TYPES:
            service_arrivals += [(0.0,typ,False)]*int(state.service.get(typ,0))
        # recovered returners require turnaround
        service_arrivals += rec_events
        # damaged aircraft go into a longer repair queue
        for typ in AIRCRAFT_TYPES:
            service_arrivals += [(0.0,typ,True)]*int(state.damaged.get(typ,0))

        ready_events=_service_queue_completion(
            rng, service_arrivals, ops.service_slots,
            service_scale=service_scale, maintenance_capacity=maintenance_capacity
        )

        # Estimate recovery blockage: next strike cannot spot until returning cycle is clear.
        recovery_clear=float(next_deck_free) if rec_events else 0.0
        for H in horizons_min:
            # ready by horizon, by type
            ready_counts={k:base_ready[k] for k in AIRCRAFT_TYPES}
            for finish,typ in ready_events:
                if finish <= H:
                    ready_counts[typ]+=1

            # crew/fuel/ammo constraints
            constrained={}
            for typ in AIRCRAFT_TYPES:
                pilot_cap=int(math.floor(state.pilots.get(typ,0)*state.pilot_fatigue_factor.get(typ,1.0)))
                stock_cap=int(math.floor(min(state.fuel_sorties.get(typ,0.0), state.ammo_sorties.get(typ,0.0))))
                constrained[typ]=max(0,min(ready_counts[typ],pilot_cap,stock_cap))

            # Full next-wave launch is recovery-first in this benchmark.
            # The deck becomes available after the return cycle, then requires spotting overhead.
            # "next_wave_* at H" means aircraft that can actually be launched by H minutes from t=0.
            if L > 1e-5:
                spot=recovery_clear+ops.deck_spot_overhead_min*deck_cycle_scale/max(0.20,L)
                launch_rate=ops.base_launch_rate_ac_min*L
                launch_time=max(0.0, H-spot)
                launch_slots=max(0,int(math.floor(launch_rate*launch_time)))
            else:
                spot=float("nan")
                launch_rate=0.0
                launch_slots=0
            # package allocation: preserve fighter cover, then split attack slots proportional
            # to attack aircraft readiness. This is a diagnostic policy, not tactical doctrine.
            f=min(constrained["F"], max(0,int(round(launch_slots*0.34))))
            remain=max(0,launch_slots-f)
            atk_total=constrained["DB"]+constrained["TB"]
            if atk_total>0:
                db=min(constrained["DB"],int(round(remain*constrained["DB"]/atk_total)))
                tb=min(constrained["TB"],remain-db)
                # use any rounding/availability remainder
                used=f+db+tb
                extra=launch_slots-used
                if extra>0:
                    add=min(extra,constrained["DB"]-db);db+=add;extra-=add
                if extra>0:
                    add=min(extra,constrained["TB"]-tb);tb+=add;extra-=add
                if extra>0:
                    add=min(extra,constrained["F"]-f);f+=add;extra-=add
            else:
                db=tb=0
                f=min(constrained["F"],launch_slots)

            recovered_by_H={k:0 for k in AIRCRAFT_TYPES}
            for land,typ,_ in rec_events:
                if land<=H: recovered_by_H[typ]+=1

            # sustainable CAP: aircraft that can support roughly one more 90-min CAP cycle
            # within 120m, limited by pilots/stocks and launch throughput.
            cap_pool=constrained["F"]
            cap_sustain=min(cap_pool, launch_slots)

            rows.append({
                "sim":sim,"horizon_min":H,
                "recovery_clear_min":recovery_clear,
                "spot_complete_min":spot,
                "recovered_F":recovered_by_H["F"],"recovered_DB":recovered_by_H["DB"],"recovered_TB":recovered_by_H["TB"],
                "ready_F":constrained["F"],"ready_DB":constrained["DB"],"ready_TB":constrained["TB"],
                "next_wave_F":f,"next_wave_DB":db,"next_wave_TB":tb,
                "next_wave_total":f+db+tb,
                "cap_sustainable":cap_sustain,
            })
    return rows


def _interp_cumulative(tgrid: np.ndarray, cum: np.ndarray, t: float) -> float:
    if t <= tgrid[0]: return float(cum[0])
    if t >= tgrid[-1]: return float(cum[-1])
    return float(np.interp(t, tgrid, cum))

def _invert_cumulative(tgrid: np.ndarray, cum: np.ndarray, target: float) -> float:
    """First time cumulative recovery work reaches target; inf if unreachable."""
    if target > float(cum[-1]) + 1e-12: return float("inf")
    j=int(np.searchsorted(cum,target,side="left"))
    if j <= 0: return float(tgrid[0])
    c0=float(cum[j-1]); c1=float(cum[j]); t0=float(tgrid[j-1]); t1=float(tgrid[j])
    if c1 <= c0 + 1e-12: return t1
    return t0+(target-c0)*(t1-t0)/(c1-c0)

def _dynamic_recovery_queue(state: AirGroupState, ops: CarrierOpsProfile,
                            tgrid_min: np.ndarray, recovery_curve: np.ndarray):
    """FCFS recovery under time-varying capacity.

    Capacity cannot be banked while the deck is closed. Each recovery consumes one aircraft
    of integrated deck throughput. Service entry is timestamped at the first usable deck time
    for that aircraft; deck clearance uses completion of its throughput quantum.
    """
    tgrid=np.asarray(tgrid_min,dtype=float)
    cap=np.clip(np.asarray(recovery_curve,dtype=float),0,1)
    if tgrid.ndim != 1 or cap.ndim != 1 or len(tgrid)!=len(cap):
        raise ValueError("recovery timeline must be 1-D and aligned")
    rate=ops.base_recovery_rate_ac_min*cap
    cum=np.zeros(len(tgrid),dtype=float)
    if len(tgrid)>1:
        dt=np.diff(tgrid)
        cum[1:]=np.cumsum(.5*(rate[:-1]+rate[1:])*dt)
    queue=sorted((float(eta),typ) for typ in AIRCRAFT_TYPES for eta in state.returning.get(typ,[]))
    out=[]; next_free=float(tgrid[0])
    for eta,typ in queue:
        earliest=max(eta,next_free)
        if earliest > tgrid[-1]: return out,float("inf")
        # If capacity is already positive, begin at the exact earliest time rather than
        # rounding every aircraft to the timeline grid. If closed, advance to first usable sample.
        if float(np.interp(earliest,tgrid,cap)) > 1e-5:
            start=earliest
        else:
            j=int(np.searchsorted(tgrid,earliest,side="left"))
            while j < len(tgrid) and cap[j] <= 1e-5: j+=1
            if j >= len(tgrid): return out,float("inf")
            start=float(tgrid[j])
        c0=_interp_cumulative(tgrid,cum,start)
        finish=_invert_cumulative(tgrid,cum,c0+1.0)
        if not np.isfinite(finish): return out,float("inf")
        out.append((start,typ,False))
        next_free=finish
    return out,next_free

def simulate_sortie_regeneration_dynamic(
    profile_id: str,
    timeline_min,
    launch_capacity_curve,
    recovery_capacity_curve,
    state: AirGroupState | None = None,
    n: int = 5000,
    seed: int = 11801,
    service_scale: float = 1.0,
    maintenance_capacity: float = 1.0,
    deck_cycle_scale: float = 1.0,
    horizon_min: int = 120,
):
    """Sortie regeneration with per-trial time-varying deck capacity.

    Both recovery and launch/spotting consume non-bankable integrated deck work. This is
    specifically intended for latent damage states where a flight deck can remain closed
    for part of the interval and reopen later.
    """
    if state is None: state=benchmark_airgroup()
    ops=OPS_PROFILES[profile_id]; rng=np.random.default_rng(seed)
    tgrid=np.asarray(timeline_min,dtype=float).reshape(-1)
    Lcurves=np.asarray(launch_capacity_curve,dtype=float)
    Rcurves=np.asarray(recovery_capacity_curve,dtype=float)
    if Lcurves.ndim==1: Lcurves=Lcurves.reshape(1,-1)
    if Rcurves.ndim==1: Rcurves=Rcurves.reshape(1,-1)
    if Lcurves.shape[1]!=len(tgrid) or Rcurves.shape[1]!=len(tgrid):
        raise ValueError("curve/time dimension mismatch")
    m=max(Lcurves.shape[0],Rcurves.shape[0])
    if Lcurves.shape[0] not in (1,m) or Rcurves.shape[0] not in (1,m):
        raise ValueError("trial dimensions must align or be scalar")
    Lcurves=np.clip(Lcurves,0,1); Rcurves=np.clip(Rcurves,0,1)

    base_ready={k:int(state.ready.get(k,0)) for k in AIRCRAFT_TYPES}; rows=[]; H=int(horizon_min)
    for sim in range(n):
        idx=0 if m==1 else int(rng.integers(0,m))
        Lcurve=Lcurves[idx if Lcurves.shape[0]>1 else 0]
        Rcurve=Rcurves[idx if Rcurves.shape[0]>1 else 0]
        rec_events,recovery_clear=_dynamic_recovery_queue(state,ops,tgrid,Rcurve)

        service_arrivals=[]
        for typ in AIRCRAFT_TYPES: service_arrivals += [(0.0,typ,False)]*int(state.service.get(typ,0))
        service_arrivals += rec_events
        for typ in AIRCRAFT_TYPES: service_arrivals += [(0.0,typ,True)]*int(state.damaged.get(typ,0))
        ready_events=_service_queue_completion(rng,service_arrivals,ops.service_slots,service_scale,maintenance_capacity)

        ready_counts={k:base_ready[k] for k in AIRCRAFT_TYPES}
        for finish,typ in ready_events:
            if finish <= H: ready_counts[typ]+=1
        constrained={}
        for typ in AIRCRAFT_TYPES:
            pilot_cap=int(math.floor(state.pilots.get(typ,0)*state.pilot_fatigue_factor.get(typ,1.0)))
            stock_cap=int(math.floor(min(state.fuel_sorties.get(typ,0.0),state.ammo_sorties.get(typ,0.0))))
            constrained[typ]=max(0,min(ready_counts[typ],pilot_cap,stock_cap))

        # Build cumulative launch/deck work; prior unused capacity is never banked because
        # every operation subtracts cumulative work at its own start time.
        Lrate=np.asarray(Lcurve,dtype=float)
        Lcum=np.zeros(len(tgrid),dtype=float)
        if len(tgrid)>1:
            dt=np.diff(tgrid); Lcum[1:]=np.cumsum(.5*(Lrate[:-1]+Lrate[1:])*dt)
        if np.isfinite(recovery_clear) and recovery_clear <= H:
            c0=_interp_cumulative(tgrid,Lcum,recovery_clear)
            spot_target=c0+ops.deck_spot_overhead_min*deck_cycle_scale
            spot=_invert_cumulative(tgrid,Lcum,spot_target)
            if np.isfinite(spot) and spot <= H:
                launch_work=max(0.0,_interp_cumulative(tgrid,Lcum,H)-_interp_cumulative(tgrid,Lcum,spot))
                launch_slots=max(0,int(math.floor(ops.base_launch_rate_ac_min*launch_work)))
            else:
                launch_slots=0
        else:
            spot=float("inf"); launch_slots=0

        f=min(constrained["F"],max(0,int(round(launch_slots*.34))))
        remain=max(0,launch_slots-f); atk_total=constrained["DB"]+constrained["TB"]
        if atk_total>0:
            db=min(constrained["DB"],int(round(remain*constrained["DB"]/atk_total)))
            tb=min(constrained["TB"],remain-db); extra=launch_slots-(f+db+tb)
            if extra>0: add=min(extra,constrained["DB"]-db);db+=add;extra-=add
            if extra>0: add=min(extra,constrained["TB"]-tb);tb+=add;extra-=add
            if extra>0: add=min(extra,constrained["F"]-f);f+=add;extra-=add
        else:
            db=tb=0; f=min(constrained["F"],launch_slots)
        recovered_by_H={k:0 for k in AIRCRAFT_TYPES}
        for land,typ,_ in rec_events:
            if land<=H: recovered_by_H[typ]+=1
        rows.append({
            "sim":sim,"horizon_min":H,"recovery_clear_min":recovery_clear,"spot_complete_min":spot,
            "recovered_F":recovered_by_H["F"],"recovered_DB":recovered_by_H["DB"],"recovered_TB":recovered_by_H["TB"],
            "ready_F":constrained["F"],"ready_DB":constrained["DB"],"ready_TB":constrained["TB"],
            "next_wave_F":f,"next_wave_DB":db,"next_wave_TB":tb,"next_wave_total":f+db+tb,
            "cap_sustainable":min(constrained["F"],launch_slots),
        })
    return rows


def summarize(rows):
    import pandas as pd
    df=pd.DataFrame(rows)
    out=[]
    for H,g in df.groupby("horizon_min"):
        r={"horizon_min":int(H)}
        for c in ["recovery_clear_min","spot_complete_min","ready_F","ready_DB","ready_TB",
                  "next_wave_F","next_wave_DB","next_wave_TB","next_wave_total","cap_sustainable"]:
            r[c+"_mean"]=float(g[c].mean())
            if c in ("recovery_clear_min","spot_complete_min"):
                # rank-based quantiles avoid inf-inf interpolation warnings when a fraction
                # of trials cannot clear the recovery cycle inside the horizon.
                a=np.sort(g[c].to_numpy(dtype=float)); m=len(a)
                q=lambda x: float(a[min(m-1,max(0,int(math.ceil(x*m)-1)))])
                r[c+"_p10"]=q(.10); r[c+"_p50"]=q(.50); r[c+"_p90"]=q(.90)
            else:
                r[c+"_p10"]=float(g[c].quantile(.10))
                r[c+"_p50"]=float(g[c].quantile(.50))
                r[c+"_p90"]=float(g[c].quantile(.90))
        wave=g["next_wave_total"].to_numpy(dtype=float)
        r["p_any_next_wave"]=float((wave>0).mean())
        for k in (12,24,36,48): r[f"p_next_wave_ge_{k}"]=float((wave>=k).mean())
        r["p_recovery_cycle_cleared"]=float(np.isfinite(g["recovery_clear_min"].to_numpy(dtype=float)).mean())
        out.append(r)
    return out
