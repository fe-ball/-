#!/usr/bin/env python3
from pathlib import Path
import sys, csv
import numpy as np
R=Path(__file__).parent; sys.path.insert(0,str(R))
from carrier_damage_continuous_v118 import sample_damage_state, evaluate_capacities
from sortie_regeneration_v118 import simulate_sortie_regeneration_dynamic, summarize, benchmark_airgroup, HORIZONS_MIN

def capacity_timeline(latent,start_h,horizon_min,step_min=.5):
    H=float(horizon_min); tmin=np.arange(0.0,H+step_min*.5,step_min,dtype=float)
    if tmin[-1]<H: tmin=np.append(tmin,H)
    else: tmin[-1]=H
    if latent is None:
        ones=np.ones((1,len(tmin)),dtype=float); return tmin,ones,ones.copy()
    ls=[]; rs=[]
    for tm in tmin:
        L,Rc=evaluate_capacities(latent,start_h+tm/60.0)
        ls.append(np.asarray(L,dtype=np.float32)); rs.append(np.asarray(Rc,dtype=np.float32))
    return tmin,np.stack(ls,axis=1),np.stack(rs,axis=1)

def run_case(case,profile,bombs,torps,damage_time_h,n_damage=6000,n_sortie=1800,seed=11811):
    latent=None if (bombs==0 and torps==0) else sample_damage_state(profile,bombs,torps,n=n_damage,seed=seed)
    out=[]
    for H in HORIZONS_MIN:
        tgrid,Lcurve,Rcurve=capacity_timeline(latent,damage_time_h,H)
        rows=simulate_sortie_regeneration_dynamic(profile,tgrid,Lcurve,Rcurve,state=benchmark_airgroup(),n=n_sortie,
                                                  seed=seed+H*17,horizon_min=H)
        r=summarize(rows)[0]
        out.append({"case":case,"profile":profile,"bomb_hits":bombs,"torpedo_hits":torps,"damage_time_h":damage_time_h,**r})
    return out

def main():
    cases=[
        ("UNDAMAGED_SHOKAKU","SHOKAKU_R30_WORK",0,0,0.0),
        ("UNRYU_1B_0H","UNRYU_R30_WORK",1,0,0.0),("UNRYU_1B_2H","UNRYU_R30_WORK",1,0,2.0),("UNRYU_1B_6H","UNRYU_R30_WORK",1,0,6.0),
        ("SHOKAKU_1B_0H","SHOKAKU_R30_WORK",1,0,0.0),("SHOKAKU_1B_6H","SHOKAKU_R30_WORK",1,0,6.0),
        ("TAIHO_1T_0H","TAIHO_R30_WORK",0,1,0.0),("TAIHO_1T_2H","TAIHO_R30_WORK",0,1,2.0),("TAIHO_1T_6H","TAIHO_R30_WORK",0,1,6.0),
        ("TAIHO_1B1T_6H","TAIHO_R30_WORK",1,1,6.0),
    ]
    allrows=[]
    for i,c in enumerate(cases): print("running",c[0],flush=True); allrows+=run_case(*c,seed=11811+i*131)
    outdir=R.parent/"results_current";outdir.mkdir(exist_ok=True);csvpath=outdir/"sortie_regeneration_benchmark_v118.csv"
    with csvpath.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(allrows[0].keys()));w.writeheader();w.writerows(allrows)
    print(csvpath)
    for r in allrows:
        print(r["case"],r["horizon_min"],"wave p10/p50/p90",r["next_wave_total_p10"],r["next_wave_total_p50"],r["next_wave_total_p90"],
              "P(any/24/48)",round(r["p_any_next_wave"],3),round(r["p_next_wave_ge_24"],3),round(r["p_next_wave_ge_48"],3))
if __name__=="__main__": main()
