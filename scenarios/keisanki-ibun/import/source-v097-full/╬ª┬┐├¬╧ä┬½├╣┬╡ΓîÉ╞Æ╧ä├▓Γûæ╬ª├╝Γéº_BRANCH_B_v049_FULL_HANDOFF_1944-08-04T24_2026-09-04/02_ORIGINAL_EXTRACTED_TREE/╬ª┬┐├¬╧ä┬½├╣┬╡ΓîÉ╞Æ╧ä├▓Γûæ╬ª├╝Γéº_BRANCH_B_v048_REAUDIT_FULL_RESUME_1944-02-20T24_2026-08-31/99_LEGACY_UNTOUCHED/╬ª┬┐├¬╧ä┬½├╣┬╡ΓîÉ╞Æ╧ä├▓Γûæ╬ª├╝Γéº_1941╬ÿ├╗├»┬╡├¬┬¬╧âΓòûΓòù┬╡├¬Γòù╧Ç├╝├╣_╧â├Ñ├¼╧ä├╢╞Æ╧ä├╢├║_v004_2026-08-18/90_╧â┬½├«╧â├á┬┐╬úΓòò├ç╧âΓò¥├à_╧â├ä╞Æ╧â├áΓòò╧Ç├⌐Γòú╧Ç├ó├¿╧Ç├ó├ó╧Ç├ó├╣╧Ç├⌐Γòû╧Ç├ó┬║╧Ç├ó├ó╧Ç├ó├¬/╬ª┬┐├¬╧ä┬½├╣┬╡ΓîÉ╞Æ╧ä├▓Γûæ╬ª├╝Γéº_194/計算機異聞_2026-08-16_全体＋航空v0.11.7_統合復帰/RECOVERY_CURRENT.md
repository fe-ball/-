# CURRENT RECOVERY

Primary project canon: `計算機異聞_r30正本/`
Current experiment continuation: `航空ミクロ戦闘_現行_v0.11.7/`

Resume from:
`航空ミクロ戦闘_現行_v0.11.7/RECOVERY_2026-08-16_carrier_mission_damage_v117.md`

Do not resume the old failed integrated historical branch.
Do not discard aircraft/ship heterogeneity by replacing the current model with generic kill ratios.

Next layer: sortie regeneration, then historical reconstruction.
