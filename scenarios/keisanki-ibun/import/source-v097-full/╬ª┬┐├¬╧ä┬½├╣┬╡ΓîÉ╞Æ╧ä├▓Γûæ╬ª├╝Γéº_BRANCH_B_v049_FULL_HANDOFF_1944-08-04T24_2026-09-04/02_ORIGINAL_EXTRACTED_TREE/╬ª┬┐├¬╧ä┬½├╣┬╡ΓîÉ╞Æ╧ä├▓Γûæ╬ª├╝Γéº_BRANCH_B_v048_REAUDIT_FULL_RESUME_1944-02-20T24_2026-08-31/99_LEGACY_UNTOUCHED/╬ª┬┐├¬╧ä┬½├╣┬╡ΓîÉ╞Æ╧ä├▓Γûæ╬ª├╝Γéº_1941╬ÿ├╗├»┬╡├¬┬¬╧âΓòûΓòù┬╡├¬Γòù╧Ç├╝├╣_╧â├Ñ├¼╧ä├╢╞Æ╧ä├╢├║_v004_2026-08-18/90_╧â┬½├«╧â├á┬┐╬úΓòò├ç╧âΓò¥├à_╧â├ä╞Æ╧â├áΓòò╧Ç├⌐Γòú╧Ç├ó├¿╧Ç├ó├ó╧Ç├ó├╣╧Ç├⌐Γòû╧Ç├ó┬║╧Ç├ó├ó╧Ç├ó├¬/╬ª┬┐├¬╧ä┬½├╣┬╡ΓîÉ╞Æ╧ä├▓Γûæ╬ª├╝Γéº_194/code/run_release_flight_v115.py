#!/usr/bin/env python3
from pathlib import Path
import sys,csv,json,math
import numpy as np
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v115 as v
import release_flight_v115 as rf
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP
US=['US02','US04','US07','US09','US13','US14']

def cfg(p,d,target):
    if target=='TBF1C':
        pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
        kw=dict(N=16,active_A=16,active_B=8,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(v._default_centered_y(8))+list(v._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500,package_weapon_release_range_m=750)
    elif target=='SBD5':
        pa=p['JP06'];da=d['JP06'];kw=dict(N=8,active_A=8,active_B=8,hA0=6000,hB0=5100,iasA0=400,iasB0=400,A_initial_x_m=-3100,package_alt_m=5000,package_speed_kmh=300,package_start_x=8000,package_target_x=-4500,package_vector_range_m=10500,package_terminal_profile='dive',package_terminal_alt_m=760,package_terminal_speed_kmh=450,package_transition_start_m=1800,package_transition_end_m=0,package_weapon_release_range_m=None)
    else:
        pa=p['JP06'];da=d['JP06'];kw=dict(N=8,active_A=8,active_B=8,hA0=5600,hB0=4800,iasA0=400,iasB0=400,A_initial_x_m=-3100,package_alt_m=4600,package_speed_kmh=310,package_start_x=8000,package_target_x=-4500,package_vector_range_m=10500,package_terminal_profile='dive',package_terminal_alt_m=760,package_terminal_speed_kmh=460,package_transition_start_m=1800,package_transition_end_m=0,package_weapon_release_range_m=None)
    return pa,da,kw

def run_air(target,us,ntr,seed,ship_policy='auto',screen='akizuki2_yugumo2'):
    p,w,e,d=v.load_all(R);at=load_attack_types(R)[target];pa,da,kw=cfg(p,d,target)
    ev=ship_policy!='none';gpol='auto' if ship_policy=='auto' else (('torpedo_'+ship_policy) if target=='TBF1C' and ship_policy in ('bow','stern') else ship_policy)
    return v.simulate_escort_cap(pa,p[us],da,d[us],w,e,ntr=ntr,seed=seed,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=True,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP[target],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=ev,global_ship_evasion_policy=gpol,global_aa_fire_discipline='center',global_screen_aa=(screen!='none'),global_screen_profile=('akizuki2_yugumo2' if screen=='none' else screen),global_screen_fire_discipline='center',global_screen_ship_motion=True,**kw)

def scaled_bomb_profile(target,scale):
    b=rf.BOMBS[target]
    return rf.BombFlightProfile(b.id+f'_ERRx{scale:.2f}',b.dive_deg,b.time_scale,b.sigma_cross_m*scale,b.sigma_along_m*scale,b.quality_cross_extra_m*scale,b.quality_along_extra_m*scale,b.near_miss_m,b.source_grade)

def flat(target,us,ntr,m,weapon,prior):
    row={'target':target,'US':us,'ntr':ntr,'weapon_prior':prior,'package_passes':m['package_attack_passes'],'clean_bursts':m['package_online_clean_bursts'],'package_mission_loss':m['package_online_mission_losses'],'release_opportunity':m['global_mean_release_opportunity_equivalent'],'delivery_quality':m['global_mean_delivery_quality_at_release'],'screen_heavy_rounds':m.get('screen_mean_heavy_rounds',0),'screen_25mm_rounds':m.get('screen_mean_25mm_rounds',0)}
    for k,val in weapon.items():
        if k.startswith('trial_'):continue
        if isinstance(val,(str,int,float,bool,np.integer,np.floating)):row['weapon_'+k]=val
    return row

def write(path,rows):
    with open(path,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=sorted(set().union(*[r.keys() for r in rows])));w.writeheader();w.writerows(rows)

def main():
    import argparse;ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=2);ap.add_argument('--targets',default='TBF1C,SBD5,SB2C1C');ap.add_argument('--us',default=','.join(US));a=ap.parse_args()
    rows=[]
    for target in a.targets.split(','):
      for us in a.us.split(','):
        seed=11550000+['TBF1C','SBD5','SB2C1C'].index(target)*100000+US.index(us)*2000+a.ntr
        m=run_air(target,us,a.ntr,seed)
        if target=='TBF1C':
            # Common random numbers across reliability/error priors.
            for pr in ['weak','center','strong']:
                wr=rf.simulate_torpedoes(m,seed=seed+811,prior=pr,torpedo_policy='auto');rows.append(flat(target,us,a.ntr,m,wr,pr))
        else:
            for sc in [.75,1.0,1.30]:
                wr=rf.simulate_bombs(m,target,seed=seed+811,profile=scaled_bomb_profile(target,sc));rows.append(flat(target,us,a.ntr,m,wr,f'error_x{sc:.2f}'))
    out=R.parent/'results_current';out.mkdir(exist_ok=True);write(out/'release_flight_lateUS6_raw_v115.csv',rows)
    ag=[]
    for target in a.targets.split(','):
      pri=sorted(set(r['weapon_prior'] for r in rows if r['target']==target))
      for pr in pri:
        rr=[r for r in rows if r['target']==target and r['weapon_prior']==pr]
        x={'target':target,'US':'lateUS6_mean','weapon_prior':pr,'n_profiles':len(rr),'ntr_per_profile':a.ntr}
        for k in sorted(set().union(*[r.keys() for r in rr])):
            if k in x or k in ('target','US','weapon_prior','ntr'):continue
            vals=[r.get(k) for r in rr]
            if vals and all(isinstance(z,(int,float,np.integer,np.floating)) for z in vals if z is not None): x[k]=float(np.nanmean([z for z in vals if z is not None]))
        ag.append(x)
    write(out/'release_flight_lateUS6_summary_v115.csv',ag);print(json.dumps(ag,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
