#!/usr/bin/env python3
from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np
import air_microcombat_v04 as one
base=one.base
from ship_aa_v110 import AA25, AA127FRAG, US40, US5FRAG, TERMINALS, _target_score, _aspect_from_ship
from global_ship_aa_v114 import _discipline_profile, _friendly_risk

@dataclass(frozen=True)
class ScreenShipClass:
    id: str
    name: str
    max_speed_kn: float
    formation_speed_kn: float = 30.0
    max_turn_rate_deg_s: float = 2.2
    turn_tau_s: float = 3.8
    speed_tau_s: float = 7.0
    station_tolerance_m: float = 250.0
    collision_avoid_m: float = 650.0
    heavy_channels: int = 0
    heavy_barrels_per_channel: int = 0
    heavy_rpm_per_barrel: float = 0.0
    heavy_max_range_m: float = 0.0
    heavy_max_alt_m: float = 0.0
    heavy_acquire_s: float = 1.4
    heavy_switch_s: float = 1.0
    heavy_track_tau_s: float = 1.6
    heavy_track_base: float = .72
    heavy_effective_event_p_shell: float = .0010
    heavy_pressure_per_round: float = .030
    heavy_sector_centers_deg: tuple[float,...] = ()
    heavy_sector_halfwidth_deg: float = 135.0
    light_channels: int = 0
    light_barrels_per_channel: int = 0
    light_rpm_per_barrel: float = 110.0
    light_max_range_m: float = 2000.0
    light_max_alt_m: float = 1000.0
    light_acquire_s: float = .85
    light_switch_s: float = .50
    light_track_tau_s: float = .85
    light_track_base: float = .52
    light_direct_hit_p_round: float = .00048
    light_pressure_per_round: float = .007
    light_sector_centers_deg: tuple[float,...] = ()
    light_sector_halfwidth_deg: float = 95.0
    damage_set: str = 'JP'
    source_grade: str = 'B-prior ship motion/AA integration'

# Working ship classes. These are mission-model profiles, not claims that every historical fit carried
# the same late-war light-AA count. Distinctions that matter here are retained: Akizuki-like DP AA
# versus Yugumo-like fleet-DD close-AA, plus separate speed/turn/formation response.
SHIP_CLASSES = {
    'FLETCHER_US_WORK': ScreenShipClass(
        id='FLETCHER_US_WORK', name='Fletcher-class US carrier-screen destroyer working profile',
        max_speed_kn=36.5, max_turn_rate_deg_s=2.4, turn_tau_s=3.4, speed_tau_s=6.2,
        heavy_channels=2, heavy_barrels_per_channel=2, heavy_rpm_per_barrel=15.0,
        heavy_max_range_m=9500.0, heavy_max_alt_m=7000.0,
        heavy_acquire_s=1.15, heavy_switch_s=.82, heavy_track_tau_s=1.25, heavy_track_base=.86,
        heavy_effective_event_p_shell=.00205, heavy_pressure_per_round=.041,
        heavy_sector_centers_deg=(0.0,180.0), heavy_sector_halfwidth_deg=140.0,
        # Working 40-mm-dominant automatic layer; 20-mm is not yet represented independently.
        light_channels=3, light_barrels_per_channel=3, light_rpm_per_barrel=120.0,
        light_max_range_m=4000.0, light_max_alt_m=2500.0,
        light_acquire_s=.52, light_switch_s=.32, light_track_tau_s=.50, light_track_base=.70,
        light_direct_hit_p_round=.00031, light_pressure_per_round=.0042,
        light_sector_centers_deg=(0.0,120.0,-120.0), light_sector_halfwidth_deg=105.0,
        damage_set='US',
        source_grade='A weapon-family/typical Fletcher armament anchors; B-prior effective directors, sectors and event probabilities'
    ),
    'AKIZUKI_WORK': ScreenShipClass(
        id='AKIZUKI_WORK', name='Akizuki-class AA destroyer working profile',
        max_speed_kn=33.0, max_turn_rate_deg_s=2.05, turn_tau_s=4.0, speed_tau_s=7.5,
        heavy_channels=2, heavy_barrels_per_channel=4, heavy_rpm_per_barrel=15.0,
        heavy_max_range_m=9500.0, heavy_max_alt_m=7000.0,
        heavy_acquire_s=1.25, heavy_switch_s=.90, heavy_track_tau_s=1.55, heavy_track_base=.80,
        heavy_effective_event_p_shell=.00082, heavy_pressure_per_round=.021,
        heavy_sector_centers_deg=(0.0,180.0), heavy_sector_halfwidth_deg=132.0,
        light_channels=4, light_barrels_per_channel=3, light_rpm_per_barrel=110.0,
        light_max_range_m=2000.0, light_max_alt_m=1000.0,
        light_acquire_s=.75, light_switch_s=.45, light_track_tau_s=.75, light_track_base=.56,
        light_direct_hit_p_round=.00050, light_pressure_per_round=.0075,
        light_sector_centers_deg=(0.0,90.0,180.0,-90.0), light_sector_halfwidth_deg=100.0,
        source_grade='A/B historical architecture + r30 role; B-prior effective channels/rates/effects'
    ),
    'YUGUMO_WORK': ScreenShipClass(
        id='YUGUMO_WORK', name='Yugumo-class fleet destroyer working profile',
        max_speed_kn=35.0, max_turn_rate_deg_s=2.35, turn_tau_s=3.5, speed_tau_s=6.5,
        # Main 12.7-cm battery is not promoted into Akizuki-like DP performance. A weak single
        # effective channel represents limited barrage/high-angle contribution rather than full DP fire.
        heavy_channels=1, heavy_barrels_per_channel=2, heavy_rpm_per_barrel=4.0,
        heavy_max_range_m=5200.0, heavy_max_alt_m=2200.0,
        heavy_acquire_s=1.9, heavy_switch_s=1.4, heavy_track_tau_s=2.2, heavy_track_base=.46,
        heavy_effective_event_p_shell=.00055, heavy_pressure_per_round=.018,
        heavy_sector_centers_deg=(90.0,), heavy_sector_halfwidth_deg=120.0,
        light_channels=3, light_barrels_per_channel=3, light_rpm_per_barrel=110.0,
        light_max_range_m=2000.0, light_max_alt_m=1000.0,
        light_acquire_s=.90, light_switch_s=.55, light_track_tau_s=.90, light_track_base=.50,
        light_direct_hit_p_round=.00046, light_pressure_per_round=.0068,
        light_sector_centers_deg=(0.0,120.0,-120.0), light_sector_halfwidth_deg=100.0,
        source_grade='r30 fleet-DD role + historical architecture; B-prior AA effectiveness'
    ),
}

@dataclass(frozen=True)
class ScreenFormation:
    id: str
    ships: tuple[tuple[str,float,float], ...]  # class_id, station forward x, station lateral y in target-ship body frame
    source_grade: str='B-prior formation architecture; not one exact historical OOB'

FORMATIONS = {
    'none': ScreenFormation('none',()),
    'us_fletcher4_work': ScreenFormation('us_fletcher4_work',(
        ('FLETCHER_US_WORK',2600.0,0.0),
        ('FLETCHER_US_WORK',0.0,2600.0),
        ('FLETCHER_US_WORK',0.0,-2600.0),
        ('FLETCHER_US_WORK',-2600.0,0.0),
    ), source_grade='US carrier-screen lower-bound working geometry; four Fletcher-like DD nodes, not an exact TF58 TG OOB'),
    'akizuki1_yugumo3': ScreenFormation('akizuki1_yugumo3',(
        ('AKIZUKI_WORK',0.0,2600.0),
        ('YUGUMO_WORK',2600.0,0.0),
        ('YUGUMO_WORK',0.0,-2600.0),
        ('YUGUMO_WORK',-2600.0,0.0),
    )),
    'akizuki2_yugumo2': ScreenFormation('akizuki2_yugumo2',(
        ('AKIZUKI_WORK',0.0,2600.0),
        ('AKIZUKI_WORK',0.0,-2600.0),
        ('YUGUMO_WORK',2600.0,0.0),
        ('YUGUMO_WORK',-2600.0,0.0),
    )),
    'akizuki2_yugumo4': ScreenFormation('akizuki2_yugumo4',(
        ('AKIZUKI_WORK',0.0,2800.0),
        ('AKIZUKI_WORK',0.0,-2800.0),
        ('YUGUMO_WORK',2425.0,1400.0),
        ('YUGUMO_WORK',2425.0,-1400.0),
        ('YUGUMO_WORK',-2425.0,1400.0),
        ('YUGUMO_WORK',-2425.0,-1400.0),
    )),
}

def get_formation(p):
    if p is None:return FORMATIONS['none']
    if isinstance(p,ScreenFormation):return p
    if isinstance(p,str):
        if p not in FORMATIONS:raise ValueError(f'unknown screen-ship formation {p}')
        return FORMATIONS[p]
    if isinstance(p,dict):return ScreenFormation(**p)
    raise TypeError('screen ship formation must be name/dict/ScreenFormation')

def _wrap(a):return (a+np.pi)%(2*np.pi)-np.pi

def _rotate(dx,dy,hdg):
    c=np.cos(hdg);s=np.sin(hdg)
    return dx*c-dy*s, dx*s+dy*c

def init_state(n,K,package_target_x,seed,formation='akizuki2_yugumo2',target_ship_state=None):
    f=get_formation(formation); M=len(f.ships); rng=np.random.default_rng((int(seed)*1000003+114041)%(2**63-1))
    classes=[SHIP_CLASSES[cid] for cid,_,_ in f.ships]
    maxhc=max([c.heavy_channels for c in classes],default=1);maxlc=max([c.light_channels for c in classes],default=1)
    station_dx=np.array([s[1] for s in f.ships],float);station_dy=np.array([s[2] for s in f.ships],float)
    if target_ship_state is not None:
        tx=np.asarray(target_ship_state['shipx'],float);ty=np.asarray(target_ship_state['shipy'],float);th=np.asarray(target_ship_state['shiphdg'],float);th0=np.asarray(target_ship_state['ship_hdg0'],float)
    else:
        tx=np.full(n,float(package_target_x));ty=np.zeros(n);th=np.zeros(n);th0=np.zeros(n)
    sx=np.zeros((n,M));sy=np.zeros((n,M));sh=np.zeros((n,M));sspd=np.zeros((n,M));srate=np.zeros((n,M))
    for m,c in enumerate(classes):
        ox,oy=_rotate(station_dx[m],station_dy[m],th)
        sx[:,m]=tx+ox+rng.normal(0,25,n);sy[:,m]=ty+oy+rng.normal(0,25,n);sh[:,m]=th+rng.normal(0,np.deg2rad(.7),n);sspd[:,m]=c.formation_speed_kn+rng.normal(0,.15,n)
    return {
      'formation':f,'classes':classes,'n':n,'K':K,'M':M,'rng':rng,'elapsed':0.0,
      'station_dx':station_dx,'station_dy':station_dy,
      'ship_x':sx,'ship_y':sy,'ship_hdg':_wrap(sh),'ship_speed_kn':sspd,'ship_rate':srate,
      'baseline_hdg0':th0.copy(),
      'ht':np.full((n,M,maxhc),-1,np.int16),'lt':np.full((n,M,maxlc),-1,np.int16),
      'hdelay':np.zeros((n,M,maxhc)),'ldelay':np.zeros((n,M,maxlc)),'hq':np.zeros((n,M,maxhc)),'lq':np.zeros((n,M,maxlc)),
      'heavy_rounds':np.zeros(n),'light_rounds':np.zeros(n),'heavy_events':np.zeros(n,int),'light_hits':np.zeros(n,int),
      'jinks':np.zeros(n,int),'new_losses':np.zeros(n,int),'hswitch':np.zeros(n,int),'lswitch':np.zeros(n,int),
      'heavy_withheld_rounds':np.zeros(n),'light_withheld_rounds':np.zeros(n),'heavy_hold_events':np.zeros(n,int),'light_hold_events':np.zeros(n,int),
      'heavy_discipline_switches':np.zeros(n,int),'light_discipline_switches':np.zeros(n,int),
      'heavy_risk_sum':np.zeros(n),'light_risk_sum':np.zeros(n),'heavy_risk_samples':np.zeros(n,int),'light_risk_samples':np.zeros(n,int),
      'first_fire_time':np.full(n,np.nan),
      'station_error_sum':np.zeros(n),'station_error_samples':np.zeros(n,int),'station_error_max':np.zeros(n),
      'min_ship_sep_m':np.full(n,1e9),'collision_avoid_events':np.zeros(n,int),'speed_saturation_s':np.zeros(n),
      'formation_motion_enabled':True,
    }

def _interp(a0,a1,f):return a0+f*(a1-a0)

def _risk(nx,ny,tx,ty,th,friend_xy,friend_h,friend_alive,disc,kind):
    if disc.id=='none':return 0.0
    lm,bm=(disc.heavy_line_m,disc.heavy_burst_m) if kind=='heavy' else (disc.light_line_m,disc.light_burst_m)
    return _friendly_risk(nx,ny,tx,ty,th,friend_xy,friend_h,friend_alive,lm,bm)

def _target_ship_at_substep(target_ship_state,si,nsub):
    # global_ship_aa_v114 records the target-ship substep trace. Fall back to the current end state.
    if target_ship_state is not None and 'last_step_shipx' in target_ship_state:
        j=min(si,target_ship_state['last_step_shipx'].shape[0]-1)
        return (target_ship_state['last_step_shipx'][j],target_ship_state['last_step_shipy'][j],target_ship_state['last_step_shiphdg'][j])
    return target_ship_state['shipx'],target_ship_state['shipy'],target_ship_state['shiphdg']

def _advance_formation(state,target_ship_state,si,nsub,sd,motion_enabled=True):
    n=state['n'];M=state['M'];classes=state['classes'];
    if M==0:return
    tx,ty,th=_target_ship_at_substep(target_ship_state,si,nsub)
    if not motion_enabled:
        for m in range(M):
            ox,oy=_rotate(state['station_dx'][m],state['station_dy'][m],th)
            state['ship_x'][:,m]=tx+ox;state['ship_y'][:,m]=ty+oy;state['ship_hdg'][:,m]=th
        return
    # diagnostics: pair separation before control
    if M>1:
        for a in range(M):
            for b in range(a+1,M):
                dd=np.hypot(state['ship_x'][:,a]-state['ship_x'][:,b],state['ship_y'][:,a]-state['ship_y'][:,b])
                state['min_ship_sep_m']=np.minimum(state['min_ship_sep_m'],dd)
    for m,c in enumerate(classes):
        ox,oy=_rotate(state['station_dx'][m],state['station_dy'][m],th)
        dx=(tx+ox)-state['ship_x'][:,m];dy=(ty+oy)-state['ship_y'][:,m]
        # Local collision-repulsion vector. This changes the desired track, not the ship position directly.
        rx=np.zeros(n);ry=np.zeros(n);avoid=np.zeros(n,bool)
        for j in range(M):
            if j==m:continue
            px=state['ship_x'][:,m]-state['ship_x'][:,j];py=state['ship_y'][:,m]-state['ship_y'][:,j];dd=np.hypot(px,py)+1e-6
            w=np.clip((c.collision_avoid_m-dd)/c.collision_avoid_m,0,1)
            rx+=w*px/dd*c.collision_avoid_m*1.8;ry+=w*py/dd*c.collision_avoid_m*1.8;avoid|=w>0
        state['collision_avoid_events']+=avoid.astype(int)
        dx+=rx;dy+=ry;err=np.hypot(dx,dy)
        state['station_error_sum']+=err;state['station_error_samples']+=1;state['station_error_max']=np.maximum(state['station_error_max'],err)
        desired=np.where(err>c.station_tolerance_m,np.arctan2(dy,dx),th)
        herr=_wrap(desired-state['ship_hdg'][:,m]);lim=np.deg2rad(c.max_turn_rate_deg_s)
        cmd=np.clip(herr/max(c.turn_tau_s,1e-3),-lim,lim);acc=lim*sd/max(c.turn_tau_s,1.0)
        state['ship_rate'][:,m]+=np.clip(cmd-state['ship_rate'][:,m],-acc,acc);state['ship_rate'][:,m]=np.clip(state['ship_rate'][:,m],-lim,lim)
        state['ship_hdg'][:,m]=_wrap(state['ship_hdg'][:,m]+state['ship_rate'][:,m]*sd)
        # Close station errors with speed; preserve enough headroom for a 30-kt target but respect class max speed.
        along=dx*np.cos(state['ship_hdg'][:,m])+dy*np.sin(state['ship_hdg'][:,m])
        cmdspd=np.clip(c.formation_speed_kn+along/450.0,8.0,c.max_speed_kn)
        state['speed_saturation_s']+=(cmdspd>=c.max_speed_kn-.05)*sd
        state['ship_speed_kn'][:,m]+=np.clip(cmdspd-state['ship_speed_kn'][:,m],-2.0*sd/max(c.speed_tau_s,1),2.0*sd/max(c.speed_tau_s,1))
        # Same baseline frame as the target ship: subtract steady target pre-evasion motion.
        v=state['ship_speed_kn'][:,m]*.514444;vbase=c.formation_speed_kn*.514444;h0=state['baseline_hdg0']
        state['ship_x'][:,m]+=(v*np.cos(state['ship_hdg'][:,m])-vbase*np.cos(h0))*sd
        state['ship_y'][:,m]+=(v*np.sin(state['ship_hdg'][:,m])-vbase*np.sin(h0))*sd

def _sector_ok(bear,ship_hdg,center_deg,halfwidth_deg):
    rel=_wrap(bear-ship_hdg-math.radians(center_deg))
    return np.abs(rel)<math.radians(halfwidth_deg)

def advance(state,attack_type,effects,package_defense,pkgStates,pkgAlive,
            mem0,mem1,dynVY,dynVZ,dynH,pkgEvTimer,pkgLastEv,cyc,evp,
            cap0=None,cap1=None,cap_alt0=None,cap_alt1=None,cap_alive=None,
            dt=2.5,subdt=.5,aa_strength=1.0,aa_fire_discipline='center',target_ship_state=None,motion_enabled=True):
    if state['M']==0:state['elapsed']+=dt;return
    n=state['n'];K=state['K'];M=state['M'];rng=state['rng'];disc=_discipline_profile(aa_fire_discipline);nsub=max(1,int(round(dt/subdt)));sd=dt/nsub
    prev=np.stack([st['mission'] for st in pkgStates],1).copy()
    for si in range(nsub):
        _advance_formation(state,target_ship_state,si,nsub,sd,motion_enabled=motion_enabled)
        f=(si+1)/nsub;x=_interp(mem0[0],mem1[0],f);y=_interp(mem0[1],mem1[1],f);h=_interp(mem0[2],mem1[2],f)
        dh=_wrap(mem1[3]-mem0[3]);hdg=_wrap(mem0[3]+f*dh)
        mission=np.stack([st['mission'] for st in pkgStates],1);alive=(~mission)&pkgAlive
        cap_pp=_interp(cap0,cap1,f) if cap0 is not None else None;cap_h=_interp(cap_alt0,cap_alt1,f) if cap_alt0 is not None else None
        for m,c in enumerate(state['classes']):
            nx=state['ship_x'][:,m];ny=state['ship_y'][:,m];sh=state['ship_hdg'][:,m]
            dx=x-nx[:,None];dy=y-ny[:,None];rngm=np.hypot(dx,dy)+1e-6;bear=np.arctan2(dy,dx)
            term_mode=TERMINALS[attack_type.id].mission if attack_type.id in TERMINALS else ('torpedo' if 'torpedo' in attack_type.name.lower() else 'dive')
            score=_target_score(rngm,h,alive,mission,term_mode)
            heavy_weapon, light_weapon = (US5FRAG,US40) if getattr(c,'damage_set','JP')=='US' else (AA127FRAG,AA25)
            for tr in range(n):
                friend_xy=cap_pp[tr] if cap_pp is not None else None;friend_h=cap_h[tr] if cap_h is not None else None;friend_alive=cap_alive[tr] if cap_alive is not None else None
                # Heavy directors / batteries
                for ch in range(c.heavy_channels):
                    center=c.heavy_sector_centers_deg[ch] if ch<len(c.heavy_sector_centers_deg) else 0.0
                    sector=_sector_ok(bear[tr],sh[tr],center,c.heavy_sector_halfwidth_deg)
                    elig=np.where((score[tr]>-1e8)&(rngm[tr]<=c.heavy_max_range_m)&(h[tr]<=c.heavy_max_alt_m)&sector)[0]
                    hrisk=np.zeros(K)
                    if len(elig) and disc.id!='none':
                        for t in elig:hrisk[t]=_risk(float(nx[tr]),float(ny[tr]),x[tr,t],y[tr,t],h[tr,t],friend_xy,friend_h,friend_alive,disc,'heavy')
                    cur=int(state['ht'][tr,m,ch]);valid=cur>=0 and alive[tr,cur] and rngm[tr,cur]<=c.heavy_max_range_m and h[tr,cur]<=c.heavy_max_alt_m and bool(_sector_ok(np.array([bear[tr,cur]]),np.array([sh[tr]]),center,c.heavy_sector_halfwidth_deg)[0])
                    cand=-1
                    if len(elig):
                        raw=int(elig[np.argmax(score[tr,elig])]);cand=raw if disc.id=='none' else int(elig[np.argmax(score[tr,elig]-disc.target_penalty*hrisk[elig])])
                        if valid and cand!=cur and hrisk[cur]>.15 and hrisk[cand]+.10<hrisk[cur]:valid=False;state['heavy_discipline_switches'][tr]+=1
                    if not valid:
                        if cand!=cur:state['hswitch'][tr]+=int(cur>=0 and cand>=0);state['ht'][tr,m,ch]=cand;state['hdelay'][tr,m,ch]=c.heavy_acquire_s if cur<0 else c.heavy_switch_s;state['hq'][tr,m,ch]=0
                    t=int(state['ht'][tr,m,ch]);
                    if t<0:continue
                    if state['hdelay'][tr,m,ch]>0:state['hdelay'][tr,m,ch]=max(0,state['hdelay'][tr,m,ch]-sd);continue
                    rangefac=float(np.clip(1-rngm[tr,t]/max(c.heavy_max_range_m,1),.16,1));jfac=.48 if pkgEvTimer[tr,t]>0 else 1.;turnfac=float(np.clip(1-.10*abs(math.degrees(state['ship_rate'][tr,m]))/max(c.max_turn_rate_deg_s,.1),.75,1))
                    risk=float(hrisk[t]);state['heavy_risk_sum'][tr]+=risk;state['heavy_risk_samples'][tr]+=1;desiredq=c.heavy_track_base*rangefac**.25*jfac*turnfac*max(.15,1-disc.track_penalty*risk)
                    state['hq'][tr,m,ch]+=np.clip(desiredq-state['hq'][tr,m,ch],-1,1)*min(1,sd/max(c.heavy_track_tau_s,.1))
                    rawrnd=int(rng.poisson(c.heavy_barrels_per_channel*c.heavy_rpm_per_barrel/60*sd));scale=float(np.clip(1-disc.heavy_hold_strength*risk,0,1));rounds=int(rng.binomial(rawrnd,scale)) if disc.id!='none' and rawrnd>0 and scale<.999999 else rawrnd
                    state['heavy_withheld_rounds'][tr]+=rawrnd-rounds;state['heavy_rounds'][tr]+=rounds
                    if rawrnd>0 and rounds==0 and risk>.05:state['heavy_hold_events'][tr]+=1
                    if rounds<=0:continue
                    if not np.isfinite(state['first_fire_time'][tr]):state['first_fire_time'][tr]=state['elapsed']+si*sd
                    pj=1-math.exp(-c.heavy_pressure_per_round*rounds*max(.15,state['hq'][tr,m,ch]))
                    if pkgEvTimer[tr,t]==0 and rng.random()<pj:
                        side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));dynVY[tr,t]+=side*float(evp.get('lat_imp',0.0))*.92*sc;dynVZ[tr,t]+=rng.normal(0,float(evp.get('vert_imp',0.0))*.8);dynH[tr,t]=float(np.clip(dynH[tr,t]+math.radians(side*float(evp.get('hdg_imp_deg',0.0))*.9*sc),-math.radians(24),math.radians(24)));pkgEvTimer[tr,t]=max(int(pkgEvTimer[tr,t]),int(rng.integers(2,4)));pkgLastEv[tr,t]=cyc;state['jinks'][tr]+=1
                    pe=min(.0029,c.heavy_effective_event_p_shell*aa_strength*max(.05,state['hq'][tr,m,ch]));ne=int(rng.binomial(rounds,pe));state['heavy_events'][tr]+=ne
                    if ne and not pkgStates[t]['mission'][tr]:
                        nf=int(ne+rng.poisson(1.15*ne));asp=int(_aspect_from_ship(np.array([hdg[tr,t]]),np.array([bear[tr,t]]))[0]);base.apply_hits(pkgStates[t],package_defense,heavy_weapon,effects,np.array([tr]),np.array([nf]),np.array([asp],np.int8),np.array([250.]),rng)
                        if pkgStates[t]['mission'][tr]:pkgAlive[tr,t]=False;alive[tr,t]=False
                # Light AA groups
                for ch in range(c.light_channels):
                    center=c.light_sector_centers_deg[ch] if ch<len(c.light_sector_centers_deg) else (360.0*ch/max(c.light_channels,1))
                    sector=_sector_ok(bear[tr],sh[tr],center,c.light_sector_halfwidth_deg)
                    elig=np.where((score[tr]>-1e8)&(rngm[tr]<=c.light_max_range_m)&(h[tr]<=c.light_max_alt_m)&sector)[0]
                    lrisk=np.zeros(K)
                    if len(elig) and disc.id!='none':
                        for t in elig:lrisk[t]=_risk(float(nx[tr]),float(ny[tr]),x[tr,t],y[tr,t],h[tr,t],friend_xy,friend_h,friend_alive,disc,'light')
                    cur=int(state['lt'][tr,m,ch]);valid=cur>=0 and alive[tr,cur] and rngm[tr,cur]<=c.light_max_range_m and h[tr,cur]<=c.light_max_alt_m and bool(_sector_ok(np.array([bear[tr,cur]]),np.array([sh[tr]]),center,c.light_sector_halfwidth_deg)[0])
                    cand=-1
                    if len(elig):
                        raw=int(elig[np.argmax(score[tr,elig])]);cand=raw if disc.id=='none' else int(elig[np.argmax(score[tr,elig]-disc.target_penalty*1.15*lrisk[elig])])
                        if valid and cand!=cur and lrisk[cur]>.12 and lrisk[cand]+.08<lrisk[cur]:valid=False;state['light_discipline_switches'][tr]+=1
                    if not valid:
                        if cand!=cur:state['lswitch'][tr]+=int(cur>=0 and cand>=0);state['lt'][tr,m,ch]=cand;state['ldelay'][tr,m,ch]=c.light_acquire_s if cur<0 else c.light_switch_s;state['lq'][tr,m,ch]=0
                    t=int(state['lt'][tr,m,ch]);
                    if t<0:continue
                    if state['ldelay'][tr,m,ch]>0:state['ldelay'][tr,m,ch]=max(0,state['ldelay'][tr,m,ch]-sd);continue
                    rangefac=float(np.clip(1-rngm[tr,t]/max(c.light_max_range_m,1),.10,1));jfac=.55 if pkgEvTimer[tr,t]>0 else 1.;turnfac=float(np.clip(1-.08*abs(math.degrees(state['ship_rate'][tr,m]))/max(c.max_turn_rate_deg_s,.1),.78,1));risk=float(lrisk[t]);state['light_risk_sum'][tr]+=risk;state['light_risk_samples'][tr]+=1
                    desiredq=c.light_track_base*rangefac**.32*jfac*turnfac*max(.12,1-disc.track_penalty*risk);state['lq'][tr,m,ch]+=np.clip(desiredq-state['lq'][tr,m,ch],-1,1)*min(1,sd/max(c.light_track_tau_s,.1))
                    rawrnd=int(rng.poisson(c.light_barrels_per_channel*c.light_rpm_per_barrel/60*sd));scale=float(np.clip(1-disc.light_hold_strength*risk,0,1));rounds=int(rng.binomial(rawrnd,scale)) if disc.id!='none' and rawrnd>0 and scale<.999999 else rawrnd
                    state['light_withheld_rounds'][tr]+=rawrnd-rounds;state['light_rounds'][tr]+=rounds
                    if rawrnd>0 and rounds==0 and risk>.05:state['light_hold_events'][tr]+=1
                    if rounds<=0:continue
                    if not np.isfinite(state['first_fire_time'][tr]):state['first_fire_time'][tr]=state['elapsed']+si*sd
                    pj=1-math.exp(-c.light_pressure_per_round*rounds*max(.12,state['lq'][tr,m,ch]))
                    if pkgEvTimer[tr,t]==0 and rng.random()<pj:
                        side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));dynVY[tr,t]+=side*float(evp.get('lat_imp',0.0))*.85*sc;dynVZ[tr,t]+=rng.normal(0,float(evp.get('vert_imp',0.0))*.72);dynH[tr,t]=float(np.clip(dynH[tr,t]+math.radians(side*float(evp.get('hdg_imp_deg',0.0))*.82*sc),-math.radians(24),math.radians(24)));pkgEvTimer[tr,t]=max(int(pkgEvTimer[tr,t]),int(rng.integers(2,4)));pkgLastEv[tr,t]=cyc;state['jinks'][tr]+=1
                    ph=c.light_direct_hit_p_round*aa_strength*max(.04,state['lq'][tr,m,ch])*rangefac**.35;nh=int(rng.binomial(rounds,min(.01,ph)));state['light_hits'][tr]+=nh
                    if nh and not pkgStates[t]['mission'][tr]:
                        asp=int(_aspect_from_ship(np.array([hdg[tr,t]]),np.array([bear[tr,t]]))[0]);base.apply_hits(pkgStates[t],package_defense,light_weapon,effects,np.array([tr]),np.array([nh]),np.array([asp],np.int8),np.array([float(rngm[tr,t])]),rng)
                        if pkgStates[t]['mission'][tr]:pkgAlive[tr,t]=False;alive[tr,t]=False
        now=np.stack([st['mission'] for st in pkgStates],1);new=now&(~prev);state['new_losses']+=new.sum(1);pkgAlive[new]=False;prev=now.copy()
    state['elapsed']+=dt

def summary(state):
    f=state['formation'];M=state['M'];meanerr=float(state['station_error_sum'].sum()/max(1,state['station_error_samples'].sum()))
    return {
      'screen_ship_model':'v0.11.4','screen_ship_formation':f.id,'screen_ship_count':M,'screen_damage_sets':sorted(set(getattr(c,'damage_set','JP') for c in state['classes'])),
      'screen_mean_heavy_rounds':float(state['heavy_rounds'].mean()),'screen_mean_25mm_rounds':float(state['light_rounds'].mean()),
      'screen_mean_heavy_effective_events':float(state['heavy_events'].mean()),'screen_mean_25mm_direct_hits':float(state['light_hits'].mean()),
      'screen_mean_jink_events':float(state['jinks'].mean()),'screen_mean_new_mission_losses':float(state['new_losses'].mean()),
      'screen_mean_heavy_withheld_rounds':float(state['heavy_withheld_rounds'].mean()),'screen_mean_light_withheld_rounds':float(state['light_withheld_rounds'].mean()),
      'screen_mean_heavy_discipline_switches':float(state['heavy_discipline_switches'].mean()),'screen_mean_light_discipline_switches':float(state['light_discipline_switches'].mean()),
      'screen_mean_heavy_friendly_risk':float(state['heavy_risk_sum'].sum()/max(1,state['heavy_risk_samples'].sum())),
      'screen_mean_light_friendly_risk':float(state['light_risk_sum'].sum()/max(1,state['light_risk_samples'].sum())),
      'screen_mean_first_fire_time_s':float(np.nanmean(state['first_fire_time'])) if np.isfinite(state['first_fire_time']).any() else math.nan,
      'screen_mean_station_error_m':meanerr,'screen_mean_max_station_error_m':float(state['station_error_max'].mean()),
      'screen_mean_min_ship_separation_m':float(state['min_ship_sep_m'].mean()) if M>1 else math.nan,
      'screen_mean_collision_avoid_events':float(state['collision_avoid_events'].mean()),
      'screen_mean_speed_saturation_ship_s':float(state['speed_saturation_s'].mean()),
    }
