from pathlib import Path
import sys,pickle,json,argparse
R=Path(__file__).parent;sys.path.insert(0,str(R))
import release_flight_v116 as rf
import release_flight_v115 as rf1
ap=argparse.ArgumentParser();ap.add_argument('--sep',type=float,required=True);ap.add_argument('--ntr',type=int,default=4);ap.add_argument('--us',default='US02');ap.add_argument('--policy',default='bisector_auto');a=ap.parse_args()
m=pickle.loads((R.parent/'results_current'/f'anvil_aircache_{a.us}_n{a.ntr}_v116.pkl').read_bytes())
if a.sep<0:
 r=rf1.simulate_torpedoes(m,seed=11688001,prior='center',torpedo_policy='auto');o={'case':'single_axis_current','separation_deg':0,**{k:r[k] for k in ['released','no_solution_rate','aircrew_aim_failure_rate','geometric_hit_rate_per_release','hit_rate_per_release','mean_hits_per_wave']}}
else:
 r=rf.simulate_torpedoes_anvil(m,separation_deg=a.sep,seed=11688001,prior='center',ship_policy=a.policy);g={x['group']:x for x in r['groups']};o={'case':'terminal_anvil','separation_deg':a.sep,**{k:r[k] for k in ['released','no_solution_rate','aircrew_aim_failure_rate','geometric_hit_rate_per_release','hit_rate_per_release','mean_hits_per_wave']},'axisA_hit_rate':g['axis_A']['hit_rate_per_release'],'axisB_hit_rate':g['axis_B']['hit_rate_per_release'],'axisA_no_solution':g['axis_A']['no_solution_rate'],'axisB_no_solution':g['axis_B']['no_solution_rate']}
o['US']=a.us;o['ntr']=a.ntr
p=R.parent/'results_current'/f'anvil_{a.us}_{a.policy}_sep{int(a.sep)}_v116.json';p.write_text(json.dumps(o,indent=2),encoding='utf-8');print(json.dumps(o))
