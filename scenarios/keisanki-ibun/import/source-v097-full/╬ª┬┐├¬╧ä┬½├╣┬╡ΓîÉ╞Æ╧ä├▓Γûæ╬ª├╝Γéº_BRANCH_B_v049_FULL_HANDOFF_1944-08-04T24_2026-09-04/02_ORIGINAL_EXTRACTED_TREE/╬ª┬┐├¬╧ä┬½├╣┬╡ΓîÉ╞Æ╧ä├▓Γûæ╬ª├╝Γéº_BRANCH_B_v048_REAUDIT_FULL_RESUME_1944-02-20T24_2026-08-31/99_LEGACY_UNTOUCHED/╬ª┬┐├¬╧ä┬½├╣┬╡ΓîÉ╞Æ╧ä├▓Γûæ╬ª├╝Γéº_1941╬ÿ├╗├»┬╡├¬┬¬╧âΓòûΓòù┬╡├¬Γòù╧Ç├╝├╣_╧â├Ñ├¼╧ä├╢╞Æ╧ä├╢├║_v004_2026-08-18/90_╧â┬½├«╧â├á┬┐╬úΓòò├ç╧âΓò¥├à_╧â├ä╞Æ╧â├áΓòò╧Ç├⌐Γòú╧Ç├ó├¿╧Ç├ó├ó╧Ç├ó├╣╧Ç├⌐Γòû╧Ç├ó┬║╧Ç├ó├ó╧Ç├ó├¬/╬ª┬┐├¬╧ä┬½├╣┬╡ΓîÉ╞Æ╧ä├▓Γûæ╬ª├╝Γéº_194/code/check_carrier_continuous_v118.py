#!/usr/bin/env python3
from pathlib import Path
import sys, numpy as np
R=Path(__file__).parent; sys.path.insert(0,str(R))
from carrier_damage_v117 import simulate_conditional, TIMES
from carrier_damage_continuous_v118 import simulate_conditional_continuous, sample_damage_state, evaluate_state

def main():
    cases=[('UNRYU_R30_WORK',1,0),('SHOKAKU_R30_WORK',1,0),('TAIHO_R30_WORK',0,1),('TAIHO_R30_WORK',1,1)]
    for i,(p,b,t) in enumerate(cases):
        seed=11901+i*17; n=9000
        rows0,tr0=simulate_conditional(p,b,t,n=n,seed=seed)
        rows1,tr1,_=simulate_conditional_continuous(p,b,t,n=n,seed=seed,times_h=TIMES)
        for h in TIMES:
            for k in ['speed','launch','recovery','aa','steer']:
                if not np.array_equal(tr0[h][k],tr1[h][k]):
                    d=float(np.max(np.abs(tr0[h][k]-tr1[h][k])))
                    raise AssertionError((p,b,t,h,k,d))
            for k in ['lost','closed','limited','restricted']:
                if not np.array_equal(tr0[h][k],tr1[h][k]): raise AssertionError((p,b,t,h,k))
        # arbitrary-time sanity: launch capacity should be finite and bounded
        s=sample_damage_state(p,b,t,n=2000,seed=seed+1)
        for h in [0.25,0.5,1.0,3.5,7.75,12.0]:
            ev=evaluate_state(s,h)
            assert np.all(np.isfinite(ev['launch'])) and np.all((ev['launch']>=0)&(ev['launch']<=1))
            assert np.all(np.isfinite(ev['recovery'])) and np.all((ev['recovery']>=0)&(ev['recovery']<=1))
        print('PASS',p,b,t)
if __name__=='__main__': main()
