#!/usr/bin/env python3
from __future__ import annotations
from dataclasses import dataclass
from copy import deepcopy
from typing import Dict, List, Any
import numpy as np
from sortie_regeneration_v118 import AirGroupState, benchmark_airgroup, AIRCRAFT_TYPES

COMPONENTS=("engine","cooling","fuel","controls","structure")

@dataclass(frozen=True)
class BridgePolicy:
    damage_threshold: float = 0.08
    fire_threshold: float = 0.05
    eta_start_min: float = 14.0
    eta_spacing_min: float = 1.25
    survivor_fatigue_factor: float = 0.88
    carrier_day_qualified: bool = True


def _trial_array(result: Dict[str,Any], field: str) -> np.ndarray:
    """Prefer terminal package state; fall back to delivery snapshot for old bundles."""
    kt=f"trial_package_terminal_{field}"
    ko=f"trial_package_online_{field}"
    if kt in result: return np.asarray(result[kt])
    if ko in result: return np.asarray(result[ko])
    raise KeyError(f"missing {kt} / {ko}")


def classify_package_trial(result: Dict[str,Any], trial_index: int, policy: BridgePolicy=BridgePolicy()):
    mission=np.asarray(_trial_array(result,"mission"),dtype=bool)
    pilot=np.asarray(_trial_array(result,"pilot"),dtype=float)
    fire=np.asarray(_trial_array(result,"fire"),dtype=float)
    comps=[np.asarray(_trial_array(result,k),dtype=float) for k in COMPONENTS]
    if mission.ndim != 2: raise ValueError("package trial arrays must be trial x aircraft")
    i=int(trial_index)
    if i<0 or i>=mission.shape[0]: raise IndexError(i)
    kpkg=mission.shape[1]
    dmg=1.0-np.minimum.reduce([a[i] for a in comps])
    # pilot kill/unusable crew is unreturnable even if an upstream mission flag is malformed.
    lost=mission[i] | (pilot[i] <= 0.05)
    damaged=(~lost) & ((dmg > policy.damage_threshold) | (fire[i] > policy.fire_threshold))
    clean=(~lost) & (~damaged)
    return {
        "package_aircraft":int(kpkg),
        "lost_mask":lost,
        "damaged_mask":damaged,
        "clean_mask":clean,
        "damage_score":dmg,
        "pilot_component":pilot[i],
        "fire":fire[i],
    }


def trial_shell_airgroup(aircraft_type: str, base: AirGroupState|None=None) -> AirGroupState:
    """Diagnostic carrier shell with one generic returning group removed for trial injection.

    This preserves the rest of the existing 72-aircraft benchmark and is only a bridge smoke state;
    it is not a historical carrier air-group claim.
    """
    typ=str(aircraft_type)
    if typ not in AIRCRAFT_TYPES: raise ValueError(typ)
    st=deepcopy(base if base is not None else benchmark_airgroup())
    st.returning={k:list(v) for k,v in st.returning.items()}
    st.returning[typ]=[]
    rd={k:[] for k in AIRCRAFT_TYPES}
    if st.returning_damaged:
        for k,v in st.returning_damaged.items(): rd[k]=list(v)
    st.returning_damaged=rd
    # The benchmark's damaged count is generic and may represent the old returning group;
    # clear only the injected type to avoid double-counting trial damage.
    st.damaged=dict(st.damaged); st.damaged[typ]=0
    st.crew_manifest={k:[] for k in AIRCRAFT_TYPES}
    return st


def inject_package_trial(
    state: AirGroupState,
    result: Dict[str,Any],
    trial_index: int,
    aircraft_type: str,
    policy: BridgePolicy=BridgePolicy(),
    crew_prefix: str="pkg",
) -> tuple[AirGroupState, Dict[str,Any]]:
    """Inject one upstream package trial into a sortie-regeneration AirGroupState.

    Surviving clean aircraft become routine returners; surviving damaged aircraft become
    returning_damaged and enter long repair only after landing. Lost/unreturnable aircraft do not
    enter either queue. Per-member crew metadata is retained in crew_manifest.
    """
    typ=str(aircraft_type)
    if typ not in AIRCRAFT_TYPES: raise ValueError(typ)
    c=classify_package_trial(result,trial_index,policy)
    st=deepcopy(state)
    st.returning={k:list(st.returning.get(k,[])) for k in AIRCRAFT_TYPES}
    if st.returning_damaged is None: st.returning_damaged={k:[] for k in AIRCRAFT_TYPES}
    else: st.returning_damaged={k:list(st.returning_damaged.get(k,[])) for k in AIRCRAFT_TYPES}
    if st.crew_manifest is None: st.crew_manifest={k:[] for k in AIRCRAFT_TYPES}
    else: st.crew_manifest={k:list(st.crew_manifest.get(k,[])) for k in AIRCRAFT_TYPES}

    survivors=[]
    for j in range(c["package_aircraft"]):
        eta=policy.eta_start_min+policy.eta_spacing_min*len(survivors)
        if c["lost_mask"][j]:
            status="lost_or_unreturnable"; eta_out=None
        else:
            survivors.append(j); eta_out=float(eta)
            if c["damaged_mask"][j]:
                st.returning_damaged[typ].append(eta_out); status="returning_damaged"
            else:
                st.returning[typ].append(eta_out); status="returning_clean"
        quals=["carrier_day"] if policy.carrier_day_qualified else []
        quals.append({"F":"fighter","DB":"dive_bomber","TB":"torpedo_bomber"}[typ])
        st.crew_manifest[typ].append({
            "crew_id":f"{crew_prefix}-{typ}-{trial_index:04d}-{j:02d}",
            "aircraft_member":int(j),
            "status":status,
            "qualified":True,
            "qualifications":quals,
            "fatigue_factor":float(policy.survivor_fatigue_factor if not c["lost_mask"][j] else 0.0),
            "pilot_component":float(c["pilot_component"][j]),
            "aircraft_damage_score":float(c["damage_score"][j]),
            "eta_min":eta_out,
        })
    audit={
        "trial_index":int(trial_index),"aircraft_type":typ,
        "package_aircraft":int(c["package_aircraft"]),
        "lost":int(c["lost_mask"].sum()),
        "returning_clean":int(c["clean_mask"].sum()),
        "returning_damaged":int(c["damaged_mask"].sum()),
        "survivors":int((~c["lost_mask"]).sum()),
        "damage_threshold":float(policy.damage_threshold),
        "eta_start_min":float(policy.eta_start_min),"eta_spacing_min":float(policy.eta_spacing_min),
    }
    return st,audit
