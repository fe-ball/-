#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,csv
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]

# Canonical r30 network bands (doc42).
NETWORK=(410,430,450)
MARIANAS=(300,315,330)
SCOUT=(30,35,40)
# doc43 values are explicitly COMPARISON-BRANCH priors to be re-opened, not final results.
JUL8_LOSS_PRIOR=(60,67,75)
JUL9_LOSS_PRIOR=(50,57,65)
# Decomposition and relocation are B-priors. Only the relative reduction in whole-unit tie-down is canonical sensitivity.
GROUND_OR_STRANDED_SHARE=(.20,.27,.35)
AIR_GROUND_SEPARATION_REL_REDUCTION=(.20,.275,.35) # doc45
NEW_BASE_HIST_READY=(.52,.62,.72)  # B-prior historical-like 24–48h readiness after move
NEW_BASE_READY_BONUS_PP=(.10,.15,.20) # doc45
# By Jul11 not all one-day-reach aircraft are committed: retain local defense/recon/reserve.
BASE_STRIKE_COMMIT=(.44,.50,.57)


def tri(r,b,n=None): return r.triangular(*b,size=n) if n is not None else float(r.triangular(*b))
def q(a):
 a=np.asarray(a,float);return {'p10':float(np.quantile(a,.1)),'p50':float(np.quantile(a,.5)),'p90':float(np.quantile(a,.9)),'mean':float(a.mean())}

def run(n=50000,seed=118740):
 rng=np.random.default_rng(seed); rows=[]
 for i in range(n):
  total=int(round(tri(rng,NETWORK))); mar=int(round(tri(rng,MARIANAS))); scouts=int(round(tri(rng,SCOUT)))
  # Comparison-branch raw loss is decomposed into in-air/irrecoverable vs base-bound/stranded components.
  surv=total; mar_live=min(mar,surv)
  reloc_ready=0; moved_total=0
  dayloss=[]
  for day,lp in [(8,JUL8_LOSS_PRIOR),(9,JUL9_LOSS_PRIOR)]:
    raw=float(tri(rng,lp)); gshare=tri(rng,GROUND_OR_STRANDED_SHARE); reduction=tri(rng,AIR_GROUND_SEPARATION_REL_REDUCTION)
    combat=raw*(1-gshare); grounded=raw*gshare*(1-reduction); loss=max(0.0,combat+grounded)
    loss_i=min(surv,int(round(loss))); surv-=loss_i; mar_live=max(0,mar_live-loss_i)
    # Deliberate dispersal/evacuation: move a fraction of remaining Marianas aircraft before the next sweep.
    # This is a B-prior policy range, not a historical measured count.
    move_frac=float(rng.triangular(.10,.15,.22)) if day==8 else float(rng.triangular(.08,.12,.18))
    move=min(mar_live,int(round(mar_live*move_frac))); mar_live-=move; moved_total+=move
    hist_ready=tri(rng,NEW_BASE_HIST_READY); bonus=tri(rng,NEW_BASE_READY_BONUS_PP)
    ready_prob=min(1.0,hist_ready+bonus)
    reloc_ready += int(rng.binomial(move,ready_prob))
    dayloss.append(loss_i)
  # Non-Marianas survivors outside the immediate island airfields are assumed within the wider network;
  # moved aircraft contribute only if their receiving-base readiness check passed.
  non_mar=max(0,surv-mar_live)
  # avoid double-count: moved aircraft are inside non_mar; replace their generic availability with readiness-tested value.
  standing_nonmar=max(0,non_mar-moved_total)
  within_day_ready=mar_live+standing_nonmar+reloc_ready
  # scouts/recon are not automatically counted as strike aircraft; a fraction remains dedicated to search.
  recon_hold=min(within_day_ready,int(round(scouts*float(rng.triangular(.72,.82,.90)))))
  strike_usable=max(0,within_day_ready-recon_hold)
  commit=tri(rng,BASE_STRIKE_COMMIT); jul11_strike=int(np.floor(strike_usable*commit))
  rows.append({
   'initial_network':total,'initial_marianas':mar,'jul8_loss':dayloss[0],'jul9_loss':dayloss[1],
   'survivors_jul9_night':surv,'moved_total':moved_total,'relocated_ready_by_jul11':reloc_ready,
   'within_one_day_ready_jul11':within_day_ready,'recon_hold':recon_hold,'strike_usable_jul11':strike_usable,
   'base_strike_commit_fraction':commit,'jul11_base_strike':jul11_strike,
  })
 return rows

def summary(rows):
 num=[k for k,v in rows[0].items() if isinstance(v,(int,float,np.integer,np.floating))]
 return {
  'schema':'FORAGER_BASE_PRESERVATION_v118_WIP','current_time_window':'1944-07-08 through Jul11 pre-strike',
  'n':len(rows),'summary':{k:q([r[k] for r in rows]) for k in num},
  'canonical_inputs':{'network_total':NETWORK,'marianas_immediate':MARIANAS,'scout_recon':SCOUT,'air_ground_separation_tiedown_rel_reduction':AIR_GROUND_SEPARATION_REL_REDUCTION,'new_base_readiness_bonus_pp':NEW_BASE_READY_BONUS_PP},
  'comparison_branch_priors':{'jul8_total_major_loss':JUL8_LOSS_PRIOR,'jul9_total_major_loss':JUL9_LOSS_PRIOR},
  'B_priors':{'ground_or_stranded_share_of_comparison_loss':GROUND_OR_STRANDED_SHARE,'historical_like_new_base_ready_24_48h':NEW_BASE_HIST_READY,'jul11_base_strike_commit_fraction':BASE_STRIKE_COMMIT,'daily_evacuation_policy':'Jul8 10–22% and Jul9 8–18% of remaining Marianas pool; B-prior'},
  'warning':'This is a transition model that re-opens doc43 comparison-branch losses using doc45 preservation effects. It is not yet a microcombat recalculation of the Jul8–9 sweeps.'
 }

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--n',type=int,default=50000);ap.add_argument('--seed',type=int,default=118740);a=ap.parse_args()
 rows=run(a.n,a.seed);s=summary(rows);out=ROOT/'results_current';out.mkdir(exist_ok=True)
 (out/'forager_base_preservation_v118.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
 with open(out/'forager_base_preservation_v118.csv','w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=['metric','p10','p50','p90','mean']);w.writeheader()
  for k,v in s['summary'].items():w.writerow({'metric':k,**v})
 print(json.dumps({k:s['summary'][k] for k in ['initial_network','jul8_loss','jul9_loss','survivors_jul9_night','moved_total','relocated_ready_by_jul11','within_one_day_ready_jul11','jul11_base_strike']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
