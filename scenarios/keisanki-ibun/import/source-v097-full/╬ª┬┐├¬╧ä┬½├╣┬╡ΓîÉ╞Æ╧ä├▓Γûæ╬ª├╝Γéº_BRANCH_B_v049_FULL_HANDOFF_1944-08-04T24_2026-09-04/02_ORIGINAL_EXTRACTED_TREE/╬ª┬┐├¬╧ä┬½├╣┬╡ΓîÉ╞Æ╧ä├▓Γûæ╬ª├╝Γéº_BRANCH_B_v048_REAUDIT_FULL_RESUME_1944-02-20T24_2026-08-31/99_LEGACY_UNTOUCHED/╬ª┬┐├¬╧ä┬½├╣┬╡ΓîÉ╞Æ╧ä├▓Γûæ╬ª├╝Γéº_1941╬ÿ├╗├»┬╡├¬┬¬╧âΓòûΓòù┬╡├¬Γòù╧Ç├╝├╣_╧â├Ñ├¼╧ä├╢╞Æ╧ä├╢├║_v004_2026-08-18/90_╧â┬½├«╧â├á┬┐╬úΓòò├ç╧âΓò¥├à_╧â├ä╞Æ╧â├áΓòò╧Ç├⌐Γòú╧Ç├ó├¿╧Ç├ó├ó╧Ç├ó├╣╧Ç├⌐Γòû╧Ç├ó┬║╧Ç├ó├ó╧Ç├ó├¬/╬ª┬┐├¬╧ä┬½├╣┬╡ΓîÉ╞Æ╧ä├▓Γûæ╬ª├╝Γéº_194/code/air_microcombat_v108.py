#!/usr/bin/env python3
from __future__ import annotations
import math, json
from pathlib import Path
import numpy as np
import air_microcombat_v04 as one
base=one.base; g=one.g
MANEUVER=one.MANEUVER; ATTACK=one.ATTACK; DEFEND=one.DEFEND; ZOOM=one.ZOOM; EXTEND=one.EXTEND
ACTION_NAMES=one.ACTION_NAMES

def wrap(a): return (a+np.pi)%(2*np.pi)-np.pi

def _ammo(df,n): return [np.full(n,int(count*apg),int) for wid,count,apg,mount,conv,sync in df.armament]

def _formation_indices(N):
    buddy=np.arange(N)^1
    section=np.arange(N)//2
    return buddy.astype(np.int16),section.astype(np.int16)

def _section_y(N):
    ns=N//2
    return (np.arange(ns)-(ns-1)/2.0)*850.0

def _expand_objects(x,N):
    if isinstance(x,(list,tuple)):
        if len(x)!=N: raise ValueError(f'expected {N} objects, got {len(x)}')
        return list(x)
    return [x for _ in range(N)]

def _expand_float(x,N,name='value'):
    a=np.asarray(x,dtype=float)
    if a.ndim==0: return np.full(N,float(a))
    if a.shape!=(N,): raise ValueError(f'{name} must be scalar or length {N}')
    return a.copy()

def _expand_bool(x,N,name='value'):
    if x is None: return np.zeros(N,dtype=bool)
    a=np.asarray(x,dtype=bool)
    if a.ndim==0: return np.full(N,bool(a))
    if a.shape!=(N,): raise ValueError(f'{name} must be scalar or length {N}')
    return a.copy()

def _default_centered_y(count,spacing=850.0,wing_sep=320.0):
    if count<=0:return np.zeros(0)
    if count%2: raise ValueError('centered fighter formation count must be even')
    sy=(np.arange(count//2)-(count//2-1)/2.0)*spacing
    y=np.zeros(count)
    for i in range(count): y[i]=sy[i//2]+(-.5 if i%2==0 else .5)*wing_sep
    return y

def _state_matrix(df,n,N): return [base._state(n) for _ in range(N)]
def _package_offsets(K=12):
    """B-prior rigid strike formation offsets in package-axis coordinates, metres."""
    pts=[]
    rows=[(120,[-330,-110,110,330]),(-80,[-360,-120,120,360]),(-280,[-300,-100,100,300])]
    for ri,(x,ys) in enumerate(rows):
        for ci,y in enumerate(ys): pts.append((x,y,(-18+12*ri)+(6 if ci%2 else -6)))
    if K<=len(pts): return np.asarray(pts[:K],float)
    # Extend conservatively aft if a larger package is requested.
    while len(pts)<K:
        q=len(pts);pts.append((-480-180*((q-12)//4),(-330,-110,110,330)[(q-12)%4],0))
    return np.asarray(pts,float)


def _package_members(pkgPos,pkgH,pkgHdg,pkgOffsets,dynX=None,dynY=None,dynZ=None,dynH=None):
    """World positions/headings of individual strike aircraft.

    dynX/dynY are offsets in package-axis coordinates; dynZ is altitude offset and dynH
    is heading deviation.  With all dynamic arrays zero this is exactly the rigid v0.10.6 formation.
    """
    n=len(pkgPos); K=len(pkgOffsets)
    if dynX is None: dynX=np.zeros((n,K))
    if dynY is None: dynY=np.zeros((n,K))
    if dynZ is None: dynZ=np.zeros((n,K))
    if dynH is None: dynH=np.zeros((n,K))
    ox=pkgOffsets[None,:,0]+dynX; oy=pkgOffsets[None,:,1]+dynY
    cph=np.cos(pkgHdg)[:,None]; sph=np.sin(pkgHdg)[:,None]
    x=pkgPos[:,None,0]+cph*ox-sph*oy
    y=pkgPos[:,None,1]+sph*ox+cph*oy
    h=pkgH[:,None]+pkgOffsets[None,:,2]+dynZ
    hdg=wrap(pkgHdg[:,None]+dynH)
    return x,y,h,hdg

def _mission(states): return np.stack([s['mission'] for s in states],1)

def _aspect_codes(target_heading, bearing_shooter_to_target):
    # Bearing from target to shooter is opposite shooter->target bearing.
    d=np.abs(wrap((bearing_shooter_to_target+np.pi)-target_heading))
    out=np.ones(d.shape,np.int8)  # beam
    out[d<np.deg2rad(60)]=2      # shooter in front of target
    out[d>np.deg2rad(120)]=0     # shooter behind target
    return out

def firing_burst_geom(shooter,target,weapons,effects,st_t,idx,quality,range_m,aspect,rng,ammo_left,shot_rounds,hit_count,size_factor=1.0):
    if not len(idx): return
    q=np.clip(quality,0,1.5)
    ranges=np.clip(range_m,90,650)
    dur=np.clip(.38+.16*q+rng.normal(0,.05,len(idx)),.26,.78)
    for gi,(wid,count,ammo_per_gun,mount,conv,sync) in enumerate(shooter.armament):
        w=weapons[wid]
        rpm=np.clip(rng.normal(w.rpm,w.rpm_sigma,len(idx)),.65*w.rpm,1.25*w.rpm)
        rounds=np.maximum(0,np.rint(count*rpm/60*dur*sync).astype(int))
        left=ammo_left[gi][idx]; rounds=np.minimum(rounds,left); ammo_left[gi][idx]-=rounds; shot_rounds[idx]+=rounds
        if mount=='nose': mountfac=np.full(len(idx),1.08)
        else:
            convfac=np.exp(-.5*((ranges-conv)/260.0)**2); mountfac=.90+.14*convfac
        rangefac=np.exp(-(ranges-220)/700)
        # Geometry is already explicit; q only represents steadiness of solution.
        ppr=np.clip(.0092*(1+.28*q)*rangefac*mountfac*float(size_factor),.0028,.040)
        hits=rng.poisson(rounds*ppr); hit_count[idx]+=hits
        base.apply_hits(st_t,target,w,effects,idx,hits,aspect,ranges,rng)

def _pair_geometry(posA,hdgA,posB,hdgB):
    dx=posB[:,None,:,0]-posA[:,:,None,0]; dy=posB[:,None,:,1]-posA[:,:,None,1]
    rng=np.sqrt(dx*dx+dy*dy)+1e-6; bear=np.arctan2(dy,dx)
    relA=wrap(bear-hdgA[:,:,None]); relB=wrap((bear+np.pi)-hdgB[:,None,:])
    # Nose alignment: +1 means target on nose. rear score: +1 means shooter behind target.
    noseA=np.cos(relA); noseB=np.cos(relB)
    rearA=-np.cos(relB); rearB=-np.cos(relA)
    return rng,bear,relA,relB,noseA,noseB,rearA,rearB

def _turn_toward(hdg,desired,max_delta):
    d=wrap(desired-hdg); return wrap(hdg+np.clip(d,-max_delta,max_delta))

def _select_actions(ownq,threatq,eadv,timer,post,policy):
    a=np.full(len(ownq),MANEUVER,np.int8); forced=timer>0
    if policy=='press': a[forced]=ATTACK
    elif policy=='zoom': a[forced]=ZOOM
    elif policy=='extend': a[forced]=EXTEND
    else:
        # Geometry-aware post-shot doctrine: keep pressing while a clean low-threat
        # rear-quarter solution still exists; zoom once the solution decays but energy remains.
        ff=np.where(forced)[0]
        if len(ff):
            good=(ownq[ff]>.60)&(threatq[ff]<.72)
            a[ff]=np.where(good,ATTACK,np.where(eadv[ff]>.16,ZOOM,np.where(eadv[ff]<-.45,EXTEND,ATTACK)))
    free=~forced
    a[free&(threatq>.72)&(ownq<.88)]=DEFEND
    a[free&(ownq>.42)&~((threatq>.72)&(ownq<.88))]=ATTACK
    a[free&(eadv<-.55)&(ownq<.30)]=DEFEND
    return a


def update_energy_from_turn(p,h,tas,action,delta_heading,h_target,pf,dt,dive_ratio):
    """Energy update tied to the turn actually flown in the horizontal geometry layer."""
    m=one.dyn_metrics(p,h,tas); v=np.maximum(35,tas/3.6)
    omega=np.abs(delta_heading)/dt
    nreq=np.sqrt(1+(omega*v/g)**2); nreq=np.minimum(nreq,m['nmax'])
    ps=one.excess_specific_power(p,m,pf)-one.maneuver_loss(m,nreq)
    ps-=np.where(action==DEFEND,5.0,0.0)
    e=g*h+.5*v*v; enew=np.maximum(g*80+.5*45**2,e+ps*dt)
    # Vertical command: attacks follow target altitude; zoom explicitly stores energy as height.
    gamma=np.clip(np.rad2deg(np.arctan2(h_target-h,np.maximum(300,v*4))),-14.0,10.0)
    gamma=np.where(action==ZOOM,np.where(enew-e>0,12.0,8.0),gamma)
    gamma=np.where(action==EXTEND,np.where(dive_ratio>=.98,-2.0,0.0),gamma)
    gamma=np.where(action==DEFEND,np.clip(gamma,-6.0,6.0),gamma)
    dh=v*np.sin(np.deg2rad(gamma))*dt; hnew=np.clip(h+dh,80,12000)
    v2=2*np.maximum(0,enew-g*hnew);vnew=np.sqrt(v2)*3.6
    vstall=one.stall_ias(p)/np.sqrt(np.maximum(.20,one.sigma_vec(hnew)));floor=1.10*vstall;low=vnew<floor
    if np.any(low):
        vnew[low]=floor[low];hnew[low]=(enew[low]-.5*(vnew[low]/3.6)**2)/g;hnew[low]=np.maximum(80,hnew[low])
    vmax=one.vinterp(p.vmax_anchors,hnew);vcap=vmax*(1.15+.12*np.clip(p.dive,.70,1.25));vnew=np.minimum(vnew,vcap)
    return hnew,vnew,nreq,gamma

def simulate_geometry(pa,pb,da,db,weapons,effects,N=8,hA0=3000,hB0=3000,iasA0=400,iasB0=400,ntr=100,seed=1,
                      max_cycles=44,dt=2.5,comm_local_A=.95,comm_local_B=.95,comm_cross_A=.88,comm_cross_B=.88,
                      policyA='auto',policyB='auto',formation=True,initial_sep_m=6200.0,freeze_energy=False,
                      package_mode=False,package_speed_kmh=300.0,package_alt_m=3000.0,package_start_x=4800.0,package_target_x=-4500.0,active_A=None,active_B=None,return_trials=False,A_lateral_offset_m=0.0,A_initial_x_m=None,B_initial_x_m=None,package_vector_range_m=6500.0,package_commit_threat=0.74,package_run_lock_cycles=5,package_run_lock_range_m=3600.0,package_run_lock_cone_deg=55.0,package_run_lock_threat=0.96,package_max_passes_per_fighter=2,package_reattack_cooldown_cycles=6,package_recover_cycles=2,package_aircraft_count=12,package_fire_substeps=5,package_hard_break_threat=0.96,escort_aim_suppression=0.55,package_terminal_profile='level',package_terminal_alt_m=None,package_terminal_speed_kmh=None,package_transition_start_m=0.0,package_transition_end_m=0.0,
                      A_initial_y_m=None,B_initial_y_m=None,A_route_side_m=None,A_route_ahead_m=2200.0,A_route_switch_range_m=650.0,A_route_release_slant_m=6500.0,A_route_alt_m=None,A_layer_labels=None,A_package_eligible=None,
                      package_dynamic_formation=False,package_evasion_params=None,package_evasion_impulse_scale=1.0,package_recovery_tau_scale=1.0,package_warn_range_m=1800.0,package_warn_cone_deg=38.0,
                      package_online_damage=False,package_defense=None,package_size_factor=1.0,package_loss_feedback=True):
    if N%2: raise ValueError('N must be even (two-ship sections)')
    paA=_expand_objects(pa,N); daA=_expand_objects(da,N)
    hA0v=_expand_float(hA0,N,'hA0'); iasA0v=_expand_float(iasA0,N,'iasA0')
    routeSide=_expand_float(0.0 if A_route_side_m is None else A_route_side_m,N,'A_route_side_m')
    routeAlt=_expand_float(hA0v if A_route_alt_m is None else A_route_alt_m,N,'A_route_alt_m')
    routeEnabled=np.abs(routeSide)>1e-6
    packageEligible=_expand_bool(True if A_package_eligible is None else A_package_eligible,N,'A_package_eligible')
    if A_layer_labels is None: layerLabels=np.array(['A']*N,dtype=object)
    else:
        if len(A_layer_labels)!=N: raise ValueError('A_layer_labels must be length N')
        layerLabels=np.asarray(A_layer_labels,dtype=object)
    rng=np.random.default_rng(seed); n=ntr; buddy,section=_formation_indices(N); ns=N//2; sy=_section_y(N)
    # Physical horizontal formation. Wingmen are 320 m apart laterally; sections 850 m apart.
    posA=np.zeros((n,N,2),float);posB=np.zeros((n,N,2),float)
    active_A=N if active_A is None else int(active_A); active_B=N if active_B is None else int(active_B)
    if A_initial_y_m is None:
        ay=_default_centered_y(active_A if active_A>0 else N)
        ayfull=np.zeros(N); ayfull[:len(ay)]=ay; ayfull+=float(A_lateral_offset_m)
    else: ayfull=_expand_float(A_initial_y_m,N,'A_initial_y_m')+float(A_lateral_offset_m)
    if B_initial_y_m is None:
        by=_default_centered_y(active_B if active_B>0 else N)
        byfull=np.zeros(N); byfull[:len(by)]=by
    else: byfull=_expand_float(B_initial_y_m,N,'B_initial_y_m')
    axfull=_expand_float((-initial_sep_m/2) if A_initial_x_m is None else A_initial_x_m,N,'A_initial_x_m')
    bxfull=_expand_float((initial_sep_m/2) if B_initial_x_m is None else B_initial_x_m,N,'B_initial_x_m')
    for i in range(N):
        posA[:,i,0]=axfull[i]+rng.normal(0,80,n);posB[:,i,0]=bxfull[i]+rng.normal(0,80,n)
        posA[:,i,1]=ayfull[i]+rng.normal(0,45,n);posB[:,i,1]=byfull[i]+rng.normal(0,45,n)
    hdgA=rng.normal(0,np.deg2rad(2.5),(n,N)); hdgB=np.pi+rng.normal(0,np.deg2rad(2.5),(n,N));hdgB=wrap(hdgB)
    hA=np.stack([np.full(n,hA0v[i])+rng.normal(0,45,n) for i in range(N)],1);hB=np.full((n,N),float(hB0))+rng.normal(0,45,(n,N))
    tasA=np.stack([np.full(n,iasA0v[i]/math.sqrt(base.sigma_at(hA0v[i])))*rng.normal(1,.006,n) for i in range(N)],1)
    tasB=np.full((n,N),float(iasB0)/math.sqrt(base.sigma_at(hB0)))*rng.normal(1,.006,(n,N))
    gammaA=np.zeros((n,N),float);gammaB=np.zeros((n,N),float)
    stA=[base._state(n) for _ in range(N)];stB=_state_matrix(db,n,N);engA=np.ones((n,N),bool);engB=np.ones((n,N),bool);disA=np.zeros((n,N),bool);disB=np.zeros((n,N),bool)
    if active_A<N:engA[:,active_A:]=False
    if active_B<N:engB[:,active_B:]=False
    ammoA=[_ammo(daA[i],n) for i in range(N)];ammoB=[_ammo(db,n) for _ in range(N)]
    roundsA=np.zeros((n,N),int);roundsB=np.zeros((n,N),int);hitsA=np.zeros((n,N),int);hitsB=np.zeros((n,N),int);burstsA=np.zeros((n,N),int);burstsB=np.zeros((n,N),int)
    timerA=np.zeros((n,N),int);timerB=np.zeros((n,N),int);postA=np.zeros((n,N),int);postB=np.zeros((n,N),int)
    targetA=np.tile(np.arange(N,dtype=np.int16),(n,1));targetB=np.tile(np.arange(N,dtype=np.int16),(n,1));prevA=targetA.copy();prevB=targetB.copy()
    cohA=np.full((n,ns),.94);cohB=np.full((n,ns),.94);groupA=np.full(n,.84);groupB=np.full(n,.84)
    firstshot=np.zeros(n,np.int8);firstloss=np.zeros(n,np.int8);firstcycle=np.full(n,-1,int)
    switchA=np.zeros(n,int);switchB=np.zeros(n,int);rescueA=np.zeros(n,int);rescueB=np.zeros(n,int);crossAcount=np.zeros(n,int);crossBcount=np.zeros(n,int)
    deconfA=np.zeros(n,int);deconfB=np.zeros(n,int);multiCandA=np.zeros(n,int);multiCandB=np.zeros(n,int)
    shotAspectA=np.zeros(3,int);shotAspectB=np.zeros(3,int);shotRangeA=0.0;shotRangeB=0.0;shotCountA=0;shotCountB=0
    action_count_A=np.zeros(5,float);action_count_B=np.zeros(5,float);min_friend_A=np.full(n,1e9);min_friend_B=np.full(n,1e9);escortAttackByLayer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())}
    Mpass=max(1,int(package_max_passes_per_fighter));Kpkg=max(1,int(package_aircraft_count));pkgOffsets=_package_offsets(Kpkg);pkgTargetA=np.tile((np.arange(N)%Kpkg).astype(np.int16),(n,1));pkgPos=np.column_stack([np.full(n,package_start_x),rng.normal(0,120,n)]);pkgH=np.full(n,float(package_alt_m));pkgSpeed=np.full(n,float(package_speed_kmh));pkgHdg=np.full(n,np.pi);pkgDeliveryCycle=np.full(n,-1,np.int16);pkgPassCount=np.zeros((n,N),np.int8);pkgReattackCD=np.zeros((n,N),np.int8);pkgRecover=np.zeros((n,N),np.int8);pkgPasses=np.zeros(n,int);pkgFirst=np.full(n,-1,int);pkgEscortIntercepts=np.zeros(n,int);pkgActive=np.full(n,bool(package_mode));pkgPassAspect=np.full((n,N,Mpass),-1,np.int8);pkgPassRange=np.full((n,N,Mpass),np.nan);pkgPassHorizRange=np.full((n,N,Mpass),np.nan);pkgPassAlign=np.full((n,N,Mpass),np.nan);pkgPassVerr=np.full((n,N,Mpass),np.nan);pkgPassCycle=np.full((n,N,Mpass),-1,np.int16);pkgPassBearing=np.full((n,N,Mpass),np.nan);pkgPassHeading=np.full((n,N,Mpass),np.nan);pkgPassAlt=np.full((n,N,Mpass),np.nan);pkgPassGamma=np.full((n,N,Mpass),np.nan);pkgPassTarget=np.full((n,N,Mpass),-1,np.int16);pkgPassTargetAlt=np.full((n,N,Mpass),np.nan);pkgPassQuality=np.full((n,N,Mpass),np.nan);pkgPassThreat=np.full((n,N,Mpass),np.nan);pkgRunLock=np.zeros((n,N),np.int8);pkgRunCommitted=np.zeros((n,N),bool);pkgRunStarts=np.zeros(n,int);pkgRouteCycles=np.zeros(n,int);pkgRouteEver=np.zeros((n,N),bool)
    # Dynamic strike formation state.  These arrays are zero in rigid-formation mode.
    pkgDynX=np.zeros((n,Kpkg),float);pkgDynY=np.zeros((n,Kpkg),float);pkgDynZ=np.zeros((n,Kpkg),float);pkgDynH=np.zeros((n,Kpkg),float)
    pkgDynVY=np.zeros((n,Kpkg),float);pkgDynVZ=np.zeros((n,Kpkg),float);pkgEvTimer=np.zeros((n,Kpkg),np.int8);pkgLastEv=np.full((n,Kpkg),-999,np.int16)
    pkgWarnCount=np.zeros(n,int);pkgWarnByMember=np.zeros((n,Kpkg),np.int16);pkgTargetSwitches=np.zeros(n,int);pkgLossDrivenSwitches=np.zeros(n,int);pkgSwitchAfterWarn=np.zeros(n,int);pkgWarnFollowOpp=np.zeros(n,int);pkgWarnNoFollowOpp=np.zeros(n,int);pkgSwitchNoWarn=np.zeros(n,int);pkgPrevTarget=np.zeros((n,N),np.int16);pkgWarnedPrev=np.zeros((n,Kpkg),bool);pkgMaxRMSY=np.zeros(n,float);pkgMaxRMSZ=np.zeros(n,float);pkgMaxRMSH=np.zeros(n,float)
    pkgDeliveryDynX=np.zeros((n,Kpkg),float);pkgDeliveryDynY=np.zeros((n,Kpkg),float);pkgDeliveryDynZ=np.zeros((n,Kpkg),float);pkgDeliveryDynH=np.zeros((n,Kpkg),float);pkgDeliveryLastEv=np.full((n,Kpkg),-999,np.int16)
    evp=package_evasion_params or {'warn':(0.0,0.0,0.0),'lat_imp':0.0,'vert_imp':0.0,'hdg_imp_deg':0.0,'tau':18.0,'immediate':1.0}
    if package_online_damage and package_defense is None:
        raise ValueError('package_defense is required when package_online_damage=True')
    pkgStates=[base._state(n) for _ in range(Kpkg)] if package_online_damage else None
    pkgAlive=np.ones((n,Kpkg),bool)
    pkgOnlineClean=np.zeros(n,int);pkgOnlineRounds=np.zeros(n,int);pkgOnlineHits=np.zeros(n,int);pkgOnlineAborted=np.zeros(n,int);pkgOnlineWasted=np.zeros(n,int)
    pkgOnlineCleanByLayer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())}
    pkgOnlineRoundsByLayer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())};pkgOnlineHitsByLayer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())}
    pkgMissionCycle=np.full((n,Kpkg),-1,np.int16)
    pkgDeliveryState={k:np.ones((n,Kpkg),float) for k in ('pilot','engine','cooling','fuel','controls','structure')}
    pkgDeliveryFire=np.zeros((n,Kpkg),float);pkgDeliveryMission=np.zeros((n,Kpkg),bool);pkgDeliveryImmediate=np.zeros((n,Kpkg),bool)
    for cyc in range(max_cycles):
        # Damage evolution and mission losses.
        for i in range(N):
            ix=np.where(engA[:,i])[0]
            if len(ix): base.evolve_damage(stA[i],daA[i],ix,rng)
            ix=np.where(engB[:,i])[0]
            if len(ix): base.evolve_damage(stB[i],db,ix,rng)
        if package_online_damage:
            for k in range(Kpkg):
                ix=np.where(pkgAlive[:,k]&pkgActive)[0]
                if len(ix): base.evolve_damage(pkgStates[k],package_defense,ix,rng)
            pmis=np.stack([st['mission'] for st in pkgStates],axis=1)
            newly=pmis&(pkgMissionCycle<0);pkgMissionCycle[newly]=cyc
            pkgAlive=~pmis
            # A package with no mission-capable aircraft has no geometry left to defend or attack.
            
            if package_loss_feedback: pkgActive&=pkgAlive.any(1)
        ma=_mission(stA);mb=_mission(stB);engA&=~ma;engB&=~mb
        unset=firstloss==0; anyA=ma.any(1);anyB=mb.any(1)
        firstloss[unset&anyA&~anyB]=-1;firstloss[unset&anyB&~anyA]=1;firstloss[unset&anyA&anyB]=2
        # In mission mode the package, not the fighter screen, defines the end of the trial.
        # If escorts are wiped out, surviving CAP may continue to attack; if CAP is wiped out, the
        # strike formation continues toward delivery and can recover from earlier jinks.
        done=(~pkgActive) if package_mode else ((~engA.any(1))|(~engB.any(1)));live=~done
        if not live.any(): break
        # Geometry and performance.
        R,bear,relA,relB,noseA,noseB,rearA,rearB=_pair_geometry(posA,hdgA,posB,hdgB)
        eA=g*hA+.5*(tasA/3.6)**2;eB=g*hB+.5*(tasB/3.6)**2
        pfA=np.stack([base.perf_factor(stA[i],daA[i]) for i in range(N)],1);pfB=np.stack([base.perf_factor(stB[i],db) for i in range(N)],1)
        # Geometry quality uses 3-D slant range and vertical LOS as well as horizontal aspect.
        dh=hB[:,None,:]-hA[:,:,None];slant=np.sqrt(R*R+dh*dh);vangA=np.arctan2(dh,R);vangB=-vangA
        near=np.clip(1-slant/4500,0,1)
        vertA=np.clip(np.cos(vangA-gammaA[:,:,None]),0,1);vertB=np.clip(np.cos(vangB-gammaB[:,None,:]),0,1)
        qA=.56*np.clip((noseA+.15)/1.15,0,1)+.21*np.clip((rearA+1)/2,0,1)+.13*near+.10*vertA
        qB=.56*np.clip((noseB+.15)/1.15,0,1)+.21*np.clip((rearB+1)/2,0,1)+.13*near+.10*vertB
        validPair=engA[:,:,None]&engB[:,None,:];qA=np.where(validPair,qA,-1);qB=np.where(validPair,qB,-1)
        # Threat to each aircraft = enemy geometry against it.
        threatA=np.max(qB,axis=2)  # n x A (B-target axis collapsed)
        threatB=np.max(qA,axis=1)  # n x B
        threatSrcA=np.argmax(qB,axis=2);threatSrcB=np.argmax(qA,axis=1)
        if package_mode:
            pdx=pkgPos[:,None,0]-posA[:,:,0];pdy=pkgPos[:,None,1]-posA[:,:,1];pkgR=np.sqrt(pdx*pdx+pdy*pdy)+1e-6;pkgBear=np.arctan2(pdy,pdx);pkgRel=wrap(pkgBear-hdgA);pkgDh=pkgH[:,None]-hA;pkgSlant=np.sqrt(pkgR*pkgR+pkgDh*pkgDh);pkgVang=np.arctan2(pkgDh,pkgR)
            # Individual strike-aircraft positions. In dynamic mode a warned aircraft can leave its
            # nominal slot; that displacement is visible to every later CAP target-selection cycle.
            pmx,pmy,pmh,pmhdg=_package_members(pkgPos,pkgH,pkgHdg,pkgOffsets,pkgDynX,pkgDynY,pkgDynZ,pkgDynH)
            mdx=pmx[:,None,:]-posA[:,:,None,0];mdy=pmy[:,None,:]-posA[:,:,None,1];mr=np.sqrt(mdx*mdx+mdy*mdy)+1e-6;mbear=np.arctan2(mdy,mdx);mrel=wrap(mbear-hdgA[:,:,None]);mdh=pmh[:,None,:]-hA[:,:,None];mslant=np.sqrt(mr*mr+mdh*mdh);mvang=np.arctan2(mdh,mr)
            # Pre-shot warning/jink belongs in main geometry, not post-processing.  A member reacts only
            # to a CAP that is physically near and approximately pointing at it.  Aspect uses the member's
            # own current heading, so a previous jink changes later warning geometry too.
            saw=np.zeros((n,Kpkg),bool)
            oldPkgTarget=pkgTargetA.copy()
            if package_dynamic_formation:
                noseok=np.abs(mrel)<np.deg2rad(float(package_warn_cone_deg))
                assigned=(pkgTargetA[:,:,None]==np.arange(Kpkg)[None,None,:])
                warncand=engA[:,:,None]&packageEligible[None,:,None]&pkgActive[:,None,None]&(pkgAlive[:,None,:] if package_loss_feedback else True)&assigned&(mslant<float(package_warn_range_m))&noseok
                # Threat strength favours close, well-aligned attackers; only the CAP currently pursuing
                # this individual can trigger its warning reaction.
                tscore=np.where(warncand,np.cos(mrel)*np.clip(1-mslant/float(package_warn_range_m),0,1),-1.0)
                besti=np.argmax(tscore,axis=1); bests=np.max(tscore,axis=1); rowsk=np.arange(n)[:,None]; kk=np.arange(Kpkg)[None,:]
                bb=mbear[rowsk,besti,kk]; aspwarn=_aspect_codes(pmhdg,bb)
                wp=np.asarray(evp.get('warn',(0.0,0.0,0.0)),float)[aspwarn]
                # Repeated warnings while already jinking are possible only at much reduced probability.
                psee=np.clip(wp*np.clip((bests+.05)/.75,0,1),0,.98)
                saw=(bests>0)&(pkgEvTimer==0)&(rng.random((n,Kpkg))<psee)
                if saw.any():
                    side=np.where(rng.random((n,Kpkg))<.5,-1.0,1.0);scale=rng.uniform(.78,1.22,(n,Kpkg))*float(package_evasion_impulse_scale)
                    pkgDynVY+=np.where(saw,side*float(evp.get('lat_imp',0.0))*scale,0.0)
                    pkgDynVZ+=np.where(saw,rng.normal(0,float(evp.get('vert_imp',0.0)),(n,Kpkg))*float(package_evasion_impulse_scale),0.0)
                    pkgDynH=wrap(pkgDynH+np.where(saw,side*np.deg2rad(float(evp.get('hdg_imp_deg',0.0)))*scale,0.0))
                    dur=rng.integers(3,6,(n,Kpkg));pkgEvTimer=np.where(saw,np.maximum(pkgEvTimer,dur),pkgEvTimer);pkgLastEv=np.where(saw,cyc,pkgLastEv)
                    pkgWarnCount+=saw.sum(1);pkgWarnByMember+=saw.astype(np.int16)
                    # Heading changed immediately; position changes during the following movement step.
                    pmhdg=wrap(pkgHdg[:,None]+pkgDynH)
            mscore=.70*np.cos(mrel)+.18*np.clip(1-mslant/3500,0,1)+.12*np.clip(np.cos(mvang-gammaA[:,:,None]),0,1)
            mscore=np.where((pkgAlive[:,None,:] if package_loss_feedback else np.ones_like(pkgAlive[:,None,:],bool)),mscore,-1e9)
            newPkgTarget=np.argmax(mscore,axis=2).astype(np.int16)
            if cyc>0:
                changed=(newPkgTarget!=pkgPrevTarget)&engA&packageEligible[None,:];pkgTargetSwitches+=changed.sum(1)
                rridx=np.arange(n)[:,None];prevMember=pkgPrevTarget
                if package_online_damage:
                    prevLost=~pkgAlive[rridx,prevMember]
                    pkgLossDrivenSwitches+=(changed&prevLost).sum(1)
                prevWarn=pkgWarnedPrev[rridx,prevMember];activeFollow=engA&packageEligible[None,:]
                pkgWarnFollowOpp+=(activeFollow&prevWarn).sum(1);pkgWarnNoFollowOpp+=(activeFollow&(~prevWarn)).sum(1)
                pkgSwitchAfterWarn+=(changed&prevWarn).sum(1);pkgSwitchNoWarn+=(changed&(~prevWarn)).sum(1)
            pkgTargetA=newPkgTarget;pkgPrevTarget=pkgTargetA.copy();pkgWarnedPrev=saw.copy()
            # Explicit moving intercept waypoint. The waypoint rides ahead of the package track and
            # is displaced laterally; high/outer layers can therefore spend early warning time on routing
            # instead of converting it into a longer frontal fight with the escort screen.
            ahead=float(A_route_ahead_m); wx=pkgPos[:,None,0]+ahead*np.cos(pkgHdg)[:,None]+routeSide[None,:]*np.cos(pkgHdg+np.pi/2)[:,None]; wy=pkgPos[:,None,1]+ahead*np.sin(pkgHdg)[:,None]+routeSide[None,:]*np.sin(pkgHdg+np.pi/2)[:,None]
            rdx=wx-posA[:,:,0];rdy=wy-posA[:,:,1];routeR=np.sqrt(rdx*rdx+rdy*rdy)+1e-6;routeBear=np.arctan2(rdy,rdx)
            vectorA=engA&packageEligible[None,:]&(pkgPassCount<Mpass)&(pkgReattackCD==0)&pkgActive[:,None]&(pkgSlant<float(package_vector_range_m))
            onRoute=vectorA&routeEnabled[None,:]&(routeR>float(A_route_switch_range_m))&(pkgSlant>float(A_route_release_slant_m))&(~pkgRunCommitted)
            pkgRouteCycles+=onRoute.sum(1);pkgRouteEver|=onRoute
            startRun=vectorA&(~onRoute)&(pkgSlant<float(package_run_lock_range_m))&(np.abs(pkgRel)<np.deg2rad(float(package_run_lock_cone_deg)))&(threatA<float(package_run_lock_threat))&(pkgRunLock==0)&(~pkgRunCommitted)
            if startRun.any():
                pkgRunLock[startRun]=int(package_run_lock_cycles);pkgRunCommitted[startRun]=True;pkgRunStarts+=startRun.sum(1)
            penetrateA=vectorA&(~onRoute)&(((threatA<.78)|(pkgSlant<2600))|(pkgRunLock>0))
        else:
            pkgR=np.full((n,N),1e9);pkgSlant=pkgR.copy();pkgBear=np.zeros((n,N));pkgRel=np.zeros((n,N));pkgVang=np.zeros((n,N));penetrateA=np.zeros((n,N),bool);onRoute=np.zeros((n,N),bool);routeBear=np.zeros((n,N));routeR=np.full((n,N),1e9)
        # Previous target saturation and communication realization.
        countA=np.zeros((n,N),int);countB=np.zeros((n,N),int)
        for i in range(N):
            rows=np.arange(n);countA[rows,prevA[:,i]]+=engA[:,i];countB[rows,prevB[:,i]]+=engB[:,i]
        localInfoA=rng.random((n,N))<(comm_local_A*cohA[:,section]);localInfoB=rng.random((n,N))<(comm_local_B*cohB[:,section])
        crossInfoA=rng.random((n,N))<(comm_cross_A*groupA[:,None]);crossInfoB=rng.random((n,N))<(comm_cross_B*groupB[:,None])
        # Target selection. Rescue bonuses require both information and physical proximity to threatened friendly.
        for i in range(N):
            sc=qA[:,i,:]-.065*np.maximum(0,countA-1)-.000055*R[:,i,:]
            rows=np.arange(n);ok=engB[rows,prevA[:,i]];sc[rows[ok],prevA[ok,i]]+=.18
            b=int(buddy[i]); bth=threatSrcA[:,b]; dBuddy=np.linalg.norm(posA[:,i]-posA[:,b],axis=1)
            for j in range(N): sc[:,j]+=.30*localInfoA[:,i]*(bth==j)*(dBuddy<2400)
            # Cross-section rescue: only if rescuer is within 3.8 km of threatened aircraft.
            other=[k for k in range(N) if section[k]!=section[i]]
            if other:
                bestk=np.array([other[np.argmax(threatA[r,other])] for r in range(n)])
                src=threatSrcA[np.arange(n),bestk]; dist=np.linalg.norm(posA[:,i]-posA[np.arange(n),bestk],axis=1)
                for j in range(N): sc[:,j]+=.13*crossInfoA[:,i]*(src==j)*(dist<3800)
            sc=np.where(engB,sc,-1e9);targetA[:,i]=np.argmax(sc,1)
        for j in range(N):
            sc=qB[:,:,j]-.065*np.maximum(0,countB-1)-.000055*R[:,:,j]
            if package_mode:
                mission_threat=.50*penetrateA+.22*np.clip((4500-pkgSlant)/4500,0,1)
                sc+=mission_threat
            rows=np.arange(n);ok=engA[rows,prevB[:,j]];sc[rows[ok],prevB[ok,j]]+=.18
            b=int(buddy[j]); bth=threatSrcB[:,b]; dBuddy=np.linalg.norm(posB[:,j]-posB[:,b],axis=1)
            for i in range(N): sc[:,i]+=.30*localInfoB[:,j]*(bth==i)*(dBuddy<2400)
            other=[k for k in range(N) if section[k]!=section[j]]
            if other:
                bestk=np.array([other[np.argmax(threatB[r,other])] for r in range(n)])
                src=threatSrcB[np.arange(n),bestk];dist=np.linalg.norm(posB[:,j]-posB[np.arange(n),bestk],axis=1)
                for i in range(N): sc[:,i]+=.13*crossInfoB[:,j]*(src==i)*(dist<3800)
            sc=np.where(engA,sc,-1e9);targetB[:,j]=np.argmax(sc,1)
        if cyc>0:
            for i in range(N):
                sw=engA[:,i]&(targetA[:,i]!=prevA[:,i]);switchA+=sw; b=int(buddy[i]);src=threatSrcA[:,b];dist=np.linalg.norm(posA[:,i]-posA[:,b],axis=1)
                rescueA+=sw&localInfoA[:,i]&(targetA[:,i]==src)&(dist<2400)
                other=[k for k in range(N) if section[k]!=section[i]]
                if other:
                    bestk=np.array([other[np.argmax(threatA[r,other])] for r in range(n)]);src2=threatSrcA[np.arange(n),bestk];dist2=np.linalg.norm(posA[:,i]-posA[np.arange(n),bestk],axis=1)
                    crossAcount+=sw&crossInfoA[:,i]&(targetA[:,i]==src2)&(dist2<3800)
            for j in range(N):
                sw=engB[:,j]&(targetB[:,j]!=prevB[:,j]);switchB+=sw;b=int(buddy[j]);src=threatSrcB[:,b];dist=np.linalg.norm(posB[:,j]-posB[:,b],axis=1)
                rescueB+=sw&localInfoB[:,j]&(targetB[:,j]==src)&(dist<2400)
                other=[k for k in range(N) if section[k]!=section[j]]
                if other:
                    bestk=np.array([other[np.argmax(threatB[r,other])] for r in range(n)]);src2=threatSrcB[np.arange(n),bestk];dist2=np.linalg.norm(posB[:,j]-posB[np.arange(n),bestk],axis=1)
                    crossBcount+=sw&crossInfoB[:,j]&(targetB[:,j]==src2)&(dist2<3800)
        prevA[:]=targetA;prevB[:]=targetB
        # Actions from chosen-target geometry and actual threat geometry.
        actA=np.full((n,N),MANEUVER,np.int8);actB=np.full((n,N),MANEUVER,np.int8)
        for i in range(N):
            t=targetA[:,i];own=qA[np.arange(n),i,t];eadv=(eA[:,i]-eB[np.arange(n),t])/10000
            actA[:,i]=_select_actions(own,threatA[:,i],eadv,timerA[:,i],postA[:,i],policyA)
            if package_mode:
                go=penetrateA[:,i]&((threatA[:,i]<float(package_commit_threat))|((pkgRunLock[:,i]>0)&(threatA[:,i]<float(package_hard_break_threat))))&(timerA[:,i]==0);actA[go,i]=ATTACK
                route=onRoute[:,i]&engA[:,i];actA[route,i]=MANEUVER
                rec=(pkgRecover[:,i]>0)&engA[:,i];actA[rec,i]=np.where(threatA[rec,i]>.88,DEFEND,ZOOM)
            actA[~engA[:,i],i]=MANEUVER
        for j in range(N):
            t=targetB[:,j];own=qB[np.arange(n),t,j];eadv=(eB[:,j]-eA[np.arange(n),t])/10000
            actB[:,j]=_select_actions(own,threatB[:,j],eadv,timerB[:,j],postB[:,j],policyB);actB[~engB[:,j],j]=MANEUVER
        for ac in range(5): action_count_A[ac]+=np.sum((actA==ac)&engA);action_count_B[ac]+=np.sum((actB==ac)&engB)
        for j in range(N):
            rows=np.arange(n);tt=targetB[:,j]
            for lab in escortAttackByLayer:
                escortAttackByLayer[lab]+=engB[:,j]&(actB[:,j]==ATTACK)&(layerLabels[tt]==lab)
        # Desired headings and physically limited turn.
        mA=[one.dyn_metrics(paA[i],hA[:,i],tasA[:,i]) for i in range(N)];mB=[one.dyn_metrics(pb,hB[:,i],tasB[:,i]) for i in range(N)]
        oldA=hdgA.copy();oldB=hdgB.copy()
        for i in range(N):
            rows=np.arange(n);t=targetA[:,i]
            # Lead pursuit: aim at a short-horizon predicted target position rather than its instantaneous point.
            # This avoids pure-pursuit overshoot artificially penalizing high-turn-rate aircraft.
            lead=np.clip(R[rows,i,t]/700.0,.55,2.0)
            tx=posB[rows,t,0]+(tasB[rows,t]/3.6)*np.cos(hdgB[rows,t])*lead
            ty=posB[rows,t,1]+(tasB[rows,t]/3.6)*np.sin(hdgB[rows,t])*lead
            des=np.arctan2(ty-posA[:,i,1],tx-posA[:,i,0]);th=threatSrcA[:,i];thbear=bear[rows,i,th]
            if package_mode:
                pt=pkgTargetA[:,i];leadp=np.clip(mslant[np.arange(n),i,pt]/700.0,.45,1.8);txp=pmx[np.arange(n),pt]+(pkgSpeed/3.6)*np.cos(pkgHdg)*leadp;typ=pmy[np.arange(n),pt]+(pkgSpeed/3.6)*np.sin(pkgHdg)*leadp;bp=np.arctan2(typ-posA[:,i,1],txp-posA[:,i,0]);des=np.where(penetrateA[:,i],bp,des);des=np.where(onRoute[:,i],routeBear[:,i],des)
            # Defensive break across the attacker's line; sign chosen from relative bearing.
            s=np.where(wrap(thbear-hdgA[:,i])>=0,1,-1);des=np.where(actA[:,i]==DEFEND,thbear+s*np.deg2rad(65),des)
            des=np.where(actA[:,i]==ZOOM,hdgA[:,i]+.15*wrap(des-hdgA[:,i]),des)
            des=np.where(actA[:,i]==EXTEND,thbear+np.pi,des)
            fac=np.where(actA[:,i]==DEFEND,1.12,np.where(actA[:,i]==MANEUVER,.78,np.where(actA[:,i]==ZOOM,.42,1.0)))
            rollfac=np.clip(mA[i]['roll']*dt/85,.30,1);maxd=np.deg2rad(mA[i]['turn']*dt*fac*rollfac*pfA[:,i])
            hdgA[:,i]=_turn_toward(hdgA[:,i],des,maxd)
        for j in range(N):
            rows=np.arange(n);t=targetB[:,j]
            lead=np.clip(R[rows,t,j]/700.0,.55,2.0)
            tx=posA[rows,t,0]+(tasA[rows,t]/3.6)*np.cos(hdgA[rows,t])*lead
            ty=posA[rows,t,1]+(tasA[rows,t]/3.6)*np.sin(hdgA[rows,t])*lead
            des=np.arctan2(ty-posB[:,j,1],tx-posB[:,j,0]);th=threatSrcB[:,j];thbear=(bear[rows,th,j]+np.pi)
            if package_mode:
                guardx=pkgPos[:,0]+1200*np.cos(pkgHdg);guardy=pkgPos[:,1]+1200*np.sin(pkgHdg)
                distguard=np.sqrt((guardx-posB[:,j,0])**2+(guardy-posB[:,j,1])**2);bguard=np.arctan2(guardy-posB[:,j,1],guardx-posB[:,j,0]);tgtPen=penetrateA[rows,t]
                tether=(distguard>2600)&(~tgtPen)&(threatB[:,j]<.72);des=np.where(tether,bguard,des)
            s=np.where(wrap(thbear-hdgB[:,j])>=0,1,-1);des=np.where(actB[:,j]==DEFEND,thbear+s*np.deg2rad(65),des)
            des=np.where(actB[:,j]==ZOOM,hdgB[:,j]+.15*wrap(des-hdgB[:,j]),des);des=np.where(actB[:,j]==EXTEND,thbear+np.pi,des)
            fac=np.where(actB[:,j]==DEFEND,1.12,np.where(actB[:,j]==MANEUVER,.78,np.where(actB[:,j]==ZOOM,.42,1.0)))
            rollfac=np.clip(mB[j]['roll']*dt/85,.30,1);maxd=np.deg2rad(mB[j]['turn']*dt*fac*rollfac*pfB[:,j])
            hdgB[:,j]=_turn_toward(hdgB[:,j],des,maxd)
        # Same-side deconfliction: heading nudge if <150 m. This is a constraint, not a performance bonus.
        for side,pos,alt,hdg,eng,deconf,minfriend in [('A',posA,hA,hdgA,engA,deconfA,min_friend_A),('B',posB,hB,hdgB,engB,deconfB,min_friend_B)]:
            for i in range(N):
                for k in range(i+1,N):
                    dvec=pos[:,i]-pos[:,k];hdist=np.linalg.norm(dvec,axis=1);dist=np.sqrt(hdist*hdist+(alt[:,i]-alt[:,k])**2);valid=eng[:,i]&eng[:,k];minfriend[:]=np.minimum(minfriend,np.where(valid,dist,1e9));close=valid&(dist<150)
                    if close.any():
                        deconf+=close;away_i=np.arctan2(dvec[:,1],dvec[:,0]);away_k=wrap(away_i+np.pi)
                        hdg[:,i]=np.where(close,_turn_toward(hdg[:,i],away_i,np.full(n,np.deg2rad(12))),hdg[:,i]);hdg[:,k]=np.where(close,_turn_toward(hdg[:,k],away_k,np.full(n,np.deg2rad(12))),hdg[:,k])
        # Energy update tied to the turn actually flown, then horizontal movement.
        if not freeze_energy:
            for i in range(N):
                t=targetA[:,i];ix=np.where(live&engA[:,i])[0]
                if len(ix):
                    dhdg=wrap(hdgA[ix,i]-oldA[ix,i]); ht=hB[ix,t[ix]]
                    if package_mode:
                        ht=np.where(penetrateA[ix,i],pmh[ix,pkgTargetA[ix,i]],ht);ht=np.where(onRoute[ix,i],routeAlt[i],ht)
                    hn,vn,_,ga=update_energy_from_turn(paA[i],hA[ix,i],tasA[ix,i],actA[ix,i],dhdg,ht,pfA[ix,i],dt,paA[i].dive/pb.dive);hA[ix,i]=hn;tasA[ix,i]=vn;gammaA[ix,i]=np.deg2rad(ga)
            for j in range(N):
                t=targetB[:,j];ix=np.where(live&engB[:,j])[0]
                if len(ix):
                    dhdg=wrap(hdgB[ix,j]-oldB[ix,j]); ht=hA[ix,t[ix]]
                    oppDive=np.array([paA[int(t[k])].dive for k in ix],float);hn,vn,_,gb=update_energy_from_turn(pb,hB[ix,j],tasB[ix,j],actB[ix,j],dhdg,ht,pfB[ix,j],dt,pb.dive/oppDive);hB[ix,j]=hn;tasB[ix,j]=vn;gammaB[ix,j]=np.deg2rad(gb)
        posA0=posA.copy();posB0=posB.copy();pkgPos0=pkgPos.copy() if package_mode else None
        if package_mode:
            pkgDynX0=pkgDynX.copy();pkgDynY0=pkgDynY.copy();pkgDynZ0=pkgDynZ.copy();pkgDynH0=pkgDynH.copy();pkgH0=np.asarray(pkgH).copy();pkgHdg0=pkgHdg.copy()
        posA[:,:,0]+=(tasA/3.6)*np.cos(hdgA)*dt;posA[:,:,1]+=(tasA/3.6)*np.sin(hdgA)*dt
        posB[:,:,0]+=(tasB/3.6)*np.cos(hdgB)*dt;posB[:,:,1]+=(tasB/3.6)*np.sin(hdgB)*dt
        if package_mode:
            # Individual strike-aircraft recovery and displacement.  Heading jink produces real cross-track
            # motion; lateral/vertical impulses add short-lived displacement.  When no longer evading, aircraft
            # gradually rejoin the nominal slot rather than snapping back to a rigid formation.
            if package_dynamic_formation:
                tau=max(7.0,float(evp.get('tau',18.0))*float(package_recovery_tau_scale)); rec=math.exp(-dt/tau); activeEv=pkgEvTimer>0
                pkgDynVY*=np.where(activeEv,.92,rec);pkgDynVZ*=np.where(activeEv,.90,rec);pkgDynH*=np.where(activeEv,.94,rec)
                vms=pkgSpeed[:,None]/3.6
                pkgDynX+=(vms*(np.cos(pkgDynH)-1.0))*dt
                pkgDynY+=(vms*np.sin(pkgDynH)+pkgDynVY)*dt
                pkgDynZ+=pkgDynVZ*dt
                restore=~activeEv
                pkgDynVY+=np.where(restore,-pkgDynY/max(18.0,tau*2.1)*dt,0.0);pkgDynVZ+=np.where(restore,-pkgDynZ/max(14.0,tau*1.8)*dt,0.0)
                pkgDynX+=np.where(restore,-pkgDynX/max(24.0,tau*3.0)*dt,0.0)
                pkgDynX=np.clip(pkgDynX,-900,500);pkgDynY=np.clip(pkgDynY,-1100,1100);pkgDynZ=np.clip(pkgDynZ,-450,450);pkgDynH=np.clip(pkgDynH,-np.deg2rad(24),np.deg2rad(24));pkgEvTimer=np.maximum(0,pkgEvTimer-1)
                pkgMaxRMSY=np.maximum(pkgMaxRMSY,np.sqrt(np.mean(pkgDynY*pkgDynY,axis=1)));pkgMaxRMSZ=np.maximum(pkgMaxRMSZ,np.sqrt(np.mean(pkgDynZ*pkgDynZ,axis=1)));pkgMaxRMSH=np.maximum(pkgMaxRMSH,np.sqrt(np.mean(np.rad2deg(pkgDynH)**2,axis=1)))
            pkgPos[:,0]+=(pkgSpeed/3.6)*np.cos(pkgHdg)*dt;pkgPos[:,1]+=(pkgSpeed/3.6)*np.sin(pkgHdg)*dt
            # Mission-specific terminal profile. Distance remaining is measured along the package track.
            rem=np.maximum(0.0,pkgPos[:,0]-float(package_target_x))
            if package_terminal_profile!='level' and package_transition_start_m>package_transition_end_m:
                ta=float(package_terminal_alt_m if package_terminal_alt_m is not None else package_alt_m)
                ts=float(package_terminal_speed_kmh if package_terminal_speed_kmh is not None else package_speed_kmh)
                frac=np.clip((float(package_transition_start_m)-rem)/(float(package_transition_start_m)-float(package_transition_end_m)),0,1)
                pkgH=float(package_alt_m)+(ta-float(package_alt_m))*frac
                pkgSpeed=float(package_speed_kmh)+(ts-float(package_speed_kmh))*frac
            was=pkgActive.copy();pkgActive&=pkgPos[:,0]>package_target_x
            just=was&(~pkgActive)&(pkgDeliveryCycle<0);pkgDeliveryCycle[just]=cyc
            if np.any(just):
                pkgDeliveryDynX[just]=pkgDynX[just];pkgDeliveryDynY[just]=pkgDynY[just];pkgDeliveryDynZ[just]=pkgDynZ[just];pkgDeliveryDynH[just]=pkgDynH[just];pkgDeliveryLastEv[just]=pkgLastEv[just]
                if package_online_damage:
                    for k,st in enumerate(pkgStates):
                        for fld in pkgDeliveryState: pkgDeliveryState[fld][just,k]=st[fld][just]
                        pkgDeliveryFire[just,k]=st['fire'][just];pkgDeliveryMission[just,k]=st['mission'][just];pkgDeliveryImmediate[just,k]=st['immediate'][just]
        timerA=np.maximum(0,timerA-1);timerB=np.maximum(0,timerB-1);pkgRunLock=np.maximum(0,pkgRunLock-1);pkgReattackCD=np.maximum(0,pkgReattackCD-1);pkgRecover=np.maximum(0,pkgRecover-1)
        # Recompute geometry after movement. Only one selected target per shooter may be fired upon.
        R,bear,relA,relB,noseA,noseB,rearA,rearB=_pair_geometry(posA,hdgA,posB,hdgB)
        cone=np.deg2rad(11.5);dh=hB[:,None,:]-hA[:,:,None];slant=np.sqrt(R*R+dh*dh);vangA=np.arctan2(dh,R);vangB=-vangA
        aspA=_aspect_codes(hdgB[:,None,:],bear);aspB=_aspect_codes(hdgA[:,:,None],wrap(bear+np.pi))
        vaOK=np.abs(wrap(vangA-gammaA[:,:,None]))<np.deg2rad(13.0);vbOK=np.abs(wrap(vangB-gammaB[:,None,:]))<np.deg2rad(13.0)
        # Rear/beam shots use the normal envelope. Head-on snapshots face much higher closure and
        # are limited to a shorter, narrower trigger window instead of counting as equivalent position.
        candA=((((aspA!=2)&(slant<520)&(np.abs(relA)<cone))|((aspA==2)&(slant<300)&(np.abs(relA)<np.deg2rad(6.0))))&vaOK)&engA[:,:,None]&engB[:,None,:]
        candB=((((aspB!=2)&(slant<520)&(np.abs(relB)<cone))|((aspB==2)&(slant<300)&(np.abs(relB)<np.deg2rad(6.0))))&vbOK)&engA[:,:,None]&engB[:,None,:]
        multiCandA+=(candA.sum(2)>1).sum(1);multiCandB+=(candB.sum(1)>1).sum(1)
        anyFA=np.zeros(n,bool);anyFB=np.zeros(n,bool);fireA=[];fireB=[]
        for i in range(N):
            t=targetA[:,i];rows=np.arange(n);ok=live&engA[:,i]&engB[rows,t]&candA[rows,i,t]
            ix=np.where(ok)[0]
            if len(ix):
                rr=slant[ix,i,t[ix]];align=np.cos(relA[ix,i,t[ix]]);quality=np.clip((520-rr)/320+.55*(align-.96)/.04,0,1.5);asp=_aspect_codes(hdgB[ix,t[ix]],bear[ix,i,t[ix]])
                fireA.append((i,t,ix,quality,rr,asp));anyFA[ix]=True
        for j in range(N):
            t=targetB[:,j];rows=np.arange(n);ok=live&engB[:,j]&engA[rows,t]&candB[rows,t,j]
            ix=np.where(ok)[0]
            if len(ix):
                rr=slant[ix,t[ix],j];align=np.cos(relB[ix,t[ix],j]);quality=np.clip((520-rr)/320+.55*(align-.96)/.04,0,1.5);asp=_aspect_codes(hdgA[ix,t[ix]],wrap(bear[ix,t[ix],j]+np.pi))
                fireB.append((j,t,ix,quality,rr,asp));anyFB[ix]=True
        un=firstshot==0;firstshot[un&anyFA&~anyFB]=1;firstshot[un&anyFB&~anyFA]=-1;firstshot[un&anyFA&anyFB]=2;firstcycle[(firstcycle<0)&(anyFA|anyFB)]=cyc
        for i,t,ix,q,rr,asp in fireA:
            tt=t[ix]
            for j in range(N):
                mask=tt==j;ii=ix[mask]
                if len(ii):
                    burstsA[ii,i]+=1; shotRangeA+=float(rr[mask].sum()); shotCountA+=len(ii)
                    for ac in range(3): shotAspectA[ac]+=int(np.sum(asp[mask]==ac))
                    firing_burst_geom(daA[i],db,weapons,effects,stB[j],ii,q[mask],rr[mask],asp[mask],rng,ammoA[i],roundsA[:,i],hitsA[:,i]);timerA[ii,i]=3;postA[ii,i]+=1
        for j,t,ix,q,rr,asp in fireB:
            tt=t[ix]
            for i in range(N):
                mask=tt==i;ii=ix[mask]
                if len(ii):
                    burstsB[ii,j]+=1; shotRangeB+=float(rr[mask].sum()); shotCountB+=len(ii)
                    for ac in range(3): shotAspectB[ac]+=int(np.sum(asp[mask]==ac))
                    firing_burst_geom(db,daA[i],weapons,effects,stA[i],ii,q[mask],rr[mask],asp[mask],rng,ammoB[j],roundsB[:,j],hitsB[:,j]);timerB[ii,j]=3;postB[ii,j]+=1
        if package_mode:
            # Sub-step only the firing geometry while keeping the 2.5 s flight/decision cycle.
            # This catches a real 300-500 m firing window crossed between state updates.
            rows=np.arange(n);gate=np.zeros((n,N),bool);gasp=np.full((n,N),-1,np.int8);gr=np.full((n,N),np.nan);gq=np.full((n,N),-1.0);gbear=np.full((n,N),np.nan);gverr=np.full((n,N),np.nan);ghr=np.full((n,N),np.nan);gfrac=np.full((n,N),1.0)
            cph=np.cos(pkgHdg);sph=np.sin(pkgHdg)
            for frac in np.linspace(1/max(1,int(package_fire_substeps)),1.0,max(1,int(package_fire_substeps))):
                capx=posA0[:,:,0]+frac*(posA[:,:,0]-posA0[:,:,0]);capy=posA0[:,:,1]+frac*(posA[:,:,1]-posA0[:,:,1]);pcx=pkgPos0[:,0]+frac*(pkgPos[:,0]-pkgPos0[:,0]);pcy=pkgPos0[:,1]+frac*(pkgPos[:,1]-pkgPos0[:,1])
                for i in range(N):
                    pt=pkgTargetA[:,i]
                    # Interpolate both package centre and individual jink state inside the 2.5 s flight step.
                    dxo=pkgDynX0[np.arange(n),pt]+frac*(pkgDynX[np.arange(n),pt]-pkgDynX0[np.arange(n),pt]);dyo=pkgDynY0[np.arange(n),pt]+frac*(pkgDynY[np.arange(n),pt]-pkgDynY0[np.arange(n),pt]);dzo=pkgDynZ0[np.arange(n),pt]+frac*(pkgDynZ[np.arange(n),pt]-pkgDynZ0[np.arange(n),pt]);dho=pkgDynH0[np.arange(n),pt]+frac*(pkgDynH[np.arange(n),pt]-pkgDynH0[np.arange(n),pt])
                    ox=pkgOffsets[pt,0]+dxo;oy=pkgOffsets[pt,1]+dyo;oz=pkgOffsets[pt,2]+dzo;tx=pcx+cph*ox-sph*oy;ty=pcy+sph*ox+cph*oy;th=(pkgH0+frac*(np.asarray(pkgH)-pkgH0))+oz;thdg=wrap(pkgHdg+dho);dx=tx-capx[:,i];dy=ty-capy[:,i];hr=np.sqrt(dx*dx+dy*dy)+1e-6;rr=np.sqrt(hr*hr+(th-hA[:,i])**2);beari=np.arctan2(dy,dx);rel=wrap(beari-hdgA[:,i]);vang=np.arctan2(th-hA[:,i],hr);verr=np.abs(wrap(vang-gammaA[:,i]));asp=_aspect_codes(thdg,beari);normal=(asp!=2)&(rr<520)&(np.abs(rel)<np.deg2rad(11.5));front=(asp==2)&(rr<300)&(np.abs(rel)<np.deg2rad(6.0));ok=engA[:,i]&packageEligible[i]&(pkgPassCount[:,i]<Mpass)&pkgActive&((pkgAlive[np.arange(n),pt]) if package_loss_feedback else True)&(normal|front)&(verr<np.deg2rad(13.0));q=np.clip((520-rr)/320+.55*(np.cos(rel)-.96)/.04,0,1.5);jfac=np.where(pkgEvTimer[np.arange(n),pt]>0,float(evp.get('immediate',1.0)),1.0) if package_dynamic_formation else 1.0;q=q*jfac;take=ok&(q>gq[:,i]);gate[:,i]|=ok;gasp[take,i]=asp[take];gr[take,i]=rr[take];gbear[take,i]=beari[take];gverr[take,i]=verr[take];ghr[take,i]=hr[take];gq[take,i]=q[take];gfrac[take,i]=frac
            accepted=np.zeros(n,int)
            if gate.any():
                ev=np.argwhere(gate)
                if package_online_damage and len(ev):
                    order=np.lexsort((gfrac[ev[:,0],ev[:,1]],ev[:,0]));ev=ev[order]
                for tr,fi in ev:
                    kk=int(pkgPassCount[tr,fi]);pt=int(pkgTargetA[tr,fi])
                    if kk>=Mpass:continue
                    lost_before=bool(package_online_damage and pkgStates[pt]['mission'][tr])
                    if lost_before and package_loss_feedback:
                        pkgOnlineAborted[tr]+=1
                        continue
                    pkgPassAspect[tr,fi,kk]=gasp[tr,fi];pkgPassRange[tr,fi,kk]=gr[tr,fi];pkgPassHorizRange[tr,fi,kk]=ghr[tr,fi];pkgPassCycle[tr,fi,kk]=cyc;pkgPassAlign[tr,fi,kk]=math.cos(float(mrel[tr,fi,pt]));pkgPassVerr[tr,fi,kk]=gverr[tr,fi];pkgPassBearing[tr,fi,kk]=gbear[tr,fi];pkgPassHeading[tr,fi,kk]=hdgA[tr,fi];pkgPassAlt[tr,fi,kk]=hA[tr,fi];pkgPassGamma[tr,fi,kk]=gammaA[tr,fi];pkgPassTarget[tr,fi,kk]=pt;pkgPassTargetAlt[tr,fi,kk]=float(pkgH[tr]+pkgOffsets[pt,2]+pkgDynZ[tr,pt]);sup=1-float(escort_aim_suppression)*float(np.clip((threatA[tr,fi]-.55)/.40,0,1));qeff=float(gq[tr,fi]*sup);pkgPassQuality[tr,fi,kk]=qeff;pkgPassThreat[tr,fi,kk]=threatA[tr,fi]
                    pkgPassCount[tr,fi]+=1;accepted[tr]+=1;pkgReattackCD[tr,fi]=int(package_reattack_cooldown_cycles);pkgRecover[tr,fi]=int(package_recover_cycles);pkgRunLock[tr,fi]=0;pkgRunCommitted[tr,fi]=False
                    if package_online_damage and lost_before:
                        pkgOnlineWasted[tr]+=1
                    if package_online_damage and (not lost_before):
                        # A physical pass does not guarantee a clean firing burst.  If it does fire,
                        # consume the same onboard ammunition used by fighter-v-fighter combat and apply
                        # component damage immediately to the selected strike aircraft.
                        firep=float(np.clip(.52+.42*(qeff/1.25),.42,.95))
                        if qeff>.08 and rng.random()<firep:
                            before_r=int(roundsA[tr,fi]);before_h=int(hitsA[tr,fi])
                            firing_burst_geom(daA[fi],package_defense,weapons,effects,pkgStates[pt],np.array([tr]),np.array([qeff]),np.array([gr[tr,fi]]),np.array([gasp[tr,fi]],np.int8),rng,ammoA[fi],roundsA[:,fi],hitsA[:,fi],size_factor=package_size_factor)
                            dr=int(roundsA[tr,fi]-before_r);dhit=int(hitsA[tr,fi]-before_h)
                            if dr>0:
                                pkgOnlineClean[tr]+=1;pkgOnlineRounds[tr]+=dr;pkgOnlineHits[tr]+=dhit;lab=str(layerLabels[fi]);pkgOnlineCleanByLayer[lab][tr]+=1;pkgOnlineRoundsByLayer[lab][tr]+=dr;pkgOnlineHitsByLayer[lab][tr]+=dhit
                            if pkgStates[pt]['mission'][tr] and pkgMissionCycle[tr,pt]<0:
                                pkgMissionCycle[tr,pt]=cyc;pkgAlive[tr,pt]=False
            pkgPasses+=accepted;pkgFirst[(pkgFirst<0)&(accepted>0)]=cyc
            # Escort interception credit: escort attacking a CAP that is currently committed near package.
            for j in range(N):
                t=targetB[:,j];close=np.sqrt((posA[rows,t,0]-pkgPos[:,0])**2+(posA[rows,t,1]-pkgPos[:,1])**2)<2500
                pkgEscortIntercepts+=engB[:,j]&penetrateA[rows,t]&close&(actB[:,j]==ATTACK)
        # Cohesion derived from real separation/heading, not abstract height/speed differences.
        if formation:
            for s in range(ns):
                i=2*s;k=i+1
                dA=np.linalg.norm(posA[:,i]-posA[:,k],axis=1);dhA=np.abs(hA[:,i]-hA[:,k]);hdA=np.abs(wrap(hdgA[:,i]-hdgA[:,k]))
                dB=np.linalg.norm(posB[:,i]-posB[:,k],axis=1);dhB=np.abs(hB[:,i]-hB[:,k]);hdB=np.abs(wrap(hdgB[:,i]-hdgB[:,k]))
                cohA[:,s]=np.clip(1-.00022*np.abs(dA-450)-.00020*dhA-.16*(hdA/np.pi),.12,1)
                cohB[:,s]=np.clip(1-.00022*np.abs(dB-450)-.00020*dhB-.16*(hdB/np.pi),.12,1)
            # Group cohesion = section centroids staying within mutual support distances.
            centA=np.stack([posA[:,2*s:2*s+2].mean(1) for s in range(ns)],1);centB=np.stack([posB[:,2*s:2*s+2].mean(1) for s in range(ns)],1)
            secA=np.stack([engA[:,2*s:2*s+2].any(1) for s in range(ns)],1);secB=np.stack([engB[:,2*s:2*s+2].any(1) for s in range(ns)],1)
            def wspread(cent,mask):
                ww=mask.astype(float);den=np.maximum(1,ww.sum(1));mu=(cent*ww[:,:,None]).sum(1)/den[:,None];rr=np.sqrt(((cent-mu[:,None,:])**2).sum(2));return (rr*ww).sum(1)/den
            spreadA=wspread(centA,secA);spreadB=wspread(centB,secB)
            groupA=np.clip(1-spreadA/6500,.20,.96);groupB=np.clip(1-spreadB/6500,.20,.96)
        else:cohA[:]=0;cohB[:]=0;groupA[:]=0;groupB[:]=0
        # Optional physical disengagement after 60 s if extending and >7 km from all enemies.
        if cyc*dt>60:
            Rnow=_pair_geometry(posA,hdgA,posB,hdgB)[0]
            for i in range(N):
                far=np.min(np.where(engB[:,None,:],Rnow[:,i:i+1,:],1e9),axis=(1,2))>7000;take=engA[:,i]&(actA[:,i]==EXTEND)&far;disA[:,i]|=take;engA[:,i]&=~take
            for j in range(N):
                far=np.min(np.where(engA[:,:,None],Rnow[:,:,j:j+1],1e9),axis=(1,2))>7000;take=engB[:,j]&(actB[:,j]==EXTEND)&far;disB[:,j]|=take;engB[:,j]&=~take
    if package_online_damage:
        pmis=np.stack([st['mission'] for st in pkgStates],axis=1);pkgAlive=~pmis
        # Trials wiped before the delivery line never triggered a delivery snapshot; preserve their
        # terminal component state so downstream release-quality code can still see that all members are lost.
        nosnap=pkgDeliveryCycle<0
        if np.any(nosnap):
            for k,st in enumerate(pkgStates):
                for fld in pkgDeliveryState: pkgDeliveryState[fld][nosnap,k]=st[fld][nosnap]
                pkgDeliveryFire[nosnap,k]=st['fire'][nosnap];pkgDeliveryMission[nosnap,k]=st['mission'][nosnap];pkgDeliveryImmediate[nosnap,k]=st['immediate'][nosnap]
    else:
        pmis=np.zeros((n,Kpkg),bool)
    ma=_mission(stA);mb=_mission(stB);lossA=ma.sum(1);lossB=mb.sum(1)
    damA=np.stack([base.damage_summary(stA[i]) for i in range(N)],1);damB=np.stack([base.damage_summary(stB[i]) for i in range(N)],1)
    layerPasses={};layerLosses={};layerDamaged={}
    for lab in dict.fromkeys(layerLabels.tolist()):
        ii=np.where(layerLabels==lab)[0];layerPasses[str(lab)]=float(pkgPassCount[:,ii].sum(1).mean()) if len(ii) else 0.0;layerLosses[str(lab)]=float(ma[:,ii].sum(1).mean()) if len(ii) else 0.0;layerDamaged[str(lab)]=float(((damA[:,ii]>.08)&(~ma[:,ii])).sum(1).mean()) if len(ii) else 0.0
    result = {
      'N':N,'active_A':active_A,'active_B':active_B,'A_mean_losses':float(lossA.mean()),'B_mean_losses':float(lossB.mean()),'A_loss_share':float(lossA.sum()/max(1,lossA.sum()+lossB.sum())),
      'A_no_loss':float((lossA==0).mean()),'B_no_loss':float((lossB==0).mean()),'A_two_plus_loss':float((lossA>=2).mean()),'B_two_plus_loss':float((lossB>=2).mean()),
      'A_group_wiped':float((lossA==N).mean()),'B_group_wiped':float((lossB==N).mean()),'A_fewer_losses':float((lossA<lossB).mean()),'B_fewer_losses':float((lossB<lossA).mean()),'equal_losses':float((lossA==lossB).mean()),
      'A_first_teamshot':float((firstshot==1).mean()),'B_first_teamshot':float((firstshot==-1).mean()),'simul_firstshot':float((firstshot==2).mean()),
      'A_inflicts_first_loss':float((firstloss==1).mean()),'B_inflicts_first_loss':float((firstloss==-1).mean()),
      'A_mean_bursts':float(burstsA.sum(1).mean()),'B_mean_bursts':float(burstsB.sum(1).mean()),'A_mean_hits':float(hitsA.sum(1).mean()),'B_mean_hits':float(hitsB.sum(1).mean()),
      'A_damaged_returnable':float(((damA>.08)&(~ma)).sum(1).mean()),'B_damaged_returnable':float(((damB>.08)&(~mb)).sum(1).mean()),
      'A_target_switches':float(switchA.mean()),'B_target_switches':float(switchB.mean()),'A_rescue_switches':float(rescueA.mean()),'B_rescue_switches':float(rescueB.mean()),'A_cross_rescues':float(crossAcount.mean()),'B_cross_rescues':float(crossBcount.mean()),
      'A_deconflict_events':float(deconfA.mean()),'B_deconflict_events':float(deconfB.mean()),'A_multi_candidate_cycles':float(multiCandA.mean()),'B_multi_candidate_cycles':float(multiCandB.mean()),
      'A_shot_aspect_rear':float(shotAspectA[0]/max(1,shotCountA)),'A_shot_aspect_beam':float(shotAspectA[1]/max(1,shotCountA)),'A_shot_aspect_front':float(shotAspectA[2]/max(1,shotCountA)),'B_shot_aspect_rear':float(shotAspectB[0]/max(1,shotCountB)),'B_shot_aspect_beam':float(shotAspectB[1]/max(1,shotCountB)),'B_shot_aspect_front':float(shotAspectB[2]/max(1,shotCountB)),'A_mean_shot_range_m':float(shotRangeA/max(1,shotCountA)),'B_mean_shot_range_m':float(shotRangeB/max(1,shotCountB)),
      'A_min_friend_spacing_m':float(np.mean(np.minimum(min_friend_A,9999))),'B_min_friend_spacing_m':float(np.mean(np.minimum(min_friend_B,9999))),
      'A_section_cohesion':float(cohA.mean()),'B_section_cohesion':float(cohB.mean()),'A_group_cohesion':float(groupA.mean()),'B_group_cohesion':float(groupB.mean()),
      'A_disengaged':float(disA.sum(1).mean()),'B_disengaged':float(disB.sum(1).mean()),
      'package_mode':bool(package_mode),'package_speed_kmh':float(package_speed_kmh),'package_alt_m':float(package_alt_m),'package_start_x':float(package_start_x),'package_target_x':float(package_target_x),'package_attack_passes':float(pkgPasses.mean()),'package_any_breach':float((pkgPasses>0).mean()),'package_two_plus_breach':float((pkgPasses>=2).mean()),'package_escort_intercepts':float(pkgEscortIntercepts.mean()),'package_mean_first_attack_time_s':float(np.mean(pkgFirst[pkgFirst>=0])*dt if np.any(pkgFirst>=0) else math.nan),
      'package_online_damage':bool(package_online_damage),'package_loss_feedback':bool(package_loss_feedback),'package_online_mission_losses':float(pmis.sum(1).mean()) if package_online_damage else 0.0,'package_online_clean_bursts':float(pkgOnlineClean.mean()) if package_online_damage else 0.0,'package_online_rounds':float(pkgOnlineRounds.mean()) if package_online_damage else 0.0,'package_online_hits':float(pkgOnlineHits.mean()) if package_online_damage else 0.0,'package_aborted_passes_on_newly_lost_target':float(pkgOnlineAborted.mean()) if package_online_damage else 0.0,'package_wasted_passes_on_lost_target':float(pkgOnlineWasted.mean()) if package_online_damage else 0.0,'package_online_clean_bursts_by_layer':{k:float(v.mean()) for k,v in pkgOnlineCleanByLayer.items()} if package_online_damage else {},'package_online_rounds_by_layer':{k:float(v.mean()) for k,v in pkgOnlineRoundsByLayer.items()} if package_online_damage else {},'package_online_hits_by_layer':{k:float(v.mean()) for k,v in pkgOnlineHitsByLayer.items()} if package_online_damage else {},
      'mean_firstshot_time_s':float(np.mean(firstcycle[firstcycle>=0])*dt if np.any(firstcycle>=0) else math.nan),
      'action_share_A':{ACTION_NAMES[i]:float(action_count_A[i]/max(1,action_count_A.sum())) for i in range(5)},'action_share_B':{ACTION_NAMES[i]:float(action_count_B[i]/max(1,action_count_B.sum())) for i in range(5)},
      'A_lateral_offset_m':float(A_lateral_offset_m),'A_initial_x_mean_m':float(np.mean(axfull)),'B_initial_x_mean_m':float(np.mean(bxfull)),'A_initial_x_m_by_fighter':axfull.tolist(),'B_initial_x_m_by_fighter':bxfull.tolist(),'package_vector_range_m':float(package_vector_range_m),'package_commit_threat':float(package_commit_threat),'package_run_lock_cycles':int(package_run_lock_cycles),'package_run_lock_range_m':float(package_run_lock_range_m),'package_run_lock_threat':float(package_run_lock_threat),'package_run_starts':float(pkgRunStarts.mean()),'package_route_fighter_cycles':float(pkgRouteCycles.mean()),'package_route_fighters_ever':float(pkgRouteEver.sum(1).mean()),'package_max_passes_per_fighter':Mpass,'package_aircraft_count':Kpkg,'package_fire_substeps':int(package_fire_substeps),'package_hard_break_threat':float(package_hard_break_threat),'escort_aim_suppression':float(escort_aim_suppression),'package_reattack_cooldown_cycles':int(package_reattack_cooldown_cycles),'package_attack_passes_by_layer':layerPasses,'A_mission_losses_by_layer':layerLosses,'A_damaged_returnable_by_layer':layerDamaged,'escort_attack_fighter_cycles_by_A_layer':{k:float(v.mean()) for k,v in escortAttackByLayer.items()},'A_route_side_m':routeSide.tolist(),'A_route_alt_m':routeAlt.tolist(),'A_route_release_slant_m':float(A_route_release_slant_m),'A_layer_labels':layerLabels.tolist(),'package_terminal_profile':str(package_terminal_profile),'package_terminal_alt_m':float(package_terminal_alt_m if package_terminal_alt_m is not None else package_alt_m),'package_terminal_speed_kmh':float(package_terminal_speed_kmh if package_terminal_speed_kmh is not None else package_speed_kmh),'package_transition_start_m':float(package_transition_start_m),'package_transition_end_m':float(package_transition_end_m),'package_dynamic_formation':bool(package_dynamic_formation),'package_warning_reactions':float(pkgWarnCount.mean()),'package_target_switches':float(pkgTargetSwitches.mean()),'package_target_switches_after_target_loss':float(pkgLossDrivenSwitches.mean()),'package_target_switches_after_warning':float(pkgSwitchAfterWarn.mean()),'package_switch_opportunities_after_warning':float(pkgWarnFollowOpp.mean()),'package_target_switches_without_warning':float(pkgSwitchNoWarn.mean()),'package_switch_opportunities_without_warning':float(pkgWarnNoFollowOpp.mean()),'package_switch_rate_after_warning':float(pkgSwitchAfterWarn.sum()/max(1,pkgWarnFollowOpp.sum())),'package_switch_rate_without_warning':float(pkgSwitchNoWarn.sum()/max(1,pkgWarnNoFollowOpp.sum())),'package_max_rms_lateral_m':float(pkgMaxRMSY.mean()),'package_max_rms_vertical_m':float(pkgMaxRMSZ.mean()),'package_max_rms_heading_deg':float(pkgMaxRMSH.mean()),'package_delivery_rms_longitudinal_m':float(np.mean(np.sqrt(np.mean(pkgDeliveryDynX**2,axis=1)))),'package_delivery_rms_lateral_m':float(np.mean(np.sqrt(np.mean(pkgDeliveryDynY**2,axis=1)))),'package_delivery_rms_vertical_m':float(np.mean(np.sqrt(np.mean(pkgDeliveryDynZ**2,axis=1)))),'package_delivery_rms_heading_deg':float(np.mean(np.sqrt(np.mean(np.rad2deg(pkgDeliveryDynH)**2,axis=1)))),'formation':bool(formation),'comm_local_A':comm_local_A,'comm_local_B':comm_local_B,'comm_cross_A':comm_cross_A,'comm_cross_B':comm_cross_B,'ntr':ntr,'max_time_s':max_cycles*dt
    }
    if return_trials:
        result['trial_package_passes']=pkgPasses.tolist();result['trial_package_delivery_cycle']=pkgDeliveryCycle.tolist()
        result['trial_package_delivery_dx_m']=pkgDeliveryDynX.tolist();result['trial_package_delivery_dy_m']=pkgDeliveryDynY.tolist();result['trial_package_delivery_dz_m']=pkgDeliveryDynZ.tolist();result['trial_package_delivery_dheading_rad']=pkgDeliveryDynH.tolist();result['trial_package_last_evasion_cycle']=pkgDeliveryLastEv.tolist();result['trial_package_warning_count_by_member']=pkgWarnByMember.tolist()
        result['trial_A_fighter_losses']=lossA.tolist();result['trial_B_fighter_losses']=lossB.tolist()
        result['trial_package_pass_aspect']=pkgPassAspect.tolist()
        result['trial_package_pass_range_m']=np.where(np.isfinite(pkgPassRange),pkgPassRange,-1).tolist()
        result['trial_package_pass_horizontal_range_m']=np.where(np.isfinite(pkgPassHorizRange),pkgPassHorizRange,-1).tolist()
        result['trial_package_pass_align']=np.where(np.isfinite(pkgPassAlign),pkgPassAlign,-1).tolist()
        result['trial_package_pass_vertical_error_rad']=np.where(np.isfinite(pkgPassVerr),pkgPassVerr,-1).tolist()
        result['trial_package_pass_cycle']=pkgPassCycle.tolist()
        result['trial_package_pass_bearing_rad']=np.where(np.isfinite(pkgPassBearing),pkgPassBearing,-99).tolist()
        result['trial_package_pass_heading_rad']=np.where(np.isfinite(pkgPassHeading),pkgPassHeading,-99).tolist()
        result['trial_package_pass_alt_m']=np.where(np.isfinite(pkgPassAlt),pkgPassAlt,-1).tolist()
        result['trial_package_pass_gamma_rad']=np.where(np.isfinite(pkgPassGamma),pkgPassGamma,-99).tolist()
        result['trial_package_pass_count_by_fighter']=pkgPassCount.tolist()
        result['trial_package_pass_target_index']=pkgPassTarget.tolist();result['trial_package_pass_target_alt_m']=np.where(np.isfinite(pkgPassTargetAlt),pkgPassTargetAlt,-1).tolist()
        result['trial_package_pass_quality']=np.where(np.isfinite(pkgPassQuality),pkgPassQuality,-1).tolist()
        result['trial_package_pass_threat']=np.where(np.isfinite(pkgPassThreat),pkgPassThreat,-1).tolist()
        if package_online_damage:
            result['trial_package_online_mission']=pkgDeliveryMission.tolist();result['trial_package_online_immediate']=pkgDeliveryImmediate.tolist();result['trial_package_mission_cycle']=pkgMissionCycle.tolist()
            result['trial_package_online_fire']=pkgDeliveryFire.tolist()
            for fld,arr in pkgDeliveryState.items(): result[f'trial_package_online_{fld}']=arr.tolist()
            result['trial_package_online_clean_bursts']=pkgOnlineClean.tolist();result['trial_package_online_rounds']=pkgOnlineRounds.tolist();result['trial_package_online_hits']=pkgOnlineHits.tolist();result['trial_package_online_aborted']=pkgOnlineAborted.tolist();result['trial_package_online_wasted']=pkgOnlineWasted.tolist()
    return result

def simulate_escort_cap(pa,pb,da,db,weapons,effects,**kwargs):
    kwargs.setdefault('package_mode',True);kwargs.setdefault('max_cycles',52);kwargs.setdefault('initial_sep_m',6200.0)
    return simulate_geometry(pa,pb,da,db,weapons,effects,**kwargs)

def load_all(root='.'):
    root=Path(root);return base.load_all(root/'profiles_v03.json',root/'weapons_v081.json',root/'aircraft_damage_v02.json')

if __name__=='__main__':
    R=Path(__file__).parent;p,w,e,d=load_all(R);print(json.dumps(simulate_escort_cap(p['JP05'],p['US02'],d['JP05'],d['US02'],w,e,N=8,ntr=50,seed=7),ensure_ascii=False,indent=2))
