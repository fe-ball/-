#!/usr/bin/env python3
from __future__ import annotations
import argparse,json,sys
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent; sys.path.insert(0,str(R))
from run_forager_strike_cell_v118 import run_air
from air_trial_bridge_v118 import classify_package_trial

def q(a,p): return float(np.quantile(np.asarray(a,float),p))
def one(target,escort,ntr,seed):
    x=run_air(target,ntr,seed,us_local_aa=True,escort_count=escort)
    audits=[classify_package_trial(x,i) for i in range(ntr)]
    lost=np.array([int(a['lost_mask'].sum()) for a in audits]); dmg=np.array([int(a['damaged_mask'].sum()) for a in audits])
    rel=np.asarray(x.get('trial_package_weapon_release_mission',[]),dtype=bool)
    release_alive=(~rel).sum(1) if rel.ndim==2 else np.full(ntr,np.nan)
    return {
      'target':target,'escort_count':escort,'ntr':ntr,
      'attack_lost_mean':float(lost.mean()),'attack_lost_p50':q(lost,.5),'attack_lost_p90':q(lost,.9),
      'attack_damaged_mean':float(dmg.mean()),'attack_p_any_damage':float((dmg>0).mean()),
      'escort_lost_mean':float(x['B_mean_losses']), 'us_cap_lost_mean':float(x['A_mean_losses']),
      'attack_passes_mean':float(x['package_attack_passes']),
      'escort_intercepts_mean':float(x['package_escort_intercepts']),
      'weapon_release_count_mean':float(x.get('package_weapon_release_count',float('nan'))),
      'weapon_release_quality_equiv_mean':float(x.get('package_weapon_release_quality_equivalent',float('nan'))),
      'weapon_release_alive_mean':float(np.nanmean(release_alive)),
      'aa_new_mission_losses_mean':float(x.get('global_mean_AA_new_mission_losses',0.0)),
      'aa_jink_events_mean':float(x.get('global_mean_AA_jink_events',0.0)),
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--ntr',type=int,default=32); ap.add_argument('--seed',type=int,default=118800); ap.add_argument('--escorts',default='0,4,6,8'); ap.add_argument('--targets',default='B6N2,D4Y2')
    a=ap.parse_args(); escorts=[int(z) for z in a.escorts.split(',')]; targets=[z.strip() for z in a.targets.split(',')]
    rows=[]
    for ti,t in enumerate(targets):
      for e in escorts:
        rows.append(one(t,e,a.ntr,a.seed+ti*100000))
        print(t,e,rows[-1]['attack_lost_mean'],rows[-1]['attack_damaged_mean'],rows[-1]['escort_lost_mean'],flush=True)
    out=R.parent/'results_current'; out.mkdir(exist_ok=True)
    (out/'forager_escort_sensitivity_v118.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    import csv
    with open(out/'forager_escort_sensitivity_v118.csv','w',newline='',encoding='utf-8-sig') as f:
      w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader();w.writerows(rows)

if __name__=='__main__': main()
