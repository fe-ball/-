# RECOVERY — v0.11.7 Carrier Mission Continuation

## Resume point

The aircraft/mission microcombat stack is substantially complete through carrier mission consequence.

Current chain:
1. individual aircraft energy/handling/damage
2. formation geometry
3. escort/CAP
4. dynamic strike formation
5. online loss feedback / rear gunners
6. heterogeneous high/low CAP including Kyofu
7. local AA / ship evasion
8. single global timeline
9. AA/CAP fire discipline
10. real maneuvering screen ships
11. actual weapon release gate
12. bomb / torpedo moving-target flight
13. synchronized multi-axis/anvil TBF geometry
14. **v0.11.7 carrier component damage / mission continuation**

## Do not do next
- Do not return to crude kill ratios.
- Do not turn `p_lost` into a historical sinking coefficient.
- Do not immediately resume 1944-07 historical clock without sortie regeneration.

## Next correct layer: sortie regeneration

Consume per-carrier state:
- launch capacity
- recovery capacity
- maximum speed / turn capacity
- deck closure/restriction state
- AA capacity
- repair state

Combine with:
- surviving aircraft by type
- damaged-returnable aircraft and repair queue
- fuel/ammunition inventory
- pilot availability/fatigue
- deck crew / maintenance capacity
- daylight/time-to-next-wave

Output:
- aircraft recoverable now
- aircraft launchable in 30/60/120 min
- next-wave package size by aircraft type
- CAP layer sustainable strength
- overnight repair / next-day availability

After sortie regeneration is validated, historical FORAGER reconstruction can resume.
