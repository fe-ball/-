#!/usr/bin/env python3
from __future__ import annotations
import argparse, json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]

# Canonical r30 bands at 1944-07-07 night.  Exact within-group role/qualification splits below are B-priors.
CANON={
    'first_group_total':(285,295,305),
    'second_group_total':(160,170,180),
    'all_carriers_combat_usable':(460,480,500),
    'frontline_qualified':(420,440,460),
}
# Ryujo is outside the central 9-carrier battle line; its working air-group size is deliberately only a B-prior.
RYUJO_B=(12,17,22)

GROUPS={
 'first':{
   'carriers':['TAIHO','SHOKAKU','ZUIKAKU','HIRYU'],
   'weights':[.25,.255,.255,.24],
   'roles_mode':[.43,.29,.28], # F,DB,TB
   'roles_conc':180,
   'limited':(.04,.06,.08), 'core':(.18,.21,.24),
   'carrier_day':(.94,.965,.985), 'night':(.24,.30,.36),
   'nav_radio':(.72,.78,.84), 'formation_lead':(.16,.20,.24), 'role_attack':(.82,.87,.92),
 },
 'second':{
   'carriers':['JUNYO','HIYO','RYUHO','ZUIHO','SHOHO'],
   'weights':[.25,.25,.17,.17,.16],
   'roles_mode':[.52,.25,.23],
   'roles_conc':130,
   'limited':(.08,.11,.14), 'core':(.12,.15,.18),
   'carrier_day':(.86,.90,.94), 'night':(.16,.22,.28),
   'nav_radio':(.58,.65,.72), 'formation_lead':(.12,.15,.18), 'role_attack':(.70,.77,.84),
 },
 'reserve':{
   'carriers':['RYUJO'], 'weights':[1.0],
   'roles_mode':[.62,.20,.18], 'roles_conc':90,
   'limited':(.15,.21,.28), 'core':(.08,.11,.14),
   'carrier_day':(.70,.80,.88), 'night':(.12,.17,.22),
   'nav_radio':(.50,.57,.65), 'formation_lead':(.10,.12,.15), 'role_attack':(.60,.68,.75),
 }
}


def tri(rng, band, n):
    lo,md,hi=band
    return rng.triangular(lo,md,hi,n)

def integer_role_counts(rng,total,mode,conc):
    share=rng.dirichlet(np.asarray(mode)*conc)
    return rng.multinomial(int(total),share)

def integer_carrier_counts(rng,total,weights,conc=240):
    w=np.asarray(weights,dtype=float); w=w/w.sum()
    share=rng.dirichlet(w*conc)
    return rng.multinomial(int(total),share)

def q(a):
    a=np.asarray(a,float)
    return {'p10':float(np.quantile(a,.1)),'p50':float(np.quantile(a,.5)),'p90':float(np.quantile(a,.9)),'mean':float(np.mean(a))}

def sample(n=20000,seed=118700):
    rng=np.random.default_rng(seed)
    rows=[]
    accepted=0; attempts=0
    while accepted<n and attempts<n*8:
        attempts+=1
        totals={
          'first':int(round(rng.triangular(*CANON['first_group_total']))),
          'second':int(round(rng.triangular(*CANON['second_group_total']))),
          'reserve':int(round(rng.triangular(*RYUJO_B))),
        }
        grand=sum(totals.values())
        if not (CANON['all_carriers_combat_usable'][0] <= grand <= CANON['all_carriers_combat_usable'][2]):
            continue
        # latent crew-quality draw correlated by trial so groups move together moderately.
        common=rng.normal(0,0.22)
        trial={'trial':accepted,'grand_total':grand}
        frontline=0
        for gn,g in GROUPS.items():
            total=totals[gn]
            limited=float(np.clip(rng.triangular(*g['limited'])+.01*common,0,1))
            core=float(np.clip(rng.triangular(*g['core'])+.01*common,0,1-limited))
            line=max(0.0,1.0-limited-core)
            frontline += round(total*(core+line))
            rc=integer_role_counts(rng,total,g['roles_mode'],g['roles_conc'])
            cc=integer_carrier_counts(rng,total,g['weights'])
            trial[f'{gn}_total']=total
            trial[f'{gn}_F'],trial[f'{gn}_DB'],trial[f'{gn}_TB']=map(int,rc)
            trial[f'{gn}_core']=round(total*core); trial[f'{gn}_line']=round(total*line); trial[f'{gn}_limited']=total-trial[f'{gn}_core']-trial[f'{gn}_line']
            for skill in ['carrier_day','night','nav_radio','formation_lead','role_attack']:
                v=float(np.clip(rng.triangular(*g[skill])+.012*common,0,1))
                trial[f'{gn}_{skill}']=round(total*v)
            for name,c in zip(g['carriers'],cc): trial[f'carrier_{name}']=int(c)
        trial['frontline_qualified']=int(frontline)
        # Require the aggregate qualified pool to remain inside the canonical high-qualification band.
        if not (CANON['frontline_qualified'][0] <= frontline <= CANON['frontline_qualified'][2]):
            continue
        rows.append(trial); accepted+=1
    if accepted<n:
        raise RuntimeError(f'only accepted {accepted}/{n} ledger trials after {attempts} attempts')
    return rows

def summarize(rows):
    keys=[k for k in rows[0] if k!='trial']
    out={k:q([r[k] for r in rows]) for k in keys}
    return {
      'schema':'FORAGER_AIR_LEDGER_v118_WIP',
      'current_time':'1944-07-07 night',
      'n':len(rows),
      'canonical_inputs':CANON,
      'working_B_priors':{
        'ryujo_reserve_total':RYUJO_B,
        'group_role_shares_and_qualification_bands':GROUPS,
        'warning':'Role shares, per-carrier allocation, and qualification sub-bands are B-priors constrained by canonical r30 aggregate bands; they are not historical measured counts.'
      },
      'summary':out,
      'source_notes':[
        '38_艦艇台帳_1944年7月_Marianas直前実艦・Availability.md: carrier combat-usable 460–500, high first-line qualification/training 420–460.',
        '42_艦艇台帳_1944年7月_FORAGER実艦TaskGroup・決戦配置.md: first carrier strike group 285–305; second carrier group 160–180; Ryujo reserve/ferry outside central battle line.',
        '46_航空人事_1942-44_自然還流・空地分離・練度平準化.md: qualification dimensions separated into carrier operations, night/twilight, overwater navigation/search, formation leadership, attack role, radio, etc.',
        '114_資料庫_2026-08-14_航空人事循環・練度平準化確定_FORAGER再計算前.md: restart point requires a qualification-distribution ledger before Jul 8–10 preservation/reallocation and Jul 11 strike recalculation.'
      ]
    }

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--n',type=int,default=20000); ap.add_argument('--seed',type=int,default=118700)
    a=ap.parse_args(); rows=sample(a.n,a.seed); s=summarize(rows)
    out=ROOT/'results_current'; out.mkdir(exist_ok=True)
    (out/'forager_air_ledger_v118.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
    # compact CSV: aggregate and group medians / uncertainty, not all MC trials
    import csv
    fields=['metric','p10','p50','p90','mean']
    with open(out/'forager_air_ledger_v118.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for k,v in s['summary'].items(): w.writerow({'metric':k,**v})
    print(json.dumps({k:s['summary'][k] for k in ['grand_total','frontline_qualified','first_total','first_F','first_DB','first_TB','second_total','second_F','second_DB','second_TB','carrier_TAIHO','carrier_SHOKAKU','carrier_ZUIKAKU','carrier_HIRYU']},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
