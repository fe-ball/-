# SOURCE AUDIT v0.11.7

## r30 canon — primary internal anchors

### `60_開戦戦力・輸送・空母・揚陸・砲計算.md`
Used as binding architecture:
- one bomb can make a flight deck unusable; flight-deck mission kill is not identical to ship loss.
- Unryu line incorporates compartmented fire mains, foam, segmented hangar water curtain/sprinklers, aviation-fuel shutoff, drainage, ventilation isolation, emergency power/communications and ordnance-handling discipline.
- Unryu does not become a Taiho-lite armored carrier.
- Taiho is the quality/protection carrier line.

### `43_歴史考察_1944年7月8-15_FORAGER前哨・フィリピン海再監査.md`
Calibration anchor for this alternate world:
- Taiho one-torpedo center result is not historical vapor-explosion loss.
- immediate speed about 24–26 kt, several hours restricted flight operations, later limited CAP/relaunch recovery.
- 6–10 week repair class can coexist with same-day survival/limited operation.

## Public US Navy war-damage sanity anchors

These are used only to confirm structural categories, not to fit Japanese carrier coefficients.

- USS Yorktown Midway action/war-damage material: bomb hits penetrated/damaged the flight deck/hangar system, demonstrating that direct bombs can immediately disrupt carrier aviation operations.
- USS Enterprise war history: some flight-deck damage was sufficient to prevent continuing flight operations until repair.
- USS Saratoga War Damage Report No. 19: a torpedo hit imposed major speed restriction while damage control preserved the ship.
- USS Franklin War Damage Report No. 56: bomb/hangar/armed-aircraft fire chains demonstrate why parked-fuel/ordnance state and secondary fire must be separate from simple deck-hole geometry.

No US carrier casualty statistic is inverted into a Japanese per-hit kill probability.

## Explicit B-priors
- deck repair-time distributions
- penetration/crater probabilities
- elevator-area probability
- hangar/fuel/ordnance fire-event probabilities
- underwater flooding and speed-loss distributions
- machinery/steering hit distributions
- AA degradation
- catastrophic cascade threshold
- DC sensitivity factors

These are model carriers constrained by r30 architecture and sensitivity checks, not historical measurements.
