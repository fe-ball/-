# v0.11.7 -> v0.11.8-WIP changelog

Date: 2026-08-16

## Added
- Queue-based sortie regeneration.
- Continuous evaluator for v0.11.7 carrier latent damage at arbitrary time.
- Time-varying, non-bankable recovery and launch/spotting deck work.
- Next-wave threshold probabilities at 12/24/36/48 aircraft.
- Regression and smoke checks.

## Corrected during WIP
- Removed 0/2/6/24 h linear interpolation from the active runner.
- Corrected returning-aircraft queue from type-ordered processing to global ETA FCFS.

## Current diagnostic result
Generic 72-aircraft recovery-first state, undamaged Shokaku working profile:
- +30 min p50: 0
- +60 min p50: 17
- +120 min p50: 50

Damage cases remain strongly distributional/bimodal; threshold probabilities are now preferred alongside medians.

## Status
WIP only. Do not treat the absolute sortie-generation values as canonical or as historical reconstruction outputs.

## 2026-08-16 — upstream air-trial bridge execution

- Added terminal per-aircraft package-state exports to `air_microcombat_v116.py`; same-seed regression confirms all legacy outputs unchanged.
- Added `air_trial_bridge_v118.py` to classify upstream individual aircraft into lost, returning-clean and returning-damaged states.
- Added `AirGroupState.returning_damaged` and preserved that flag through both recovery APIs; damaged airborne aircraft now enter long repair after landing rather than routine turnaround.
- Added optional `AirGroupState.crew_manifest` carrying individual identity/qualification/fatigue metadata. Aggregate pilot gate remains active for now.
- Added bridge checks and a reproducible 64-trial structural smoke runner/output.
- 64-trial smoke is explicitly non-historical (US TBF package into Japanese carrier-ops shell) and is retained only as an end-to-end plumbing diagnostic.
