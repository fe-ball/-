# v0.11.7 -> v0.11.8-WIP changelog

Date: 2026-08-16

## Added
- Queue-based sortie regeneration.
- Continuous evaluator for v0.11.7 carrier latent damage at arbitrary time.
- Time-varying, non-bankable recovery and launch/spotting deck work.
- Next-wave threshold probabilities at 12/24/36/48 aircraft.
- Regression and smoke checks.

## Corrected during WIP
- Removed 0/2/6/24 h linear interpolation from the active runner.
- Corrected returning-aircraft queue from type-ordered processing to global ETA FCFS.

## Current diagnostic result
Generic 72-aircraft recovery-first state, undamaged Shokaku working profile:
- +30 min p50: 0
- +60 min p50: 17
- +120 min p50: 50

Damage cases remain strongly distributional/bimodal; threshold probabilities are now preferred alongside medians.

## Status
WIP only. Do not treat the absolute sortie-generation values as canonical or as historical reconstruction outputs.
