#!/usr/bin/env python3
from __future__ import annotations
import math, numpy as np
import air_microcombat_v107 as geom
from strike_damage_v102 import load_attack_types,_burst,_rear
from strike_response_v103 import RESP,wrap
from strike_response_v106 import DELIVERY_WEIGHTS,SETUP_SECONDS,CLEAN_Q,DEGRADED_Q,_rear_threat_strength
base=geom.base

def _delivery_quality_dynamic(at,states,mission,x,y,z,hd,last_ev,delcy,dt,setup_seconds=None):
    n,K=mission.shape; rpar=RESP[at.id]
    hddeg=np.abs(np.rad2deg(hd)); xx=np.abs(x); yy=np.abs(y); zz=np.abs(z)
    since=np.maximum(0,(delcy[:,None]-last_ev)*dt)
    setup_s=float(SETUP_SECONDS[at.id] if setup_seconds is None else setup_seconds)
    setup=np.clip(since/max(setup_s,1e-6),0,1)
    # Longitudinal displacement matters less than cross-track/vertical/heading error, but a badly
    # strung-out section is not equivalent to a clean release formation.
    track=np.exp(-.10*(xx/420.0)**2-.40*(hddeg/rpar['ready_hdg'])**2-.27*(yy/rpar['ready_y'])**2-.20*(zz/rpar['ready_z'])**2)
    ww=DELIVERY_WEIGHTS[at.id]; comp=np.ones((n,K),float)
    for k,st in enumerate(states):
        vals={name:np.clip(st[name],.03,1.0) for name in ('controls','structure','engine','cooling')}
        logq=np.zeros(n,float)
        for name,w in ww.items(): logq += w*np.log(vals[name])
        comp[:,k]=np.exp(logq)
    q=np.clip(track*setup*comp,0,1); q[mission]=0.0
    clean=(q>=CLEAN_Q)&(~mission); degraded=(q>=DEGRADED_Q)&(q<CLEAN_Q)&(~mission); lost=(q<DEGRADED_Q)&(~mission)
    return q,clean,degraded,lost,track,setup,comp

def simulate_strike_response(m,jp,at,weapons,effects,seed=1,rear_gunner_disruption=.08,rear_gunner_enabled=True,setup_seconds_override=None):
    """Damage/release replay for v0.10.7 dynamic formation.

    Evasion is NOT replayed here.  It already happened in main geometry and therefore already changed
    later CAP target selection and firing opportunities.  This pass only converts the physically valid
    firing events into weapon damage and rear-gun effects, then evaluates the dynamic formation state at delivery.
    """
    rng=np.random.default_rng(seed); n=len(m['trial_package_passes']); N=m['N']; K=int(m.get('package_aircraft_count',12)); dt=2.5
    jpA=geom._expand_objects(jp,N); layerLabels=np.asarray(m.get('A_layer_labels',['A']*N),dtype=object)
    cy=np.asarray(m['trial_package_pass_cycle']); tg=np.asarray(m['trial_package_pass_target_index']); rr=np.asarray(m['trial_package_pass_range_m']); asp=np.asarray(m['trial_package_pass_aspect']); qq=np.asarray(m['trial_package_pass_quality'])
    states=[base._state(n) for _ in range(K)]; caps=[base._state(n) for _ in range(N)]
    events=[]
    for tr in range(n):
        for fi in range(N):
            for kk in range(cy.shape[2]):
                if cy[tr,fi,kk]>=0: events.append((int(cy[tr,fi,kk]),tr,fi,kk))
    events.sort(); ep=0
    clean=np.zeros(n,int); wasted=np.zeros(n,int); lowq=np.zeros(n,int); rdtot=np.zeros(n,int); hits=np.zeros(n,int); gb=np.zeros(n,int); gh=np.zeros(n,int); targeted=np.zeros((n,K),int);rear_disrupt=np.zeros(n,int);rear_disrupt_sum=np.zeros(n,float)
    clean_by_layer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())}; rounds_by_layer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())}; hits_by_layer={str(l):np.zeros(n,int) for l in dict.fromkeys(layerLabels.tolist())}
    delcy=np.asarray(m.get('trial_package_delivery_cycle',np.zeros(n,int)))
    last=max(int(np.max(delcy[delcy>=0],initial=0)),max([x[0] for x in events],default=-1)+3)
    for c in range(last+1):
        for st in states:
            ix=np.where(~st['mission'])[0]
            if len(ix): base.evolve_damage(st,at.defense,ix,rng)
        for fi,st in enumerate(caps):
            ix=np.where(~st['mission'])[0]
            if len(ix): base.evolve_damage(st,jpA[fi],ix,rng)
        while ep<len(events) and events[ep][0]==c:
            _,tr,fi,kk=events[ep]; ep+=1; t=int(tg[tr,fi,kk])
            if t<0 or t>=K: continue
            targeted[tr,t]+=1
            if states[t]['mission'][tr]: wasted[tr]+=1; continue
            q=float(qq[tr,fi,kk]); r=float(rr[tr,fi,kk]); a=int(asp[tr,fi,kk])
            if rear_gunner_enabled:
                th=_rear_threat_strength(at,weapons,r,a)
                if th>0:
                    frac=float(np.clip(rear_gunner_disruption*th,0,.35)); q*=1-frac; rear_disrupt[tr]+=1; rear_disrupt_sum[tr]+=frac
            if q<=.08: lowq[tr]+=1; continue
            firep=float(np.clip(.52+.42*(q/1.25),.42,.95))
            if rng.random()<firep:
                rd,hh=_burst(jpA[fi],at.defense,weapons,effects,states[t],tr,q,r,a,rng,at.size_factor);clean[tr]+=1;rdtot[tr]+=rd;hits[tr]+=hh;lab=str(layerLabels[fi]);clean_by_layer[lab][tr]+=1;rounds_by_layer[lab][tr]+=rd;hits_by_layer[lab][tr]+=hh
            rd,hh,fired=_rear(at,jpA[fi],weapons,effects,caps[fi],tr,r,a,rng)
            if fired: gb[tr]+=1
            gh[tr]+=hh
    mission=np.stack([st['mission'] for st in states],1); dam=np.stack([base.damage_summary(st) for st in states],1); alive=~mission
    x=np.asarray(m.get('trial_package_delivery_dx_m',np.zeros((n,K))),float); y=np.asarray(m.get('trial_package_delivery_dy_m',np.zeros((n,K))),float); z=np.asarray(m.get('trial_package_delivery_dz_m',np.zeros((n,K))),float); hd=np.asarray(m.get('trial_package_delivery_dheading_rad',np.zeros((n,K))),float); last_ev=np.asarray(m.get('trial_package_last_evasion_cycle',np.full((n,K),-999)),int)
    qrel,rel_clean,rel_deg,rel_lost,trackq,setupq,compq=_delivery_quality_dynamic(at,states,mission,x,y,z,hd,last_ev,delcy,dt,setup_seconds_override)
    # Dynamic formation cohesion at release.  This is descriptive, not a combat multiplier.
    rmsx=np.sqrt(np.mean(x*x,axis=1));rmsy=np.sqrt(np.mean(y*y,axis=1));rmsz=np.sqrt(np.mean(z*z,axis=1));rmsh=np.sqrt(np.mean(np.rad2deg(hd)**2,axis=1));coh=np.exp(-.16*rmsx/420-.42*rmsy/220-.30*rmsz/100-.36*rmsh/9)
    capmission=np.stack([st['mission'] for st in caps],1)
    return {
      'model':'strike-response-v0.10.7-dynamic','target_type':at.id,'ntr':n,'package_count':K,'terminal_profile':m.get('package_terminal_profile','level'),
      'mean_physical_passes':float(np.mean(m['trial_package_passes'])),'mean_clean_bursts':float(clean.mean()),'mean_low_quality_passes':float(lowq.mean()),'mean_wasted_passes_on_already_lost_target':float(wasted.mean()),
      'mean_warning_reactions':float(m.get('package_warning_reactions',0.0)),'mean_target_switches_due_geometry':float(m.get('package_target_switches',0.0)),'mean_distinct_attackers_targeted':float((targeted>0).sum(1).mean()),'mean_max_passes_on_one_attacker':float(targeted.max(1).mean()),
      'mean_attackers_mission_lost':float(mission.sum(1).mean()),'mean_attackers_damaged_survivors':float(((dam>.08)&alive).sum(1).mean()),
      'mean_release_clean':float(rel_clean.sum(1).mean()),'mean_release_degraded':float(rel_deg.sum(1).mean()),'mean_release_setup_lost':float(rel_lost.sum(1).mean()),'mean_delivery_quality_equivalent':float(qrel.sum(1).mean()),'mean_release_quality_per_survivor':float(qrel.sum()/max(1,alive.sum())),
      'mean_track_quality':float(trackq[alive].mean() if alive.any() else 0.0),'mean_setup_quality':float(setupq[alive].mean() if alive.any() else 0.0),'mean_component_quality':float(compq[alive].mean() if alive.any() else 0.0),
      'mean_dynamic_formation_cohesion':float(coh.mean()),'mean_rms_longitudinal_m':float(rmsx.mean()),'mean_rms_lateral_m':float(rmsy.mean()),'mean_rms_vertical_m':float(rmsz.mean()),'mean_rms_heading_deg':float(rmsh.mean()),
      'mean_japanese_rounds':float(rdtot.mean()),'mean_japanese_hits':float(hits.mean()),'mean_gunner_bursts':float(gb.mean()),'mean_gunner_hits':float(gh.mean()),'mean_CAP_mission_losses_from_gunners':float(capmission.sum(1).mean()),
      'mean_rear_disruption_events':float(rear_disrupt.mean()),'mean_rear_disruption_fraction_sum':float(rear_disrupt_sum.mean()),
      'mean_clean_bursts_by_layer':{k:float(v.mean()) for k,v in clean_by_layer.items()},'mean_rounds_by_layer':{k:float(v.mean()) for k,v in rounds_by_layer.items()},'mean_hits_by_layer':{k:float(v.mean()) for k,v in hits_by_layer.items()},
      'CAP_mission_losses_from_gunners_by_layer':{str(l):float(capmission[:,np.where(layerLabels==l)[0]].sum(1).mean()) for l in dict.fromkeys(layerLabels.tolist())},
      'delivery_quality_note':'0-1 setup quality only; NOT bomb/torpedo hit probability','damage_feedback_note':'strike mission-loss is damage-replay and is not yet fed back into main geometry; dynamic evasion/formation displacement IS fed back.'
    }
