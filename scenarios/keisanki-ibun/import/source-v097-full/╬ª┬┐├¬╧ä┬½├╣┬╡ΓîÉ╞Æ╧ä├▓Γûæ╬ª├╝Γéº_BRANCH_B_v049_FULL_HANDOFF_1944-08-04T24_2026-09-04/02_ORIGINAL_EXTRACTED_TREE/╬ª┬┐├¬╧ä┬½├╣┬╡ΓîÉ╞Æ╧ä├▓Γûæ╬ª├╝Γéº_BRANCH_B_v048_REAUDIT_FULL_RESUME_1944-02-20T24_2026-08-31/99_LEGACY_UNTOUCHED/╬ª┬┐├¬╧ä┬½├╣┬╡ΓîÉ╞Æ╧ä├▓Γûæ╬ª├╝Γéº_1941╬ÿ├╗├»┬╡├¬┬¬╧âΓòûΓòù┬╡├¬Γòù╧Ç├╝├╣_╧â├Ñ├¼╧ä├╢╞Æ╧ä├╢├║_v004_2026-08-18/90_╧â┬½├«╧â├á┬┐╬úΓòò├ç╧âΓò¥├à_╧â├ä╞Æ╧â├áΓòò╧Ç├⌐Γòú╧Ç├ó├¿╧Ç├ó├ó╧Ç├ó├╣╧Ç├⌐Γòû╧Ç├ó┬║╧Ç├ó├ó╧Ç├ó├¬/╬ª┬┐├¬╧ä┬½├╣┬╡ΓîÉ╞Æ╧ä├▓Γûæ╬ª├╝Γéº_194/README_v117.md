# 航空ミクロ戦闘 / 任務戦 v0.11.7 — Carrier Mission Continuation

## 現在地

v0.11.7 は v0.11.6 の moving-target geometric hit/miss の次に、**weapon hit → carrier component damage → 0/2/6/24h mission state** を追加した固定候補。

重要: この層は「何発で沈むか」の撃沈係数ではない。主出力は、

- flight deck / launch / recovery capacity
- max speed
- steering capacity
- AA capacity
- fire / flooding
- `FULL / RESTRICTED / LIMITED / FLIGHT_DECK_CLOSED / LOST`

である。

## 1. r30 正本からの拘束

v0.11.7 は次の正本判断を校正器として使う。

1. **飛行甲板一発使用不能は避けきれないが、飛行甲板を失うことと艦を失うことを同義にしない。**
2. MI 後は消防主管分割、泡消火、航空燃料主管区画遮断、通風区画化、排水、非常電源、弾薬仮置き制限等を強化。
3. 大鳳相当の魚雷1本中心では、24–26ktへ一時低下、数時間発着制限、その後限定的な航空運用へ復旧し得る。史実 Taihō 型の航空燃料蒸気拡散→大爆発を中心結果にしない。

これらを満たすよう working B-prior damage ledger を作った。史実被害統計へ fit したモデルではない。

## 2. Carrier profiles — 同質化しない

### UNRYU_R30_WORK
- 17,000t級高速中型量産空母の作業profile。
- 非装甲飛行甲板。
- MI戦訓による消防・燃料遮断・排水等の詳細艤装改善。
- 大鳳級水中防御/装甲化は移植しない。

### SHOKAKU_R30_WORK
- 大型高速主力空母。
- 既存艦体に対するMI後の手順・装備改善を反映するworking profile。
- 雲龍より水中区画余裕、ただし装甲空母ではない。

### TAIHO_R30_WORK
- 防御・新艤装を試す質の空母。
- 飛行甲板/水中防御をより強く、航空燃料隔離・通風・消防手順も改善。

数値係数は `carrier_damage_profiles_v117.json` に分離し、すべてB-prior表記。

## 3. Damage ledger

### Bomb hit
1000-lb級 direct hit の作業処理:
- flight-deck crater / patch time
- elevator-area damage
- penetration / hangar damage
- aviation fuel / ordnance secondary fire risk
- machinery / steering low-probability penetration
- local AA/director degradation

飛行甲板の物理破壊と艦喪失は別状態。

### Torpedo hit
Mk13-class underwater direct hit の作業処理:
- broad flooding/shock speed penalty
- longitudinal machinery/shaft hit
- aft steering hit
- flooding/list/free-surface burden
- temporary aviation safety stand-down / restricted flight operations
- local aviation-fuel damage risk

魚雷ショックは flight-deck crater ではないため、単純な `DECK CLOSED` へ変換しない。

## 4. 校正チェック

### 大鳳相当 1 torpedo
100,000級 Monte Carlo の中心profile:

| 時刻 | mission-kill | physical deck closed | median speed | mean launch capacity |
|---|---:|---:|---:|---:|
| 0h | .903 | .0046 | **25.43 kt** | .361 |
| 2h | .646 | .0001 | 27.18 kt | .557 |
| 6h | **.073** | ~0 | 28.86 kt | **.949** |
| 24h | .051 | 0 | 29.77 kt | .980 |

即時には大幅な航空運用制限を受けるが、物理甲板破壊・艦喪失は中心結果ではなく、数時間で限定/制限運用へ戻る。

### 雲龍相当 1 bomb
中心profile:
- 0h flight-deck closed: **.924**
- 0h ship lost: **.00032**
- 6h mission-kill: .598
- 24h mission-kill: .023, ただし restricted state は別に残る

つまり「一発で航空mission kill」は高率でも、「一発で艦喪失」にはならない。

## 5. 6時間条件付き mission-kill

| carrier | 1 bomb | 2 bombs | 1 torpedo | 2 torpedoes | 1B+1T |
|---|---:|---:|---:|---:|---:|
| UNRYU | .598 | .862 | .183 | .956 | .727級 |
| SHOKAKU | .565級 | .84級 | .10級 | .82級 | .61級 |
| TAIHO | .20級 | .39級 | .073 | .581 | .257 |

正確値はCSVを参照。ここで重要なのは、艦型差・命中数増加・DC感度が同じ方向に出ていること。

## 6. Invariants / sensitivity

`carrier_damage_invariants_v117.json` の全チェックが pass。

- Taiho 1T immediate median speed ∈ 24–26 kt
- Taiho 1T: 6h後は大半がmission-kill状態から外れる
- Unryu 1B: 高いdeck stop、低いship-loss
- 1→2→3 pure bomb/torpedo で6h mission-kill単調増加
- Taihoが同命中条件のUnryuより脆くなる逆転なし

DC `0.82 / 1.00 / 1.18` を振ると、高DCほど fire/flooding/loss/mission-kill が改善する。感度時定数の符号検査も通過済み。

## 7. Air trial → carrier mission state 接続

F6F benchmark の実trial hit countを、そのまま条件付きdamage ledgerへ畳み込む smoke/diagnostic も保存した。

- SBD5, 6 trials: hit counts `[2,1,2,5,2,3]`, mean 2.5
- SB2C, 6 trials: `[5,2,3,4,3,1]`, mean 3.0
- synchronized 60° TBF, 4 trials: `[1,1,1,3]`, mean 1.5

`air_to_carrier_mission_F6F_v117.csv` が、各carrier profileの0/6/24h期待mission stateへ変換する。

**これは航空hit prior自体が低N/B-priorなので歴史的戦果値ではない。** 接続が trial-by-trial で動くことの検証用。

## 8. 現在の完成判定

航空ミクロ戦闘編は、

`fighter geometry → strike release → hit/miss → carrier mission continuation`

まで一通り閉じた。

この先は航空機の旋回係数をさらに足す段階ではない。次に進むべきものは **sortie regeneration / deck cycle / repair / fuel-ammo / pilot availability** であり、これを通して初めて「次のwaveに何機戻せるか」を出す。

その後に historical FORAGER clock へ戻す。
