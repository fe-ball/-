# RECOVERY — v0.11.6 Multi-axis Torpedo / Air Microcombat Hit-Miss Closure

## Current resume point

Do not jump directly back to the historical clock without deciding whether the next desired layer is ship damage / mission continuation or sortie regeneration.

The air/mission microcombat stack now reaches moving-target geometric hit/miss with:

1. aircraft energy / handling / damage
2. 1v1 -> formation geometry
3. escort/CAP
4. dynamic strike formation
5. online mission-loss and rear-gunner feedback
6. heterogeneous high/low CAP including Kyofu
7. target-ship local AA + evasion
8. single global timeline
9. AA/CAP fire discipline
10. distributed AA -> maneuvering real screen ships
11. physical weapon-release gate
12. bomb / Mk13 post-release flight
13. **v0.11.6 full-global multi-axis / anvil TBF geometry**

## What v0.11.6 closes

- Release range is measured to the actual moving carrier, not a stale nominal target point.
- TBF performs finite terminal tracking of the moving ship.
- Multi-axis groups exist before release, so CAP/escort/AA/ship evasion see their real geometry.
- Trial does not terminate before late unreleased groups finish their terminal pursuit.
- Anvil synchronization is explicit route phasing, not assumed.
- Post-release ship response defaults to continuing the already-established turn rather than magical re-optimization.

## Final structural diagnostic

F6F, 12 TBF, n=4:
- 60° unphased: release gap 10.25 s, 0 hit/wave.
- 60° phased: gap 1.41 s, no-solution 0, 1.5 hit/wave.
- 30° phased: gap .94 s, no-solution 0, 5.5 hit/wave.
- 90° phased: gap 1.69 s, no-solution 0, 4.75 hit/wave.

Do NOT rank 30/60/90° from these absolute hit values. The stable conclusion is that **simultaneity is a necessary variable and one evasive turn cannot optimize both axes simultaneously.**

## Recommended next layer

If continuing the combat model:

### Ship hit consequence / carrier mission continuation
Convert bomb / torpedo geometric hits into component damage:
- flight deck / elevators
- hangar / parked aircraft
- aviation fuel / ordnance
- machinery / propulsion
- steering
- flooding / fire
- AA/director degradation

Outputs should be mission variables, not just sunk/not sunk:
- deck usable / launch-only / recovery-only / closed
- aircraft service rate
- speed/turn capability
- AA capacity
- time-to-repair bands
- probability of mission kill vs recoverable damage

### Then sortie regeneration
Use surviving CAP/strike aircraft, deck availability, fuel/ammo, pilots and maintenance to regenerate next wave.

Only after that should the historical FORAGER clock be rebuilt.
