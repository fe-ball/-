# SOURCE AUDIT v0.11.8 WIP

## Internal canonical anchors

- r30 `44_戦術研鑽_1942-44_空母指揮・艦隊回避・教範化.md`
  - CAP launch and attack-wave launch compete for deck cycles.
  - launch/recovery/rearm cycle-time variance reduced 15–25% in the mature alternate-world doctrine.

- r30 `45_航空運用制度_1942-44_空地分離・攻防火器管制破綻研究.md`
  - carrier wind-up periods, CAP turnover/refuel timing, launch/recovery interruption, first/second wave timing.

- r30 `46_航空人事_1942-44_自然還流・空地分離・練度平準化.md`
  - carrier qualification, deck handling, maintenance/ordnance competencies and fatigue/personnel circulation remain separate constraints.

- v0.11.7 carrier mission continuation
  - launch/recovery capacity, speed, steering, AA, fire/flooding and deck closure are consumed directly.

## Public historical architecture anchors

- Jonathan B. Parshall, David D. Dickson, Anthony P. Tully,
  “Doctrine Matters: Why the Japanese Lost at Midway,” Naval War College Review 54(3), 2001.
  Used for the structural distinction between Japanese hangar-centered handling/elevator dependence and US flight-deck-centered servicing.

- Dallas W. Isom,
  “The Battle of Midway: Why the Japanese Lost,” Naval War College Review 53(3), 2000.
  Used as a sanity anchor that rearming/weapon-change was a substantial handling process with ordnance-cart/elevator constraints.

- U.S. Navy / NHHC Midway combat narratives and action reports.
  Used only to check that carrier launch/recovery/refuel/rearm cycles occur on operationally significant tens-of-minutes-to-hours timescales.

No US sortie-generation rate is copied into the Japanese model.

## Explicit B-priors

- base launch/recovery throughput
- number of simultaneous service slots
- deck respot overhead
- per-type routine turnaround time
- repairable-aircraft maintenance time
- pilot-fatigue availability multiplier

All must remain sensitivity-tested until a stronger source basis is assembled.
