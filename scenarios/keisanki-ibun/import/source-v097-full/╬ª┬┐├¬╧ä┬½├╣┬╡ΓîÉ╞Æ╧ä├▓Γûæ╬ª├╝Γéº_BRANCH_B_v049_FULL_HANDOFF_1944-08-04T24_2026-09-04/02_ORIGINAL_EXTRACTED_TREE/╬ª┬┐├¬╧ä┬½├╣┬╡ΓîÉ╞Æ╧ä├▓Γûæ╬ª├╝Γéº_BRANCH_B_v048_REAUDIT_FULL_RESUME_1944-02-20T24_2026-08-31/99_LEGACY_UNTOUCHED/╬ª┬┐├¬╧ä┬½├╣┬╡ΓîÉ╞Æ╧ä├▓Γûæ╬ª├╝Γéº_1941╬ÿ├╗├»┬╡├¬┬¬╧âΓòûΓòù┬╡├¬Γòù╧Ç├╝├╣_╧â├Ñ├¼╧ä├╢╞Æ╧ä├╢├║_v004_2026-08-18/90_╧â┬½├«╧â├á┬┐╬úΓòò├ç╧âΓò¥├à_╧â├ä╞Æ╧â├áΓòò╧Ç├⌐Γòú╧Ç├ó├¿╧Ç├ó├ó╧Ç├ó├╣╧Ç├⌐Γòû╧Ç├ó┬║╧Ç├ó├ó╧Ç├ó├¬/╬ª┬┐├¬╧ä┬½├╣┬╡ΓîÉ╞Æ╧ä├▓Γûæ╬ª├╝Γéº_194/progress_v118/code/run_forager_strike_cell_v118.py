#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import argparse, json, sys
import numpy as np

R=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
import air_microcombat_v116 as air
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP
from air_trial_bridge_v118 import trial_shell_airgroup, inject_package_trial
from sortie_regeneration_v118 import simulate_sortie_regeneration, summarize
from ship_aa_v110 import US_CV_LOCAL_AA_WORK, US_FAST_CV_WORK


def cfg(target, p, d, at, escort_count=6, cap_count=12):
    N=max(int(cap_count),int(escort_count),2)
    hi=(int(cap_count)+1)//2; lo=int(cap_count)-hi
    if target=='B6N2':
        high_alt,low_alt=3800,900; high_x,low_x=-1000,-3100; high_ias,low_ias=430,350
        hB,iasB=3200,390
        terminal=dict(package_alt_m=3000,package_speed_kmh=at.package_speed_kmh,
            package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,
            package_terminal_profile='torpedo',package_terminal_alt_m=120,
            package_terminal_speed_kmh=300,package_transition_start_m=9000,
            package_transition_end_m=4500,package_weapon_release_range_m=750)
    elif target=='D4Y2':
        high_alt,low_alt=5200,2500; high_x,low_x=-1500,-3100; high_ias,low_ias=430,430
        hB,iasB=4800,410
        terminal=dict(package_alt_m=5000,package_speed_kmh=at.package_speed_kmh,
            package_start_x=8000,package_target_x=-4500,package_vector_range_m=10500,
            package_terminal_profile='dive',package_terminal_alt_m=760,
            package_terminal_speed_kmh=450,package_transition_start_m=1800,
            package_transition_end_m=0,package_weapon_release_range_m=850)
    else: raise ValueError(target)
    # Inactive A slots, when N exceeds cap_count, are padded with the high-layer geometry.
    pad=N-int(cap_count)
    hA=[high_alt]*hi+[low_alt]*lo+[high_alt]*pad
    iasA=[high_ias]*hi+[low_ias]*lo+[high_ias]*pad
    labels=['high']*hi+['low']*lo+['inactive']*pad
    xA=[high_x]*hi+[low_x]*lo+[high_x]*pad
    yA=list(air._default_centered_y(hi))+list(air._default_centered_y(lo))+([0.0]*pad)
    pa=[p['US02']]*N; da=[d['US02']]*N
    kw=dict(N=N,active_A=int(cap_count),active_B=int(escort_count),hA0=hA,iasA0=iasA,
            hB0=hB,iasB0=iasB,A_layer_labels=labels,A_initial_x_m=xA,A_initial_y_m=yA,**terminal)
    return pa,da,kw

def run_air(target, ntr, seed, us_local_aa=False, escort_count=6, us_screen=False, cap_count=12):
    p,w,e,d=air.load_all(R); at=load_attack_types(R)[target]
    pa,da,kw=cfg(target,p,d,at,escort_count=escort_count,cap_count=cap_count)
    # side-B fighter objects are structurally required but inactive.
    return air.simulate_escort_cap(
        pa,p['JP01'],da,d['JP01'],w,e,
        ntr=ntr,seed=seed,max_cycles=76,return_trials=True,
        package_aircraft_count=12,package_run_lock_cycles=5,package_fire_substeps=5,
        escort_aim_suppression=.55,package_max_passes_per_fighter=2,
        package_dynamic_formation=True,package_evasion_params=RESP[target],
        package_warn_range_m=1100,package_online_damage=True,
        package_defense=at.defense,package_size_factor=at.size_factor,
        package_loss_feedback=True,package_rear_armament=at.rear_armament,
        package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,
        global_ship_aa=bool(us_local_aa),package_attack_type=(at if us_local_aa else None),
        ship_profile=(US_FAST_CV_WORK if us_local_aa else None),
        aa_profile=(US_CV_LOCAL_AA_WORK if us_local_aa else None),
        global_aa_enabled=True,global_ship_evasion_enabled=bool(us_local_aa),
        global_ship_evasion_policy='auto',global_aa_fire_discipline='center',
        global_screen_aa=bool(us_screen),global_screen_profile=('us_fletcher4_work' if us_screen else 'none'),**kw
    )


def pctl(a,q):
    return float(np.quantile(np.asarray(a,dtype=float),q)) if len(a) else float('nan')


def bridge_target(target,ntr,regen_per_trial,seed,us_local_aa=False,escort_count=6,us_screen=False,cap_count=12):
    typ='TB' if target=='B6N2' else 'DB'
    res=run_air(target,ntr,seed,us_local_aa=us_local_aa,escort_count=escort_count,us_screen=us_screen,cap_count=cap_count)
    audits=[]; regen=[]
    for i in range(ntr):
        shell=trial_shell_airgroup(typ)
        st,a=inject_package_trial(shell,res,i,typ,crew_prefix=target)
        audits.append(a)
        # Sample two operational horizons for each upstream structural trial.
        for H in (60,120):
            rows=simulate_sortie_regeneration(
                'SHOKAKU_R30_WORK',1.0,1.0,state=st,n=regen_per_trial,
                seed=seed+10000+i*101+H,horizons_min=(H,),service_model='split'
            )
            for r in rows:
                r['upstream_trial']=i; r['target']=target
            regen.extend(rows)
    lost=[a['lost'] for a in audits]; clean=[a['returning_clean'] for a in audits]; damaged=[a['returning_damaged'] for a in audits]
    out={
        'target':target,'aircraft_type':typ,'n_upstream_trials':ntr,
        'regen_mc_per_upstream_trial':regen_per_trial,
        'fleet_aa_mode':('US_carrier_local_plus_Fletcher4_screen_work' if (us_local_aa and us_screen) else ('US_carrier_local_AA_work' if us_local_aa else 'disabled_US_CAP_only')),
        'cap_profile':f'US02 F6F-5 (WEP), {cap_count} active, two altitude layers',
        'escort_profile':f'JP01 後期瑞星零戦, {escort_count} active',
        'package_aircraft':12,
        'lost_mean':float(np.mean(lost)),'lost_p50':pctl(lost,.5),'lost_p90':pctl(lost,.9),
        'returning_clean_mean':float(np.mean(clean)),
        'returning_damaged_mean':float(np.mean(damaged)),
        'returning_damaged_p_any':float(np.mean(np.asarray(damaged)>0)),
        'package_attack_passes':float(res.get('package_attack_passes',float('nan'))),
        'package_online_mission_losses':float(res.get('package_online_mission_losses',float('nan'))),
        'rear_gunner_bursts':float(res.get('package_rear_gunner_bursts',0.0)),
        'aa_heavy_rounds':float(res.get('global_mean_AA_heavy_rounds',0.0)),
        'aa_light_rounds':float(res.get('global_mean_AA_light_rounds',0.0)),
        'aa_new_mission_losses':float(res.get('global_mean_AA_new_mission_losses',0.0)),
        'aa_jink_events':float(res.get('global_mean_AA_jink_events',0.0)),
        'screen_heavy_rounds':float(res.get('screen_mean_heavy_rounds',0.0)),
        'screen_light_rounds':float(res.get('screen_mean_25mm_rounds',0.0)),
        'screen_new_mission_losses':float(res.get('screen_mean_new_mission_losses',0.0)),
        'screen_jink_events':float(res.get('screen_mean_jink_events',0.0)),
        'sortie_summary':summarize(regen),
        'trial_audits':audits,
    }
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--ntr',type=int,default=32)
    ap.add_argument('--regen-per-trial',type=int,default=120)
    ap.add_argument('--targets',default='B6N2,D4Y2')
    ap.add_argument('--seed',type=int,default=118300)
    ap.add_argument('--us-local-aa',action='store_true')
    ap.add_argument('--us-screen',action='store_true')
    ap.add_argument('--escort',type=int,default=6,choices=[0,2,4,6,8,10,12])
    ap.add_argument('--cap',type=int,default=12,choices=[6,8,10,12,14,16,18,20,24])
    a=ap.parse_args()
    results=[]
    for j,t in enumerate([x.strip() for x in a.targets.split(',') if x.strip()]):
        results.append(bridge_target(t,a.ntr,a.regen_per_trial,a.seed+j*100000,us_local_aa=a.us_local_aa,escort_count=a.escort,us_screen=a.us_screen,cap_count=a.cap))
    out=R.parent/'results_current'; out.mkdir(exist_ok=True)
    p=out/f'forager_strike_cell_CAP{a.cap}_escort{a.escort}_{"USlocalAA_screen" if (a.us_local_aa and a.us_screen) else ("USlocalAA" if a.us_local_aa else "CAPonly")}_v118.json'
    p.write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(results,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
