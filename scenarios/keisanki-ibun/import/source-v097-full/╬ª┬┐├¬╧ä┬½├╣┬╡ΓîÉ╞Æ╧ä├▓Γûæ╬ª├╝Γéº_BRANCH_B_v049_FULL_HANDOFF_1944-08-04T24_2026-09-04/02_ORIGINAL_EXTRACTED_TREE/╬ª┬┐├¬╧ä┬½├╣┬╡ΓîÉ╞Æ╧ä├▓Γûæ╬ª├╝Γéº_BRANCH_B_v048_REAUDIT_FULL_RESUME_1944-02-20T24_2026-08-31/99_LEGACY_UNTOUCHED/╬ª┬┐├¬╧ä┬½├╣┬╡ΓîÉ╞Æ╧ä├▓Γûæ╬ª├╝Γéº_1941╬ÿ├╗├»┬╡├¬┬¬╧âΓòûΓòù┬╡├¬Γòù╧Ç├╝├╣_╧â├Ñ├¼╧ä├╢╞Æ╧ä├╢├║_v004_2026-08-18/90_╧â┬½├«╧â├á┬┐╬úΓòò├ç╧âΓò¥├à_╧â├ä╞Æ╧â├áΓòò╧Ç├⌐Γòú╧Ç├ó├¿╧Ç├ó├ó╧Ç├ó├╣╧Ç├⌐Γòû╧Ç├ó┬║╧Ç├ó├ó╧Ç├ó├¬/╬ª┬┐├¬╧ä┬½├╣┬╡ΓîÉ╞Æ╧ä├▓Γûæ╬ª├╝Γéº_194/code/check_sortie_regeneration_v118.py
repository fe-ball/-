#!/usr/bin/env python3
from pathlib import Path
import sys, numpy as np
R=Path(__file__).parent;sys.path.insert(0,str(R))
from sortie_regeneration_v118 import simulate_sortie_regeneration_dynamic,summarize
from carrier_damage_continuous_v118 import sample_damage_state
from run_sortie_regeneration_v118 import capacity_timeline

def p50(rows): return summarize(rows)[0]["next_wave_total_p50"]
def run(profile,t,L,R,H,seed=11884,n=2400,**kw): return simulate_sortie_regeneration_dynamic(profile,t,L,R,n=n,seed=seed,horizon_min=H,**kw)
def main():
    vals=[]
    for H in (30,60,120):
        t,L,R=capacity_timeline(None,0,H); vals.append(p50(run("SHOKAKU_R30_WORK",t,L,R,H,seed=11880+H)))
    assert vals==sorted(vals),vals
    H=120;t=np.arange(0,H+.5,.5);hiC=np.ones((1,len(t)));loC=np.full((1,len(t)),.55)
    hi=p50(run("SHOKAKU_R30_WORK",t,hiC,hiC,H,seed=11881));lo=p50(run("SHOKAKU_R30_WORK",t,loC,loC,H,seed=11881));assert lo<=hi,(lo,hi)
    fast=p50(run("SHOKAKU_R30_WORK",t,hiC,hiC,H,seed=11882,service_scale=.8));slow=p50(run("SHOKAKU_R30_WORK",t,hiC,hiC,H,seed=11882,service_scale=1.2));assert slow<=fast,(slow,fast)
    latent=sample_damage_state("TAIHO_R30_WORK",0,1,n=8000,seed=11883)
    t0,L0,R0=capacity_timeline(latent,0.0,H);t6,L6,R6=capacity_timeline(latent,6.0,H)
    v0=p50(run("TAIHO_R30_WORK",t0,L0,R0,H,seed=11884,n=2400));v6=p50(run("TAIHO_R30_WORK",t6,L6,R6,H,seed=11884,n=2400));assert v6>=v0,(v0,v6)
    print("PASS",{"undamaged_p50":vals,"cap_hi":hi,"cap_lo":lo,"service_fast":fast,"service_slow":slow,"taiho_1T_0h_120":v0,"taiho_1T_6h_120":v6})
if __name__=='__main__':main()
