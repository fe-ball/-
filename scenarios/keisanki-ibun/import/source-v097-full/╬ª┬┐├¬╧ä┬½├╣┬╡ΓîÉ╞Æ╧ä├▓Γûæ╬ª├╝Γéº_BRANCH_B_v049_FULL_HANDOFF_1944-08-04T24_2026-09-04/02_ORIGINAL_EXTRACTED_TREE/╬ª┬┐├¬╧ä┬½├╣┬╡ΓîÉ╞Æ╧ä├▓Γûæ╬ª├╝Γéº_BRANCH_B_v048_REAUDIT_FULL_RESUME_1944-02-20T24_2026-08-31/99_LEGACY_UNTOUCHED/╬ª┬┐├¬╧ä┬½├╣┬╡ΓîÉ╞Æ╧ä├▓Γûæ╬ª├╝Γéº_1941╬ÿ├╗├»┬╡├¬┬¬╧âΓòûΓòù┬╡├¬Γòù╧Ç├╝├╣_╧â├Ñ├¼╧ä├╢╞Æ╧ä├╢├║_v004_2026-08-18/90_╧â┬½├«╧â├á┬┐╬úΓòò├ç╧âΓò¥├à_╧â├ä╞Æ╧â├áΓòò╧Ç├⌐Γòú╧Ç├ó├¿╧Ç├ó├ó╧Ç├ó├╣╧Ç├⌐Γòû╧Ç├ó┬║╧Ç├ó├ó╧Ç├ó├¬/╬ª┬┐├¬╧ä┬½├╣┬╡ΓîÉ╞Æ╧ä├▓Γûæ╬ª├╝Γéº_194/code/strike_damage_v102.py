#!/usr/bin/env python3
from __future__ import annotations
import json,math
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import air_microcombat_v102 as geom
base=geom.base
@dataclass
class AttackType:
 id:str;name:str;gross_lb:float;empty_lb:float;wing_sqft:float;package_speed_kmh:float;fixed_armament_note:str;rear_armament:list;size_factor:float;defense:base.Defense;source_date:str;source_notes:list
def load_attack_types(root):
 raw=json.loads((Path(root)/'attack_aircraft_v081.json').read_text())['attack_aircraft'];out={}
 for k,v in raw.items():
  dd=v['defense'].copy();out[k]=AttackType(k,v['name'],v['gross_lb'],v['empty_lb'],v['wing_sqft'],v['package_speed_kmh'],v['fixed_armament_note'],v['rear_armament'],v['size_factor'],base.Defense(id=k,armament=[],**dd),v['source_date'],v['source_notes'])
 return out
def _burst(shooter,target,weapons,effects,st,tr,q,rr,asp,rng,size_factor):
 dur=float(np.clip(.40+.17*q+rng.normal(0,.045),.25,.82));idx=np.array([tr]);aspa=np.array([asp],np.int8);rra=np.array([rr]);rt=ht=0
 for wid,count,apg,mount,conv,sync in shooter.armament:
  w=weapons[wid];rpm=float(np.clip(rng.normal(w.rpm,w.rpm_sigma),.65*w.rpm,1.25*w.rpm));rd=max(0,int(round(count*rpm/60*dur*sync)));mountfac=1.08 if mount=='nose' else .90+.14*math.exp(-.5*((rr-conv)/260)**2);p=float(np.clip(.0092*(1+.28*q)*math.exp(-(rr-220)/700)*mountfac*size_factor,.0028,.040));hh=int(rng.poisson(rd*p));rt+=rd;ht+=hh
  if hh:base.apply_hits(st,target,w,effects,idx,np.array([hh]),aspa,rra,rng)
 return rt,ht
def _rear(at,jp,weapons,effects,st,tr,rr,asp,rng):
 if asp==2:return 0,0,False
 if asp==1 and rng.random()>.48:return 0,0,False
 idx=np.array([tr]);aspa=np.array([0 if asp==0 else 1],np.int8);rra=np.array([rr]);rt=ht=0;basep=.0056 if asp==0 else .0038
 for wid,count,apg in at.rear_armament:
  w=weapons[wid];rpm=float(np.clip(rng.normal(w.rpm,w.rpm_sigma),.65*w.rpm,1.25*w.rpm));dur=float(np.clip(rng.normal(.62,.10),.32,.90));rd=max(0,int(round(count*rpm/60*dur)));hh=int(rng.poisson(rd*np.clip(basep*math.exp(-(rr-220)/650),.0012,.012)));rt+=rd;ht+=hh
  if hh:base.apply_hits(st,jp,w,effects,idx,np.array([hh]),aspa,rra,rng)
 return rt,ht,True
def convert_events(m,jp,at,weapons,effects,seed=1,gunner_suppression=True):
 rng=np.random.default_rng(seed);n=len(m['trial_package_passes']);N=m['N'];K=int(m.get('package_aircraft_count',12));cy=np.asarray(m['trial_package_pass_cycle']);tg=np.asarray(m['trial_package_pass_target_index']);rr=np.asarray(m['trial_package_pass_range_m']);asp=np.asarray(m['trial_package_pass_aspect']);qq=np.asarray(m['trial_package_pass_quality']);states=[base._state(n) for _ in range(K)];caps=[base._state(n) for _ in range(N)];events=[]
 for tr in range(n):
  for fi in range(N):
   for kk in range(cy.shape[2]):
    if cy[tr,fi,kk]>=0:events.append((int(cy[tr,fi,kk]),tr,fi,kk))
 events.sort();clean=np.zeros(n,int);wasted=np.zeros(n,int);rdtot=np.zeros(n,int);hits=np.zeros(n,int);gb=np.zeros(n,int);gh=np.zeros(n,int);targ=np.zeros((n,K),int)
 dt=2.5;delivery=int(math.ceil((m.get('package_start_x',4800)-m.get('package_target_x',-4500))/(m.get('package_speed_kmh',300)/3.6)/dt));ep=0;last=max(delivery,max([x[0] for x in events],default=-1)+3)
 for c in range(last+1):
  for st in states:
   ix=np.where(~st['mission'])[0]
   if len(ix):base.evolve_damage(st,at.defense,ix,rng)
  for st in caps:
   ix=np.where(~st['mission'])[0]
   if len(ix):base.evolve_damage(st,jp,ix,rng)
  while ep<len(events) and events[ep][0]==c:
   _,tr,fi,kk=events[ep];ep+=1;t=int(tg[tr,fi,kk]);r=float(rr[tr,fi,kk]);a=int(asp[tr,fi,kk]);q=float(qq[tr,fi,kk]);
   if t<0 or t>=K:continue
   if states[t]['mission'][tr]:wasted[tr]+=1;continue
   targ[tr,t]+=1;firep=float(np.clip(.55+.40*(q/1.25),.50,.95))
   rear_threat=(a==0) or (a==1 and rng.random()<.48)
   if gunner_suppression and rear_threat:firep*=.93 if at.id=='TBF1C' else .96
   if rng.random()<firep:
    rd,hh=_burst(jp,at.defense,weapons,effects,states[t],tr,q,r,a,rng,at.size_factor);clean[tr]+=1;rdtot[tr]+=rd;hits[tr]+=hh
   rd,hh,fired=_rear(at,jp,weapons,effects,caps[fi],tr,r,a,rng)
   if fired:gb[tr]+=1
   gh[tr]+=hh
 mm=np.stack([st['mission'] for st in states],1);dam=np.stack([base.damage_summary(st) for st in states],1);deliv=(~mm).sum(1);damdel=((~mm)&(dam>.08)).sum(1);imm=np.stack([st['immediate'] for st in states],1).sum(1);capm=np.stack([st['mission'] for st in caps],1).sum(1)
 return {'target_type':at.id,'ntr':n,'package_count':K,'mean_attack_events':float(np.mean(m['trial_package_passes'])),'mean_clean_firing_passes':float(clean.mean()),'mean_wasted_passes_on_already_lost_target':float(wasted.mean()),'mean_distinct_attackers_targeted':float((targ>0).sum(1).mean()),'mean_max_passes_on_one_attacker':float(targ.max(1).mean()),'mean_attackers_mission_lost':float(mm.sum(1).mean()),'mean_attackers_immediate_lost':float(imm.mean()),'mean_attackers_delivered':float(deliv.mean()),'mean_attackers_damaged_but_delivered':float(damdel.mean()),'package_2plus_mission_lost':float((mm.sum(1)>=2).mean()),'mean_japanese_rounds':float(rdtot.mean()),'mean_japanese_hits':float(hits.mean()),'mean_gunner_bursts':float(gb.mean()),'mean_gunner_hits':float(gh.mean()),'mean_CAP_mission_losses_from_gunners':float(capm.mean()),'gunner_suppression':bool(gunner_suppression)}
