#!/usr/bin/env python3
from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np
from ship_aa_v110 import ShipProfile, TERMINALS
import air_microcombat_v115 as geom

G=9.80665

def wrap(a): return (a+np.pi)%(2*np.pi)-np.pi

@dataclass(frozen=True)
class BombFlightProfile:
    id:str
    dive_deg:float
    time_scale:float
    sigma_cross_m:float
    sigma_along_m:float
    quality_cross_extra_m:float
    quality_along_extra_m:float
    near_miss_m:float=50.0
    source_grade:str='B-prior release-error carrier; terminal altitude/speed anchored in mission model'

@dataclass(frozen=True)
class TorpedoFlightProfile:
    id:str='MK13_1944_WORK'
    water_speed_kn:float=33.5
    max_run_m:float=5800.0
    arming_m:float=250.0
    entry_time_s:float=3.5
    entry_forward_m:float=220.0
    sigma_heading_deg:float=1.15
    quality_heading_extra_deg:float=3.5
    sigma_entry_cross_m:float=10.0
    quality_entry_cross_extra_m:float=35.0
    # Aircrew target-motion estimate, separate from torpedo's own heading/water-entry errors.
    target_course_sigma_deg:float=2.0
    quality_course_extra_deg:float=4.0
    target_speed_sigma_kn:float=1.5
    quality_speed_extra_kn:float=2.5
    target_track_lag_s:float=1.5
    run_normal_p:float=.85
    hitbox_margin_m:float=2.0
    near_miss_m:float=45.0
    source_grade:str='A 1944 Mark 13 improvement/launch-envelope anchor; B-prior speed/range/reliability/error decomposition'

BOMBS={
 'SBD5':BombFlightProfile('SBD5_1000LB_WORK',70.0,1.05,32.0,45.0,70.0,85.0),
 'SB2C1C':BombFlightProfile('SB2C1C_1000LB_WORK',67.0,1.06,35.0,50.0,75.0,90.0),
}

TORPEDO_PRIORS={
 'weak':TorpedoFlightProfile(run_normal_p=.70,sigma_heading_deg=1.45,quality_heading_extra_deg=4.2,sigma_entry_cross_m=14.0,quality_entry_cross_extra_m=42.0,target_course_sigma_deg=3.0,quality_course_extra_deg=5.5,target_speed_sigma_kn=2.4,quality_speed_extra_kn=3.5,target_track_lag_s=2.5),
 'center':TorpedoFlightProfile(),
 'strong':TorpedoFlightProfile(run_normal_p=.95,sigma_heading_deg=.90,quality_heading_extra_deg=2.8,sigma_entry_cross_m=8.0,quality_entry_cross_extra_m=28.0,target_course_sigma_deg=1.2,quality_course_extra_deg=2.6,target_speed_sigma_kn=.8,quality_speed_extra_kn=1.6,target_track_lag_s=.8),
}

def _package_release_positions(m):
    n=len(m['trial_package_passes']);K=int(m.get('package_aircraft_count',12));offs=geom._package_offsets(K)
    dx=np.asarray(m['trial_package_delivery_dx_m'],float);dy=np.asarray(m['trial_package_delivery_dy_m'],float);dz=np.asarray(m['trial_package_delivery_dz_m'],float)
    x=float(m['package_target_x'])+offs[None,:,0]+dx
    y=offs[None,:,1]+dy
    term=TERMINALS[m.get('package_attack_type','TBF1C')] if isinstance(m.get('package_attack_type'),str) and m.get('package_attack_type') in TERMINALS else None
    return x,y,dz

def _ship_post_release(ship:ShipProfile,x0,y0,h0,r0,attack_hdg,mission,times,turn_scale=1.0,torpedo_policy='auto'):
    """Integrate target ship after release. Coordinates are in the global intercept frame.
    Torpedo defense converges bow/stern onto attack axis; dive defense keeps the established hard turn.
    """
    times=np.asarray(times,float);order=np.argsort(times);outx=np.empty_like(times);outy=np.empty_like(times);outh=np.empty_like(times)
    x=float(x0);y=float(y0);h=float(h0);r=float(r0);tprev=0.0;dt=.10
    if mission=='torpedo':
        # attack_hdg points from attacker toward target; the threat bearing from ship toward attacker is reciprocal.
        threat=wrap(float(attack_hdg)+math.pi)
        if torpedo_policy=='none': desired=h
        elif torpedo_policy=='bow': desired=threat
        elif torpedo_policy=='stern': desired=wrap(threat+math.pi)
        else:
            cands=(threat,wrap(threat+math.pi));desired=min(cands,key=lambda z:abs(wrap(z-h)))
        sign=0.0
    else:
        sign=1.0 if r>=0 else -1.0
        if abs(r)<1e-5:sign=1.0
        desired=None
    vmax=math.radians(ship.max_turn_rate_deg_s*turn_scale);acc=math.radians(ship.max_turn_rate_deg_s)*dt/max(ship.turn_tau_s,1.0);v=ship.speed_kn*.514444
    for idx in order:
        targ=float(times[idx])
        while tprev+1e-9<targ:
            ds=min(dt,targ-tprev)
            if mission=='torpedo':
                err=wrap(desired-h);cmd=float(np.clip(err/max(ship.turn_tau_s,.1),-vmax,vmax))
            else: cmd=sign*vmax
            r+=float(np.clip(cmd-r,-acc*ds/dt,acc*ds/dt));r=float(np.clip(r,-vmax,vmax));h=wrap(h+r*ds)
            # full actual movement after release; no baseline subtraction needed because both weapon and ship are in same global frame.
            x+=v*math.cos(h)*ds;y+=v*math.sin(h)*ds;tprev+=ds
        outx[idx]=x;outy[idx]=y;outh[idx]=h
    return outx,outy,outh

def _solve_intercept(px,py,tx,ty,tvx,tvy,speed,max_t):
    rx=tx-px;ry=ty-py
    a=tvx*tvx+tvy*tvy-speed*speed;b=2*(rx*tvx+ry*tvy);c=rx*rx+ry*ry
    if abs(a)<1e-9:
        if abs(b)<1e-9:return None
        roots=[-c/b]
    else:
        d=b*b-4*a*c
        if d<0:return None
        sd=math.sqrt(d);roots=[(-b-sd)/(2*a),(-b+sd)/(2*a)]
    roots=[t for t in roots if t>0 and t<=max_t]
    return min(roots) if roots else None

def _point_ship_miss(px,py,sx,sy,sh,length,beam):
    dx=px-sx;dy=py-sy;c=math.cos(sh);s=math.sin(sh);along=dx*c+dy*s;cross=-dx*s+dy*c
    da=max(0.0,abs(along)-length/2);dc=max(0.0,abs(cross)-beam/2)
    return math.hypot(da,dc),along,cross

def simulate_bombs(m,attack_id,seed=11501,ship=None,turn_scale=1.0,profile=None):
    ship=ship or ShipProfile();bp=profile or BOMBS[attack_id];term=TERMINALS[attack_id];rng=np.random.default_rng(seed)
    q=np.asarray(m['trial_global_release_quality'],float);mis=np.asarray(m['trial_package_online_mission'],bool);sx0=np.asarray(m['trial_global_ship_x_release_m'],float);sy0=np.asarray(m['trial_global_ship_y_release_m'],float);sh0=np.asarray(m['trial_global_ship_heading_release_rad'],float);sr0=np.asarray(m['trial_global_ship_turn_rate_release_rad_s'],float);ah=np.asarray(m['trial_global_attack_heading_release_rad'],float)
    n,K=q.shape;hits=np.zeros((n,K),bool);near=np.zeros((n,K),bool);miss=np.full((n,K),np.nan);fall=np.zeros((n,K));impact_x=np.full((n,K),np.nan);impact_y=np.full((n,K),np.nan)
    # Vertical initial velocity inherited from a steep dive; time_scale carries unmodelled bomb drag.
    v=term.speed_release_kmh/3.6;vz=v*math.sin(math.radians(bp.dive_deg));
    tf=(-vz+math.sqrt(vz*vz+2*G*term.release_alt_m))/G*bp.time_scale
    for tr in range(n):
      for k in range(K):
        if mis[tr,k] or q[tr,k]<=0:continue
        fall[tr,k]=tf
        # Crew solves lead with instantaneous ship velocity (constant-course assumption).
        sv=ship.speed_kn*.514444;predx=sx0[tr,k]+sv*math.cos(sh0[tr,k])*tf;predy=sy0[tr,k]+sv*math.sin(sh0[tr,k])*tf
        qq=float(np.clip(q[tr,k],0,1));sc=bp.sigma_cross_m+bp.quality_cross_extra_m*(1-qq)**1.15;sa=bp.sigma_along_m+bp.quality_along_extra_m*(1-qq)**1.15
        ea=float(rng.normal(0,sa));ec=float(rng.normal(0,sc));c=math.cos(ah[tr,k]);s=math.sin(ah[tr,k]);ix=predx+ea*c-ec*s;iy=predy+ea*s+ec*c;impact_x[tr,k]=ix;impact_y[tr,k]=iy
        ax,ay,hh=_ship_post_release(ship,sx0[tr,k],sy0[tr,k],sh0[tr,k],sr0[tr,k],ah[tr,k],'dive',[tf],turn_scale)
        md,_,_=_point_ship_miss(ix,iy,float(ax[0]),float(ay[0]),float(hh[0]),ship.length_m,ship.beam_m);miss[tr,k]=md;hits[tr,k]=md<=0;near[tr,k]=md<=bp.near_miss_m
    rel=(~mis)&(q>0);den=max(1,rel.sum())
    return {'model':'v0.11.5','weapon':bp.id,'released':int(rel.sum()),'hits':int(hits.sum()),'near_50m':int(near.sum()),'hit_rate_per_release':float(hits.sum()/den),'near_rate_per_release':float(near.sum()/den),'mean_hits_per_wave':float(hits.sum()/n),'mean_near_per_wave':float(near.sum()/n),'mean_miss_m':float(np.nanmean(miss)),'trial_hits':hits.tolist(),'trial_near':near.tolist(),'trial_miss_m':np.where(np.isfinite(miss),miss,-1).tolist(),'fall_time_s':tf}

def simulate_torpedoes(m,seed=11502,ship=None,turn_scale=1.0,prior='center',torpedo_policy='auto'):
    ship=ship or ShipProfile();tp=TORPEDO_PRIORS[prior] if isinstance(prior,str) else prior;term=TERMINALS['TBF1C'];rng=np.random.default_rng(seed)
    # Torpedoes use the explicit pre-target weapon-release gate when available.
    if 'trial_package_weapon_release_quality' in m and m.get('package_weapon_release_range_m') is not None:
        q=np.asarray(m['trial_package_weapon_release_quality'],float);mis=np.asarray(m['trial_package_weapon_release_mission'],bool);
        rx=np.asarray(m['trial_package_weapon_release_x_m'],float);ry=np.asarray(m['trial_package_weapon_release_y_m'],float);
        sx0=np.asarray(m['trial_package_weapon_release_ship_x_m'],float);sy0=np.asarray(m['trial_package_weapon_release_ship_y_m'],float);
        sh0=np.asarray(m['trial_package_weapon_release_ship_heading_rad'],float);sr0=np.asarray(m['trial_package_weapon_release_ship_turn_rate_rad_s'],float);
        ah=np.asarray(m['trial_package_weapon_release_heading_rad'],float);gate=np.asarray(m['trial_package_weapon_release_cycle'],int)>=0
        mis=mis|(~gate)
    else:
        q=np.asarray(m['trial_global_release_quality'],float);mis=np.asarray(m['trial_package_online_mission'],bool);sx0=np.asarray(m['trial_global_ship_x_release_m'],float);sy0=np.asarray(m['trial_global_ship_y_release_m'],float);sh0=np.asarray(m['trial_global_ship_heading_release_rad'],float);sr0=np.asarray(m['trial_global_ship_turn_rate_release_rad_s'],float);ah=np.asarray(m['trial_global_attack_heading_release_rad'],float);dx=np.asarray(m['trial_package_delivery_dx_m'],float);dy=np.asarray(m['trial_package_delivery_dy_m'],float)
        n0,K0=q.shape;offs=geom._package_offsets(K0);rx=float(m['package_target_x'])+offs[None,:,0]+dx;ry=offs[None,:,1]+dy
    n,K=q.shape
    geomhit=np.zeros((n,K),bool);hit=np.zeros((n,K),bool);normal=np.zeros((n,K),bool);near=np.zeros((n,K),bool);miss=np.full((n,K),np.nan);nosol=np.zeros((n,K),bool);aimfail=np.zeros((n,K),bool);runlen=np.full((n,K),np.nan);runtime=np.full((n,K),np.nan)
    torpspd=tp.water_speed_kn*.514444;maxt=tp.max_run_m/torpspd
    for tr in range(n):
      for k in range(K):
        if mis[tr,k] or q[tr,k]<=0:continue
        qq=float(np.clip(q[tr,k],0,1));normal[tr,k]=rng.random()<tp.run_normal_p
        # water-entry point with lateral entry error
        sigc=tp.sigma_entry_cross_m+tp.quality_entry_cross_extra_m*(1-qq)**1.15;ec=float(rng.normal(0,sigc));c=math.cos(ah[tr,k]);s=math.sin(ah[tr,k]);px=rx[tr,k]+tp.entry_forward_m*c-ec*s;py=ry[tr,k]+tp.entry_forward_m*s+ec*c
        # target advances during air-entry interval
        ex,ey,eh=_ship_post_release(ship,sx0[tr,k],sy0[tr,k],sh0[tr,k],sr0[tr,k],ah[tr,k],'torpedo',[tp.entry_time_s],turn_scale,torpedo_policy);tx=float(ex[0]);ty=float(ey[0]);th=float(eh[0])
        tv=ship.speed_kn*.514444;tvx=tv*math.cos(th);tvy=tv*math.sin(th);true_sol=_solve_intercept(px,py,tx,ty,tvx,tvy,torpspd,maxt)
        if true_sol is None:nosol[tr,k]=True
        # Aircrew does not know the target's instantaneous motion perfectly. Estimate course/speed
        # with quality-dependent noise and a short lag while the ship is turning.
        est_rate=wrap(th-float(sh0[tr,k]))/max(tp.entry_time_s,1e-6)
        sc=math.radians(tp.target_course_sigma_deg+tp.quality_course_extra_deg*(1-qq)**1.15);ss=tp.target_speed_sigma_kn+tp.quality_speed_extra_kn*(1-qq)**1.15
        eth=wrap(th-est_rate*tp.target_track_lag_s+rng.normal(0,sc));espd=max(5.0,ship.speed_kn+rng.normal(0,ss))*.514444;evx=espd*math.cos(eth);evy=espd*math.sin(eth)
        esol=_solve_intercept(px,py,tx,ty,evx,evy,torpspd,maxt)
        if esol is None:
            aimfail[tr,k]=True;hd=math.atan2(ty-py,tx-px)
        else:
            aimx=tx+evx*esol;aimy=ty+evy*esol;hd=math.atan2(aimy-py,aimx-px)
        sigh=math.radians(tp.sigma_heading_deg+tp.quality_heading_extra_deg*(1-qq)**1.15);hd=wrap(hd+rng.normal(0,sigh))
        # integrate weapon and maneuvering ship through max run; find minimum rectangle miss after arming.
        step=.25;t=0.;wx=px;wy=py;best=1e9;bestlen=0.;bestt=0.
        times=np.arange(step,maxt+step/2,step);sx,sy,sh=_ship_post_release(ship,tx,ty,th,sr0[tr,k],ah[tr,k],'torpedo',times,turn_scale,torpedo_policy)
        for ii,tt in enumerate(times):
            wx=px+torpspd*math.cos(hd)*tt;wy=py+torpspd*math.sin(hd)*tt;rl=torpspd*tt
            if rl<tp.arming_m:continue
            md,_,_=_point_ship_miss(wx,wy,float(sx[ii]),float(sy[ii]),float(sh[ii]),ship.length_m+2*tp.hitbox_margin_m,ship.beam_m+2*tp.hitbox_margin_m)
            if md<best:best=md;bestlen=rl;bestt=tt
            if md<=0:break
        miss[tr,k]=best;runlen[tr,k]=bestlen;runtime[tr,k]=bestt;geomhit[tr,k]=best<=0;near[tr,k]=best<=tp.near_miss_m;hit[tr,k]=geomhit[tr,k]&normal[tr,k]
    rel=(~mis)&(q>0);den=max(1,rel.sum())
    return {'model':'v0.11.5','weapon':tp.id,'prior':prior if isinstance(prior,str) else 'custom','torpedo_policy':str(torpedo_policy),'released':int(rel.sum()),'no_constant_course_solution':int(nosol.sum()),'aircrew_aim_solution_failure':int(aimfail.sum()),'run_normal':int(normal.sum()),'geometric_hits':int(geomhit.sum()),'hits':int(hit.sum()),'near_45m':int(near.sum()),'geometric_hit_rate_per_release':float(geomhit.sum()/den),'hit_rate_per_release':float(hit.sum()/den),'no_solution_rate':float(nosol.sum()/den),'aircrew_aim_failure_rate':float(aimfail.sum()/den),'solution_count':int(rel.sum()-nosol.sum()),'normal_rate_per_release':float(normal.sum()/den),'mean_geometric_hits_per_wave':float(geomhit.sum()/n),'mean_hits_per_wave':float(hit.sum()/n),'mean_miss_m':float(np.nanmean(miss)) if np.isfinite(miss).any() else math.nan,'mean_best_run_m':float(np.nanmean(runlen)) if np.isfinite(runlen).any() else math.nan,'mean_best_time_s':float(np.nanmean(runtime)) if np.isfinite(runtime).any() else math.nan,'trial_hits':hit.tolist(),'trial_geometric_hits':geomhit.tolist(),'trial_miss_m':np.where(np.isfinite(miss),miss,-1).tolist()}
