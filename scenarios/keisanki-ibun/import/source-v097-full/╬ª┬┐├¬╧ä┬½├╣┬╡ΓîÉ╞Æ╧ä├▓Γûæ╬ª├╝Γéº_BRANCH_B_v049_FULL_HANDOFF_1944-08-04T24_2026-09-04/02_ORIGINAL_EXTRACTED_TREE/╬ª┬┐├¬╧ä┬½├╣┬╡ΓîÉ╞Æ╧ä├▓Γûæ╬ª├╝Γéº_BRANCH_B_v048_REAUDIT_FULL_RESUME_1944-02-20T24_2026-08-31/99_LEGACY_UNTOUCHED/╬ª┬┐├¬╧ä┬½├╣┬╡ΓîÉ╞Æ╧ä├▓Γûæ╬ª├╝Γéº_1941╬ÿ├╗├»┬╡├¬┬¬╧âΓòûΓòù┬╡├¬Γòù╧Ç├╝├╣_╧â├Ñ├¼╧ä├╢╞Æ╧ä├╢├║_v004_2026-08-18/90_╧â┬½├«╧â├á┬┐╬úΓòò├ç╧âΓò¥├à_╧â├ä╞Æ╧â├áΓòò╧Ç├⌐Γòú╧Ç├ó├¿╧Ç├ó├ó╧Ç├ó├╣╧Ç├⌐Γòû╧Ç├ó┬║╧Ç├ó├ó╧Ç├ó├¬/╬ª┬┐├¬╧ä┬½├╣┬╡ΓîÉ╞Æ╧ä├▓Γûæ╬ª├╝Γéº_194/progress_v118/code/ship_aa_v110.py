#!/usr/bin/env python3
from __future__ import annotations
import math
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
import air_microcombat_v109 as geom
from strike_response_v103 import RESP
from strike_response_v106 import DELIVERY_WEIGHTS, SETUP_SECONDS

base=geom.base
G=9.80665

@dataclass
class ShipProfile:
    id:str='CV_FAST_JP_WORK'
    name:str='fast Japanese carrier-like target, working profile'
    speed_kn:float=30.0
    length_m:float=250.0
    beam_m:float=26.0
    turn_delay_s:float=2.5
    turn_tau_s:float=5.0
    max_turn_rate_deg_s:float=1.45
    source_grade:str='B-prior maneuver / generic dimensions'

@dataclass
class AAProfile:
    id:str='JP_CV_LOCAL_AA_WORK'
    name:str='Japanese carrier local AA working profile'
    heavy_channels:int=2
    heavy_barrels_per_channel:int=3
    heavy_rpm_per_barrel:float=8.0
    heavy_max_range_m:float=8000.0
    heavy_max_alt_m:float=3000.0
    heavy_acquire_s:float=1.6
    heavy_switch_s:float=1.2
    heavy_track_tau_s:float=1.8
    heavy_track_base:float=.78
    # O-44 theoretical static-target example is 0.0029 shell effectiveness; center is intentionally below it.
    heavy_effective_event_p_shell:float=.00125
    light_channels:int=6
    light_barrels_per_channel:int=4
    light_rpm_per_barrel:float=110.0
    light_max_range_m:float=2000.0
    light_max_alt_m:float=1000.0
    light_acquire_s:float=.75
    light_switch_s:float=.45
    light_track_tau_s:float=.75
    light_track_base:float=.58
    light_direct_hit_p_round:float=.00058
    # pressure coefficients create warning/jink without assuming a hit.
    heavy_pressure_per_round:float=.035
    light_pressure_per_round:float=.008
    source_grade:str='A range/claimed-expenditure anchors from USNTMJ O-44; B-prior channels/rates/effectiveness'
    damage_set:str='JP'


# v0.11.8 WIP US carrier-local AA abstraction. Weapon-family/rate anchors are historical;
# participating channels, tracking quality and per-round effective-event probabilities remain B-priors.
US_FAST_CV_WORK=ShipProfile(
    id='CV_FAST_US_WORK',name='fast US fleet-carrier-like target, working profile',
    speed_kn=32.0,length_m=265.0,beam_m=28.5,turn_delay_s=2.5,turn_tau_s=5.0,
    max_turn_rate_deg_s=1.35,source_grade='A dimensions/speed class anchor; B-prior maneuver response')
US_CV_LOCAL_AA_WORK=AAProfile(
    id='US_CV_LOCAL_AA_WORK',name='US fleet-carrier local AA working profile',
    heavy_channels=4,heavy_barrels_per_channel=2,heavy_rpm_per_barrel=15.0,
    heavy_max_range_m=9500.0,heavy_max_alt_m=7000.0,heavy_acquire_s=1.2,heavy_switch_s=.9,
    heavy_track_tau_s=1.35,heavy_track_base=.88,heavy_effective_event_p_shell=.00225,
    light_channels=8,light_barrels_per_channel=4,light_rpm_per_barrel=120.0,
    light_max_range_m=4000.0,light_max_alt_m=2500.0,light_acquire_s=.55,light_switch_s=.35,
    light_track_tau_s=.55,light_track_base=.72,light_direct_hit_p_round=.00034,
    heavy_pressure_per_round=.045,light_pressure_per_round=.0045,
    source_grade='A weapon-family/rate anchors; B-prior effective participating channels/tracking/effectiveness; 40mm-dominant light layer',
    damage_set='US')

@dataclass
class TerminalProfile:
    id:str
    start_range_m:float
    release_range_m:float
    start_alt_m:float
    release_alt_m:float
    speed_start_kmh:float
    speed_release_kmh:float
    setup_seconds:float
    mission:str

TERMINALS={
    'TBF1C':TerminalProfile('TBF1C',6000.0,900.0,700.0,120.0,300.0,280.0,15.0,'torpedo'),
    'SBD5':TerminalProfile('SBD5',6000.0,850.0,2900.0,760.0,360.0,450.0,7.5,'dive'),
    'SB2C1C':TerminalProfile('SB2C1C',6000.0,850.0,2700.0,760.0,365.0,460.0,8.0,'dive'),
    'B6N2':TerminalProfile('B6N2',6000.0,750.0,700.0,120.0,320.0,300.0,15.0,'torpedo'),
    'D4Y2':TerminalProfile('D4Y2',6000.0,850.0,3000.0,760.0,360.0,450.0,7.5,'dive'),
}

# Notional damage carriers. They are effective-event representations, not claims about exact shell fragments.
AA25=base.Weapon(id='JP25_T96_AA_EVENT',name='25mm Type 96 effective direct-hit event (working)',caliber_mm=25.0,
    projectile_g=250.0,muzzle_mps=900.0,rpm=110.0,rpm_sigma=12.0,base_pen_mm_250=25.0,blast=.95,incendiary=.42,
    ammo_mix={'HEI':.70,'AP':.20,'T':.10},source_grade='B-prior damage carrier')
AA127FRAG=base.Weapon(id='JP127_AA_FRAGMENT_EVENT',name='12.7cm AA effective fragment event (working)',caliber_mm=12.7,
    projectile_g=45.0,muzzle_mps=620.0,rpm=1.0,rpm_sigma=0.0,base_pen_mm_250=10.0,blast=.42,incendiary=.20,
    ammo_mix={'HEI':.70,'AP':.10,'T':.20},source_grade='B-prior effective fragment carrier')

US40=base.Weapon(id='US40_AA_EVENT',name='40mm Bofors effective direct-hit event (working)',caliber_mm=40.0,
    projectile_g=900.0,muzzle_mps=880.0,rpm=120.0,rpm_sigma=10.0,base_pen_mm_250=45.0,blast=1.15,incendiary=.30,
    ammo_mix={'HEI':.80,'AP':.10,'T':.10},source_grade='A caliber/mass/velocity class anchor; B-prior effective damage carrier')
US5FRAG=base.Weapon(id='US5_VT_FRAGMENT_EVENT',name='5in/38 VT/AAC effective fragment event (working)',caliber_mm=16.0,
    projectile_g=85.0,muzzle_mps=700.0,rpm=1.0,rpm_sigma=0.0,base_pen_mm_250=13.0,blast=.58,incendiary=.24,
    ammo_mix={'HEI':.78,'AP':.05,'T':.17},source_grade='A 5in/38+VT role anchor; B-prior fragment-event carrier')

def _damage_event_weapons(aa:AAProfile):
    return (US5FRAG,US40) if getattr(aa,'damage_set','JP')=='US' else (AA127FRAG,AA25)


def _copy_online_states(m,n,K):
    states=[]
    mission=np.asarray(m['trial_package_online_mission'],bool)
    immediate=np.asarray(m['trial_package_online_immediate'],bool)
    fire=np.asarray(m.get('trial_package_online_fire',np.zeros((n,K))),float)
    for k in range(K):
        st=base._state(n)
        for fld in ('pilot','engine','cooling','fuel','controls','structure'):
            st[fld]=np.asarray(m[f'trial_package_online_{fld}'],float)[:,k].copy()
        st['fire']=fire[:,k].copy(); st['mission']=mission[:,k].copy(); st['immediate']=immediate[:,k].copy()
        st['ever_hit']=(st['pilot']<1)|(st['engine']<1)|(st['cooling']<1)|(st['fuel']<1)|(st['controls']<1)|(st['structure']<1)|(st['fire']>0)
        states.append(st)
    return states


def _delivery_component_quality(at,states):
    n=len(states[0]['mission']);K=len(states);ww=DELIVERY_WEIGHTS[at.id];comp=np.ones((n,K),float)
    for k,st in enumerate(states):
        logq=np.zeros(n,float)
        for name,w in ww.items(): logq+=w*np.log(np.clip(st[name],.03,1.0))
        comp[:,k]=np.exp(logq)
    return comp


def _aspect_from_ship(target_hdg,bearing_ship_to_target):
    # 0 rear,1 beam,2 front from target's point of view.
    d=np.abs(geom.wrap((bearing_ship_to_target+np.pi)-target_hdg))
    out=np.ones(np.shape(d),np.int8);out[d<np.deg2rad(60)]=2;out[d>np.deg2rad(120)]=0
    return out


def _target_score(rng_m,alt_m,alive,mission,mission_type):
    # closer and still mission-capable gets priority; torpedo attackers become sharply more threatening close in.
    close=np.clip(1-rng_m/8000.0,0,1)
    if mission_type=='torpedo': threat=np.clip(1-rng_m/4500.0,0,1)**1.7
    else: threat=np.clip(1-rng_m/6500.0,0,1)**1.25
    return np.where(alive&(~mission),.55*close+.45*threat,-1e9)


def _ship_solution_quality(ship:ShipProfile,term:TerminalProfile,ship_hdg,ship_turn_rate,attack_hdg):
    # This is target-solution quality at release, NOT weapon hit probability.
    rel=np.abs(geom.wrap(ship_hdg-attack_hdg))
    if term.mission=='torpedo':
        # Projected cross-track target width: broadside ~ length, bow/stern ~ beam.
        proj=np.sqrt((ship.length_m*np.sin(rel))**2+(ship.beam_m*np.cos(rel))**2)
        sizeq=np.clip(.45+.55*np.sqrt(proj/ship.length_m),.48,1.0)
        turnq=np.exp(-.22*(np.abs(np.rad2deg(ship_turn_rate))/1.2)**1.25)
        return np.clip(sizeq*turnq,0,1)
    # Dive-bomb release: vertical planform area is unchanged by heading; turning creates lead/acceleration uncertainty.
    fall=max(4.0,math.sqrt(2*term.release_alt_m/G))
    v=ship.speed_kn*.514444
    aperp=np.abs(v*ship_turn_rate)
    disp=.5*aperp*fall*fall
    turnq=np.exp(-.5*(disp/max(24.0,1.45*ship.beam_m))**2)
    return np.clip(turnq,0,1)


def _desired_ship_heading(policy,mission,ship_hdg,threat_bearing,turn_sign):
    if policy=='none': return ship_hdg
    if mission=='torpedo':
        # turn bow/stern toward the attack axis; choose nearer of bearing and reciprocal.
        cands=np.array([threat_bearing,geom.wrap(threat_bearing+np.pi)])
        ds=np.abs(geom.wrap(cands-ship_hdg));return float(cands[np.argmin(ds)])
    # Dive-bomb defense: sustained hard turn, not a magic 'perfect dodge'.
    return float(geom.wrap(ship_hdg+turn_sign*np.deg2rad(95.0)))


def simulate_ship_aa_phase(m,at,effects,ship=None,aa=None,aa_strength=1.0,ship_turn_scale=1.0,
                           aa_enabled=True,evasion_enabled=True,ship_evasion_policy='auto',seed=11001,
                           dt=.5,return_trials=False):
    """Final ship-AA corridor from CAP handoff to release.

    Re-bases the v0.10.9 delivery state at a mission-specific outer AA handoff.  Damage and formation
    deviations are preserved; absolute terminal altitude/speed follow the v0.11 mission profile.
    Outputs target-solution/release-opportunity quality only. No bomb/torpedo hit probability is claimed.
    """
    ship=ship or ShipProfile();aa=aa or AAProfile();term=TERMINALS[at.id];heavy_event_weapon,light_event_weapon=_damage_event_weapons(aa)
    n=len(m['trial_package_passes']);K=int(m.get('package_aircraft_count',12));rng=np.random.default_rng(seed)
    states=_copy_online_states(m,n,K);effects=effects
    initial_mission=np.stack([st['mission'] for st in states],1).copy();initial_damage=np.stack([base.damage_summary(st) for st in states],1).copy()
    offs=geom._package_offsets(K)
    dynX=np.asarray(m.get('trial_package_delivery_dx_m',np.zeros((n,K))),float).copy()
    dynY=np.asarray(m.get('trial_package_delivery_dy_m',np.zeros((n,K))),float).copy()
    dynZ=np.asarray(m.get('trial_package_delivery_dz_m',np.zeros((n,K))),float).copy()
    dynH=np.asarray(m.get('trial_package_delivery_dheading_rad',np.zeros((n,K))),float).copy()
    last_ev=np.asarray(m.get('trial_package_last_evasion_cycle',np.full((n,K),-999)),int).copy()
    delcy=np.asarray(m.get('trial_package_delivery_cycle',np.zeros(n,int)),int)
    since_ev_s=np.maximum(0.0,(delcy[:,None]-last_ev)*2.5)
    ev_timer=np.zeros((n,K),np.int16);vy=np.zeros((n,K));vz=np.zeros((n,K));rpar=RESP[at.id]
    # Ship starts abeam for torpedo working case; dive case starts on attack axis then begins evasive hard turn.
    shipx=np.zeros(n);shipy=np.zeros(n);shiphdg=np.full(n,np.pi/2 if term.mission=='torpedo' else 0.0);shiprate=np.zeros(n)
    ship_turn_sign=np.where(rng.random(n)<.5,-1.0,1.0);turn_clock=np.zeros(n)
    ship_initial_hdg=shiphdg.copy();shipbase_x=shipx.copy();shipbase_y=shipy.copy()
    # package center starts east (+x) and flies west toward ship.
    center_x=np.full(n,term.start_range_m);center_y=np.zeros(n);center_hdg=np.full(n,np.pi)
    elapsed=np.zeros(n)
    total_dist=term.start_range_m-term.release_range_m
    # Channel states by trial.
    hc=aa.heavy_channels;lc=aa.light_channels
    ht=np.full((n,hc),-1,np.int16);lt=np.full((n,lc),-1,np.int16)
    hdelay=np.zeros((n,hc));ldelay=np.zeros((n,lc));hq=np.zeros((n,hc));lq=np.zeros((n,lc))
    # Light groups have overlapping local arcs; attack-side groups can participate but not every mount at once.
    light_sector=np.linspace(-np.pi,np.pi,lc,endpoint=False)
    # Diagnostics.
    hrds=np.zeros(n);lrds=np.zeros(n);hevents=np.zeros(n,int);lhits=np.zeros(n,int);jinks=np.zeros(n,int);aa_losses=np.zeros(n,int)
    chan_switch_h=np.zeros(n,int);chan_switch_l=np.zeros(n,int);max_rmsy=np.zeros(n);max_rmsh=np.zeros(n)
    prev_mission=np.stack([st['mission'] for st in states],1).copy()
    # Track release state; use full arrays to support aircraft reaching range at slightly different times.
    released=np.zeros((n,K),bool);release_q=np.zeros((n,K));ship_q=np.zeros((n,K));release_time=np.full((n,K),np.nan)
    ship_hdg_release=np.full((n,K),np.nan);ship_rate_release=np.full((n,K),np.nan)
    # Upper duration based slowest profile + margin.
    max_time=1.35*total_dist/(min(term.speed_start_kmh,term.speed_release_kmh)/3.6)+8.0;steps=int(math.ceil(max_time/dt))
    for step in range(steps):
        # Evolve continuing damage on original 2.5 s cadence.
        if step%max(1,int(round(2.5/dt)))==0:
            for st in states:
                ix=np.where(~st['mission'])[0]
                if len(ix): base.evolve_damage(st,at.defense,ix,rng)
        mission=np.stack([st['mission'] for st in states],1);alive=~mission
        newly=mission&(~prev_mission);aa_losses+=newly.sum(1);prev_mission=mission.copy()
        # Nominal terminal speed/altitude by progress along corridor.
        progress=np.clip((term.start_range_m-center_x)/max(total_dist,1),0,1)
        speed=term.speed_start_kmh+(term.speed_release_kmh-term.speed_start_kmh)*progress
        alt=term.start_alt_m+(term.release_alt_m-term.start_alt_m)*progress
        # Dynamic formation recovery and AA-induced jink persistence.
        comp=_delivery_component_quality(at,states)
        for k,st in enumerate(states):
            dmg=base.damage_summary(st);active=(ev_timer[:,k]>0)&alive[:,k];tau=np.maximum(7.0,rpar['tau']*(1+.9*dmg));rec=np.exp(-dt/tau)
            vy[:,k]*=np.where(active,.94,rec);vz[:,k]*=np.where(active,.93,rec);dynH[:,k]*=np.where(active,.96,rec)
            dynY[:,k]+=vy[:,k]*dt;dynZ[:,k]+=vz[:,k]*dt
            restore=(~active)&alive[:,k];vy[:,k]+=np.where(restore,-dynY[:,k]/np.maximum(18.0,tau*2.1)*dt,0);vz[:,k]+=np.where(restore,-dynZ[:,k]/np.maximum(14.0,tau*1.8)*dt,0)
            ev_timer[:,k]=np.maximum(0,ev_timer[:,k]-1);since_ev_s[:,k]+=dt
        rmsy=np.sqrt(np.mean(dynY*dynY,axis=1));rmsh=np.sqrt(np.mean(np.rad2deg(dynH)**2,axis=1));max_rmsy=np.maximum(max_rmsy,rmsy);max_rmsh=np.maximum(max_rmsh,rmsh)
        # Individual aircraft world geometry.
        # Formation-axis +x points forward (west), hence world x subtracts longitudinal offsets.
        ax=center_x[:,None]-offs[None,:,0]-dynX;ay=center_y[:,None]-offs[None,:,1]-dynY
        ah=alt[:,None]+offs[None,:,2]+dynZ;ahdg=geom.wrap(center_hdg[:,None]+dynH)
        dx=ax-shipx[:,None];dy=ay-shipy[:,None];rng_m=np.sqrt(dx*dx+dy*dy)+1e-6;bear=np.arctan2(dy,dx)
        # Ship maneuver uses the closest mission-capable attacker as threat bearing.
        for tr in range(n):
            liveidx=np.where(alive[tr]&(~released[tr]))[0]
            if not len(liveidx): continue
            kk=liveidx[np.argmin(rng_m[tr,liveidx])];tb=float(bear[tr,kk])
            pol='none' if not evasion_enabled else ('torpedo' if term.mission=='torpedo' else 'dive') if ship_evasion_policy=='auto' else ship_evasion_policy
            desired=_desired_ship_heading(pol,term.mission,float(shiphdg[tr]),tb,float(ship_turn_sign[tr]))
            turn_clock[tr]+=dt
            if pol!='none' and turn_clock[tr]>=ship.turn_delay_s:
                err=float(geom.wrap(desired-shiphdg[tr]));cmd=np.clip(err/max(ship.turn_tau_s,1e-3),-math.radians(ship.max_turn_rate_deg_s*ship_turn_scale),math.radians(ship.max_turn_rate_deg_s*ship_turn_scale))
            else: cmd=0.0
            shiprate[tr]+=np.clip(cmd-shiprate[tr],-math.radians(ship.max_turn_rate_deg_s)*dt/max(ship.turn_tau_s,1),math.radians(ship.max_turn_rate_deg_s)*dt/max(ship.turn_tau_s,1))
            shiprate[tr]=float(np.clip(shiprate[tr],-math.radians(ship.max_turn_rate_deg_s*ship_turn_scale),math.radians(ship.max_turn_rate_deg_s*ship_turn_scale)))
        shiphdg=geom.wrap(shiphdg+shiprate*dt);sv=ship.speed_kn*.514444;shipx+=sv*np.cos(shiphdg)*dt;shipy+=sv*np.sin(shiphdg)*dt
        # AA target assignment + fire.
        if aa_enabled:
            score=_target_score(rng_m,ah,alive&(~released),mission,term.mission)
            for tr in range(n):
                # Heavy director channels.
                for c in range(hc):
                    cur=int(ht[tr,c]);valid=cur>=0 and alive[tr,cur] and (not released[tr,cur]) and rng_m[tr,cur]<=aa.heavy_max_range_m and ah[tr,cur]<=aa.heavy_max_alt_m
                    if not valid:
                        elig=np.where((score[tr]>-1e8)&(rng_m[tr]<=aa.heavy_max_range_m)&(ah[tr]<=aa.heavy_max_alt_m))[0]
                        new=int(elig[np.argmax(score[tr,elig])]) if len(elig) else -1
                        if new!=cur:chan_switch_h[tr]+=int(cur>=0 and new>=0);ht[tr,c]=new;hdelay[tr,c]=aa.heavy_acquire_s if cur<0 else aa.heavy_switch_s;hq[tr,c]=0
                    t=int(ht[tr,c])
                    if t<0:continue
                    if hdelay[tr,c]>0:hdelay[tr,c]=max(0,hdelay[tr,c]-dt);continue
                    rangefac=float(np.clip(1-rng_m[tr,t]/aa.heavy_max_range_m,.18,1.0));jfac=.48 if ev_timer[tr,t]>0 else 1.0;turnfac=float(np.clip(1-.10*abs(math.degrees(shiprate[tr]))/max(ship.max_turn_rate_deg_s,1e-3),.78,1.0));desiredq=aa.heavy_track_base*rangefac**.25*jfac*turnfac
                    hq[tr,c]+=np.clip(desiredq-hq[tr,c],-1,1)*min(1,dt/aa.heavy_track_tau_s)
                    rounds=int(rng.poisson(aa.heavy_barrels_per_channel*aa.heavy_rpm_per_barrel/60*dt));hrds[tr]+=rounds
                    if rounds<=0:continue
                    # Pressure warning/jink, separate from physical hit.
                    pj=1-math.exp(-aa.heavy_pressure_per_round*rounds*max(.15,hq[tr,c]))
                    if ev_timer[tr,t]==0 and rng.random()<pj:
                        side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));vy[tr,t]+=side*rpar['lat_imp']*.92*sc;vz[tr,t]+=rng.normal(0,rpar['vert_imp']*.8);dynH[tr,t]+=math.radians(side*rpar['hdg_imp_deg']*.9*sc);ev_timer[tr,t]=int(rng.integers(3,7));jinks[tr]+=1;since_ev_s[tr,t]=0.0
                    pe=min(.0029,aa.heavy_effective_event_p_shell*aa_strength*max(.05,hq[tr,c]))
                    ne=int(rng.binomial(rounds,pe));hevents[tr]+=ne
                    if ne and not states[t]['mission'][tr]:
                        # One effective shell event yields a small cluster of damaging fragments.
                        nf=int(ne+rng.poisson(1.15*ne));asp=int(_aspect_from_ship(np.array([ahdg[tr,t]]),np.array([bear[tr,t]]))[0])
                        base.apply_hits(states[t],at.defense,heavy_event_weapon,effects,np.array([tr]),np.array([nf]),np.array([asp],np.int8),np.array([250.0]),rng)
                # 25mm local groups.
                for c in range(lc):
                    cur=int(lt[tr,c]);relsec=lambda t: abs(float(geom.wrap(bear[tr,t]-shiphdg[tr]-light_sector[c])))
                    valid=cur>=0 and alive[tr,cur] and (not released[tr,cur]) and rng_m[tr,cur]<=aa.light_max_range_m and ah[tr,cur]<=aa.light_max_alt_m and relsec(cur)<math.radians(78)
                    if not valid:
                        elig=np.where((score[tr]>-1e8)&(rng_m[tr]<=aa.light_max_range_m)&(ah[tr]<=aa.light_max_alt_m))[0]
                        elig=np.array([t for t in elig if relsec(int(t))<math.radians(78)],int)
                        new=int(elig[np.argmax(score[tr,elig])]) if len(elig) else -1
                        if new!=cur:chan_switch_l[tr]+=int(cur>=0 and new>=0);lt[tr,c]=new;ldelay[tr,c]=aa.light_acquire_s if cur<0 else aa.light_switch_s;lq[tr,c]=0
                    t=int(lt[tr,c]);
                    if t<0:continue
                    if ldelay[tr,c]>0:ldelay[tr,c]=max(0,ldelay[tr,c]-dt);continue
                    rangefac=float(np.clip(1-rng_m[tr,t]/aa.light_max_range_m,.10,1.0));jfac=.55 if ev_timer[tr,t]>0 else 1.0;desiredq=aa.light_track_base*rangefac**.32*jfac
                    lq[tr,c]+=np.clip(desiredq-lq[tr,c],-1,1)*min(1,dt/aa.light_track_tau_s)
                    rounds=int(rng.poisson(aa.light_barrels_per_channel*aa.light_rpm_per_barrel/60*dt));lrds[tr]+=rounds
                    if rounds<=0:continue
                    pj=1-math.exp(-aa.light_pressure_per_round*rounds*max(.12,lq[tr,c]))
                    if ev_timer[tr,t]==0 and rng.random()<pj:
                        side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));vy[tr,t]+=side*rpar['lat_imp']*.85*sc;vz[tr,t]+=rng.normal(0,rpar['vert_imp']*.72);dynH[tr,t]+=math.radians(side*rpar['hdg_imp_deg']*.82*sc);ev_timer[tr,t]=int(rng.integers(2,6));jinks[tr]+=1;since_ev_s[tr,t]=0.0
                    ph=aa.light_direct_hit_p_round*aa_strength*max(.04,lq[tr,c])*rangefac**.35
                    nh=int(rng.binomial(rounds,min(.01,ph)));lhits[tr]+=nh
                    if nh and not states[t]['mission'][tr]:
                        asp=int(_aspect_from_ship(np.array([ahdg[tr,t]]),np.array([bear[tr,t]]))[0])
                        base.apply_hits(states[t],at.defense,light_event_weapon,effects,np.array([tr]),np.array([nh]),np.array([asp],np.int8),np.array([float(rng_m[tr,t])]),rng)
        # Release condition is along the attacker's nominal weapon-run axis.  The aircraft can continuously
        # update lead on a steadily moving ship; ship maneuver is represented in target-solution quality, not
        # by requiring the ship to remain inside a fixed 900-m bubble around the original aim point.
        along=ax
        for tr in range(n):
            for k in range(K):
                if released[tr,k] or states[k]['mission'][tr]:continue
                if along[tr,k]<=term.release_range_m:
                    # Setup quality at release from live geometry, damage and time since last jink.
                    compk=float(_delivery_component_quality(at,states)[tr,k]);hddeg=abs(math.degrees(float(dynH[tr,k])));track=math.exp(-.10*(abs(float(dynX[tr,k]))/420)**2-.40*(hddeg/rpar['ready_hdg'])**2-.27*(abs(float(dynY[tr,k]))/rpar['ready_y'])**2-.20*(abs(float(dynZ[tr,k]))/rpar['ready_z'])**2)
                    since=float(since_ev_s[tr,k]);setup=min(1.0,since/max(term.setup_seconds,1e-6));dq=float(np.clip(track*setup*compk,0,1))
                    sq=float(_ship_solution_quality(ship,term,float(shiphdg[tr]),float(shiprate[tr]),float(ahdg[tr,k]))) if evasion_enabled else float(_ship_solution_quality(ship,term,float(ship_initial_hdg[tr]),0.0,float(ahdg[tr,k])))
                    release_q[tr,k]=dq;ship_q[tr,k]=sq;released[tr,k]=True;release_time[tr,k]=step*dt;ship_hdg_release[tr,k]=shiphdg[tr];ship_rate_release[tr,k]=shiprate[tr]
        # Move package nominal center.  Aircraft deviations are relative to it.
        center_x-=speed/3.6*dt;elapsed+=dt
        # Stop trial when all survivors have released or passed beyond ship/release point.
        if np.all(released|np.stack([st['mission'] for st in states],1)):break
    mission=np.stack([st['mission'] for st in states],1);dam=np.stack([base.damage_summary(st) for st in states],1);alive=~mission
    comp=_delivery_component_quality(at,states)
    # unreleased surviving aircraft have lost terminal setup by definition.
    opportunity=release_q*ship_q
    out={
      'model':'ship-aa-terminal-v0.11.0','target_type':at.id,'ntr':n,'package_count':K,'mission':term.mission,
      'aa_enabled':bool(aa_enabled),'ship_evasion_enabled':bool(evasion_enabled),'aa_strength':float(aa_strength),'ship_turn_scale':float(ship_turn_scale),
      'mean_attackers_mission_lost_at_handoff':float(initial_mission.sum(1).mean()),'mean_attackers_mission_lost_total':float(mission.sum(1).mean()),
      'mean_mission_loss_increment_after_handoff':float((mission.sum(1)-initial_mission.sum(1)).mean()),'mean_attackers_damaged_survivors_total':float(((dam>.08)&alive).sum(1).mean()),
      'mean_damage_increment_equivalent':float(np.maximum(0.0,dam-initial_damage).sum(1).mean()),
      'mean_release_count':float(released.sum(1).mean()),'mean_delivery_quality_at_release':float(release_q.sum(1).mean()),'mean_ship_solution_quality_equivalent':float(ship_q.sum(1).mean()),'mean_ship_solution_quality_per_releaser':float(ship_q.sum()/max(1,released.sum())),
      'mean_release_opportunity_equivalent':float(opportunity.sum(1).mean()),'mean_release_opportunity_per_releaser':float(opportunity.sum()/max(1,released.sum())),
      'mean_AA_heavy_rounds':float(hrds.mean()),'mean_AA_25mm_rounds':float(lrds.mean()),'mean_AA_heavy_effective_events':float(hevents.mean()),'mean_AA_25mm_direct_hits':float(lhits.mean()),'mean_AA_jink_events':float(jinks.mean()),'mean_phase_new_mission_losses_diagnostic':float(aa_losses.mean()),
      'mean_heavy_channel_switches':float(chan_switch_h.mean()),'mean_light_channel_switches':float(chan_switch_l.mean()),
      'mean_ship_heading_change_deg':float(np.mean(np.abs(np.rad2deg(geom.wrap(shiphdg-ship_initial_hdg))))),
      'mean_ship_maneuver_displacement_m':float(np.mean(np.hypot(shipx-(shipbase_x+ship.speed_kn*.514444*np.cos(ship_initial_hdg)*elapsed),shipy-(shipbase_y+ship.speed_kn*.514444*np.sin(ship_initial_hdg)*elapsed)))),
      'mean_max_rms_lateral_m':float(max_rmsy.mean()),'mean_max_rms_heading_deg':float(max_rmsh.mean()),
      'terminal_profile':asdict(term),'ship_profile':asdict(ship),'aa_profile':asdict(aa),
      'note':'release-opportunity = aircraft delivery/setup quality x target-solution quality; NOT bomb/torpedo hit probability.'
    }
    if return_trials:
        out.update(trial_release_q=release_q.tolist(),trial_ship_solution_q=ship_q.tolist(),trial_opportunity=opportunity.tolist(),trial_released=released.tolist(),trial_mission=mission.tolist(),trial_AA_heavy_rounds=hrds.tolist(),trial_AA_25mm_rounds=lrds.tolist(),trial_AA_jinks=jinks.tolist(),trial_AA_loss_increment=aa_losses.tolist(),trial_ship_heading_change_deg=np.abs(np.rad2deg(geom.wrap(shiphdg-ship_initial_hdg))).tolist(),trial_ship_maneuver_displacement_m=np.hypot(shipx-(shipbase_x+ship.speed_kn*.514444*np.cos(ship_initial_hdg)*elapsed),shipy-(shipbase_y+ship.speed_kn*.514444*np.sin(ship_initial_hdg)*elapsed)).tolist())
    return out
