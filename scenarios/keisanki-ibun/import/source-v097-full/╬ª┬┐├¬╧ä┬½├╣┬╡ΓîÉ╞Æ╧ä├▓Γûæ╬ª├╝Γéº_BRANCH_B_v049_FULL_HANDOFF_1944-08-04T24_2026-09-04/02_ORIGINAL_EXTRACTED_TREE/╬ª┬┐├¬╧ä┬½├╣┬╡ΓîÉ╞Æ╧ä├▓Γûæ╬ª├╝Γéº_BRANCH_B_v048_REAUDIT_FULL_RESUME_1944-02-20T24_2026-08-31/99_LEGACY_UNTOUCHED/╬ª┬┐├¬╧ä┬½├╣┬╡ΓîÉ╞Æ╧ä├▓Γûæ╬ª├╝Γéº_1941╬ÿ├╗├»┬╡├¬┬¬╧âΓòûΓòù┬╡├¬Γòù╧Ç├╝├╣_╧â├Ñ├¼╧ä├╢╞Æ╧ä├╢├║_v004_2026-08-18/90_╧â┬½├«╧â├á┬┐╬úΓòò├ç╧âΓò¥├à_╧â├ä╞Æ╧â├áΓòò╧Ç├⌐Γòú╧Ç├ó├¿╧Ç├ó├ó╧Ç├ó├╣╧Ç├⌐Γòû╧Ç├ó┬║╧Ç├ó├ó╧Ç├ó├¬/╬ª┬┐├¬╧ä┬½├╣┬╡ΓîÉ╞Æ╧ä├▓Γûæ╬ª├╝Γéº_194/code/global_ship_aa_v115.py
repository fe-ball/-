#!/usr/bin/env python3
from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np
import air_microcombat_v04 as one
base=one.base
from ship_aa_v110 import ShipProfile, AAProfile, TERMINALS, AA25, AA127FRAG, _target_score, _desired_ship_heading, _ship_solution_quality, _aspect_from_ship, _delivery_component_quality


@dataclass(frozen=True)
class FireDisciplineProfile:
    id: str
    heavy_line_m: float
    heavy_burst_m: float
    light_line_m: float
    light_burst_m: float
    target_penalty: float
    heavy_hold_strength: float
    light_hold_strength: float
    track_penalty: float


FIRE_DISCIPLINE = {
    # B-prior safety geometry.  These are deliberately swept; they are NOT asserted historical separation minima.
    'none': FireDisciplineProfile('none',0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0),
    'weak': FireDisciplineProfile('weak',90.0,220.0,70.0,150.0,.28,.30,.42,.10),
    'center': FireDisciplineProfile('center',160.0,360.0,120.0,240.0,.62,.68,.82,.18),
    'strict': FireDisciplineProfile('strict',260.0,520.0,190.0,340.0,1.05,.96,1.00,.28),
}


def _discipline_profile(p):
    if isinstance(p, FireDisciplineProfile): return p
    if p is None: return FIRE_DISCIPLINE['none']
    if isinstance(p, str):
        if p not in FIRE_DISCIPLINE: raise ValueError(f'unknown AA fire discipline: {p}')
        return FIRE_DISCIPLINE[p]
    if isinstance(p, dict): return FireDisciplineProfile(**p)
    raise TypeError('aa_fire_discipline must be a profile name, dict, or FireDisciplineProfile')


def _friendly_risk(shipx,shipy,target_x,target_y,target_h,friend_xy,friend_h,friend_alive,line_m,burst_m):
    """0..1 friendly-air risk around the ship->target 3-D fire line and target burst volume.
    The geometry is a working deconfliction model, not a claim about historical safety minima.
    """
    if friend_xy is None or friend_h is None or friend_alive is None or (line_m<=0 and burst_m<=0): return 0.0
    idx=np.where(friend_alive)[0]
    if not len(idx): return 0.0
    sx,sy,sz=float(shipx),float(shipy),0.0
    tx,ty,tz=float(target_x),float(target_y),float(target_h)
    vx,vy,vz=tx-sx,ty-sy,tz-sz; vv=vx*vx+vy*vy+vz*vz+1e-9
    fx=friend_xy[idx,0]-sx; fy=friend_xy[idx,1]-sy; fz=friend_h[idx]-sz
    u=(fx*vx+fy*vy+fz*vz)/vv
    # Only friends between the mount and just beyond the target matter for line-of-fire risk.
    uc=np.clip(u,0.0,1.08)
    px=sx+uc*vx; py=sy+uc*vy; pz=sz+uc*vz
    dl=np.sqrt((friend_xy[idx,0]-px)**2+(friend_xy[idx,1]-py)**2+(friend_h[idx]-pz)**2)
    line_r=np.where((u>=.02)&(u<=1.08),np.clip(1-dl/max(line_m,1e-6),0,1),0.0) if line_m>0 else np.zeros(len(idx))
    db=np.sqrt((friend_xy[idx,0]-tx)**2+(friend_xy[idx,1]-ty)**2+(friend_h[idx]-tz)**2)
    burst_r=np.clip(1-db/max(burst_m,1e-6),0,1) if burst_m>0 else np.zeros(len(idx))
    return float(max(np.max(line_r,initial=0.0),np.max(burst_r,initial=0.0)))


def _risk_vector(tr,x,y,h,shipx,shipy,friend_xy,friend_h,friend_alive,prof,kind):
    K=x.shape[1]; out=np.zeros(K,float)
    if prof.id=='none' or friend_xy is None:return out
    if kind=='heavy': lm,bm=prof.heavy_line_m,prof.heavy_burst_m
    else: lm,bm=prof.light_line_m,prof.light_burst_m
    for k in range(K):
        out[k]=_friendly_risk(shipx[tr],shipy[tr],x[tr,k],y[tr,k],h[tr,k],friend_xy[tr],friend_h[tr],friend_alive[tr],lm,bm)
    return out


def init_state(n,K,attack_type,package_target_x,seed,ship=None,aa=None):
    ship=ship or ShipProfile(); aa=aa or AAProfile(); term=TERMINALS[attack_type.id]
    rng=np.random.default_rng((int(seed)*1000003+111011)%(2**63-1))
    hdg0=np.pi/2 if term.mission=='torpedo' else 0.0
    s={
      'ship':ship,'aa':aa,'term':term,'rng':rng,'n':n,'K':K,
      'shipx':np.full(n,float(package_target_x)), 'shipy':np.zeros(n),
      'shiphdg':np.full(n,hdg0), 'shiprate':np.zeros(n), 'ship_hdg0':np.full(n,hdg0),
      'shipx0':np.full(n,float(package_target_x)), 'shipy0':np.zeros(n),
      'turn_sign':np.where(rng.random(n)<.5,-1.0,1.0),'turn_clock':np.zeros(n),'turn_started':np.zeros(n,bool),
      'elapsed':0.0,
      'ht':np.full((n,aa.heavy_channels),-1,np.int16),'lt':np.full((n,aa.light_channels),-1,np.int16),
      'hdelay':np.zeros((n,aa.heavy_channels)),'ldelay':np.zeros((n,aa.light_channels)),
      'hq':np.zeros((n,aa.heavy_channels)),'lq':np.zeros((n,aa.light_channels)),
      'light_sector':np.linspace(-np.pi,np.pi,aa.light_channels,endpoint=False),
      'heavy_rounds':np.zeros(n),'light_rounds':np.zeros(n),'heavy_events':np.zeros(n,int),'light_hits':np.zeros(n,int),
      'jinks':np.zeros(n,int),'new_losses':np.zeros(n,int),'hswitch':np.zeros(n,int),'lswitch':np.zeros(n,int),
      'first_aa_time':np.full(n,np.nan),'first_turn_time':np.full(n,np.nan),
      'cap_heavy_overlap_s':np.zeros(n), 'cap_light_overlap_s':np.zeros(n),
      'escort_heavy_overlap_s':np.zeros(n), 'escort_light_overlap_s':np.zeros(n),
      'release_q':np.zeros((n,K)), 'ship_q':np.zeros((n,K)), 'released':np.zeros((n,K),bool),
      'ship_hdg_release':np.full((n,K),np.nan),'ship_rate_release':np.full((n,K),np.nan),'ship_x_release':np.full((n,K),np.nan),'ship_y_release':np.full((n,K),np.nan),'attack_hdg_release':np.full((n,K),np.nan),
      'heavy_withheld_rounds':np.zeros(n),'light_withheld_rounds':np.zeros(n),
      'heavy_hold_events':np.zeros(n,int),'light_hold_events':np.zeros(n,int),
      'heavy_discipline_switches':np.zeros(n,int),'light_discipline_switches':np.zeros(n,int),
      'heavy_friendly_risk_channel_s':np.zeros(n),'light_friendly_risk_channel_s':np.zeros(n),
      'heavy_risk_sum':np.zeros(n),'light_risk_sum':np.zeros(n),'heavy_risk_samples':np.zeros(n,int),'light_risk_samples':np.zeros(n,int),
      'last_step_shipx':np.zeros((1,n)),'last_step_shipy':np.zeros((1,n)),'last_step_shiphdg':np.zeros((1,n)),'last_step_shiprate':np.zeros((1,n)),
    }
    return s


def _interp(a0,a1,f):
    return a0+f*(a1-a0)


def advance(state,attack_type,effects,package_defense,pkgStates,pkgAlive,
            mem0,mem1, dynVY,dynVZ,dynH,pkgEvTimer,pkgLastEv,cyc,evp,
            cap0=None,cap1=None,cap_alt0=None,cap_alt1=None,cap_alive=None,
            esc0=None,esc1=None,esc_alt0=None,esc_alt1=None,esc_alive=None,
            dt=2.5,subdt=.5,aa_enabled=True,evasion_enabled=True,aa_strength=1.0,ship_turn_scale=1.0,ship_evasion_policy='auto',aa_fire_discipline='none'):
    """Advance ship motion + local AA over one fighter decision step.
    mem0/mem1 = tuple(x,y,h,hdg) for strike members at start/end of the step.
    Jink impulses and damage are written directly into package state arrays.
    """
    n=state['n'];K=state['K'];aa=state['aa'];ship=state['ship'];term=state['term'];rng=state['rng'];disc=_discipline_profile(aa_fire_discipline)
    nsub=max(1,int(round(dt/subdt))); sd=dt/nsub
    state['last_step_shipx']=np.zeros((nsub,n));state['last_step_shipy']=np.zeros((nsub,n));state['last_step_shiphdg']=np.zeros((nsub,n));state['last_step_shiprate']=np.zeros((nsub,n))
    prev_mis=np.stack([st['mission'] for st in pkgStates],1).copy()
    for si in range(nsub):
        f=(si+1)/nsub
        x=_interp(mem0[0],mem1[0],f); y=_interp(mem0[1],mem1[1],f); h=_interp(mem0[2],mem1[2],f)
        # wrapped heading interpolation
        dh=((mem1[3]-mem0[3]+np.pi)%(2*np.pi))-np.pi; hdg=(mem0[3]+f*dh+np.pi)%(2*np.pi)-np.pi
        mission=np.stack([st['mission'] for st in pkgStates],1);alive=(~mission)&pkgAlive
        dx=x-state['shipx'][:,None];dy=y-state['shipy'][:,None];rngm=np.sqrt(dx*dx+dy*dy)+1e-6;bear=np.arctan2(dy,dx)
        # Maneuver starts only once a mission-capable attacker penetrates the 6-km terminal corridor.
        for tr in range(n):
            li=np.where(alive[tr])[0]
            if not len(li): continue
            kk=li[np.argmin(rngm[tr,li])]; rr=float(rngm[tr,kk]); tb=float(bear[tr,kk])
            if rr<=term.start_range_m:
                if not state['turn_started'][tr]:
                    state['turn_started'][tr]=True; state['first_turn_time'][tr]=state['elapsed']+si*sd
                state['turn_clock'][tr]+=sd
            pol='none' if not evasion_enabled else ('torpedo' if term.mission=='torpedo' else 'dive') if ship_evasion_policy=='auto' else ship_evasion_policy
            if pol=='torpedo_bow':
                desired=float(tb)
            elif pol=='torpedo_stern':
                desired=float((tb+np.pi+np.pi)%(2*np.pi)-np.pi)
            else:
                desired=_desired_ship_heading(pol,term.mission,float(state['shiphdg'][tr]),tb,float(state['turn_sign'][tr]))
            if pol!='none' and state['turn_started'][tr] and state['turn_clock'][tr]>=ship.turn_delay_s:
                err=float(((desired-state['shiphdg'][tr]+np.pi)%(2*np.pi))-np.pi)
                lim=math.radians(ship.max_turn_rate_deg_s*ship_turn_scale)
                cmd=float(np.clip(err/max(ship.turn_tau_s,1e-3),-lim,lim))
            else: cmd=0.0
            accel=math.radians(ship.max_turn_rate_deg_s)*sd/max(ship.turn_tau_s,1.0)
            state['shiprate'][tr]+=float(np.clip(cmd-state['shiprate'][tr],-accel,accel))
            lim=math.radians(ship.max_turn_rate_deg_s*ship_turn_scale)
            state['shiprate'][tr]=float(np.clip(state['shiprate'][tr],-lim,lim))
        state['shiphdg']=(state['shiphdg']+state['shiprate']*sd+np.pi)%(2*np.pi)-np.pi
        # Coordinates are in the continuously-updated baseline intercept frame: the strike package
        # is assumed to lead the ship's steady pre-evasion motion.  Only maneuver displacement away
        # from that baseline appears here, so a non-evading ship remains at the nominal target point.
        sv=ship.speed_kn*.514444
        state['shipx']+=sv*(np.cos(state['shiphdg'])-np.cos(state['ship_hdg0']))*sd
        state['shipy']+=sv*(np.sin(state['shiphdg'])-np.sin(state['ship_hdg0']))*sd
        state['last_step_shipx'][si]=state['shipx'];state['last_step_shipy'][si]=state['shipy'];state['last_step_shiphdg'][si]=state['shiphdg'];state['last_step_shiprate'][si]=state['shiprate']
        # Overlap diagnostics and live friendly-air positions for fire-discipline checks.
        cap_pp=_interp(cap0,cap1,f) if cap0 is not None else None; cap_ah=_interp(cap_alt0,cap_alt1,f) if cap_alt0 is not None else None
        esc_pp=_interp(esc0,esc1,f) if esc0 is not None else None; esc_ah=_interp(esc_alt0,esc_alt1,f) if esc_alt0 is not None else None
        def overlap(pp,ah,eng,prefix):
            if pp is None or eng is None:return
            rr=np.sqrt((pp[:,:,0]-state['shipx'][:,None])**2+(pp[:,:,1]-state['shipy'][:,None])**2)
            state[prefix+'_heavy_overlap_s']+=((rr<=aa.heavy_max_range_m)&(ah<=aa.heavy_max_alt_m)&eng).sum(1)*sd
            state[prefix+'_light_overlap_s']+=((rr<=aa.light_max_range_m)&(ah<=aa.light_max_alt_m)&eng).sum(1)*sd
        overlap(cap_pp,cap_ah,cap_alive,'cap');overlap(esc_pp,esc_ah,esc_alive,'escort')
        if not aa_enabled: continue
        # Recompute relative geometry after ship motion this substep.
        dx=x-state['shipx'][:,None];dy=y-state['shipy'][:,None];rngm=np.sqrt(dx*dx+dy*dy)+1e-6;bear=np.arctan2(dy,dx)
        score=_target_score(rngm,h,alive,mission,term.mission)
        for tr in range(n):
            if np.any((rngm[tr]<=aa.heavy_max_range_m)&alive[tr]) and not np.isfinite(state['first_aa_time'][tr]): state['first_aa_time'][tr]=state['elapsed']+si*sd
            hrisk=_risk_vector(tr,x,y,h,state['shipx'],state['shipy'],cap_pp,cap_ah,cap_alive,disc,'heavy')
            lrisk=_risk_vector(tr,x,y,h,state['shipx'],state['shipy'],cap_pp,cap_ah,cap_alive,disc,'light')
            # heavy directors
            for c in range(aa.heavy_channels):
                cur=int(state['ht'][tr,c]);valid=cur>=0 and alive[tr,cur] and rngm[tr,cur]<=aa.heavy_max_range_m and h[tr,cur]<=aa.heavy_max_alt_m
                elig=np.where((score[tr]>-1e8)&(rngm[tr]<=aa.heavy_max_range_m)&(h[tr]<=aa.heavy_max_alt_m))[0]
                if len(elig):
                    raw=int(elig[np.argmax(score[tr,elig])])
                    if disc.id=='none':
                        cand=raw
                    else:
                        adj=score[tr,elig]-disc.target_penalty*hrisk[elig];cand=int(elig[np.argmax(adj)])
                        # A valid channel does not hunt continuously for tiny gains. It changes only when the
                        # present line is materially risky and another mission-capable target is distinctly safer.
                        if valid and cand!=cur and hrisk[cur]>.15 and hrisk[cand]+.10<hrisk[cur] and adj[np.argmax(adj)]>score[tr,cur]-disc.target_penalty*hrisk[cur]+.035:
                            valid=False; state['heavy_discipline_switches'][tr]+=1
                        elif (not valid) and cand!=raw and hrisk[raw]>hrisk[cand]+.08:
                            state['heavy_discipline_switches'][tr]+=1
                else: cand=-1
                if not valid:
                    new=cand
                    if new!=cur:
                        state['hswitch'][tr]+=int(cur>=0 and new>=0);state['ht'][tr,c]=new;state['hdelay'][tr,c]=aa.heavy_acquire_s if cur<0 else aa.heavy_switch_s;state['hq'][tr,c]=0
                t=int(state['ht'][tr,c])
                if t<0:continue
                if state['hdelay'][tr,c]>0:state['hdelay'][tr,c]=max(0,state['hdelay'][tr,c]-sd);continue
                rangefac=float(np.clip(1-rngm[tr,t]/aa.heavy_max_range_m,.18,1.0));jfac=.48 if pkgEvTimer[tr,t]>0 else 1.0
                turnfac=float(np.clip(1-.10*abs(math.degrees(state['shiprate'][tr]))/max(ship.max_turn_rate_deg_s,1e-3),.78,1.0))
                risk=float(hrisk[t]); state['heavy_risk_sum'][tr]+=risk; state['heavy_risk_samples'][tr]+=1; state['heavy_friendly_risk_channel_s'][tr]+=sd*float(risk>.05)
                desiredq=aa.heavy_track_base*rangefac**.25*jfac*turnfac*max(.15,1-disc.track_penalty*risk)
                state['hq'][tr,c]+=np.clip(desiredq-state['hq'][tr,c],-1,1)*min(1,sd/aa.heavy_track_tau_s)
                raw_rounds=int(rng.poisson(aa.heavy_barrels_per_channel*aa.heavy_rpm_per_barrel/60*sd))
                fire_scale=float(np.clip(1-disc.heavy_hold_strength*risk,0,1)); rounds=int(rng.binomial(raw_rounds,fire_scale)) if (disc.id!='none' and raw_rounds>0 and fire_scale<.999999) else raw_rounds
                state['heavy_withheld_rounds'][tr]+=raw_rounds-rounds; state['heavy_rounds'][tr]+=rounds
                if raw_rounds>0 and rounds==0 and risk>.05: state['heavy_hold_events'][tr]+=1
                if rounds<=0:continue
                pj=1-math.exp(-aa.heavy_pressure_per_round*rounds*max(.15,state['hq'][tr,c]))
                if pkgEvTimer[tr,t]==0 and rng.random()<pj:
                    side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));dynVY[tr,t]+=side*float(evp.get('lat_imp',0.0))*.92*sc;dynVZ[tr,t]+=rng.normal(0,float(evp.get('vert_imp',0.0))*.8);dynH[tr,t]=float(np.clip(dynH[tr,t]+math.radians(side*float(evp.get('hdg_imp_deg',0.0))*.9*sc),-math.radians(24),math.radians(24)));pkgEvTimer[tr,t]=max(int(pkgEvTimer[tr,t]),int(rng.integers(2,4)));pkgLastEv[tr,t]=cyc;state['jinks'][tr]+=1
                pe=min(.0029,aa.heavy_effective_event_p_shell*aa_strength*max(.05,state['hq'][tr,c]));ne=int(rng.binomial(rounds,pe));state['heavy_events'][tr]+=ne
                if ne and not pkgStates[t]['mission'][tr]:
                    nf=int(ne+rng.poisson(1.15*ne));asp=int(_aspect_from_ship(np.array([hdg[tr,t]]),np.array([bear[tr,t]]))[0]);
                    base.apply_hits(pkgStates[t],package_defense,AA127FRAG,effects,np.array([tr]),np.array([nf]),np.array([asp],np.int8),np.array([250.0]),rng)
                    if pkgStates[t]['mission'][tr]: pkgAlive[tr,t]=False;alive[tr,t]=False
            # 25mm groups
            for c in range(aa.light_channels):
                cur=int(state['lt'][tr,c]);
                def relsec(tt): return abs(float(((bear[tr,tt]-state['shiphdg'][tr]-state['light_sector'][c]+np.pi)%(2*np.pi))-np.pi))
                valid=cur>=0 and alive[tr,cur] and rngm[tr,cur]<=aa.light_max_range_m and h[tr,cur]<=aa.light_max_alt_m and relsec(cur)<math.radians(78)
                elig=np.where((score[tr]>-1e8)&(rngm[tr]<=aa.light_max_range_m)&(h[tr]<=aa.light_max_alt_m))[0];elig=np.array([tt for tt in elig if relsec(int(tt))<math.radians(78)],int)
                if len(elig):
                    raw=int(elig[np.argmax(score[tr,elig])])
                    if disc.id=='none':
                        cand=raw
                    else:
                        adj=score[tr,elig]-disc.target_penalty*1.15*lrisk[elig];cand=int(elig[np.argmax(adj)])
                        if valid and cand!=cur and lrisk[cur]>.12 and lrisk[cand]+.08<lrisk[cur] and adj[np.argmax(adj)]>score[tr,cur]-disc.target_penalty*1.15*lrisk[cur]+.025:
                            valid=False;state['light_discipline_switches'][tr]+=1
                        elif (not valid) and cand!=raw and lrisk[raw]>lrisk[cand]+.06:
                            state['light_discipline_switches'][tr]+=1
                else:cand=-1
                if not valid:
                    new=cand
                    if new!=cur:
                        state['lswitch'][tr]+=int(cur>=0 and new>=0);state['lt'][tr,c]=new;state['ldelay'][tr,c]=aa.light_acquire_s if cur<0 else aa.light_switch_s;state['lq'][tr,c]=0
                t=int(state['lt'][tr,c])
                if t<0:continue
                if state['ldelay'][tr,c]>0:state['ldelay'][tr,c]=max(0,state['ldelay'][tr,c]-sd);continue
                rangefac=float(np.clip(1-rngm[tr,t]/aa.light_max_range_m,.10,1.0));jfac=.55 if pkgEvTimer[tr,t]>0 else 1.0;risk=float(lrisk[t]);state['light_risk_sum'][tr]+=risk;state['light_risk_samples'][tr]+=1;state['light_friendly_risk_channel_s'][tr]+=sd*float(risk>.05);desiredq=aa.light_track_base*rangefac**.32*jfac*max(.12,1-disc.track_penalty*risk)
                state['lq'][tr,c]+=np.clip(desiredq-state['lq'][tr,c],-1,1)*min(1,sd/aa.light_track_tau_s)
                raw_rounds=int(rng.poisson(aa.light_barrels_per_channel*aa.light_rpm_per_barrel/60*sd));fire_scale=float(np.clip(1-disc.light_hold_strength*risk,0,1));rounds=int(rng.binomial(raw_rounds,fire_scale)) if (disc.id!='none' and raw_rounds>0 and fire_scale<.999999) else raw_rounds;state['light_withheld_rounds'][tr]+=raw_rounds-rounds;state['light_rounds'][tr]+=rounds
                if raw_rounds>0 and rounds==0 and risk>.05:state['light_hold_events'][tr]+=1
                if rounds<=0:continue
                pj=1-math.exp(-aa.light_pressure_per_round*rounds*max(.12,state['lq'][tr,c]))
                if pkgEvTimer[tr,t]==0 and rng.random()<pj:
                    side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));dynVY[tr,t]+=side*float(evp.get('lat_imp',0.0))*.85*sc;dynVZ[tr,t]+=rng.normal(0,float(evp.get('vert_imp',0.0))*.72);dynH[tr,t]=float(np.clip(dynH[tr,t]+math.radians(side*float(evp.get('hdg_imp_deg',0.0))*.82*sc),-math.radians(24),math.radians(24)));pkgEvTimer[tr,t]=max(int(pkgEvTimer[tr,t]),int(rng.integers(2,4)));pkgLastEv[tr,t]=cyc;state['jinks'][tr]+=1
                ph=aa.light_direct_hit_p_round*aa_strength*max(.04,state['lq'][tr,c])*rangefac**.35;nh=int(rng.binomial(rounds,min(.01,ph)));state['light_hits'][tr]+=nh
                if nh and not pkgStates[t]['mission'][tr]:
                    asp=int(_aspect_from_ship(np.array([hdg[tr,t]]),np.array([bear[tr,t]]))[0]);base.apply_hits(pkgStates[t],package_defense,AA25,effects,np.array([tr]),np.array([nh]),np.array([asp],np.int8),np.array([float(rngm[tr,t])]),rng)
                    if pkgStates[t]['mission'][tr]: pkgAlive[tr,t]=False;alive[tr,t]=False
        # immediate loss feedback within AA substep
        now=np.stack([st['mission'] for st in pkgStates],1);new=now&(~prev_mis);state['new_losses']+=new.sum(1);pkgAlive[new]=False;prev_mis=now.copy()
    state['elapsed']+=dt


def capture_release(state,attack_type,pkgStates,dynX,dynY,dynZ,dynH,pkgLastEv,cyc,dt,evasion_enabled=True,mask=None):
    n=state['n'];K=state['K'];term=state['term'];ship=state['ship']
    if mask is None: mask=np.ones(n,bool)
    mission=np.stack([st['mission'] for st in pkgStates],1); comp=_delivery_component_quality(attack_type,pkgStates)
    rpar=__import__('strike_response_v103').RESP[attack_type.id]
    for tr in np.where(mask)[0]:
        for k in range(K):
            if mission[tr,k]:continue
            hddeg=abs(math.degrees(float(dynH[tr,k])));track=math.exp(-.10*(abs(float(dynX[tr,k]))/420)**2-.40*(hddeg/rpar['ready_hdg'])**2-.27*(abs(float(dynY[tr,k]))/rpar['ready_y'])**2-.20*(abs(float(dynZ[tr,k]))/rpar['ready_z'])**2)
            since=max(0.0,(cyc-int(pkgLastEv[tr,k]))*dt);setup=min(1.0,since/max(term.setup_seconds,1e-6));dq=float(np.clip(track*setup*comp[tr,k],0,1))
            attack_hdg=float((math.pi+dynH[tr,k]+math.pi)%(2*math.pi)-math.pi)
            if evasion_enabled:sq=float(_ship_solution_quality(ship,term,float(state['shiphdg'][tr]),float(state['shiprate'][tr]),attack_hdg))
            else:sq=float(_ship_solution_quality(ship,term,float(state['ship_hdg0'][tr]),0.0,attack_hdg))
            state['release_q'][tr,k]=dq;state['ship_q'][tr,k]=sq;state['released'][tr,k]=True;state['ship_hdg_release'][tr,k]=state['shiphdg'][tr];state['ship_rate_release'][tr,k]=state['shiprate'][tr];state['ship_x_release'][tr,k]=state['shipx'][tr];state['ship_y_release'][tr,k]=state['shipy'][tr];state['attack_hdg_release'][tr,k]=attack_hdg


def summary(state,pkgStates):
    mission=np.stack([st['mission'] for st in pkgStates],1);opp=state['release_q']*state['ship_q'];ship=state['ship'];elapsed=state['elapsed']
    base_x=state['shipx0'];base_y=state['shipy0']
    return {
      'global_ship_aa_model':'v0.11.5','global_mean_AA_heavy_rounds':float(state['heavy_rounds'].mean()),'global_mean_AA_25mm_rounds':float(state['light_rounds'].mean()),
      'global_mean_AA_heavy_effective_events':float(state['heavy_events'].mean()),'global_mean_AA_25mm_direct_hits':float(state['light_hits'].mean()),'global_mean_AA_jink_events':float(state['jinks'].mean()),'global_mean_AA_new_mission_losses':float(state['new_losses'].mean()),
      'global_mean_release_count':float(state['released'].sum(1).mean()),'global_mean_delivery_quality_at_release':float(state['release_q'].sum(1).mean()),'global_mean_ship_solution_quality_equivalent':float(state['ship_q'].sum(1).mean()),'global_mean_release_opportunity_equivalent':float(opp.sum(1).mean()),
      'global_mean_ship_heading_change_deg':float(np.mean(np.abs(np.rad2deg((state['shiphdg']-state['ship_hdg0']+np.pi)%(2*np.pi)-np.pi)))),
      'global_mean_ship_maneuver_displacement_m':float(np.mean(np.hypot(state['shipx']-base_x,state['shipy']-base_y))),
      'global_mean_first_AA_time_s':float(np.nanmean(state['first_aa_time'])) if np.isfinite(state['first_aa_time']).any() else math.nan,
      'global_mean_first_ship_turn_time_s':float(np.nanmean(state['first_turn_time'])) if np.isfinite(state['first_turn_time']).any() else math.nan,
      'global_CAP_heavy_overlap_fighter_s':float(state['cap_heavy_overlap_s'].mean()),'global_CAP_light_overlap_fighter_s':float(state['cap_light_overlap_s'].mean()),
      'global_escort_heavy_overlap_fighter_s':float(state['escort_heavy_overlap_s'].mean()),'global_escort_light_overlap_fighter_s':float(state['escort_light_overlap_s'].mean()),
      'global_heavy_channel_switches':float(state['hswitch'].mean()),'global_light_channel_switches':float(state['lswitch'].mean()),
      'global_heavy_withheld_rounds':float(state['heavy_withheld_rounds'].mean()),'global_light_withheld_rounds':float(state['light_withheld_rounds'].mean()),
      'global_heavy_hold_events':float(state['heavy_hold_events'].mean()),'global_light_hold_events':float(state['light_hold_events'].mean()),
      'global_heavy_discipline_switches':float(state['heavy_discipline_switches'].mean()),'global_light_discipline_switches':float(state['light_discipline_switches'].mean()),
      'global_heavy_friendly_risk_channel_s':float(state['heavy_friendly_risk_channel_s'].mean()),'global_light_friendly_risk_channel_s':float(state['light_friendly_risk_channel_s'].mean()),
      'global_heavy_mean_friendly_risk':float(state['heavy_risk_sum'].sum()/max(1,state['heavy_risk_samples'].sum())),'global_light_mean_friendly_risk':float(state['light_risk_sum'].sum()/max(1,state['light_risk_samples'].sum())),
    }
