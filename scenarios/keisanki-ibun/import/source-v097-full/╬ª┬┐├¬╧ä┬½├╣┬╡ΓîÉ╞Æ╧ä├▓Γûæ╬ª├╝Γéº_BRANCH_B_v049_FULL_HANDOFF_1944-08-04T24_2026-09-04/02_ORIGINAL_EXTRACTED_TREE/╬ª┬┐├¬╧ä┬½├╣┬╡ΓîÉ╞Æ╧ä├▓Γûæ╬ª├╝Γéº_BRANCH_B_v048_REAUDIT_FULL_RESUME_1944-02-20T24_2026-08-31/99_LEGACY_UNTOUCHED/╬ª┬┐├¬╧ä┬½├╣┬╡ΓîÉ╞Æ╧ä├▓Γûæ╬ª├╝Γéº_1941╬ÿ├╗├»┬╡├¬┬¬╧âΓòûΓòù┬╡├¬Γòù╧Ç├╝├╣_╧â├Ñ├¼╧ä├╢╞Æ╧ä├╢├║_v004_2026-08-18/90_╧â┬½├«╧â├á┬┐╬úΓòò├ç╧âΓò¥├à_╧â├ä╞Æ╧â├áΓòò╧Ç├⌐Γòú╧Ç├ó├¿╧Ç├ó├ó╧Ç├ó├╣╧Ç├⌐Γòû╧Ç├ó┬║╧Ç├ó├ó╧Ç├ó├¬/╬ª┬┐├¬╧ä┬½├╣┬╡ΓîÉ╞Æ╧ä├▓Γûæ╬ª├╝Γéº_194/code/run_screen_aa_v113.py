#!/usr/bin/env python3
from pathlib import Path
import sys,csv,json,concurrent.futures as cf
import numpy as np
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v113 as v
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP
US=['US02','US04','US07','US09','US13','US14']
SC=['none','sparse','center','dense']

def cfg(p,d,target):
    if target=='TBF1C':
        pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
        kw=dict(N=16,active_A=16,active_B=8,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(v._default_centered_y(8))+list(v._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500)
    elif target=='SBD5':
        pa=p['JP06'];da=d['JP06'];kw=dict(N=8,active_A=8,active_B=8,hA0=6000,hB0=5100,iasA0=400,iasB0=400,A_initial_x_m=-3100,package_alt_m=5000,package_speed_kmh=300,package_start_x=8000,package_target_x=-4500,package_vector_range_m=10500,package_terminal_profile='dive',package_terminal_alt_m=760,package_terminal_speed_kmh=450,package_transition_start_m=1800,package_transition_end_m=0)
    else:
        pa=p['JP06'];da=d['JP06'];kw=dict(N=8,active_A=8,active_B=8,hA0=5600,hB0=4800,iasA0=400,iasB0=400,A_initial_x_m=-3100,package_alt_m=4600,package_speed_kmh=310,package_start_x=8000,package_target_x=-4500,package_vector_range_m=10500,package_terminal_profile='dive',package_terminal_alt_m=760,package_terminal_speed_kmh=460,package_transition_start_m=1800,package_transition_end_m=0)
    return pa,da,kw

def worker(job):
    target,us,sc,ntr=job;p,w,e,d=v.load_all(R);at=load_attack_types(R)[target];pa,da,kw=cfg(p,d,target)
    seed=11330000+['TBF1C','SBD5','SB2C1C'].index(target)*100000+US.index(us)*5000+ntr
    m=v.simulate_escort_cap(pa,p[us],da,d[us],w,e,ntr=ntr,seed=seed,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=False,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP[target],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=True,global_aa_fire_discipline='center',global_screen_aa=(sc!='none'),global_screen_profile=('center' if sc=='none' else sc),global_screen_fire_discipline='center',**kw)
    keys=['package_attack_passes','package_online_clean_bursts','package_online_mission_losses','A_mean_losses','B_mean_losses','global_mean_AA_heavy_rounds','global_mean_AA_25mm_rounds','global_mean_AA_jink_events','global_mean_AA_new_mission_losses','global_mean_release_opportunity_equivalent','global_mean_delivery_quality_at_release','global_mean_ship_solution_quality_equivalent','global_heavy_withheld_rounds','global_light_withheld_rounds','screen_nodes','screen_mean_heavy_rounds','screen_mean_25mm_rounds','screen_mean_jink_events','screen_mean_new_mission_losses','screen_mean_heavy_withheld_rounds','screen_mean_light_withheld_rounds','screen_mean_heavy_discipline_switches','screen_mean_light_discipline_switches','screen_mean_heavy_friendly_risk','screen_mean_light_friendly_risk','screen_mean_first_fire_time_s']
    return {'target':target,'US':us,'screen':sc,'ntr':ntr,**{k:m.get(k,0.0) for k in keys}}

def write(path,rows):
    with open(path,'w',newline='',encoding='utf-8-sig') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def main():
    import argparse;ap=argparse.ArgumentParser();ap.add_argument('--ntr',type=int,default=8);ap.add_argument('--targets',default='TBF1C');ap.add_argument('--screens',default='none,sparse,center,dense');a=ap.parse_args()
    targets=a.targets.split(',');screens=a.screens.split(',');jobs=[(t,u,s,a.ntr) for t in targets for u in US for s in screens]
    with cf.ProcessPoolExecutor(max_workers=6) as ex:rows=list(ex.map(worker,jobs))
    out=R.parent/'results_current';tag='_'.join(targets);write(out/f'screen_aa_{tag}_v113.csv',rows)
    ag=[]
    for t in targets:
      for sc in screens:
        rr=[r for r in rows if r['target']==t and r['screen']==sc];x={'target':t,'screen':sc,'US':'lateUS6_mean','n_profiles':len(rr),'ntr_per_profile':a.ntr}
        for k,v0 in rr[0].items():
            if k in x or k in ('target','screen','US','ntr'):continue
            if isinstance(v0,(int,float,np.integer,np.floating)):x[k]=float(np.nanmean([r[k] for r in rr]))
        ag.append(x)
    write(out/f'screen_aa_{tag}_lateUS6_summary_v113.csv',ag);print(json.dumps(ag,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
