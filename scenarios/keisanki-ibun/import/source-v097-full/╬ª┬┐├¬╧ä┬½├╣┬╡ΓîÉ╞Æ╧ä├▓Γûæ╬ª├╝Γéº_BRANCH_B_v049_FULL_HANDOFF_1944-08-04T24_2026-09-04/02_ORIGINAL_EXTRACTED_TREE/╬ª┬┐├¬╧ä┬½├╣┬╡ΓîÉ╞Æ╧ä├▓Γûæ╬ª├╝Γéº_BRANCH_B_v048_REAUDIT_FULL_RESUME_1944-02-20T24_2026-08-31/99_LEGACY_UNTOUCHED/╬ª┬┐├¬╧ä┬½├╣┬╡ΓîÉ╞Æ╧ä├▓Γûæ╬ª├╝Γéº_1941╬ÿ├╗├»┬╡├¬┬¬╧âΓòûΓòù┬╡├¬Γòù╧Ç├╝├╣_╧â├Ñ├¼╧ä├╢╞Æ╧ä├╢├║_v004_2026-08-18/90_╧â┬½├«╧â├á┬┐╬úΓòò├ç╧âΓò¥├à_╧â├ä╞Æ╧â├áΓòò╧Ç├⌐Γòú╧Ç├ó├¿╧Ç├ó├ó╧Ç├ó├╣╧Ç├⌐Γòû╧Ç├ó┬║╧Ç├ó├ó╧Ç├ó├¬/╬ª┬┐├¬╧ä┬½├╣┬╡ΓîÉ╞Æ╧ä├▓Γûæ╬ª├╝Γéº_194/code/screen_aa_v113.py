#!/usr/bin/env python3
from __future__ import annotations
import math
from dataclasses import dataclass
import numpy as np
import air_microcombat_v04 as one
base=one.base
from ship_aa_v110 import AA25, AA127FRAG, _target_score, _aspect_from_ship
from global_ship_aa_v113 import _discipline_profile, _friendly_risk

@dataclass(frozen=True)
class ScreenProfile:
    id: str
    node_offsets_m: tuple[tuple[float,float], ...]
    heavy_channels_per_node: int = 1
    heavy_barrels_per_channel: int = 2
    heavy_rpm_per_barrel: float = 8.0
    heavy_max_range_m: float = 8000.0
    heavy_max_alt_m: float = 3000.0
    heavy_acquire_s: float = 1.8
    heavy_switch_s: float = 1.3
    heavy_track_tau_s: float = 2.0
    heavy_track_base: float = .72
    heavy_effective_event_p_shell: float = .0010
    heavy_pressure_per_round: float = .030
    light_channels_per_node: int = 2
    light_barrels_per_channel: int = 3
    light_rpm_per_barrel: float = 110.0
    light_max_range_m: float = 2000.0
    light_max_alt_m: float = 1000.0
    light_acquire_s: float = .85
    light_switch_s: float = .50
    light_track_tau_s: float = .85
    light_track_base: float = .52
    light_direct_hit_p_round: float = .00048
    light_pressure_per_round: float = .007
    source_grade: str = 'B-prior distributed escort-screen geometry; local AA effect carriers inherited from v0.11.0'


def _ring(n:int,r:float,phase:float=0.0):
    return tuple((r*math.cos(phase+2*math.pi*i/n), r*math.sin(phase+2*math.pi*i/n)) for i in range(n))

SCREEN_PROFILES={
    'none': ScreenProfile('none',()),
    # The profiles are architecture/sensitivity cases, not claims that a specific historical force always had this exact ring.
    'sparse': ScreenProfile('sparse',((1800.0,1900.0),(1800.0,-1900.0))),
    'center': ScreenProfile('center',((2500.0,0.0),(0.0,2500.0),(0.0,-2500.0),(-2500.0,0.0))),
    'dense': ScreenProfile('dense',_ring(6,2800.0,0.0)),
}

def get_profile(p):
    if p is None: return SCREEN_PROFILES['none']
    if isinstance(p,ScreenProfile): return p
    if isinstance(p,str):
        if p not in SCREEN_PROFILES: raise ValueError(f'unknown screen profile {p}')
        return SCREEN_PROFILES[p]
    if isinstance(p,dict): return ScreenProfile(**p)
    raise TypeError('screen profile must be name/dict/ScreenProfile')


def init_state(n,K,package_target_x,seed,profile='center'):
    p=get_profile(profile); M=len(p.node_offsets_m); hc=max(1,p.heavy_channels_per_node); lc=max(1,p.light_channels_per_node)
    rng=np.random.default_rng((int(seed)*1000003+113031)%(2**63-1))
    return {
      'profile':p,'n':n,'K':K,'M':M,'rng':rng,'elapsed':0.0,
      'node_x':np.array([package_target_x+o[0] for o in p.node_offsets_m],float),
      'node_y':np.array([o[1] for o in p.node_offsets_m],float),
      'ht':np.full((n,M,hc),-1,np.int16),'lt':np.full((n,M,lc),-1,np.int16),
      'hdelay':np.zeros((n,M,hc)),'ldelay':np.zeros((n,M,lc)),'hq':np.zeros((n,M,hc)),'lq':np.zeros((n,M,lc)),
      'light_sector':np.linspace(-np.pi,np.pi,lc,endpoint=False),
      'heavy_rounds':np.zeros(n),'light_rounds':np.zeros(n),'heavy_events':np.zeros(n,int),'light_hits':np.zeros(n,int),
      'jinks':np.zeros(n,int),'new_losses':np.zeros(n,int),'hswitch':np.zeros(n,int),'lswitch':np.zeros(n,int),
      'heavy_withheld_rounds':np.zeros(n),'light_withheld_rounds':np.zeros(n),'heavy_hold_events':np.zeros(n,int),'light_hold_events':np.zeros(n,int),
      'heavy_discipline_switches':np.zeros(n,int),'light_discipline_switches':np.zeros(n,int),
      'heavy_risk_sum':np.zeros(n),'light_risk_sum':np.zeros(n),'heavy_risk_samples':np.zeros(n,int),'light_risk_samples':np.zeros(n,int),
      'first_fire_time':np.full(n,np.nan),
    }


def _interp(a0,a1,f): return a0+f*(a1-a0)


def _risk_for_node_target(nx,ny,tx,ty,th,friend_xy,friend_h,friend_alive,disc,kind):
    if disc.id=='none': return 0.0
    if kind=='heavy': lm,bm=disc.heavy_line_m,disc.heavy_burst_m
    else: lm,bm=disc.light_line_m,disc.light_burst_m
    return _friendly_risk(nx,ny,tx,ty,th,friend_xy,friend_h,friend_alive,lm,bm)


def advance(state,attack_type,effects,package_defense,pkgStates,pkgAlive,
            mem0,mem1,dynVY,dynVZ,dynH,pkgEvTimer,pkgLastEv,cyc,evp,
            cap0=None,cap1=None,cap_alt0=None,cap_alt1=None,cap_alive=None,
            dt=2.5,subdt=.5,aa_strength=1.0,aa_fire_discipline='center'):
    p=state['profile'];
    if state['M']==0: state['elapsed']+=dt; return
    n=state['n'];K=state['K'];rng=state['rng'];disc=_discipline_profile(aa_fire_discipline)
    nsub=max(1,int(round(dt/subdt))); sd=dt/nsub
    prev=np.stack([st['mission'] for st in pkgStates],1).copy()
    for si in range(nsub):
        f=(si+1)/nsub
        x=_interp(mem0[0],mem1[0],f);y=_interp(mem0[1],mem1[1],f);h=_interp(mem0[2],mem1[2],f)
        dh=((mem1[3]-mem0[3]+np.pi)%(2*np.pi))-np.pi;hdg=(mem0[3]+f*dh+np.pi)%(2*np.pi)-np.pi
        mission=np.stack([st['mission'] for st in pkgStates],1);alive=(~mission)&pkgAlive
        cap_pp=_interp(cap0,cap1,f) if cap0 is not None else None;cap_h=_interp(cap_alt0,cap_alt1,f) if cap_alt0 is not None else None
        for m in range(state['M']):
            nx=float(state['node_x'][m]);ny=float(state['node_y'][m])
            dx=x-nx;dy=y-ny;rngm=np.sqrt(dx*dx+dy*dy)+1e-6;bear=np.arctan2(dy,dx)
            score=_target_score(rngm,h,alive,mission,attack_type.id.startswith('TBF') and 'torpedo' or 'dive')
            for tr in range(n):
                friend_xy=cap_pp[tr] if cap_pp is not None else None;friend_h=cap_h[tr] if cap_h is not None else None;friend_alive=cap_alive[tr] if cap_alive is not None else None
                # heavy channels
                elig_h=np.where((score[tr]>-1e8)&(rngm[tr]<=p.heavy_max_range_m)&(h[tr]<=p.heavy_max_alt_m))[0]
                hrisk=np.zeros(K,float)
                if len(elig_h) and disc.id!='none':
                    for t in elig_h: hrisk[t]=_risk_for_node_target(nx,ny,x[tr,t],y[tr,t],h[tr,t],friend_xy,friend_h,friend_alive,disc,'heavy')
                for c in range(p.heavy_channels_per_node):
                    cur=int(state['ht'][tr,m,c]);valid=cur>=0 and alive[tr,cur] and rngm[tr,cur]<=p.heavy_max_range_m and h[tr,cur]<=p.heavy_max_alt_m
                    cand=-1
                    if len(elig_h):
                        raw=int(elig_h[np.argmax(score[tr,elig_h])])
                        if disc.id=='none':cand=raw
                        else:
                            adj=score[tr,elig_h]-disc.target_penalty*hrisk[elig_h];cand=int(elig_h[np.argmax(adj)])
                            if valid and cand!=cur and hrisk[cur]>.15 and hrisk[cand]+.10<hrisk[cur]:
                                valid=False;state['heavy_discipline_switches'][tr]+=1
                    if not valid:
                        new=cand
                        if new!=cur:
                            state['hswitch'][tr]+=int(cur>=0 and new>=0);state['ht'][tr,m,c]=new;state['hdelay'][tr,m,c]=p.heavy_acquire_s if cur<0 else p.heavy_switch_s;state['hq'][tr,m,c]=0
                    t=int(state['ht'][tr,m,c]);
                    if t<0:continue
                    if state['hdelay'][tr,m,c]>0:state['hdelay'][tr,m,c]=max(0,state['hdelay'][tr,m,c]-sd);continue
                    rangefac=float(np.clip(1-rngm[tr,t]/p.heavy_max_range_m,.18,1.0));jfac=.48 if pkgEvTimer[tr,t]>0 else 1.0;risk=float(hrisk[t]);state['heavy_risk_sum'][tr]+=risk;state['heavy_risk_samples'][tr]+=1
                    desiredq=p.heavy_track_base*rangefac**.25*jfac*max(.15,1-disc.track_penalty*risk)
                    state['hq'][tr,m,c]+=np.clip(desiredq-state['hq'][tr,m,c],-1,1)*min(1,sd/p.heavy_track_tau_s)
                    raw_rounds=int(rng.poisson(p.heavy_barrels_per_channel*p.heavy_rpm_per_barrel/60*sd));fire_scale=float(np.clip(1-disc.heavy_hold_strength*risk,0,1));rounds=int(rng.binomial(raw_rounds,fire_scale)) if disc.id!='none' and raw_rounds>0 and fire_scale<.999999 else raw_rounds
                    state['heavy_withheld_rounds'][tr]+=raw_rounds-rounds;state['heavy_rounds'][tr]+=rounds
                    if raw_rounds>0 and rounds==0 and risk>.05:state['heavy_hold_events'][tr]+=1
                    if rounds<=0:continue
                    if not np.isfinite(state['first_fire_time'][tr]):state['first_fire_time'][tr]=state['elapsed']+si*sd
                    pj=1-math.exp(-p.heavy_pressure_per_round*rounds*max(.15,state['hq'][tr,m,c]))
                    if pkgEvTimer[tr,t]==0 and rng.random()<pj:
                        side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));dynVY[tr,t]+=side*float(evp.get('lat_imp',0.0))*.92*sc;dynVZ[tr,t]+=rng.normal(0,float(evp.get('vert_imp',0.0))*.8);dynH[tr,t]=float(np.clip(dynH[tr,t]+math.radians(side*float(evp.get('hdg_imp_deg',0.0))*.9*sc),-math.radians(24),math.radians(24)));pkgEvTimer[tr,t]=max(int(pkgEvTimer[tr,t]),int(rng.integers(2,4)));pkgLastEv[tr,t]=cyc;state['jinks'][tr]+=1
                    pe=min(.0029,p.heavy_effective_event_p_shell*aa_strength*max(.05,state['hq'][tr,m,c]));ne=int(rng.binomial(rounds,pe));state['heavy_events'][tr]+=ne
                    if ne and not pkgStates[t]['mission'][tr]:
                        nf=int(ne+rng.poisson(1.15*ne));asp=int(_aspect_from_ship(np.array([hdg[tr,t]]),np.array([bear[tr,t]]))[0]);base.apply_hits(pkgStates[t],package_defense,AA127FRAG,effects,np.array([tr]),np.array([nf]),np.array([asp],np.int8),np.array([250.0]),rng)
                        if pkgStates[t]['mission'][tr]:pkgAlive[tr,t]=False;alive[tr,t]=False
                # light channels; sectors are fixed around the escort node because own maneuver is not represented.
                elig0=np.where((score[tr]>-1e8)&(rngm[tr]<=p.light_max_range_m)&(h[tr]<=p.light_max_alt_m))[0]
                for c in range(p.light_channels_per_node):
                    center=float(state['light_sector'][c]);
                    def relsec(tt):return abs(float(((bear[tr,tt]-center+np.pi)%(2*np.pi))-np.pi))
                    elig=np.array([tt for tt in elig0 if relsec(int(tt))<math.radians(95)],int)
                    lrisk=np.zeros(K,float)
                    if len(elig) and disc.id!='none':
                        for t0 in elig:lrisk[t0]=_risk_for_node_target(nx,ny,x[tr,t0],y[tr,t0],h[tr,t0],friend_xy,friend_h,friend_alive,disc,'light')
                    cur=int(state['lt'][tr,m,c]);valid=cur>=0 and alive[tr,cur] and rngm[tr,cur]<=p.light_max_range_m and h[tr,cur]<=p.light_max_alt_m and relsec(cur)<math.radians(95)
                    cand=-1
                    if len(elig):
                        raw=int(elig[np.argmax(score[tr,elig])]);cand=raw if disc.id=='none' else int(elig[np.argmax(score[tr,elig]-disc.target_penalty*1.15*lrisk[elig])])
                        if valid and cand!=cur and lrisk[cur]>.12 and lrisk[cand]+.08<lrisk[cur]:valid=False;state['light_discipline_switches'][tr]+=1
                    if not valid:
                        new=cand
                        if new!=cur:state['lswitch'][tr]+=int(cur>=0 and new>=0);state['lt'][tr,m,c]=new;state['ldelay'][tr,m,c]=p.light_acquire_s if cur<0 else p.light_switch_s;state['lq'][tr,m,c]=0
                    t=int(state['lt'][tr,m,c]);
                    if t<0:continue
                    if state['ldelay'][tr,m,c]>0:state['ldelay'][tr,m,c]=max(0,state['ldelay'][tr,m,c]-sd);continue
                    rangefac=float(np.clip(1-rngm[tr,t]/p.light_max_range_m,.10,1.0));jfac=.55 if pkgEvTimer[tr,t]>0 else 1.0;risk=float(lrisk[t]);state['light_risk_sum'][tr]+=risk;state['light_risk_samples'][tr]+=1;desiredq=p.light_track_base*rangefac**.32*jfac*max(.12,1-disc.track_penalty*risk)
                    state['lq'][tr,m,c]+=np.clip(desiredq-state['lq'][tr,m,c],-1,1)*min(1,sd/p.light_track_tau_s)
                    raw_rounds=int(rng.poisson(p.light_barrels_per_channel*p.light_rpm_per_barrel/60*sd));fire_scale=float(np.clip(1-disc.light_hold_strength*risk,0,1));rounds=int(rng.binomial(raw_rounds,fire_scale)) if disc.id!='none' and raw_rounds>0 and fire_scale<.999999 else raw_rounds
                    state['light_withheld_rounds'][tr]+=raw_rounds-rounds;state['light_rounds'][tr]+=rounds
                    if raw_rounds>0 and rounds==0 and risk>.05:state['light_hold_events'][tr]+=1
                    if rounds<=0:continue
                    if not np.isfinite(state['first_fire_time'][tr]):state['first_fire_time'][tr]=state['elapsed']+si*sd
                    pj=1-math.exp(-p.light_pressure_per_round*rounds*max(.12,state['lq'][tr,m,c]))
                    if pkgEvTimer[tr,t]==0 and rng.random()<pj:
                        side=-1 if rng.random()<.5 else 1;sc=float(rng.uniform(.78,1.22));dynVY[tr,t]+=side*float(evp.get('lat_imp',0.0))*.85*sc;dynVZ[tr,t]+=rng.normal(0,float(evp.get('vert_imp',0.0))*.72);dynH[tr,t]=float(np.clip(dynH[tr,t]+math.radians(side*float(evp.get('hdg_imp_deg',0.0))*.82*sc),-math.radians(24),math.radians(24)));pkgEvTimer[tr,t]=max(int(pkgEvTimer[tr,t]),int(rng.integers(2,4)));pkgLastEv[tr,t]=cyc;state['jinks'][tr]+=1
                    ph=p.light_direct_hit_p_round*aa_strength*max(.04,state['lq'][tr,m,c])*rangefac**.35;nh=int(rng.binomial(rounds,min(.01,ph)));state['light_hits'][tr]+=nh
                    if nh and not pkgStates[t]['mission'][tr]:
                        asp=int(_aspect_from_ship(np.array([hdg[tr,t]]),np.array([bear[tr,t]]))[0]);base.apply_hits(pkgStates[t],package_defense,AA25,effects,np.array([tr]),np.array([nh]),np.array([asp],np.int8),np.array([float(rngm[tr,t])]),rng)
                        if pkgStates[t]['mission'][tr]:pkgAlive[tr,t]=False;alive[tr,t]=False
        now=np.stack([st['mission'] for st in pkgStates],1);new=now&(~prev);state['new_losses']+=new.sum(1);pkgAlive[new]=False;prev=now.copy()
    state['elapsed']+=dt


def summary(state):
    p=state['profile']
    return {
      'screen_aa_model':'v0.11.3','screen_profile':p.id,'screen_nodes':state['M'],
      'screen_mean_heavy_rounds':float(state['heavy_rounds'].mean()),'screen_mean_25mm_rounds':float(state['light_rounds'].mean()),
      'screen_mean_heavy_effective_events':float(state['heavy_events'].mean()),'screen_mean_25mm_direct_hits':float(state['light_hits'].mean()),
      'screen_mean_jink_events':float(state['jinks'].mean()),'screen_mean_new_mission_losses':float(state['new_losses'].mean()),
      'screen_mean_heavy_withheld_rounds':float(state['heavy_withheld_rounds'].mean()),'screen_mean_light_withheld_rounds':float(state['light_withheld_rounds'].mean()),
      'screen_mean_heavy_hold_events':float(state['heavy_hold_events'].mean()),'screen_mean_light_hold_events':float(state['light_hold_events'].mean()),
      'screen_mean_heavy_discipline_switches':float(state['heavy_discipline_switches'].mean()),'screen_mean_light_discipline_switches':float(state['light_discipline_switches'].mean()),
      'screen_mean_heavy_friendly_risk':float(state['heavy_risk_sum'].sum()/max(1,state['heavy_risk_samples'].sum())),
      'screen_mean_light_friendly_risk':float(state['light_risk_sum'].sum()/max(1,state['light_risk_samples'].sum())),
      'screen_mean_first_fire_time_s':float(np.nanmean(state['first_fire_time'])) if np.isfinite(state['first_fire_time']).any() else math.nan,
    }
