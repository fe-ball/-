#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import sys
import numpy as np
R=Path(__file__).resolve().parent; sys.path.insert(0,str(R))
from sortie_regeneration_v118 import AirGroupState,_crew_cap_at,simulate_sortie_regeneration_dynamic
from carrier_damage_continuous_v118 import sample_damage_state,evaluate_service_capacities


def empty_state():
    return AirGroupState(
        ready={'F':0,'DB':0,'TB':0}, service={'F':0,'DB':0,'TB':0},
        returning={'F':[],'DB':[],'TB':[]}, damaged={'F':0,'DB':0,'TB':0},
        pilots={'F':0,'DB':0,'TB':0}, fuel_sorties={'F':20,'DB':20,'TB':20},
        ammo_sorties={'F':20,'DB':20,'TB':20}, pilot_fatigue_factor={'F':1,'DB':1,'TB':1},
        returning_damaged={'F':[],'DB':[],'TB':[]}, crew_manifest={'F':[],'DB':[],'TB':[]}
    )


def check_crew_return_gate():
    st=empty_state()
    st.crew_manifest['TB']=[{
        'crew_id':f'c{i}','status':'returning_clean','qualified':True,
        'qualifications':['carrier_day','torpedo_bomber'],'fatigue_factor':.90,
        'pilot_component':1.0,'eta_min':10.0+i,
    } for i in range(4)]
    rec=[(20.0+i,'TB',False) for i in range(4)]
    before=_crew_cap_at(st,'TB',27.0,rec,crew_rest_min=8.0)
    after=_crew_cap_at(st,'TB',35.0,rec,crew_rest_min=8.0)
    assert before[0]==0 and before[2]==0, before
    assert after[0]==3 and after[2]==4, after
    return {'before_cap':before[0],'after_cap':after[0],'after_headcount':after[2],'after_effective':after[1]}


def check_split_resource_stop():
    st=empty_state(); st.service['TB']=4; st.pilots['TB']=8
    t=np.arange(0,181,1,dtype=float); one=np.ones_like(t); zero=np.zeros_like(t)
    common=dict(profile_id='SHOKAKU_R30_WORK',timeline_min=t,launch_capacity_curve=one,
                recovery_capacity_curve=one,state=st,n=500,seed=118451,horizon_min=120,
                service_model='split')
    ok=simulate_sortie_regeneration_dynamic(**common,handling_capacity_curve=one,fuel_capacity_curve=one,
        ordnance_capacity_curve=one,maintenance_capacity_curve=one)
    stop=simulate_sortie_regeneration_dynamic(**common,handling_capacity_curve=one,fuel_capacity_curve=zero,
        ordnance_capacity_curve=one,maintenance_capacity_curve=one)
    ok_tb=float(np.median([r['ready_TB'] for r in ok])); stop_tb=float(np.median([r['ready_TB'] for r in stop]))
    assert ok_tb>0, ok_tb
    assert stop_tb==0, stop_tb
    return {'normal_ready_TB_p50':ok_tb,'fuel_standdown_ready_TB_p50':stop_tb}


def check_carrier_service_hazard_shape():
    s=sample_damage_state('TAIHO_R30_WORK',bomb_hits=1,torpedo_hits=1,n=4000,seed=118452)
    e0=evaluate_service_capacities(s,0.5); e6=evaluate_service_capacities(s,6.0)
    out={}
    for k in ('handling','fuel','ordnance','maintenance'):
        assert np.all((e0[k]>=0)&(e0[k]<=1)); assert np.all((e6[k]>=0)&(e6[k]<=1))
        out[k+'_mean_0p5h']=float(np.mean(e0[k])); out[k+'_mean_6h']=float(np.mean(e6[k]))
    # Hazard recovery should improve the hazardous resources in aggregate for this condition.
    assert out['fuel_mean_6h'] >= out['fuel_mean_0p5h'], out
    assert out['ordnance_mean_6h'] >= out['ordnance_mean_0p5h'], out
    return out

if __name__=='__main__':
    print({'crew':check_crew_return_gate(),'split':check_split_resource_stop(),'hazard':check_carrier_service_hazard_shape()})
