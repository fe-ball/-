from pathlib import Path
import sys,json,dataclasses
R=Path(__file__).parent;sys.path.insert(0,str(R))
import screen_ships_v114 as ss
import release_flight_v115 as rf
out=R.parent
sp={'model':'v0.11.4','note':'Working mission-model profiles. Effective AA channels/effects and screen formations are B-priors, not exact historical fits.',
    'classes':{k:dataclasses.asdict(v) for k,v in ss.SHIP_CLASSES.items()},
    'formations':{k:dataclasses.asdict(v) for k,v in ss.FORMATIONS.items()}}
(out/'screen_ship_profiles_v114.json').write_text(json.dumps(sp,ensure_ascii=False,indent=2),encoding='utf-8')
wp={'model':'v0.11.5','note':'Post-release flight working profiles. Error/reliability decomposition is sensitivity prior, not historical hit-rate calibration.',
    'bombs':{k:dataclasses.asdict(v) for k,v in rf.BOMBS.items()},
    'torpedoes':{k:dataclasses.asdict(v) for k,v in rf.TORPEDO_PRIORS.items()},
    'torpedo_release_range_sensitivity_m':[600,750,1000],
    'working_center_release_range_m':750,
    'target_ship':dataclasses.asdict(rf.ShipProfile())}
(out/'weapon_flight_profiles_v115.json').write_text(json.dumps(wp,ensure_ascii=False,indent=2),encoding='utf-8')
