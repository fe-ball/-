# MODEL NOTES v0.11.7

## Scope

Conditional carrier component/mission damage after already-resolved geometric bomb/torpedo hits. No historical sunk-per-hit fit.

## State variables
- flight deck repair/closure timer
- elevator outages
- hangar damage
- aviation-fuel / ordnance secondary risk
- fire severity
- flooding severity
- permanent + temporary speed loss
- steering capacity
- AA capacity
- catastrophic cascade flag

Outputs at 0/2/6/24 h.

## Mission classes
- FULL
- RESTRICTED
- LIMITED
- FLIGHT_DECK_CLOSED
- LOST

`mission_kill` in CSV = LOST + CLOSED + LIMITED. RESTRICTED remains combat-capable at degraded rate.

## Calibration constraints from r30

### Unryu line
A direct bomb may mission-kill flight operations without implying ship loss. Improved fire/fuel/DC architecture suppresses secondary catastrophe, not deck-crater physics.

### Taiho line
One torpedo center: immediate ~24–26 kt band, several hours flight-operation restriction, later limited/restricted recovery, very low probability of historical vapor-catastrophe chain under improved fuel isolation/ventilation doctrine.

## Numerical priors
All component probabilities and recovery time distributions are B-priors:
- bomb penetration / crater repair
- elevator area probability
- hangar fire / avgas / ordnance event probability
- machinery / steering hit probability
- torpedo flooding and speed-loss distributions
- AA degradation
- catastrophic cascade threshold

They are separated in code/profile and tested by sensitivity. Do not rewrite as historical measurements.

## DC sensitivity
`dc_scale` affects:
- fire decay
- flooding recovery component
- temporary speed-loss recovery
- steering recovery component
- safety stand-down duration
- weakly, deck clearing/patching
- catastrophic cascade probability

A sign error in the first draft made high DC recover more slowly; it was caught by automated sensitivity audit and corrected before v0.11.7 fixation.

## Limitations
- carrier internal geometry is component-level, not compartment-by-compartment 3D flooding
- bomb penetration depends on working deck resistance, not detailed striking velocity/armor calculation
- no bomb fuze/dud/underwater near-miss consequence
- no torpedo depth/warhead/bulkhead hydrodynamic finite-element model
- no crew casualty model
- no simultaneous repair-resource scheduling yet
- no aircraft parked-on-deck/hangar inventory state coupled to a specific deck cycle yet
- `LOST` is a severe/catastrophic state carrier, not a validated sinking probability curve

The next sortie-regeneration layer should consume launch/recovery capacity and repair state rather than binary sunk/not sunk.
