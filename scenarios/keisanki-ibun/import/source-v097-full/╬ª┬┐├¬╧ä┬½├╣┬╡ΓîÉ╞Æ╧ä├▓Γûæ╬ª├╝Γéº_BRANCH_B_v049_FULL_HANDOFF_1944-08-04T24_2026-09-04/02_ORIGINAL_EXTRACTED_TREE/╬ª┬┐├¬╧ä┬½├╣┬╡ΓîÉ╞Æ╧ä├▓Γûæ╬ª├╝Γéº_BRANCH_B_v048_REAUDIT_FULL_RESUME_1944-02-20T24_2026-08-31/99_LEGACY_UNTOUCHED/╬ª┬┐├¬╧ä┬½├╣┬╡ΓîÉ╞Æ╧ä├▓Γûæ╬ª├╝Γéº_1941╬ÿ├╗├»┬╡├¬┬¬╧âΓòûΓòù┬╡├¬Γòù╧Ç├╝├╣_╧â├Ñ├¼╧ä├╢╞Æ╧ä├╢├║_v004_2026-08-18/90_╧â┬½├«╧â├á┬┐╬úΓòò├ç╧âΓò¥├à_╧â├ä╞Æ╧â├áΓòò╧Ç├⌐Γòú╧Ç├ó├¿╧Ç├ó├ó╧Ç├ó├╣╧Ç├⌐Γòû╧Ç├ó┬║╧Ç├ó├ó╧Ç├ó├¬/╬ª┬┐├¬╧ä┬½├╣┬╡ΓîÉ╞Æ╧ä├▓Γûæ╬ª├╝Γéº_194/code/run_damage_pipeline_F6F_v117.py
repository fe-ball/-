#!/usr/bin/env python3
from pathlib import Path
import sys,json,csv
import numpy as np
R=Path(__file__).parent;sys.path.insert(0,str(R))
import air_microcombat_v116 as v
import release_flight_v117 as rf
import release_flight_v115 as rf115
import run_release_flight_v115 as rr115
from carrier_damage_v117 import simulate_conditional,PROFILES
from strike_damage_v102 import load_attack_types
from strike_response_v103 import RESP

def tbf_air(sep,lead,ntr=4,seed=117880):
 p,w,e,d=v.load_all(R);at=load_attack_types(R)['TBF1C'];pa=[p['JP06']]*8+[p['JP08']]*8;da=[d['JP06']]*8+[d['JP08']]*8
 axis=[-sep/2]*6+[sep/2]*6;leads=[0]*6+[lead]*6
 m=v.simulate_escort_cap(pa,p['US02'],da,d['US02'],w,e,ntr=ntr,seed=seed,max_cycles=76,package_run_lock_cycles=5,package_fire_substeps=5,return_trials=True,escort_aim_suppression=.55,package_max_passes_per_fighter=2,package_dynamic_formation=True,package_evasion_params=RESP['TBF1C'],package_warn_range_m=1100,package_online_damage=True,package_defense=at.defense,package_size_factor=at.size_factor,package_loss_feedback=True,package_rear_armament=at.rear_armament,package_rear_gunner_enabled=True,package_rear_gunner_feedback=True,global_ship_aa=True,package_attack_type=at,global_aa_enabled=True,global_ship_evasion_enabled=True,global_ship_evasion_policy='auto',global_aa_fire_discipline='center',global_screen_aa=True,global_screen_profile='akizuki2_yugumo2',global_screen_fire_discipline='center',global_screen_ship_motion=True,N=16,active_A=16,active_B=8,hA0=[4000]*8+[100]*8,hB0=900,iasA0=[400]*8+[320]*8,iasB0=400,A_layer_labels=['high']*8+['low']*8,A_initial_x_m=[-1000]*8+[-3100]*8,A_initial_y_m=list(v._default_centered_y(8))+list(v._default_centered_y(8)),package_alt_m=3000,package_speed_kmh=300,package_start_x=6200,package_target_x=-4500,package_vector_range_m=11500,package_terminal_profile='torpedo',package_terminal_alt_m=120,package_terminal_speed_kmh=280,package_transition_start_m=9000,package_transition_end_m=4500,package_weapon_release_range_m=750,package_member_axis_offsets_deg=axis,package_weapon_release_actual_ship_range=True,package_terminal_track_ship=True,package_terminal_track_start_m=4500,package_terminal_track_turn_deg_s=2.0,package_member_route_lead_m=leads)
 r=rf.simulate_torpedoes_anvil(m,separation_deg=0,seed=seed+191,prior='center',ship_policy='continue_turn')
 return m,r

def bomb_air(target,ntr=6,seed=117990):
 m=rr115.run_air(target,'US02',ntr,seed)
 r=rf115.simulate_bombs(m,target,seed=seed+811,profile=rr115.scaled_bomb_profile(target,1.0))
 return m,r

def expected_damage_from_counts(counts,weapon,profile,time_h,seedbase=118000):
 vals=[]
 cache={}
 for i,k in enumerate(counts):
  key=int(k)
  if key not in cache:
   b,t=(key,0) if weapon=='bomb' else (0,key)
   rows,_=simulate_conditional(profile,b,t,n=18000,seed=seedbase+key*101+hash(profile)%997)
   cache[key]=next(x for x in rows if x['time_h']==time_h)
  vals.append(cache[key])
 keys=['p_mission_kill','p_flight_deck_closed','p_lost','mean_launch_capacity','mean_recovery_capacity','median_speed_kn','mean_AA_capacity']
 return {k:float(np.mean([v[k] for v in vals])) for k in keys}

def main():
 cases=[]
 # Bomb benchmarks
 for target in ['SBD5','SB2C1C']:
  _,r=bomb_air(target,6,seed=117990+(0 if target=='SBD5' else 5000));counts=np.asarray(r['trial_hits'],bool).sum(axis=1)
  cases.append((target+'_F6F','bomb',counts,float(r['mean_hits_per_wave'])))
 # TBF structural cases
 for sep,lead,label in [(0,0,'TBF_single0'),(30,550,'TBF_sync30'),(60,700,'TBF_sync60'),(90,700,'TBF_sync90')]:
  _,r=tbf_air(sep,lead,4,seed=11699017);counts=np.asarray(r['trial_hits'],bool).sum(axis=1)
  cases.append((label,'torp',counts,float(r['mean_hits_per_wave'])))
 rows=[]
 raw=[]
 for ci,(case,weap,counts,mean_hits) in enumerate(cases):
  raw.append({'case':case,'weapon':weap,'trial_hit_counts':counts.tolist(),'mean_hits':mean_hits})
  for pid in PROFILES:
   for tm in [0.0,6.0,24.0]:
    x=expected_damage_from_counts(counts,weap,pid,tm,seedbase=118000+ci*5000)
    rows.append({'case':case,'weapon':weap,'carrier_profile':pid,'time_h':tm,'air_trials':len(counts),'mean_weapon_hits':float(np.mean(counts)),**x})
 out=R.parent/'results_current';
 with open(out/'air_to_carrier_mission_F6F_v117.csv','w',newline='',encoding='utf-8') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 (out/'air_to_carrier_mission_F6F_hitcounts_v117.json').write_text(json.dumps(raw,indent=2),encoding='utf-8')
 print(json.dumps(raw,indent=2));print('rows',len(rows))
if __name__=='__main__':main()
