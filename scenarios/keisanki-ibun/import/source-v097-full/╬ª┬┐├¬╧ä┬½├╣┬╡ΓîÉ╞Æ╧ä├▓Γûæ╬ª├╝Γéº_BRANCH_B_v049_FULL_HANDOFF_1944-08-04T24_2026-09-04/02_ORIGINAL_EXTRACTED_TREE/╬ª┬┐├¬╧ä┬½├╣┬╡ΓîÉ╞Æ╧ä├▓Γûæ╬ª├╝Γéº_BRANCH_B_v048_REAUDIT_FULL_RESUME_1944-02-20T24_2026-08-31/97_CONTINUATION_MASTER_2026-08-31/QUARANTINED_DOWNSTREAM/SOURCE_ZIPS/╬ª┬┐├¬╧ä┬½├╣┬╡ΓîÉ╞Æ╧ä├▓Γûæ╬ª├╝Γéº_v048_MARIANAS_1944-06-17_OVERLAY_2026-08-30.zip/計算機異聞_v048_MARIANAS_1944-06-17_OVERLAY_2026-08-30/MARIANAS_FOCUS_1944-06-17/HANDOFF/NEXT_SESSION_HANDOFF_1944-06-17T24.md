# NEXT SESSION HANDOFF — v048 Branch B — 1944-06-17T24

## Authoritative resume point

Load canonical v048 + continuation overlays through 028, then the 1944-06-16 overlay, then this 1944-06-17 overlay. Current global frontier: **1944-06-17T24**. Primary theater: **Marianas / Saipan / Philippine Sea**.

## Critical state

The 16/17 Jun bounded Saipan counterattack is closed. It fails to rupture the US lodgment but does not liquidate the 9th Tank Regiment: end-17 Jun armor remains roughly **35-43 ready + 7-11 short repair**. Aslito is entered/approached on selected axes but remains **contested and not secure**.

The Mobile Fleet uses the Kongo-class four-ship layer as a **carrier-battle fast vanguard**, not a detached Saipan dash. Kongo/Haruna/Hiei/Kirishima with Takao-class cruisers and a deep DD screen run roughly tens of miles ahead of the five-carrier core. This both exposes a conspicuous surface cue to US scouts and provides early warning/air-attack dilution for the carriers.

At dawn 17 Jun Japan wins the actionable carrier-fix race by minutes. A 242-258-aircraft five-carrier first wave launches about 07:00-07:30, followed by an 88-108-aircraft limited second-echelon wave. TF58 first finds the Kongo vanguard and then the carrier core, launching a 292-326-aircraft counterstrike while retaining heavy CAP.

The result is a true carrier exchange, not a historical turkey shoot. Japanese raids heavy-mission-kill one US CVL, medium-damage one CV and lightly interrupt another deck centered, with no fast-carrier sinking centered. The US counterstrike heavily mission-kills **Taiho** and damages two other first-line decks; Taiho survives T24 because flooding/fuel-vapor handling does not replay the historical catastrophic damage-control chain. No Japanese carrier sinking is centered on 17 Jun.

Day irreversible aircraft losses: Japan roughly **138-174**, US roughly **78-102**. This is a US strategic exchange advantage due to deck/replacement depth, but Japan retains credible carrier, surface and secondary-deck power for 18 Jun.

No independent Kongo night attack is released after the exchange. TF58 remains coherent, Japan has damaged carriers to cover, and the US fast-battleship screen remains formidable.

## Next exact step

Advance **1944-06-18**. First close Taiho and other carrier damage/repair clocks plus US damaged-deck recovery. Then run dawn search from the Japanese west-southwest withdrawal geometry behind the Kongo vanguard. The central gate is whether TF58 reacquires the carrier center early enough for a second major strike, or whether Yamamoto can break contact and preserve the remaining air groups/secondary carriers for a controlled continuation or withdrawal.
