# Branch B handoff — 1944-06-19T24

Current frontier: 1944-06-19T24, Marianas.

Load after the 17-Jun re-audit + 18-Jun overlay.

19 Jun key results:
- Japan completes rolling replenishment and does **not** yet close the decisive-battle option.
- Taiho returns only limited recovery/ferry/CAP capability; no normal synchronized strike cycle.
- Japanese pooled mobile air at T24: roughly 338-394 immediate ready; practical coherent major strike 198-236 if a fresh fix/geometry opens.
- TF58 performs staggered replenishment. A conventional I-boat cues Ko-3 onto a fleet-oiler group; one US oiler is mission-killed but afloat. One/more TG refuel cycles slip about 5-8h; no US fuel crisis.
- Ko-3 is medium-damaged by ASW and is ineffective for roughly 48-72h.
- No 19-Jun carrier mass strike by either side; no fresh weapon-quality enemy carrier-center fix in time.
- Yamamoto stops extending the withdrawal after refuel and keeps a 20-Jun re-engagement gate open, but does not charge east on an oiler report alone.
- Aslito is physically held/engineerable by the US but is not yet a routine high-output shore fighter base.
- Marianas water aviation remains 8-13 ready and continues ISR/attention-tax work.

Next: 20 Jun mutual search/re-engagement gate. If no fresh Japanese carrier fix opens by midday, decide whether Yamamoto closes the main fleet-battle phase.
