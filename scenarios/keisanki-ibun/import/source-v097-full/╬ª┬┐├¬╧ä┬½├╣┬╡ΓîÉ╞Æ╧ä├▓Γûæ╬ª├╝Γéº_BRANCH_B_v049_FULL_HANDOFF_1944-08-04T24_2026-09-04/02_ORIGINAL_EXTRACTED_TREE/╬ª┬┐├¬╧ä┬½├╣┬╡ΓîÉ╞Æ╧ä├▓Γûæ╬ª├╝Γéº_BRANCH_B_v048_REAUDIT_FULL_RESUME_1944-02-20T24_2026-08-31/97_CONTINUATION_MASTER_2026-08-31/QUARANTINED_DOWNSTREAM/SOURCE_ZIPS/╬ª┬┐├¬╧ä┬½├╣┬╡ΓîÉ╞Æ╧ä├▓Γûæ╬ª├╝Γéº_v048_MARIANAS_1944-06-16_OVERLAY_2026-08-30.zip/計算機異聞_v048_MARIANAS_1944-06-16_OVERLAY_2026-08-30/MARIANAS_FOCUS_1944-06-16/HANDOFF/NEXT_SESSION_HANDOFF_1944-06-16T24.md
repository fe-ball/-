# NEXT SESSION HANDOFF — v048 Branch B — 1944-06-16T24

## Authoritative resume point

Load canonical v048 + continuation overlays through 028, then this 1944-06-16 overlay. Current global frontier: **1944-06-16T24**. Primary theater: **Marianas / Saipan / Philippine Sea**.

## Critical state

The Saipan lodgment has deepened but Aslito is not secure. Japanese armor remains much healthier than the old settlement assumed. Saito's 16/17 Jun counterattack order is obeyed in **bounded** form: 20-24 tanks are selected for the first night wave, with a substantial reserve retained. The attack began before midnight and is still in progress at T24; do not pre-book its full losses.

TF58 has all sixteen fast decks back inside the broader support geometry after the northern four-deck group returns, but simultaneous-task load means only about 12-14 decks are immediately high-output at end-day. US submarines reconfirm Japanese eastward closure but do not provide a fresh carrier-center fix.

The Japanese Mobile Fleet completes rolling refuel, advances to roughly 370-510 nmi WSW of Saipan, and remains around 350-374 ready aircraft in the five-carrier core. Sixth Fleet + Marianas land recon + Mobile Fleet scout fusion produces the first genuinely good visual fix on one TF58 task group in the afternoon. **No strike is launched on 16 Jun** because the fix arrives late at a 430-510 nmi launch range, making fuel/payload and night-recovery risk unacceptable. Contact is not maintained through dusk.

The old legacy 16/17 Jun fast-battleship dash to Saipan is **not valid** in the current geometry and must not be replayed.

## Next exact step

Advance **1944-06-17**. First finish the night ground counterattack and tank-loss/recovery ledger. Then at dawn run mutual carrier search from the shortened geometry. The central decision gate is whether a fresh visual/submarine/land-air cue overlaps practical strike range early enough for a coordinated carrier launch.
