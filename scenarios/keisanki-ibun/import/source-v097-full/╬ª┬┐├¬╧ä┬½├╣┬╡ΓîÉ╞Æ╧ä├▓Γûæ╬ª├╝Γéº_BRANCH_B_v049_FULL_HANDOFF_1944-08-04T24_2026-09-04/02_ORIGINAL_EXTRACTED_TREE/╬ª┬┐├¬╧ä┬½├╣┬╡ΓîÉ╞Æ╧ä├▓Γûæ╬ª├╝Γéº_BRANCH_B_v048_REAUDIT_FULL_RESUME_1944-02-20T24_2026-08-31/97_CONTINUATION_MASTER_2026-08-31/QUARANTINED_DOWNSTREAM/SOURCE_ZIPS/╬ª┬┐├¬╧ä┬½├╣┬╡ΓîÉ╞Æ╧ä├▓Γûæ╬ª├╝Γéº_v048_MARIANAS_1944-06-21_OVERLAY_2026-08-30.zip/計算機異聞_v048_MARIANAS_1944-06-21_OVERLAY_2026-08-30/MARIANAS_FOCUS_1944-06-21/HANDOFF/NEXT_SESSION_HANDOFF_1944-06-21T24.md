# Branch B handoff — 1944-06-21T24

Current frontier: **1944-06-21T24, Marianas.**

## 21 Jun key results

- The immediate carrier battle remains closed. The Japanese Mobile Fleet continues a protected west-southwest withdrawal toward the central-Philippines replenishment/repair system; no 21-Jun turnback is generated without a new exceptional trigger.
- Kongo/Haruna/Hiei/Kirishima serve as eastern cover/rearguard early and then fold back toward the normal screen as US pursuit fails to develop. Yamato/Musashi/Nagato remain with heavy support.
- Japanese pooled mobile air improves by reorganization rather than replacement: **351-411 immediate ready**, with **220-260** practical coherent major-strike capacity. Taiho can conduct routine bounded recovery/CAP/recon and a small package but is still not a veteran synchronized first-line strike deck.
- TF58 confirms continued withdrawal, retains **14-15 high-output fast decks** and about **820-938 ready aircraft**, and shifts effort toward Saipan cover and suppression rather than deep western pursuit.
- Ledger correction: runway-based Marianas aviation did not vanish after 17 Jun. End-21 Jun runway ready is **18-27**, mainly Tinian/Guam/Rota-Pagan/dispersed strips; water aviation is **5-8 ready**. Saipan runway combat generation itself is nearly extinguished.
- Aslito runway is physically capable of test/emergency/limited ferry use, but routine resident fighter operations are not yet centered. Earliest small shore-fighter detachment gate is late 22 Jun; **23 Jun is the centered routine-operation date** if security/fuel/maintenance hold.
- Saipan armor ends at roughly **20-28 ready + 4-7 short repair**. US pressure begins to transition from the southern lodgment toward the central high ground while a substantial force remains tied to Nafutan/southern cleanup.
- No centered carrier/battleship/oiler submarine hit on 21 Jun.

## Next

22 Jun: process Japanese protected anchorage/replenishment and Taiho inspection; normalize pooled carrier air groups; open the Aslito shore-fighter gate; continue Nafutan/central-ridge fighting; maintain Tinian/Guam runway-air and water-air suppression as separate mission layers; begin reassessing Guam/Tinian assault timing without mechanically copying history.
