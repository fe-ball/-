# Branch B handoff — 1944-06-20T24

Current frontier: 1944-06-20T24, Marianas.

20 Jun key results:
- Japanese expanded dawn ISR **does find TF58**. By about 08:00 it is clear that multiple fast-carrier TGs are again concentrated and the vulnerable 19-Jun peak-refuel geometry has expired.
- Decision range is roughly 390-455 nm from the principal Japanese offensive decks. A renewed strike would require either a thin extreme-range launch or further eastward closure that also improves US reciprocal search/strike geometry.
- Yamamoto therefore closes the immediate FORAGER fleet-battle phase around 09:00 and begins protected west-southwest withdrawal. This is a search-informed NO-GO, not a failure to locate the enemy.
- Japanese mobile-air pool at T24: roughly 344-400 immediate ready; coherent major-strike capacity about 208-244. Taiho has bounded flight operations but is still not a normal synchronized strike deck.
- US search later regains the Kongo/heavy-screen axis and then the carrier center, but only at roughly 445-520 nm with the Japanese already opening range. No historical-style 20-Jun late long-range mass strike is replayed.
- TF58 ends the day with roughly 14-15 high-output fast decks and 814-932 ready aircraft.
- No centered 20-Jun capital-ship/oiler torpedo hit. Ko-3 remains temporarily combat-unavailable.
- Saipan: Aslito has a substantially continuous local US security perimeter and sustained engineer access; emergency individual recovery is possible, routine high-output resident fighter operations are not yet centered.
- Japanese armor: roughly 22-30 ready + 5-8 short repair.
- Marianas water aviation: roughly 6-10 ready, still imposing ISR/attention-tax work.

Strategic meaning:
The immediate carrier-decision window closes as a US operational victory because Saipan remains covered and the invasion is not broken. Japan, however, preserves a substantial carrier air pool, carrier hulls, Kongo vanguard and the Yamato/Musashi/Nagato heavy force rather than suffering a historical-style carrier-air annihilation.

Next:
21 Jun protected withdrawal / air-group reorganization; US pursuit-versus-consolidation choice; Aslito security and counterattack gate; continued submarine/logistics harassment.
