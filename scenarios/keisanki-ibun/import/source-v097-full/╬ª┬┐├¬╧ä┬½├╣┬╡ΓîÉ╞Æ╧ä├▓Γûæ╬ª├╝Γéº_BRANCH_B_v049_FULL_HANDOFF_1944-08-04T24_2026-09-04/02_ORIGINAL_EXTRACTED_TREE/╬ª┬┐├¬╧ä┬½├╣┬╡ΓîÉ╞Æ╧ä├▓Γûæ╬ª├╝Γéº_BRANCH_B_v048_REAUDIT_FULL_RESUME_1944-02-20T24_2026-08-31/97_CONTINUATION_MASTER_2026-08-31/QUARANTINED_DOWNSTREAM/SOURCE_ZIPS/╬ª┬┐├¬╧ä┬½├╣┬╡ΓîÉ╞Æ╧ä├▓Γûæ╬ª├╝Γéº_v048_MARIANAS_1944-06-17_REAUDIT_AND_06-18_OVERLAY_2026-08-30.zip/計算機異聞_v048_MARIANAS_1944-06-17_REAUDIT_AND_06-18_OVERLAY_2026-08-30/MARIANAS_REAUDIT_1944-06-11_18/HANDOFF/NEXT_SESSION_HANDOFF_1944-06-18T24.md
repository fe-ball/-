# Branch B handoff — 1944-06-18T24

Current frontier: 1944-06-18T24, Marianas.

Load this overlay after the original 1944-06-17 overlay. The v002 17-Jun exchange/state supersede the corresponding v001 records only where stated.

Key re-audit:
- Marianas water aviation is a separate mission system. It survives runway suppression in diminished form and imposes an ongoing US search/escort/suppression attention tax.
- The six secondary Japanese carriers are not a single weak strike group. They form a second-strike nucleus, Ryujo swing deck, and rear CAP/recovery bank.
- Cross-deck recovery reduces Japanese 17-Jun recovery/ditch losses. Taiho hull mission-kill does not auto-destroy its airborne air group.
- Revised 17-Jun Japanese irrecoverable aircraft: 120-154; US: 82-108.
- Revised Japanese mobile-air T24: 302-354 immediate ready, 24-40 cross-deck reorganization, 18-30 short repair.

18 Jun:
- No second major carrier exchange centered.
- Spruance protects Saipan and does not pursue deeply west without a fresh carrier-center fix.
- Yamamoto performs a controlled west-southwest reset while retaining a return-strike option.
- Taiho remains non-offensive but stable; limited recovery/ferry use may return late.
- Aslito is denied to Japan and substantially occupied, but not yet a secure high-output US air base.

Next: 19 Jun carrier-search/refuel decision, Taiho deck recovery, cross-deck air-group reformation, Aslito operationalization.
